"""Offline safety checks. No real MySQL command or database is used."""
import argparse
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import local_mysql as tool


class LocalMysqlTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.mysql = self.root / "mysql.exe"
        self.mysql.write_bytes(b"test-only")
        self.private = self.root / "private"
        self.private.mkdir()
        self.config = self.private / "connection-private.json"
        self.patches = [
            patch.object(tool, "PRIVATE", self.private),
            patch.object(tool, "CONFIG", self.config),
            patch.object(tool, "private_directory", lambda: None),
        ]
        for item in self.patches:
            item.start()
            self.addCleanup(item.stop)
        self.addCleanup(self.temporary.cleanup)

    def args(self):
        password = self.root / "admin-password.txt"
        password.write_text("admin-only-do-not-store", encoding="utf-8")
        return argparse.Namespace(mysql=self.mysql, port=3306, admin_user="root",
                                  admin_password_file=password)

    def test_refuses_existing_schema_before_any_ddl(self):
        queries = []
        def query(client, sql):
            queries.append(sql)
            if sql.startswith("SELECT VERSION"):
                return "8.0.45\t3306\tMySQL Community Server - GPL"
            return "1" if "schemata" in sql else "0"
        with patch.object(tool.Mysql, "query", query):
            with self.assertRaisesRegex(tool.SetupError, "refusing overwrite"):
                tool.initialize(self.args())
        self.assertTrue(all(sql.startswith("SELECT ") for sql in queries))
        self.assertFalse(self.config.exists())

    def test_refuses_existing_account_before_any_ddl(self):
        queries = []
        def query(client, sql):
            queries.append(sql)
            if sql.startswith("SELECT VERSION"):
                return "8.0.45\t3306\tMySQL Community Server - GPL"
            return "1" if "mysql.user" in sql else "0"
        with patch.object(tool.Mysql, "query", query):
            with self.assertRaises(tool.SetupError):
                tool.initialize(self.args())
        self.assertTrue(all(sql.startswith("SELECT ") for sql in queries))

    def test_refuses_mysql84_before_any_create(self):
        with patch.object(tool.Mysql, "query", return_value="8.4.11\t3306\tMySQL Community Server - GPL") as query:
            with self.assertRaisesRegex(tool.SetupError, "MySQL 8.0"):
                tool.initialize(self.args())
        self.assertEqual(query.call_count, 1)

    def test_success_uses_new_schema_scoped_grants_and_does_not_store_root_password(self):
        queries = []
        def query(client, sql):
            queries.append(sql)
            if sql.startswith("SELECT VERSION"):
                return "8.0.45\t3306\tMySQL Community Server - GPL"
            return "0" if sql.startswith("SELECT ") else ""
        with patch.object(tool.Mysql, "query", query):
            tool.initialize(self.args())
        data = json.loads(self.config.read_text(encoding="utf-8"))
        self.assertNotIn("admin-only-do-not-store", self.config.read_text(encoding="utf-8"))
        self.assertEqual(data["database"], "roomly_local80")
        self.assertEqual(data["user"], "roomly_local80")
        self.assertGreaterEqual(len(data["password"]), 40)
        for pattern in (r"[a-z]", r"[A-Z]", r"[0-9]", r"[^A-Za-z0-9]"):
            self.assertRegex(data["password"], pattern)
        ddl = next(sql for sql in queries if sql.startswith("CREATE "))
        self.assertIn("ON roomly_local80.*", ddl)
        self.assertNotIn("ON *.*", ddl)
        self.assertNotIn("DROP ", ddl)
        self.assertNotIn("ALTER ", ddl)
        self.assertNotIn("DELETE ", ddl)

    def test_repeat_init_checks_connection_without_create_or_password_prompt(self):
        self.config.write_text(json.dumps({"database": "roomly_local80", "user": "roomly_local80",
                                          "host": "127.0.0.1", "port": 3306, "mysql": str(self.mysql),
                                          "password": "app-only"}), encoding="utf-8")
        with patch.object(tool.Mysql, "query", return_value="8.0.45\t3306\tMySQL Community Server - GPL") as query:
            with patch.object(tool.getpass, "getpass", side_effect=AssertionError("No prompt expected")):
                tool.initialize(self.args())
        self.assertEqual(query.call_count, 1)
        self.assertTrue(query.call_args.args[0].startswith("SELECT VERSION"))

    def test_mysql_password_not_in_argv_and_temporary_file_removed(self):
        observed = []
        secret = 'private"pass\\word'
        def run(command, **kwargs):
            self.assertFalse(any(secret in part for part in command))
            options = Path(command[1].split("=", 1)[1])
            self.assertIn(tool.option_value(secret), options.read_text(encoding="utf-8"))
            observed.append(options)
            return subprocess.CompletedProcess(command, 0, "8.0.45", "")
        with patch.object(tool.subprocess, "run", side_effect=run):
            self.assertEqual(tool.Mysql(self.mysql, 3306, "root", secret).query("SELECT VERSION();"), "8.0.45")
        self.assertTrue(observed)
        self.assertTrue(all(not path.exists() for path in observed))

    def test_mysql_failure_hides_remote_output_and_secret(self):
        with patch.object(tool.subprocess, "run", return_value=subprocess.CompletedProcess(
                [], 1, "password-secret", "SQL includes password-secret")):
            with self.assertRaises(tool.SetupError) as failure:
                tool.Mysql(self.mysql, 3306, "root", "password-secret").query("SELECT VERSION();")
        self.assertNotIn("password-secret", str(failure.exception))
        self.assertFalse(list(self.private.glob("mysql-client-*.cnf")))

    def test_option_password_rejects_control_characters(self):
        for secret in ("line\npassword=x", "pass\rword", "nul\x00byte"):
            with self.subTest(secret=repr(secret)):
                with self.assertRaises(tool.SetupError):
                    tool.option_value(secret)

    def test_config_cannot_target_another_database_or_host(self):
        for field, value in (("database", "homely"), ("user", "root"), ("host", "example.com")):
            data = {"database": "roomly_local80", "user": "roomly_local80", "host": "127.0.0.1"}
            data[field] = value
            self.config.write_text(json.dumps(data), encoding="utf-8")
            with self.subTest(field=field):
                with self.assertRaises(tool.SetupError):
                    tool.load_config()

    def test_config_access_denied_is_not_reported_as_missing(self):
        with patch.object(Path, "read_text", side_effect=PermissionError("private")):
            with self.assertRaisesRegex(tool.SetupError, "Cannot read the private configuration"):
                tool.load_config()

    def test_init_does_not_prompt_or_query_if_config_access_is_denied(self):
        with patch.object(Path, "stat", side_effect=PermissionError("private")):
            with patch.object(tool.Mysql, "query") as query:
                with patch.object(tool.getpass, "getpass") as prompt:
                    with self.assertRaisesRegex(tool.SetupError, "no database operation"):
                        tool.initialize(argparse.Namespace())
        query.assert_not_called()
        prompt.assert_not_called()

    def compact_fixture(self):
        artifacts = self.root / "artifacts"
        artifacts.mkdir()
        migration = self.root / "backend/src/main/resources/db/migration/V19__compact_fourteen_table_schema.sql"
        migration.parent.mkdir(parents=True)
        migration.write_bytes(b"reviewed migration")
        jar = self.root / "backend.jar"
        jar.write_bytes(b"tested backend")
        backup = self.private / "before-schema14-test"
        backup.mkdir()
        dump = backup / "database.sql"
        dump.write_bytes(b"verified backup")
        manifest = {"pass": True, "database": tool.DATABASE,
                    "database_sql_sha256": hashlib.sha256(dump.read_bytes()).hexdigest(),
                    "tables": {"users": 0, "roles": 3, "amenities": 15}}
        report = {"pass": True,
                  "migration_sha256": hashlib.sha256(migration.read_bytes()).hexdigest(),
                  "backend_jar_sha256": hashlib.sha256(jar.read_bytes()).hexdigest()}
        for name, value in ((backup / "manifest.json", manifest),
                            (artifacts / "schema14-tests-test.json", report)):
            name.write_text(json.dumps(value), encoding="utf-8")
        for name, value in (("ROOT", self.root), ("ARTIFACTS", artifacts), ("JAR", jar)):
            item = patch.object(tool, name, value)
            item.start()
            self.addCleanup(item.stop)
        return backup, migration, jar

    def test_compact_requires_backup_and_native_test_report(self):
        with patch.object(tool, "ARTIFACTS", self.root / "missing"), patch.object(tool, "schema") as schema:
            with self.assertRaisesRegex(tool.SetupError, "verified backup"):
                tool.compact_schema(self.args())
        schema.assert_not_called()

    def test_compact_refuses_tampered_backup(self):
        backup, _, _ = self.compact_fixture()
        (backup / "database.sql").write_bytes(b"changed")
        with patch.object(tool, "schema") as schema:
            with self.assertRaisesRegex(tool.SetupError, "checksum mismatch"):
                tool.compact_schema(self.args())
        schema.assert_not_called()

    def test_compact_refuses_backup_containing_business_data(self):
        backup, _, _ = self.compact_fixture()
        manifest = backup / "manifest.json"
        data = json.loads(manifest.read_text(encoding="utf-8"))
        data["tables"]["users"] = 1
        manifest.write_text(json.dumps(data), encoding="utf-8")
        with patch.object(tool, "schema") as schema:
            with self.assertRaisesRegex(tool.SetupError, "business data"):
                tool.compact_schema(self.args())
        schema.assert_not_called()

    def test_compact_requires_exact_tested_migration_and_jar(self):
        _, migration, jar = self.compact_fixture()
        for artifact in (migration, jar):
            original = artifact.read_bytes()
            artifact.write_bytes(b"untested change")
            with self.subTest(artifact=artifact.name), patch.object(tool, "schema") as schema:
                with self.assertRaisesRegex(tool.SetupError, "isolated native tests"):
                    tool.compact_schema(self.args())
                schema.assert_not_called()
            artifact.write_bytes(original)

    def test_compact_accepts_verified_empty_backup_and_tested_artifacts(self):
        self.compact_fixture()
        args = self.args()
        with patch.object(tool, "schema") as schema:
            tool.compact_schema(args)
        schema.assert_called_once_with(args, "compact")


if __name__ == "__main__":
    unittest.main()
