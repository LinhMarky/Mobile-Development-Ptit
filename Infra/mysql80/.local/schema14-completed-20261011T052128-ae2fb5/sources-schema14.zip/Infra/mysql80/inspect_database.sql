-- Read-only queries for MySQL Workbench 8.0 CE.
-- Connection: Standard TCP/IP, 127.0.0.1:3306, schema roomly_local80.
USE roomly_local80;

SELECT VERSION() AS mysql_version, DATABASE() AS current_database,
       CURRENT_USER() AS authenticated_account, @@port AS mysql_port;

SELECT version, description, type, success
FROM flyway_schema_history
ORDER BY installed_rank;

SELECT table_name, engine, table_collation
FROM information_schema.tables
WHERE table_schema = DATABASE()
ORDER BY table_name;

-- V19: 13 application tables + Flyway = 14 base tables, no compatibility views.
SELECT COUNT(*) AS physical_tables, 14 AS expected_tables
FROM information_schema.tables
WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE';

-- Concrete entity types sharing physical storage.
SELECT 'account_records' AS physical_table, record_type, COUNT(*) AS records
FROM account_records GROUP BY record_type
UNION ALL
SELECT 'catalog_items', record_type, COUNT(*) FROM catalog_items GROUP BY record_type
UNION ALL
SELECT 'rental_records', record_type, COUNT(*) FROM rental_records GROUP BY record_type
UNION ALL
SELECT 'activity_records', record_type, COUNT(*) FROM activity_records GROUP BY record_type;

SELECT table_name, column_name, referenced_table_name, referenced_column_name
FROM information_schema.key_column_usage
WHERE table_schema = DATABASE() AND referenced_table_name IS NOT NULL
ORDER BY table_name, ordinal_position;
