"""Native MySQL 8.0 setup in a new schema; no app source regeneration or database reset."""
import argparse
import base64
from contextlib import contextmanager
from datetime import datetime, timezone
import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import socket
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PRIVATE = HERE / ".local"
ARTIFACTS = ROOT / "backend/target/local-mysql80"
CONFIG = PRIVATE / "connection-private.json"
DATABASE = USER = "roomly_local80"
MYSQL_DEFAULT = Path("C:/Program Files/MySQL/MySQL Server 8.0/bin/mysql.exe")
JAVA_DEFAULT = Path("C:/Program Files/Java/jdk-17")
JAR = ROOT / "backend/target/rental-0.0.1-SNAPSHOT.jar"


class SetupError(ValueError):
    """Messages are safe to display and never include credentials/SQL."""


def stamp():
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + secrets.token_hex(3)


def private_directory():
    PRIVATE.mkdir(parents=True, exist_ok=True)
    if os.name == "nt":
        identity = subprocess.run(
            ["powershell.exe", "-NoProfile", "-Command",
             "[Security.Principal.WindowsIdentity]::GetCurrent().User.Value"],
            capture_output=True, text=True, check=False)
        sid = identity.stdout.strip()
        if identity.returncode or not re.fullmatch(r"S-\d+(?:-\d+)+", sid):
            raise SetupError("Cannot determine the Windows account for private file permissions")
        acl = subprocess.run(["icacls", str(PRIVATE), "/inheritance:r",
                              "/grant:r", "*" + sid + ":(OI)(CI)F"], capture_output=True, check=False)
        if acl.returncode:
            raise SetupError("Cannot protect the local credential folder")
    else:
        PRIVATE.chmod(0o700)


def option_value(value):
    if any(ord(char) < 32 for char in value):
        raise SetupError("MySQL password cannot contain control characters")
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


@contextmanager
def password_file(password):
    private_directory()
    descriptor, name = tempfile.mkstemp(prefix="mysql-client-", suffix=".cnf", dir=PRIVATE)
    path = Path(name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
            stream.write("[client]\npassword=" + option_value(password) + "\n")
        path.chmod(0o600)
        yield path
    finally:
        if path.parent == PRIVATE and path.name.startswith("mysql-client-"):
            path.unlink(missing_ok=True)


class Mysql:
    def __init__(self, executable, port, username, password):
        self.executable = Path(executable)
        self.port = int(port)
        self.username = username
        self.password = password
        if not self.executable.is_file() or not 1 <= self.port <= 65535:
            raise SetupError("MySQL client missing or invalid port")
        if not re.fullmatch(r"[A-Za-z0-9_]{1,32}", username):
            raise SetupError("Invalid MySQL username")

    def query(self, sql):
        with password_file(self.password) as options:
            result = subprocess.run(
                [str(self.executable), "--defaults-file=" + str(options), "--protocol=TCP",
                 "--host=127.0.0.1", "--port=" + str(self.port), "--user=" + self.username,
                 "--connect-timeout=5", "--batch", "--raw", "--skip-column-names",
                 "--default-character-set=utf8mb4"],
                input=sql, capture_output=True, text=True, encoding="utf-8",
                errors="replace", timeout=30, check=False)
        if result.returncode:
            raise SetupError("MySQL rejected the connection/query; check username, password, port and privileges")
        return result.stdout.strip()

    def check_server(self):
        row = self.query("SELECT VERSION(), @@port, @@version_comment;").split("\t")
        if len(row) != 3 or not re.fullmatch(r"8\.0\.\d+.*", row[0]) or int(row[1]) != self.port:
            raise SetupError("Expected native MySQL 8.0 on the chosen loopback port")
        if "mysql" not in row[2].lower():
            raise SetupError("The selected server is not MySQL")
        return row[0]


def load_config():
    try:
        content = CONFIG.read_text(encoding="utf-8")
    except FileNotFoundError:
        raise SetupError("Run init in a local terminal to enter the administrator password") from None
    except PermissionError:
        raise SetupError("Cannot read the private configuration; run as the Windows account that performed setup") from None
    config = json.loads(content)
    if (config.get("database"), config.get("user"), config.get("host")) != (DATABASE, USER, "127.0.0.1"):
        raise SetupError("Unexpected local database configuration; nothing changed")
    return config


def initialize(args):
    try:
        CONFIG.stat()
        configured = True
    except FileNotFoundError:
        configured = False
    except PermissionError:
        raise SetupError("Cannot read the private configuration; no database operation performed") from None
    if configured:
        config = load_config()
        version = Mysql(config["mysql"], config["port"], USER, config["password"]).check_server()
        print("Already configured: MySQL " + version + ", " + DATABASE + "; no CREATE/ALTER performed.")
        return
    private_directory()
    if args.admin_password_file:
        password = Path(args.admin_password_file).resolve(strict=True).read_text(
            encoding="utf-8-sig").rstrip("\r\n")
    else:
        if not sys.stdin.isatty():
            raise SetupError("Open the local interactive terminal to enter the password")
        password = getpass.getpass("MySQL administrator password (hidden, never stored): ")
    admin = Mysql(args.mysql, args.port, args.admin_user, password)
    version = admin.check_server()
    database_exists = admin.query("SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name='roomly_local80';")
    user_exists = admin.query("SELECT COUNT(*) FROM mysql.user WHERE User='roomly_local80';")
    if database_exists != "0" or user_exists != "0":
        raise SetupError("roomly_local80 schema/account already exists; refusing overwrite. Choose a reviewed recovery.")
    # Satisfy common MySQL password policies; all characters are SQL-literal safe.
    app_password = "Aa9!" + secrets.token_urlsafe(36)
    admin.query(
        "CREATE DATABASE roomly_local80 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\n"
        f"CREATE USER 'roomly_local80'@'localhost' IDENTIFIED BY '{app_password}';\n"
        f"CREATE USER 'roomly_local80'@'127.0.0.1' IDENTIFIED BY '{app_password}';\n"
        "GRANT ALL PRIVILEGES ON roomly_local80.* TO 'roomly_local80'@'localhost';\n"
        "GRANT ALL PRIVILEGES ON roomly_local80.* TO 'roomly_local80'@'127.0.0.1';\n")
    config = {"host": "127.0.0.1", "port": int(args.port), "database": DATABASE, "user": USER,
              "password": app_password, "jwt_secret": base64.b64encode(secrets.token_bytes(64)).decode("ascii"),
              "mysql": str(Path(args.mysql).resolve()), "created_at_utc": datetime.now(timezone.utc).isoformat()}
    with CONFIG.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(config, stream, indent=2)
        stream.write("\n")
    CONFIG.chmod(0o600)
    Mysql(config["mysql"], config["port"], USER, app_password).check_server()
    print("Created separate database/account on MySQL " + version + ": " + DATABASE)
    print("Root password not stored; application credentials are private and Git-ignored.")


def java_environment(config):
    result = os.environ.copy()
    result.update(ROOMLY_LOCAL_DB_PASSWORD=config["password"], ROOMLY_LOCAL_DB_PORT=str(config["port"]),
                  JWT_SECRET=config["jwt_secret"])
    return result


def prepare_java(java_home):
    suffix = ".exe" if os.name == "nt" else ""
    java, javac = (Path(java_home) / ("bin/" + name + suffix) for name in ("java", "javac"))
    if not java.is_file() or not javac.is_file():
        raise SetupError("JDK17+ missing; select --java-home")
    if not JAR.is_file():
        raise SetupError("Backend JAR missing; build with backend/mvnw.cmd package first")
    digest = hashlib.sha256(JAR.read_bytes()).hexdigest()
    directory = ARTIFACTS / ("flyway-runner-" + digest[:16])
    libraries, classes = directory / "lib", directory / "classes"
    libraries.mkdir(parents=True, exist_ok=True)
    classes.mkdir(exist_ok=True)
    with zipfile.ZipFile(JAR) as archive:
        for item in archive.infolist():
            if item.filename.startswith("BOOT-INF/lib/") and item.filename.endswith(".jar"):
                destination = libraries / Path(item.filename).name
                if not destination.exists():
                    with archive.open(item) as source, destination.open("xb") as target:
                        shutil.copyfileobj(source, target)
    classpath = str(libraries / "*")
    result = subprocess.run([str(javac), "-encoding", "UTF-8", "-cp", classpath, "-d", str(classes),
                             str(HERE / "LocalMySqlSchema.java")], capture_output=True, check=False)
    if result.returncode:
        raise SetupError("Cannot compile the isolated Flyway helper using backend libraries")
    return java, str(classes) + os.pathsep + classpath


def schema(args, mode):
    config = load_config()
    Mysql(config["mysql"], config["port"], USER, config["password"]).check_server()
    java, classpath = prepare_java(args.java_home)
    report = ARTIFACTS / (mode + "-" + stamp() + ".json")
    result = subprocess.run([str(java), "-cp", classpath, "LocalMySqlSchema", mode,
                             str(ROOT / "backend/src/main/resources/db/migration"), str(report)],
                            env=java_environment(config), capture_output=True, text=True,
                            encoding="utf-8", errors="replace", check=False, timeout=90)
    if result.returncode:
        raise SetupError("Flyway refused the schema operation; no database clean/reset attempted. Inspect schema state before retry")
    print("PASS: " + mode + " using existing Flyway migrations. Report: " + str(report.relative_to(ROOT)))


def compact_schema(args):
    """Explicit V18 -> V19 upgrade, gated by a complete backup and isolated native tests."""
    backups = sorted(PRIVATE.glob("before-schema14-*/manifest.json"))
    reports = sorted(ARTIFACTS.glob("schema14-tests-*.json"))
    if not backups or not reports:
        raise SetupError("Schema14 requires a verified backup and isolated native test report first")
    backup = json.loads(backups[-1].read_text(encoding="utf-8"))
    dump = backups[-1].with_name("database.sql")
    if (not backup.get("pass") or backup.get("database") != DATABASE or
            hashlib.sha256(dump.read_bytes()).hexdigest() != backup.get("database_sql_sha256")):
        raise SetupError("Backup missing or checksum mismatch; no schema change performed")
    rows = backup.get("tables", {})
    if not rows or any(count for table, count in rows.items()
                       if table not in ("roles", "amenities", "flyway_schema_history")):
        raise SetupError("Existing business data needs a separate reviewed data migration")
    report = json.loads(reports[-1].read_text(encoding="utf-8"))
    migration = ROOT / "backend/src/main/resources/db/migration/V19__compact_fourteen_table_schema.sql"
    if (not report.get("pass") or report.get("migration_sha256") != hashlib.sha256(migration.read_bytes()).hexdigest()
            or report.get("backend_jar_sha256") != hashlib.sha256(JAR.read_bytes()).hexdigest()):
        raise SetupError("The current migration/JAR must pass isolated native tests before compacting")
    schema(args, "compact")


def export_schema(args):
    config = load_config()
    dump = Path(config["mysql"]).with_name("mysqldump.exe" if os.name == "nt" else "mysqldump")
    if not dump.is_file():
        raise SetupError("mysqldump missing beside mysql")
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    output = ARTIFACTS / ("schema-" + stamp() + ".sql")
    with password_file(config["password"]) as options, output.open("xb") as stream:
        result = subprocess.run(
            [str(dump), "--defaults-file=" + str(options), "--protocol=TCP", "--host=127.0.0.1",
             "--port=" + str(config["port"]), "--user=" + USER, "--no-data", "--skip-add-drop-table",
             "--skip-comments", "--set-gtid-purged=OFF", "--no-tablespaces",
             "--default-character-set=utf8mb4", DATABASE],
            stdout=stream, stderr=subprocess.PIPE, check=False, timeout=60)
    if result.returncode:
        raise SetupError("DDL export failed; incomplete output may remain")
    print("Read-only DDL export, no user data: " + str(output.relative_to(ROOT)))


def run_backend(args):
    config = load_config()
    schema(args, "check")
    java = Path(args.java_home) / ("bin/java.exe" if os.name == "nt" else "bin/java")
    if not 1024 <= args.http_port <= 65535:
        raise SetupError("Choose an unprivileged HTTP port")
    with socket.socket() as listener:
        try:
            listener.bind(("127.0.0.1", args.http_port))
        except OSError:
            raise SetupError("HTTP port occupied; existing backend was not stopped") from None
    environment = java_environment(config)
    environment["ROOMLY_LOCAL_HTTP_PORT"] = str(args.http_port)
    print("Separate backend: http://127.0.0.1:" + str(args.http_port))
    print("Media/mail require separate MinIO/SMTP services.")
    subprocess.run([str(java), "-Xmx640m", "-jar", str(JAR), "--spring.profiles.active=local-mysql80",
                    "--spring.config.additional-location=" + HERE.as_uri() + "/"],
                   env=environment, cwd=ROOT / "backend", check=False)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("init", "migrate", "check", "export-schema", "run", "setup", "compact"))
    parser.add_argument("--mysql", type=Path, default=MYSQL_DEFAULT)
    parser.add_argument("--port", type=int, default=3306)
    parser.add_argument("--admin-user", default="root")
    parser.add_argument("--admin-password-file", type=Path, help="Existing local password file; never printed/copied")
    parser.add_argument("--java-home", type=Path, default=JAVA_DEFAULT)
    parser.add_argument("--http-port", type=int, default=18091)
    args = parser.parse_args(argv)
    try:
        if args.action in ("init", "setup"):
            initialize(args)
        if args.action in ("migrate", "setup"):
            schema(args, "migrate")
        if args.action == "check":
            schema(args, "check")
        if args.action == "compact":
            compact_schema(args)
        if args.action in ("export-schema", "setup"):
            export_schema(args)
        if args.action == "run":
            run_backend(args)
    except SetupError as error:
        parser.exit(1, "Stopped safely: " + str(error) + "\n")
    except (OSError, subprocess.SubprocessError, ValueError, zipfile.BadZipFile):
        parser.exit(1, "Local operation failed; raw output omitted to protect credentials. "
                    "Existing databases were not dropped/reset.\n")


if __name__ == "__main__":
    main()
