"""Run native MySQL tests on a separate temporary server, never the MySQL80 service."""
from datetime import datetime, timezone
import json
import hashlib
import os
from pathlib import Path
import secrets
import socket
import subprocess
import time
import xml.etree.ElementTree as ET

import local_mysql as tool

PORT = 13307
ROOT = tool.ROOT


def main():
    server = tool.MYSQL_DEFAULT.with_name('mysqld.exe')
    if not server.is_file():
        raise tool.SetupError('Native mysqld.exe missing')
    with socket.socket() as probe:
        try:
            probe.bind(('127.0.0.1', PORT))
        except OSError:
            raise tool.SetupError('Test port occupied; existing processes will not be stopped') from None
    tool.private_directory()
    folder = tool.PRIVATE / ('schema14-test-' + tool.stamp())
    data = folder / 'data'
    data.mkdir(parents=True)
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    server_args = [str(server), '--no-defaults', '--basedir=' + str(server.parents[1]),
                   '--datadir=' + str(data), '--innodb-buffer-pool-size=64M', '--skip-log-bin',
                   '--mysqlx=OFF', '--performance-schema=OFF', '--max-connections=40']
    with (folder / 'initialize.log').open('wb') as log:
        initialized = subprocess.run(server_args + ['--initialize-insecure'],
            stdout=log, stderr=subprocess.STDOUT, creationflags=flags, check=False, timeout=90)
    if initialized.returncode:
        raise tool.SetupError('Isolated test-server initialization failed; MySQL80 untouched')
    password = 'Test14-Aa9!' + secrets.token_hex(24)
    root_client = tool.Mysql(tool.MYSQL_DEFAULT, PORT, 'root', '')
    authenticated = False
    log = (folder / 'server.log').open('wb')
    process = subprocess.Popen(server_args + ['--port=' + str(PORT), '--bind-address=127.0.0.1', '--console'],
        stdout=log, stderr=subprocess.STDOUT, creationflags=flags)
    try:
        for attempt in range(60):
            if process.poll() is not None:
                raise tool.SetupError('Isolated test server exited; see private server.log')
            try:
                root_client.check_server()
                break
            except tool.SetupError:
                time.sleep(0.5)
        else:
            raise tool.SetupError('Isolated MySQL did not become ready')
        root_client.query("ALTER USER 'root'@'localhost' IDENTIFIED BY '" + password + "';")
        root_client = tool.Mysql(tool.MYSQL_DEFAULT, PORT, 'root', password)
        authenticated = True
        root_client.query('CREATE DATABASE roomly_schema14_test CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;'
                          'CREATE DATABASE roomly_schema14_guard CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;')
        environment = os.environ.copy()
        environment['JAVA_HOME'] = str(tool.JAVA_DEFAULT)
        environment['HOMELY_TEST_MYSQL_URL'] = ('jdbc:mysql://127.0.0.1:' + str(PORT) +
            '/roomly_schema14_test?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true')
        environment['HOMELY_SCHEMA14_GUARD_URL'] = environment['HOMELY_TEST_MYSQL_URL'].replace(
            '/roomly_schema14_test?', '/roomly_schema14_guard?')
        environment['HOMELY_TEST_MYSQL_USER'] = 'root'
        environment['HOMELY_TEST_MYSQL_PASSWORD'] = password
        print('Isolated MySQL 8.0 ready on 127.0.0.1:' + str(PORT) + '; production service unchanged.', flush=True)
        with (folder / 'maven.log').open('wb') as build_log:
            build = subprocess.run(['cmd.exe', '/d', '/c', str(ROOT / 'backend/mvnw.cmd'),
                '-o', '-B', '-ntp', 'package',
                '-DargLine=-Xmx768m -XX:ActiveProcessorCount=2 -Dspring.test.context.cache.maxSize=4'],
                cwd=ROOT / 'backend', env=environment, stdout=build_log, stderr=subprocess.STDOUT,
                creationflags=flags, check=False)
        totals = dict(tests=0, failures=0, errors=0, skipped=0)
        for path in (ROOT / 'backend/target/surefire-reports').glob('TEST-*.xml'):
            suite = ET.parse(path).getroot()
            for key in totals:
                totals[key] += int(suite.get(key, '0'))
        tables = root_client.query("SELECT table_name FROM information_schema.tables WHERE table_schema='roomly_schema14_test' AND table_type='BASE TABLE' ORDER BY table_name;").splitlines()
        report = {'completed_at_utc': datetime.now(timezone.utc).isoformat(),
            'isolated_mysql_port': PORT, 'mysql_version': root_client.check_server(),
            'application_mysql_service_untouched': True, 'tests': totals, 'tables': tables,
            'migration_sha256': hashlib.sha256((ROOT / 'backend/src/main/resources/db/migration/V19__compact_fourteen_table_schema.sql').read_bytes()).hexdigest(),
            'backend_jar_sha256': hashlib.sha256(tool.JAR.read_bytes()).hexdigest(),
            'pass': build.returncode == 0 and len(tables) == 14 and totals['failures'] == totals['errors'] == totals['skipped'] == 0}
        output = tool.ARTIFACTS / ('schema14-tests-' + tool.stamp() + '.json')
        output.write_text(json.dumps(report, indent=2), encoding='utf-8')
        print(json.dumps(report, indent=2), flush=True)
        print('Private diagnostics: ' + str(folder.relative_to(ROOT)), flush=True)
        if not report['pass']:
            raise tool.SetupError('Isolated schema/test verification failed; application database unchanged')
    finally:
        if process.poll() is None:
            admin = tool.MYSQL_DEFAULT.with_name('mysqladmin.exe')
            with tool.password_file(password if authenticated else '') as options:
                subprocess.run([str(admin), '--defaults-file=' + str(options), '--protocol=TCP',
                    '--host=127.0.0.1', '--port=' + str(PORT), '--user=root', 'shutdown'],
                    capture_output=True, check=False, timeout=20)
            process.wait(timeout=30)
        log.close()


if __name__ == '__main__':
    try:
        main()
    except (tool.SetupError, OSError, subprocess.SubprocessError) as error:
        print('Native test run stopped. Details are in the private test directory; no application database reset.', flush=True)
        raise SystemExit(1) from None
