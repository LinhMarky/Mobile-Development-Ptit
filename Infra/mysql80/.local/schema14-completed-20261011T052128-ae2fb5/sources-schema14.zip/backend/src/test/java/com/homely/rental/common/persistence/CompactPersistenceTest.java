package com.homely.rental.common.persistence;

import com.homely.rental.auth.entity.*;
import com.homely.rental.auth.repository.*;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ContextConfiguration;

import java.time.Instant;
import java.util.UUID;

import static org.assertj.core.api.Assertions.*;

@DataJpaTest(showSql = false, properties = {"spring.flyway.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop", "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.H2Dialect"})
@ContextConfiguration(classes = CompactPersistenceTest.Config.class)
class CompactPersistenceTest {
    @Configuration
    @EntityScan("com.homely.rental")
    @EnableJpaRepositories("com.homely.rental")
    @Import(com.homely.rental.common.config.AuditConfig.class)
    static class Config { }

    @Autowired RoleRepository roles;
    @Autowired UserRepository users;
    @Autowired OneTimeTokenRepository tokens;
    @Autowired NotificationPreferenceRepository preferences;
    @Autowired AccountLifecycleLockRepository lifecycle;
    @Autowired EntityManager em;

    private User user() {
        User user = new User();
        user.setEmail(UUID.randomUUID() + "@example.test");
        user.setPassword("test-password-hash");
        user.setFullName("Persistence test");
        return users.saveAndFlush(user);
    }

    private OneTimeToken token(User user) {
        OneTimeToken token = new OneTimeToken();
        token.setUser(user);
        token.setTokenHash(UUID.randomUUID().toString());
        token.setPurpose(OneTimeToken.OneTimeTokenPurpose.EMAIL_VERIFICATION);
        token.setExpiresAt(Instant.now().minusSeconds(60));
        return tokens.saveAndFlush(token);
    }

    @Test void findByIdCannotReturnAnotherConcreteTypeFromTheSameTable() {
        User user = user();
        OneTimeToken token = token(user);
        Long lockId = lifecycle.lock(user.getId()).orElseThrow().getId();
        em.clear();
        assertThat(roles.findById(token.getId())).isEmpty();
        assertThat(tokens.findById(lockId)).isEmpty();
        assertThat(tokens.findById(token.getId())).isPresent();
    }

    @Test void expiryBulkDeletePreservesRolesPreferencesAndLifecycleLocks() {
        User user = user();
        Role role = new Role(); role.setName(RoleName.ROLE_TENANT); roles.saveAndFlush(role);
        NotificationPreference preference = new NotificationPreference(); preference.setUser(user);
        preferences.saveAndFlush(preference);
        token(user);
        assertThat(tokens.deleteExpiredTokens(Instant.now())).isEqualTo(1);
        em.clear();
        assertThat(tokens.count()).isZero();
        assertThat(roles.findByName(RoleName.ROLE_TENANT)).isPresent();
        assertThat(preferences.findByUserId(user.getId())).isPresent();
        assertThat(lifecycle.lock(user.getId())).isPresent();
    }

    @Test void roleBulkDeleteDoesNotDeleteOneTimeTokensOrLifecycleLocks() {
        User user = user();
        Role role = new Role(); role.setName(RoleName.ROLE_HOST); roles.saveAndFlush(role);
        OneTimeToken token = token(user);
        roles.deleteAllInBatch();
        em.clear();
        assertThat(roles.count()).isZero();
        assertThat(tokens.findById(token.getId())).isPresent();
        assertThat(lifecycle.lock(user.getId())).isPresent();
    }
}
