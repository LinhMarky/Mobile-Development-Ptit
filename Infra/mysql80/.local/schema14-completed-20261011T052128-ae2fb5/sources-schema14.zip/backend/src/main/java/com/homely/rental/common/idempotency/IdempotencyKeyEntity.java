package com.homely.rental.common.idempotency;

import com.homely.rental.common.persistence.ActivityRecord;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * Stores idempotency keys to prevent duplicate processing of POST mutation requests.
 * Key = Idempotency-Key header + principal.id + request_path.
 */
@Entity
@DiscriminatorValue("IDEMPOTENCY")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class IdempotencyKeyEntity extends ActivityRecord {

    /** SHA-256 of principal, HTTP method, request path and client key. */
    @Column(name = "request_idempotency_key", length = 512, nullable = true)
    private String idempotencyKey;

    @Column(name = "request_request_hash", length = 64)
    private String requestHash;

    @Column(name = "request_response_content_type", length = 255)
    private String responseContentType;

    @Column(name = "request_response_location", length = 2048, columnDefinition = "TEXT")
    private String responseLocation;

    @Enumerated(EnumType.STRING)
    @Column(name = "request_status", length = 20, nullable = true)
    private IdempotencyStatus status = IdempotencyStatus.PROCESSING;

    @Column(name = "request_response_status_code")
    private Integer responseStatusCode;

    @Column(name = "request_response_body", columnDefinition = "LONGTEXT")
    private String responseBody;

    @Column(name = "request_expires_at", nullable = true)
    private Instant expiresAt;

    @Column(name = "request_created_at", updatable = false)
    private Instant createdAt = Instant.now();

    public enum IdempotencyStatus {
        PROCESSING,
        COMPLETED
    }
}
