package com.homely.rental.common.persistence;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

/** Shared physical storage; repositories still address each concrete entity type. */
@Entity
@Table(name = "activity_records", uniqueConstraints = {
        @UniqueConstraint(name = "uk_activity_records_5", columnNames = {"delivery_notification_id", "delivery_device_id"}),
        @UniqueConstraint(name = "uk_activity_records_8", columnNames = {"request_idempotency_key"}),
        @UniqueConstraint(name = "uk_activity_records_11", columnNames = {"review_booking_id"})
})
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "record_type", length = 32)
@org.hibernate.annotations.Check(constraints = """
        record_type IN ('NOTIFICATION','PUSH_DELIVERY','AUDIT_LOG','IDEMPOTENCY','REVIEW','REPORT')
        AND (record_type <> 'NOTIFICATION' OR (notification_user_id IS NOT NULL AND notification_type IS NOT NULL AND notification_title IS NOT NULL AND notification_is_read IS NOT NULL))
        AND (record_type <> 'PUSH_DELIVERY' OR (delivery_notification_id IS NOT NULL AND delivery_device_id IS NOT NULL AND delivery_status IS NOT NULL AND delivery_attempts IS NOT NULL AND delivery_next_attempt_at IS NOT NULL AND delivery_created_at IS NOT NULL))
        AND (record_type <> 'AUDIT_LOG' OR (audit_actor_type IS NOT NULL AND audit_action IS NOT NULL AND audit_target_type IS NOT NULL AND audit_target_id IS NOT NULL))
        AND (record_type <> 'IDEMPOTENCY' OR (request_idempotency_key IS NOT NULL AND request_status IS NOT NULL AND request_expires_at IS NOT NULL))
        AND (record_type <> 'REVIEW' OR (review_booking_id IS NOT NULL AND review_reviewer_id IS NOT NULL AND review_room_id IS NOT NULL AND review_rating IS NOT NULL AND review_visible IS NOT NULL))
        AND (record_type <> 'REPORT' OR (report_reporter_id IS NOT NULL AND report_target_type IS NOT NULL AND report_target_id IS NOT NULL AND report_reason_code IS NOT NULL AND report_status IS NOT NULL))
        """)
@Getter
@Setter
public abstract class ActivityRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;
}
