package com.homely.rental.common.persistence;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

/** Shared physical storage; repositories still address each concrete entity type. */
@Entity
@Table(name = "account_records", uniqueConstraints = {
        @UniqueConstraint(name = "uk_account_records_1", columnNames = {"role_name"}),
        @UniqueConstraint(name = "uk_account_records_4", columnNames = {"refresh_token_hash"}),
        @UniqueConstraint(name = "uk_account_records_7", columnNames = {"verify_token_hash"}),
        @UniqueConstraint(name = "uk_account_records_11", columnNames = {"device_user_id", "device_installation_id"}),
        @UniqueConstraint(name = "uk_account_records_12", columnNames = {"preference_user_id"}),
        @UniqueConstraint(name = "uk_account_records_14", columnNames = {"deletion_user_id"}),
        @UniqueConstraint(name = "uk_account_records_15", columnNames = {"lifecycle_user_id"})
})
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "record_type", length = 32)
@org.hibernate.annotations.Check(constraints = """
        record_type IN ('ROLE','REFRESH_TOKEN','ONE_TIME_TOKEN','DEVICE_TOKEN','PREFERENCES','DELETION_REQUEST','LIFECYCLE_LOCK')
        AND (record_type <> 'ROLE' OR (role_name IS NOT NULL))
        AND (record_type <> 'REFRESH_TOKEN' OR (refresh_token_hash IS NOT NULL AND refresh_user_id IS NOT NULL AND refresh_installation_id IS NOT NULL AND refresh_device_name IS NOT NULL AND refresh_expires_at IS NOT NULL AND refresh_revoked IS NOT NULL))
        AND (record_type <> 'ONE_TIME_TOKEN' OR (verify_token_hash IS NOT NULL AND verify_user_id IS NOT NULL AND verify_purpose IS NOT NULL AND verify_used IS NOT NULL AND verify_expires_at IS NOT NULL))
        AND (record_type <> 'DEVICE_TOKEN' OR (device_user_id IS NOT NULL AND device_token IS NOT NULL AND device_platform IS NOT NULL AND device_device_name IS NOT NULL AND device_installation_id IS NOT NULL AND device_active IS NOT NULL))
        AND (record_type <> 'PREFERENCES' OR (preference_user_id IS NOT NULL AND preference_transaction_push IS NOT NULL AND preference_transaction_email IS NOT NULL AND preference_chat_push IS NOT NULL AND preference_recommendation_push IS NOT NULL))
        AND (record_type <> 'DELETION_REQUEST' OR (deletion_user_id IS NOT NULL AND deletion_reason IS NOT NULL AND deletion_status IS NOT NULL))
        AND (record_type <> 'LIFECYCLE_LOCK' OR (lifecycle_user_id IS NOT NULL))
        """)
@Getter
@Setter
public abstract class AccountRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;
}
