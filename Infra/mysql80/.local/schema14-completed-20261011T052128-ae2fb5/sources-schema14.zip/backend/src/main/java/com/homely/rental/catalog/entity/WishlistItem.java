package com.homely.rental.catalog.entity;

import com.homely.rental.common.persistence.CatalogRecord;

import com.homely.rental.auth.entity.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * Wishlist item entity (CAT11–13).
 * Users can save/unsave listings.
 */
@Entity
@DiscriminatorValue("WISHLIST_ITEM")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class WishlistItem extends CatalogRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "wishlist_user_id", nullable = true)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "wishlist_room_id", nullable = true)
    private Room room;

    @Column(name = "wishlist_created_at", updatable = false)
    private Instant createdAt = Instant.now();
}
