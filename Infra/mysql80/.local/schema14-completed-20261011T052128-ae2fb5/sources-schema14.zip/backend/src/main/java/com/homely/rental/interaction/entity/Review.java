package com.homely.rental.interaction.entity;

import com.homely.rental.common.persistence.ActivityRecord;

import com.homely.rental.auth.entity.User;
import com.homely.rental.catalog.entity.Room;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("REVIEW")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Review extends ActivityRecord {

    /** One review per booking — UNIQUE constraint in DB */
    @Column(name = "review_booking_id", nullable = true)
    private Long bookingId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "review_reviewer_id", nullable = true)
    private User reviewer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "review_room_id", nullable = true)
    private Room room;

    @Column(name = "review_rating", nullable = true)
    private int rating; // 1–5

    @Column(name = "review_comment", length = 2000, columnDefinition = "TEXT")
    private String comment;

    @Column(name = "review_visible", nullable = true)
    private boolean visible = true;

    @Column(name = "review_hide_reason", length = 500)
    private String hideReason;

    @Column(name = "review_created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "review_updated_at")
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }
}
