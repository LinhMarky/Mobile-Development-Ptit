package com.homely.rental.common.audit;

import com.homely.rental.common.persistence.ActivityRecord;

import com.homely.rental.auth.entity.User;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("AUDIT_LOG")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuditLog extends ActivityRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "audit_actor_id")
    private User actor;

    @Column(name = "audit_actor_type", length = 20, nullable = true)
    private String actorType;

    @Column(name = "audit_action", length = 100, nullable = true)
    private String action;

    @Column(name = "audit_target_type", length = 50, nullable = true)
    private String targetType;

    @Column(name = "audit_target_id", nullable = true)
    private Long targetId;

    @Column(name = "audit_detail", columnDefinition = "JSON")
    private String detail;

    @Column(name = "audit_ip_address", length = 45)
    private String ipAddress;

    @Column(name = "audit_trace_id", length = 64)
    private String traceId;

    @Column(name = "audit_created_at", updatable = false)
    private Instant createdAt = Instant.now();
}
