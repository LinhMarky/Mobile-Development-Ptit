package com.homely.rental.auth.entity;

import com.homely.rental.common.persistence.AccountRecord;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * Stores FCM device tokens for push notifications (AUTH10).
 */
@Entity
@DiscriminatorValue("DEVICE_TOKEN")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DeviceToken extends AccountRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "device_user_id", nullable = true)
    private User user;

    @Column(name = "device_token", length = 4096, nullable = true, columnDefinition = "TEXT")
    private String token;

    @Enumerated(EnumType.STRING)
    @Column(name = "device_platform", length = 10, nullable = true)
    private Platform platform = Platform.ANDROID;

    @Column(name = "device_device_name", length = 100, nullable = true)
    private String deviceName;

    @Column(name = "device_installation_id", length = 36, nullable = true)
    private String installationId;

    @Column(name = "device_active")
    private boolean active = true;

    @Column(name = "device_created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "device_updated_at")
    private Instant updatedAt = Instant.now();

    public enum Platform {
        ANDROID
    }
}
