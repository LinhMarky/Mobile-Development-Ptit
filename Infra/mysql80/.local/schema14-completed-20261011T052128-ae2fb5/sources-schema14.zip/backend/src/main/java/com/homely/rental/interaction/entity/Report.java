package com.homely.rental.interaction.entity;

import com.homely.rental.common.persistence.ActivityRecord;

import com.homely.rental.auth.entity.User;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("REPORT")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Report extends ActivityRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "report_reporter_id", nullable = true)
    private User reporter;

    /** "listing", "review", "message", "user" */
    @Column(name = "report_target_type", length = 50, nullable = true)
    private String targetType;

    @Column(name = "report_target_id", nullable = true)
    private Long targetId;

    /** SPAM, SCAM, INAPPROPRIATE, DUPLICATE, OTHER */
    @Column(name = "report_reason_code", length = 50, nullable = true)
    private String reasonCode;

    @Column(name = "report_description", length = 2000, columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "report_status", length = 20, nullable = true)
    private ReportStatus status = ReportStatus.PENDING;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "report_resolved_by")
    private User resolvedBy;

    @Column(name = "report_resolution_note", length = 1000)
    private String resolutionNote;

    @Column(name = "report_resolved_at")
    private Instant resolvedAt;

    @Column(name = "report_created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "report_updated_at")
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }
}
