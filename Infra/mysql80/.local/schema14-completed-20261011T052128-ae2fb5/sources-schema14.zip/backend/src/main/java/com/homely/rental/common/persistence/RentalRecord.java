package com.homely.rental.common.persistence;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

/** Shared physical storage; repositories still address each concrete entity type. */
@Entity
@Table(name = "rental_records", uniqueConstraints = {
        @UniqueConstraint(name = "uk_rental_records_1", columnNames = {"booking_allocated_payment_id"}),
        @UniqueConstraint(name = "uk_rental_records_26", columnNames = {"payment_provider_payment_id"}),
        @UniqueConstraint(name = "uk_rental_records_29", columnNames = {"refund_payment_id"}),
        @UniqueConstraint(name = "uk_rental_records_30", columnNames = {"refund_provider_refund_id"}),
        @UniqueConstraint(name = "uk_rental_records_32", columnNames = {"webhook_provider", "webhook_event_id"})
})
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "record_type", length = 32)
@org.hibernate.annotations.Check(constraints = """
        record_type IN ('BOOKING','BOOKING_CASE','BOOKING_HISTORY','VIEWING_SLOT','VIEWING','PAYMENT','REFUND','WEBHOOK_RECEIPT')
        AND (record_type <> 'BOOKING' OR (booking_tenant_id IS NOT NULL AND booking_host_id IS NOT NULL AND booking_room_id IS NOT NULL AND booking_listing_id IS NOT NULL AND booking_status IS NOT NULL AND booking_occupant_count IS NOT NULL AND booking_rent_vnd IS NOT NULL AND booking_deposit_vnd IS NOT NULL AND booking_terms_snapshot IS NOT NULL AND booking_snapshot_schema_version IS NOT NULL AND booking_request_expires_at IS NOT NULL))
        AND (record_type <> 'BOOKING_CASE' OR (case_booking_id IS NOT NULL AND case_type IS NOT NULL AND case_description IS NOT NULL AND case_status IS NOT NULL))
        AND (record_type <> 'BOOKING_HISTORY' OR (history_booking_id IS NOT NULL AND history_to_status IS NOT NULL AND history_actor_type IS NOT NULL AND history_trace_id IS NOT NULL))
        AND (record_type <> 'VIEWING_SLOT' OR (slot_room_id IS NOT NULL AND slot_host_id IS NOT NULL AND slot_start_at IS NOT NULL AND slot_end_at IS NOT NULL AND slot_status IS NOT NULL))
        AND (record_type <> 'VIEWING' OR (viewing_viewing_slot_id IS NOT NULL AND viewing_tenant_id IS NOT NULL AND viewing_room_id IS NOT NULL AND viewing_host_id IS NOT NULL AND viewing_status IS NOT NULL))
        AND (record_type <> 'PAYMENT' OR (payment_booking_id IS NOT NULL AND payment_payer_id IS NOT NULL AND payment_provider IS NOT NULL AND payment_amount_vnd IS NOT NULL AND payment_currency IS NOT NULL AND payment_status IS NOT NULL AND payment_expires_at IS NOT NULL AND payment_is_test IS NOT NULL))
        AND (record_type <> 'REFUND' OR (refund_payment_id IS NOT NULL AND refund_amount_vnd IS NOT NULL AND refund_status IS NOT NULL AND refund_attempt_count IS NOT NULL))
        AND (record_type <> 'WEBHOOK_RECEIPT' OR (webhook_provider IS NOT NULL AND webhook_event_id IS NOT NULL AND webhook_payload_hash IS NOT NULL AND webhook_processed_at IS NOT NULL))
        """)
@Getter
@Setter
public abstract class RentalRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;
}
