package com.homely.rental.interaction.entity;

import com.homely.rental.common.persistence.RentalRecord;

import com.homely.rental.auth.entity.User;
import com.homely.rental.catalog.entity.Room;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("VIEWING")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Viewing extends RentalRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "viewing_viewing_slot_id", nullable = true)
    private ViewingSlot viewingSlot;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "viewing_tenant_id", nullable = true)
    private User tenant;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "viewing_room_id", nullable = true)
    private Room room;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "viewing_host_id", nullable = true)
    private User host;

    @Enumerated(EnumType.STRING)
    @Column(name = "viewing_status", length = 30, nullable = true)
    private ViewingStatus status = ViewingStatus.REQUESTED;

    @Column(name = "viewing_note", length = 1000)
    private String note;

    @Column(name = "viewing_cancelled_reason", length = 1000)
    private String cancelledReason;

    @Column(name = "viewing_completed_at")
    private Instant completedAt;

    @Column(name = "viewing_created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "viewing_updated_at")
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }
}
