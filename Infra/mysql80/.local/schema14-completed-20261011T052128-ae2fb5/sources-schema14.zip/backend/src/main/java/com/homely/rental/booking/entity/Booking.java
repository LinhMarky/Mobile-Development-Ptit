package com.homely.rental.booking.entity;

import com.homely.rental.common.persistence.RentalRecord;

import com.homely.rental.auth.entity.User;
import com.homely.rental.catalog.entity.Listing;
import com.homely.rental.catalog.entity.Room;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

/**
 * Booking entity (§2.5, BR-06).
 * Tracks the full lifecycle: PENDING → APPROVED → CONFIRMED → COMPLETED.
 */
@Entity
@DiscriminatorValue("BOOKING")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Booking extends RentalRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "booking_tenant_id", nullable = true)
    private User tenant;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "booking_host_id", nullable = true)
    private User host;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "booking_room_id", nullable = true)
    private Room room;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "booking_listing_id", nullable = true)
    private Listing listing;

    @Enumerated(EnumType.STRING)
    @Column(name = "booking_status", length = 20, nullable = true)
    private BookingStatus status = BookingStatus.PENDING;

    @Column(name = "booking_desired_move_in")
    private LocalDate desiredMoveIn;

    @Column(name = "booking_occupant_count", nullable = true)
    private int occupantCount = 1;

    @Column(name = "booking_rent_vnd", precision = 18, scale = 0, nullable = true)
    private BigDecimal rentVnd;

    @Column(name = "booking_deposit_vnd", precision = 18, scale = 0, nullable = true)
    private BigDecimal depositVnd = BigDecimal.ZERO;

    @Column(name = "booking_note", length = 1000)
    private String note;

    @Column(name = "booking_terms_snapshot", columnDefinition = "JSON", nullable = true)
    private String termsSnapshot;

    @Column(name = "booking_snapshot_schema_version", nullable = true)
    private int snapshotSchemaVersion = 1;

    @Column(name = "booking_request_expires_at", nullable = true)
    private Instant requestExpiresAt;

    @Column(name = "booking_hold_expires_at")
    private Instant holdExpiresAt;

    @Column(name = "booking_handover_due_at")
    private Instant handoverDueAt;

    @Column(name = "booking_tenant_terms_accepted_at")
    private Instant tenantTermsAcceptedAt;

    @Column(name = "booking_tenant_handover_confirmed_at")
    private Instant tenantHandoverConfirmedAt;

    @Column(name = "booking_host_handover_confirmed_at")
    private Instant hostHandoverConfirmedAt;

    @Column(name = "booking_allocated_payment_id")
    private Long allocatedPaymentId;

    @Column(name = "booking_completed_at")
    private Instant completedAt;

    @Column(name = "booking_cancelled_at")
    private Instant cancelledAt;

    @Column(name = "booking_last_reason", length = 1000)
    private String lastReason;

    @Column(name = "booking_created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "booking_updated_at")
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }
}
