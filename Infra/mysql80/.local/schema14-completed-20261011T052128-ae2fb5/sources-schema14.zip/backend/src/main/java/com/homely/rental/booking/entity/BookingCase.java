package com.homely.rental.booking.entity;

import com.homely.rental.common.persistence.RentalRecord;

import com.homely.rental.auth.entity.User;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("BOOKING_CASE")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class BookingCase extends RentalRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "case_booking_id", nullable = true)
    private Booking booking;

    @Enumerated(EnumType.STRING)
    @Column(name = "case_type", length = 30, nullable = true)
    private BookingCaseType type;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "case_opened_by")
    private User openedBy;

    @Column(name = "case_description", columnDefinition = "TEXT", nullable = true)
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "case_status", length = 20, nullable = true)
    private CaseStatus status = CaseStatus.OPEN;

    @Enumerated(EnumType.STRING)
    @Column(name = "case_decision", length = 30)
    private BookingCaseDecision decision;
    @Column(name = "case_tenant_refund_vnd", precision=18, scale=0)
    private java.math.BigDecimal tenantRefundVnd;
    @Column(name = "case_host_retained_vnd", precision=18, scale=0)
    private java.math.BigDecimal hostRetainedVnd;

    @Column(name = "case_resolution_note", columnDefinition = "TEXT")
    private String resolutionNote;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "case_resolved_by")
    private User resolvedBy;

    @Column(name = "case_resolved_at")
    private Instant resolvedAt;

    @Column(name = "case_created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "case_updated_at")
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }
}
