package com.homely.rental.auth.entity;

import com.homely.rental.common.persistence.AccountRecord;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * Refresh token entity for session management (SEC-02).
 * Each login creates a new session/refresh token record.
 */
@Entity
@DiscriminatorValue("REFRESH_TOKEN")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RefreshToken extends AccountRecord {

    @Column(name = "refresh_token_hash", length = 64, nullable = true)
    private String tokenHash;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "refresh_user_id", nullable = true)
    private User user;

    @Column(name = "refresh_installation_id", length = 36, nullable = true)
    private String installationId;

    @Column(name = "refresh_device_name", length = 100, nullable = true)
    private String deviceName;

    @Column(name = "refresh_expires_at", nullable = true)
    private Instant expiresAt;

    @Column(name = "refresh_revoked")
    private boolean revoked = false;

    @Column(name = "refresh_created_at", updatable = false)
    private Instant createdAt = Instant.now();
}
