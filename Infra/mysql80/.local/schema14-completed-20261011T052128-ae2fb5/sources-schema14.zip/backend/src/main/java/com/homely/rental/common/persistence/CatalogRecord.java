package com.homely.rental.common.persistence;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

/** Shared physical storage; repositories still address each concrete entity type. */
@Entity
@Table(name = "catalog_items", uniqueConstraints = {
        @UniqueConstraint(name = "uk_catalog_items_1", columnNames = {"amenity_name"}),
        @UniqueConstraint(name = "uk_catalog_items_5", columnNames = {"wishlist_user_id", "wishlist_room_id"})
})
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "record_type", length = 32)
@org.hibernate.annotations.Check(constraints = """
        record_type IN ('AMENITY','LISTING_FEE','WISHLIST_ITEM')
        AND (record_type <> 'AMENITY' OR (amenity_name IS NOT NULL))
        AND (record_type <> 'LISTING_FEE' OR (fee_listing_id IS NOT NULL AND fee_fee_code IS NOT NULL AND fee_fee_mode IS NOT NULL AND fee_amount_vnd IS NOT NULL AND fee_sort_order IS NOT NULL))
        AND (record_type <> 'WISHLIST_ITEM' OR (wishlist_user_id IS NOT NULL AND wishlist_room_id IS NOT NULL))
        """)
@Getter
@Setter
public abstract class CatalogRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

}
