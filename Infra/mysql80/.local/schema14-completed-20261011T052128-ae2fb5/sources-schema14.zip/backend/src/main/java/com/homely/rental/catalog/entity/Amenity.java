package com.homely.rental.catalog.entity;

import com.homely.rental.common.persistence.CatalogRecord;

import com.homely.rental.common.entity.AbstractAuditingEntity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Amenity entity for rooms (CAT14).
 * Represents a facility/feature that can be associated with rooms.
 */
@Entity
@DiscriminatorValue("AMENITY")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Amenity extends CatalogRecord {

    @Column(name = "amenity_name", length = 100, nullable = true)
    private String name;

    @Column(name = "amenity_icon", length = 100)
    private String icon;

    @Column(name = "amenity_category", length = 50)
    private String category;
}
