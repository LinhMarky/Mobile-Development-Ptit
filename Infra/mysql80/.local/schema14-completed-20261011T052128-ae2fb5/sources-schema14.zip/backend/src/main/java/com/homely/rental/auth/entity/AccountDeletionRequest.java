package com.homely.rental.auth.entity;

import com.homely.rental.common.persistence.AccountRecord;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * Account deletion request entity (§2.8).
 * Tracks user-initiated account deletion with status lifecycle.
 */
@Entity
@DiscriminatorValue("DELETION_REQUEST")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccountDeletionRequest extends AccountRecord {

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "deletion_user_id", nullable = true)
    private User user;

    @Column(name = "deletion_reason", length = 1000, nullable = true)
    private String reason = "";

    @Enumerated(EnumType.STRING)
    @Column(name = "deletion_status", length = 20, nullable = true)
    private DeletionStatus status = DeletionStatus.PENDING;

    @Column(name = "deletion_failure_code", length = 100)
    private String failureCode;

    @Column(name = "deletion_completed_at")
    private Instant completedAt;

    @Column(name = "deletion_created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "deletion_updated_at")
    private Instant updatedAt = Instant.now();

    public enum DeletionStatus {
        PENDING,
        PROCESSING,
        COMPLETED,
        FAILED
    }
}
