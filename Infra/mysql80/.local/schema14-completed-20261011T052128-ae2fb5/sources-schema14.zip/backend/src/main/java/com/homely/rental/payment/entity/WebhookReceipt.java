package com.homely.rental.payment.entity;

import com.homely.rental.common.persistence.RentalRecord;
import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;

@Entity @DiscriminatorValue("WEBHOOK_RECEIPT")
@Getter @Setter @NoArgsConstructor
public class WebhookReceipt extends RentalRecord {

    @Column(name = "webhook_provider", nullable = true, length=20) private String provider;
    @Column(name = "webhook_event_id", nullable = true, columnDefinition="CHAR(36)") private String eventId;
    @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name = "webhook_payment_id") private Payment payment;
    @Column(name = "webhook_payload_hash", nullable = true, columnDefinition="BINARY(32)") private byte[] payloadHash;
    @Column(name = "webhook_outcome", length=30) private String outcome;
    @Column(name = "webhook_processed_at", nullable = true) private Instant processedAt = Instant.now();
    @Column(name = "webhook_created_at") private Instant createdAt = Instant.now();
}
