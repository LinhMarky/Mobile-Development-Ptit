package com.homely.rental.catalog.entity;

import com.homely.rental.common.persistence.CatalogRecord;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Listing fee entity (BR-04).
 * Additional fees associated with a listing (electricity, water, internet, etc.)
 */
@Entity
@DiscriminatorValue("LISTING_FEE")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ListingFee extends CatalogRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fee_listing_id", nullable = true)
    private Listing listing;

    @Column(name = "fee_fee_code", length = 50, nullable = true)
    private String feeCode;

    @Column(name = "fee_fee_mode", length = 20, nullable = true)
    private String feeMode = "FIXED";

    @Column(name = "fee_amount_vnd", precision = 18, scale = 0, nullable = true)
    private BigDecimal amountVnd;

    @Column(name = "fee_unit_name", length = 50)
    private String unitName; // e.g., "kWh", "m³", "month"

    @Column(name = "fee_note", length = 500)
    private String note;

    @Column(name = "fee_sort_order", nullable = true)
    private int sortOrder = 0;
}
