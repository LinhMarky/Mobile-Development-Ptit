package com.homely.rental.notification.push;

import com.homely.rental.common.persistence.ActivityRecord;
import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;
@Entity @DiscriminatorValue("PUSH_DELIVERY")
@Getter @Setter @NoArgsConstructor
public class PushDelivery extends ActivityRecord {

    @Column(name = "delivery_notification_id",nullable = true) private Long notificationId;
    @Column(name = "delivery_device_id",nullable = true) private Long deviceId;
    @Column(name = "delivery_status", nullable = true,length=20) private String status="PENDING";
    @Column(name = "delivery_attempts", nullable = true) private int attempts;
    @Column(name = "delivery_next_attempt_at",nullable = true) private Instant nextAttemptAt=Instant.now();
    @Column(name = "delivery_last_error",length=100) private String lastError;
    @Column(name = "delivery_created_at",nullable = true) private Instant createdAt=Instant.now();

}
