# Schema 14 bảng — 10/10/2026

Quyết định của chủ dự án: dưới 15 bảng, giữ đầy đủ chức năng và API; chấp nhận sửa lớp persistence. Đây là thay đổi schema nội bộ, không đổi giao thức HTTP/STOMP, DTO, enum hay đường dẫn API v1.6. Không thay đổi code Android để thích nghi schema.

## Danh sách đầy đủ

| STT | Bảng vật lý | Nội dung |
| --- | --- | --- |
| 1 | users | Tài khoản, hồ sơ, trạng thái, optimistic version |
| 2 | user_roles | Vai trò được cấp cho từng tài khoản |
| 3 | account_records | Vai trò, refresh/one-time/device token, preferences, yêu cầu xóa và hàng khóa lifecycle |
| 4 | rooms | Phòng, địa chỉ, vị trí, điều khoản và trạng thái còn trống |
| 5 | room_amenities | Liên kết phòng–tiện ích |
| 6 | catalog_items | Danh mục tiện ích, phí tin đăng, wishlist |
| 7 | listings | Tin đăng và trạng thái duyệt/hiển thị |
| 8 | media | Metadata ảnh/tệp; nội dung vẫn ở MinIO |
| 9 | rental_records | Booking, lịch sử booking, tranh chấp, slot/hẹn xem, payment, refund, webhook receipt |
| 10 | conversations | Hội thoại và sequence |
| 11 | messages | Tin nhắn và client_message_id chống gửi trùng |
| 12 | read_markers | Sequence đã đọc riêng theo thành viên hội thoại |
| 13 | activity_records | Inbox notification, FCM delivery, audit, idempotency, review và report |
| 14 | flyway_schema_history | Lịch sử/checksum migration; bảng kỹ thuật |

Tổng: **13 bảng ứng dụng + 1 bảng Flyway = 14 bảng**. Không dùng view để che bảng, không bỏ FCM hay nghiệp vụ thanh toán/tranh chấp.

## Cách mapping

Bốn lớp gốc `AccountRecord`, `CatalogRecord`, `RentalRecord`, `ActivityRecord` dùng JPA `SINGLE_TABLE`, phân loại bằng `record_type`. 24 entity cụ thể vẫn giữ tên, property và repository riêng. Ví dụ `RefreshTokenRepository` chỉ đọc/xóa `REFRESH_TOKEN`; `PaymentRepository` chỉ thao tác `PAYMENT`. Service không truy vấn một kho JSON tổng hợp.

Mỗi loại có tiền tố cột riêng, tránh trộn ý nghĩa các trường `status`, `user_id`, `created_at`. ID do bảng gốc cấp; ID/version dùng lại accessor đã có. FE tiếp tục coi ID là giá trị định danh, không suy luận thứ tự hoặc số lượng từ khoảng ID.

Các cột riêng của một loại phải nullable ở mức bảng vì loại khác không dùng chúng. `CHECK` theo `record_type` giữ ràng buộc bắt buộc của từng loại. Các khóa ngoại tới bảng dùng chung kèm loại đích cố định: gán nhầm lifecycle lock thành role hoặc booking thành payment bị database từ chối. Unique index và generated column cho giữ phòng, pending payment, open case và thiết bị active được giữ trong migration.

Hàng khóa lifecycle vẫn là bản ghi riêng với tài khoản, dù dùng chung `account_records`; optimistic version và khóa pessimistic vẫn hoạt động. Khóa giao dịch, retry FCM, idempotency và cursor chat không bị thay bằng dữ liệu chỉ lưu trong RAM.

Đổi lại, bốn bảng dùng chung rộng hơn và ít chuẩn hóa hơn bản 37 bảng. Đây là sự đánh đổi để đạt giới hạn số bảng và giữ ít thay đổi service; số bảng ít hơn không tự chứng minh thiết kế tốt hơn. Khi cần tách lại để mở rộng, giữ repository/DTO và viết migration riêng.

Tham khảo cách mapping chuẩn: [Hibernate ORM 6.5 — Single table inheritance](https://docs.jboss.org/hibernate/orm/6.5/userguide/html_single/Hibernate_User_Guide.html#entity-inheritance-single-table).

## Nâng cấp và dữ liệu

Giữ nguyên V1–V18 để không đổi checksum các môi trường đã chạy. Thêm V19 để chuyển một database V18 **chưa có dữ liệu người dùng/giao dịch** sang 14 bảng. ID và nội dung danh mục role/amenity được giữ nguyên. Ba bảng cũ chưa có entity/luồng sử dụng (`listing_status_history`, `viewing_status_history`, `case_evidence`) được loại cùng các bảng đã gộp; lịch sử booking và audit đang được code sử dụng vẫn được lưu.

V19 kiểm tra dữ liệu trước khi tạo bảng mới hoặc bỏ bảng cũ. Có dữ liệu nghiệp vụ thì dừng; không tự xóa dữ liệu để đạt số bảng. Cần một đợt migration dữ liệu có mapping ID/backup riêng nếu nâng cấp database đang sử dụng. Không dùng V19 để reset database production.

Database local đã được sao lưu trước đợt thay đổi tại `Infra/mysql80/.local/before-schema14-20261010T152703-d69fc6/` (SQL đầy đủ, mã nguồn và manifest SHA-256; đã Git ignore và giới hạn quyền Windows). MySQL80 hiện có vẫn chạy trên 3306. Kiểm thử native dùng một tiến trình MySQL riêng ở 13307, dữ liệu riêng và được tắt sau kiểm thử.

Kết quả kiểm thử và nghiệm thu hiện hành cập nhật tại `IMPLEMENTATION_STATUS.md`; phần này mô tả thiết kế, không tự xác nhận test đã PASS.
