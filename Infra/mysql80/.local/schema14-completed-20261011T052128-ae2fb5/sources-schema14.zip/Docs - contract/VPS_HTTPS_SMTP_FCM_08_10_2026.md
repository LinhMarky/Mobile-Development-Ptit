# Đóng gói và triển khai VPS: HTTPS/WSS, SMTP, FCM

Cập nhật 10/10/2026. Backend contract **1.6.0**, app chính **Roomly** ở `Frontend-Mobile-App`. Mốc 09/10: **255 test H2/MySQL 8.4, Gmail thật và FCM OAuth + HTTP V1 validate-only 200 đã kiểm chứng**; image `homely-backend:vps-verified-20261009-fcm` thuộc bản trước gộp bảng. Mốc mới 10/10: **273 test H2/MySQL 8.0.45 đạt**, native runtime đã chuyển V19/14 bảng. Chưa có VPS/IP hoặc endpoint công khai; push tới điện thoại cần FE tích hợp và nghiệm thu. VPS là bước cuối theo yêu cầu chủ dự án. [Hiện trạng/P1 còn mở](IMPLEMENTATION_STATUS.md), [bàn giao FE](FE_BACKEND_HANDOFF_08_10_2026.md).

**Triển khai schema V19:** Phải build image mới từ source hiện tại, không dùng lại image 09/10 để chạy database V19. Với VPS mới, Flyway tự chạy V1–V19 trên database trống và kết thúc ở **14 bảng, gồm Flyway**. Với database V18 đã có user/giao dịch, V19 chủ động từ chối nâng cấp; cần backup và migration dữ liệu riêng. Không xóa volume hay sửa checksum để ép chạy. Chưa nghiệm thu V19 trên Docker/MySQL 8.4 trong đợt native này. Xem [mapping, kiểm thử và giới hạn](SCHEMA_14_TABLES.md).

## 1. Thành phần và kiểm chứng local

| Thành phần | File | Hành vi |
| --- | --- | --- |
| Proxy | `Infra/vps/render_proxy.py`, `compose.proxy.yaml` | Sinh Nginx HTTP bootstrap/TLS; giữ đường dẫn API/media; WSS `/ws`; body 60 MiB, timeout upload 120 giây; timeout socket 3600 giây |
| IP người gọi | `compose.proxy.yaml` | Tomcat NATIVE chỉ tin các IP proxy cụ thể; Nginx đặt lại X-Forwarded-For/Proto và xóa Forwarded từ client |
| Lỗi tại proxy | Nginx được sinh | 413/502/503/504 giữ HTTP status và `{statusCode,message,data}`; lỗi backend được chuyển nguyên vẹn; media vẫn trả bytes |
| SMTP thật | `compose.smtp.yaml`, `check_services.py` | Auth + STARTTLS hoặc implicit TLS; kiểm tra TLS/auth; tùy chọn gửi một email thử |
| Firebase | `Infra/compose.firebase.yaml`, `check_services.py` | File hiện có, read-only; chặn JSON Android/nhầm project; kiểm tra backend user đọc được mount |
| FCM API thật | `check_firebase.py`, `requirements-firebase.txt` | OAuth bằng service account, HTTP V1 `validate_only=true`; xác minh API/quyền mà không gửi thông báo tới thiết bị |
| Lệnh thống nhất | `Infra/vps/stack.py` | Chọn cùng bộ overlay cho config/build/up/check/ps/logs; `config` không in secret; `up` không tự build |
| Kiểm tra từ ngoài VPS | `check_public.py` | TLS được tin cậy, health, Swagger/OpenAPI, wrapper, HTTP 401 và tùy chọn WSS/STOMP CONNECTED |

Backend contract vẫn **1.6.0**. Roomly ở `Frontend-Mobile-App` là app chính; `Homely-android` là client tham khảo. Không thay đổi code FE trong lượt này.

Kiểm chứng proxy ngày 09/10: 5 kiểm tra cấu hình offline PASS; Nginx `nginx:1.28-alpine` chạy thực tế với HTTP/STOMP fixture riêng đạt syntax bootstrap/TLS, HTTPS giữ path/auth và thay header giả, WSS/STOMP, 413 JSON, metrics private, access-log bỏ query token, 502 JSON. Bằng chứng local `backend/target/backend-verification/proxy-integration/result.json`. Chứng chỉ một ngày chỉ dùng cho test fixture, không phải chứng chỉ IP do CA cấp cho VPS. Container thử đã được xóa; không thay stack/data backend đã kiểm chứng ở mục 1–2.

Kiểm tra Compose/preflight thêm **7 trường hợp PASS**: hợp nhất demo/proxy/SMTP/Firebase và giữ đúng regex, credential fixture hợp cấu trúc, chặn SMTP không mã hóa, chặn bật hai TLS mode, chấp nhận SMTP implicit TLS, chặn nhầm Firebase project và chặn file credential bị thiếu. Bằng chứng `backend/target/backend-verification/service-preflight-49d631a3/result.json`. Đã xử lý việc Compose bỏ field `create_host_path=false` khỏi JSON chuẩn hóa; checker không báo lỗi sai đối với mount hợp lệ. Các credential này chỉ là fixture, không thể dùng gửi FCM thật.

## 2. Bộ release, máy đích và khởi động

### Máy đích

Bộ đã xuất là **Linux amd64**, không dùng cho ARM. Cấu hình đã chuẩn bị: Ubuntu 24.04, 2 vCPU, 4 GiB RAM, ít nhất 40 GiB SSD và public IPv4. Cần Docker Engine/Compose plugin, Python 3; không cần Android Studio/JDK/Maven để chạy image có sẵn. Cài theo [Docker Ubuntu](https://docs.docker.com/engine/install/ubuntu/). Chốt cấu hình theo VPS thực tế trước khi chạy.

Mở SSH theo cấu hình máy và **80/443**; không mở MySQL/MinIO/Mailpit/API backend ra Internet. Nginx chạy trên host, API publish loopback. Lệnh trên VPS chạy bằng tài khoản quản trị; backend trong container vẫn non-root. Không đổi secret/project khi volume cũ còn dùng.

### Snapshot cũ và checksum đối chiếu

Snapshot **`backend/target/backend-verification/pre-vps-release-20261009`**, hoàn tất 15:10:20 VN ngày 09/10:

| Thành phần | Kết quả |
| --- | --- |
| Payload | 46 file cấu hình/tài liệu được chọn + `images.tar` = 47 payload, có manifest riêng; toàn bộ size/checksum đã đối chiếu |
| Backend | `homely-backend:vps-verified-20261008`, ID `sha256:ffe071cda9e4e2a859d88887da7923024ee2aaa5b0da6ebd131bfb42c86bb542` |
| MinIO | `homely-minio-source:release-2025-04-22`, ID `sha256:78dd3d1fb0d04442c23548d6c3312902b415505a7464fc32f81f211494b72f49` |
| MySQL | `mysql:8.4`, ID `sha256:6ea90827b1100f8f2ae306a539f86d2c264a26ed435a2a9f75551dd5c3aeb242` |
| Mailpit | `axllent/mailpit:v1.31.3`, ID `sha256:ed9b00c609e77e99c79b93f1178255ebc271868920f2c69a8d166bd5634ed10d` |
| `images.tar` | 561504768 bytes (~535.49 MiB), SHA-256 `f42a8550ca32f17b7dd3fd012abbf4220f36b1c5f656e1a7d28dd5e432f25ae3` |
| `manifest.json` | SHA-256 `90e033634af037f5a7051784d1a48cc14331ed7c246061a50590092a7e205da9` |

Snapshot này được giữ nguyên để đối chiếu, gồm tài liệu trước khi bật Firebase/dọn docs và image trước khi bổ sung validation đăng ký thiết bị. **Bản triển khai hiện tại dùng `pre-vps-release-20261009-fcm` với image `homely-backend:vps-verified-20261009-fcm` ở mục dưới.** Các checksum trong bảng trên chỉ thuộc snapshot cũ, không dùng để kiểm tra bản mới. Env/credential luôn cấu hình riêng.

Bundle không chứa `.env`, `.env.smtp`, private key, token, backup DB/object hoặc application source đầy đủ. Dockerfile/pom chỉ đối chiếu cấu hình; **không build ứng dụng từ bundle**, phải load image và dùng cơ chế `--no-build` của helper. Dữ liệu cũ cần backup riêng. Git push không chuyển archive dưới `backend/target`.

### Bộ hiện tại cho bàn giao FE và triển khai VPS

Image hiện tại đã đạt 255 test, gồm kiểm thử MySQL 8.4.11; local đã kiểm chứng request thiết bị sai trả 400 và dữ liệu cũ/Gmail/Firebase giữ nguyên sau thay image. Bundle hiện tại nằm tại `backend/target/backend-verification/pre-vps-release-20261009-fcm`. Lệnh tạo từ gốc repository khi thư mục này chưa tồn tại:

```powershell
python -B ./Infra/vps/package_release.py --output ./backend/target/backend-verification/pre-vps-release-20261009-fcm --backend-image homely-backend:vps-verified-20261009-fcm --minio-image homely-minio-source:release-2025-04-22 --include-data-images
```

Công cụ chọn file theo allowlist, gồm 17 tài liệu đang giữ và bộ kiểm tra FCM API; ghi SHA-256/size và chỉ nhận image linux/amd64 có tag phiên bản. Công cụ không pull/build/start/push/deploy. Bộ công cụ đạt **50 test offline**: Firebase 21, cấu hình 6, packaging 14, backup 9. Khi cần xuất lại, chọn output mới; công cụ không ghi đè bundle đã có. Kiểm tra từng payload theo `manifest.json`; backend image ID hiện tại là `sha256:2560655cc7570382c279af21ce76d8f8d383eeb7acdff60003535405bbf75e49`.

### Chép snapshot tới VPS và chạy

Ví dụ PowerShell từ máy phát triển, thay địa chỉ thật:

```powershell
$RoomlyVpsAddress = 'IP_VPS_THAT'
ssh "root@$RoomlyVpsAddress" 'mkdir -p /opt/homely-releases'
scp -r ./backend/target/backend-verification/pre-vps-release-20261009-fcm "root@${RoomlyVpsAddress}:/opt/homely-releases/"
```

Trên VPS, đối chiếu checksum các file với `manifest.json` của bản mới và checksum manifest lưu riêng từ máy nguồn, rồi load image. Ví dụ này tạo **dataset demo mới**:

```bash
cd /opt/homely-releases/pre-vps-release-20261009-fcm
sha256sum images.tar manifest.json
docker image load --input images.tar
cd Infra/vps
python3 init_env.py --demo --tag vps-verified-20261009-fcm
python3 configure_smtp.py --gmail --username linhcoder2006@gmail.com --output .env.smtp
python3 check_services.py --smtp-only --smtp-env .env.smtp --network
python3 stack.py --smtp-env .env.smtp --demo --smtp config
python3 stack.py --smtp-env .env.smtp --demo --smtp up
python3 stack.py --smtp-env .env.smtp --demo --smtp check
```

Chỉ `init_env.py` một lần khi chưa có `.env`; nhập App Password ở prompt ẩn. Nếu cần dữ liệu laptop, chuyển riêng backup/env nguồn và theo [backup–restore](BACKUP_RESTORE_09_10_2026.md), không sinh secret mới cho dữ liệu cũ. Các mục tiếp theo chạy tại `Infra/vps` của release này. Giữ `--smtp-env .env.smtp --smtp`; thêm `--proxy`/`--firebase` khi đã cấu hình tương ứng.

## 3. HTTPS trực tiếp bằng IP, không cần mua tên miền

Theo thông tin chủ dự án: **chưa có tên miền**. Let's Encrypt hiện hỗ trợ chứng chỉ IP; Certbot webroot cần **5.4 trở lên**, chứng chỉ IP thuộc nhóm thời hạn ngắn khoảng 160 giờ. Phải kiểm tra tự động gia hạn. Xem [Let's Encrypt về Certbot/IP](https://letsencrypt.org/2026/03/11/shorter-certs-certbot) và [thời hạn chứng chỉ IP](https://letsencrypt.org/2026/01/15/6day-and-ip-general-availability). Không dùng chứng chỉ self-signed hoặc tắt kiểm tra TLS cho APK bàn giao.

Trên VPS Ubuntu, cài Nginx và Certbot bằng snap theo [Certbot chính thức](https://certbot.eff.org/instructions?ws=nginx&os=snap). Nếu máy đã có Certbot, kiểm tra nguồn cài/version trước khi thay:

```bash
sudo apt update
sudo apt install -y nginx python3 snapd
sudo snap install --classic certbot
sudo /snap/bin/certbot --version
```

Tại `/opt/homely-releases/pre-vps-release-20261009-fcm/Infra/vps`, thay IP ví dụ bằng **IP VPS thật**. `203.0.113.10` dưới đây chỉ là địa chỉ minh họa, không phải endpoint đã triển khai:

```bash
VPS_IP=203.0.113.10
BACKEND_ID="$(docker compose --env-file .env -f compose.yaml -f compose.demo.yaml ps -q backend)"
GATEWAY="$(docker inspect --format '{{range .NetworkSettings.Networks}}{{println .Gateway}}{{end}}' "$BACKEND_ID" | head -n 1)"
test -n "$GATEWAY"
python3 render_proxy.py --host "$VPS_IP" --trusted-proxy 127.0.0.1 --trusted-proxy ::1 --trusted-proxy "$GATEWAY"
python3 stack.py --smtp-env .env.smtp --demo --smtp --proxy config
python3 stack.py --smtp-env .env.smtp --demo --smtp --proxy up
```

Gateway lấy từ network **thật của VPS**, không sao chép IP bridge từ máy Windows. Chỉ chấp nhận các IP cụ thể; không đặt regex rỗng hoặc `.*`. Nếu đổi network/project, sinh lại cấu hình và kiểm tra limiter. Nginx đặt lại header trước khi gửi vào backend; không cấu hình Tomcat để tin toàn bộ các mạng private. [Spring Boot phía sau proxy](https://docs.spring.io/spring-boot/3.3/how-to/webserver.html#howto.webserver.use-behind-a-proxy-server).

Bootstrap chỉ phục vụ ACME; các đường dẫn khác trả 503 JSON, không nhận login qua HTTP. Trên VPS riêng cho dự án, cài bootstrap dưới đây; nếu đã có site tên `homely-api.conf`, lưu bản cấu hình hiện hành trước khi thay:

```bash
sudo install -d -m 755 /var/www/homely-acme
sudo install -m 644 generated/proxy/nginx-bootstrap.conf /etc/nginx/conf.d/homely-api.conf
sudo nginx -t
sudo systemctl enable --now nginx
sudo systemctl reload nginx
```

Port **80** phải truy cập được từ Internet cho HTTP-01. Kiểm tra cổng/firewall của nhà cung cấp trước khi gọi CA. Dùng **email thật của người quản lý VPS** cho Certbot:

```bash
ACME_EMAIL=your-real-email@example.com
sudo /snap/bin/certbot certonly --webroot --webroot-path /var/www/homely-acme --cert-name homely-api --preferred-profile shortlived --ip-address "$VPS_IP" --email "$ACME_EMAIL" --agree-tos --non-interactive
sudo install -m 644 generated/proxy/nginx-tls.conf /etc/nginx/conf.d/homely-api.conf
sudo nginx -t
sudo systemctl reload nginx
```

Nếu có lỗi cấp chứng chỉ, giữ bootstrap, đọc lỗi và xử lý nguyên nhân; không thay bằng chứng chỉ thử cho FE. Không liên tục gọi production CA khi đang sửa cấu hình. [Giới hạn cấp chứng chỉ](https://letsencrypt.org/docs/rate-limits/).

Tạo hook reload Nginx sau gia hạn, kiểm tra timer snap và dry run:

```bash
sudo install -d -m 755 /etc/letsencrypt/renewal-hooks/deploy
sudo install -m 755 nginx/renew-nginx.sh /etc/letsencrypt/renewal-hooks/deploy/homely-nginx
systemctl list-timers --all | rg 'certbot|snap.certbot'
sudo /snap/bin/certbot renew --dry-run --run-deploy-hooks
python3 stack.py --smtp-env .env.smtp --demo --smtp --proxy check
```

Nếu VPS chưa có `rg`, dùng `systemctl list-timers --all` để xem trực tiếp. Hook chạy `nginx -t` trước reload. Nginx `/ws` chuyển Upgrade/Connection và giữ header auth; không có SockJS. [NGINX WebSocket](https://nginx.org/en/docs/http/websocket.html).

Log Nginx được đặt dưới `/var/log/nginx/*.log`, dùng cơ chế logrotate của gói Ubuntu; access log không lưu query string. Metrics/actuator quản trị bị chặn public, chỉ health UP được mở. Swagger được mở cho nhóm FE trong môi trường báo cáo; thay phạm vi truy cập khi triển khai phục vụ thực tế.

## 4. SMTP thật khi vẫn giữ tài khoản báo cáo

**Bổ sung 09/10:** nên dùng file SMTP riêng do `configure_smtp.py` tạo, rồi thêm `--smtp-env .env.smtp` cho checker và stack. Quy trình nhập password ẩn, kiểm tra SMTP không cần DB và bằng chứng mới tại [MAIL_REAL_CHECK_09_10_2026.md](MAIL_REAL_CHECK_09_10_2026.md). Các lệnh cũ bên dưới vẫn dùng được khi SMTP đã được điền trực tiếp trong `.env` chính.

Sửa riêng `.env`, không in nội dung file vào log/chat. Ví dụ cấu hình Gmail dùng **App Password** khi tài khoản đủ điều kiện; hoặc dùng thông số nhà cung cấp SMTP hiện có. Không dùng mật khẩu đăng nhập thông thường thay cho credential SMTP khi nhà cung cấp yêu cầu App Password.

| Biến | STARTTLS | Implicit TLS |
| --- | --- | --- |
| `SMTP_HOST` | Host SMTP thật | Host SMTP thật |
| `SMTP_PORT` | Thường `587` | Thường `465` |
| `SMTP_STARTTLS` | `true` | `false` |
| `SMTP_SSL` | `false` | `true` |
| `SMTP_USERNAME`, `SMTP_PASSWORD` | Credential SMTP | Credential SMTP |
| `MAIL_FROM` | Sender được nhà cung cấp cho phép | Sender được nhà cung cấp cho phép |

Đặt giá trị có ký tự đặc biệt trong single quotes đúng cú pháp dotenv, đặc biệt ký tự `$`; không tự source file .env vào shell. Không bật đồng thời hai chế độ TLS. Compose demo mặc định dùng Mailpit; phải thêm **`--smtp`** để chuyển backend sang SMTP thật:

```bash
python3 check_services.py --smtp-env .env.smtp --demo --smtp --network
python3 stack.py --smtp-env .env.smtp --demo --proxy --smtp config
python3 stack.py --smtp-env .env.smtp --demo --proxy --smtp up
python3 stack.py --smtp-env .env.smtp --demo --proxy --smtp check
python3 check_services.py --smtp-env .env.smtp --demo --smtp --send-test-email your-recipient@example.com
```

Network check xác minh certificate/auth, **không gửi email** nếu không có `--send-test-email`. SMTP chấp nhận gửi chưa chứng minh thư đã vào inbox; xem inbox/spam. Sau đó đăng ký một tài khoản mới bằng API/app, nhận token xác minh, xác minh và đăng nhập. Mailpit vẫn có thể nằm trong stack demo nhưng backend với `--smtp` dùng dịch vụ thật; Mailpit chỉ bind loopback.



## 5. Firebase cùng project của Roomly

Project **`roomly-6d99d`** và Android/service-account thật đã có. OAuth và quyền gọi HTTP V1 đã đạt **200 validate-only lúc 17:59:13 VN ngày 09/10**, không cần bật lại API hoặc tạo lại project/key. Push tới thiết bị còn chờ FE tích hợp SDK/token và nghiệm thu. Hướng dẫn/bằng chứng tại [FIREBASE_SETUP.md](FIREBASE_SETUP.md).

Chép service-account qua SSH riêng, ví dụ nguồn `/root/firebase-service-account.json`. Lấy UID/GID từ backend đã chạy khi chưa bật FCM, rồi đặt file riêng ngoài release:

```bash
BACKEND_UID="$(docker compose --env-file .env -f compose.yaml -f compose.demo.yaml exec -T backend id -u)"
BACKEND_GID="$(docker compose --env-file .env -f compose.yaml -f compose.demo.yaml exec -T backend id -g)"
sudo install -d -m 700 /opt/homely-private
sudo install -o "$BACKEND_UID" -g "$BACKEND_GID" -m 400 /root/firebase-service-account.json /opt/homely-private/firebase-service-account.json
```

Không giả định UID/GID 1000/10001; thay nguồn theo file thật, không chmod world-readable. Điền trong `.env`:

```dotenv
FIREBASE_PROJECT_ID=roomly-6d99d
FIREBASE_CREDENTIALS_FILE=/opt/homely-private/firebase-service-account.json
```

Overlay đặt `GOOGLE_APPLICATION_CREDENTIALS` thành đường dẫn trong container. Kiểm tra rồi bật đúng flags sau khi proxy đã cấu hình:

```bash
python3 check_services.py --smtp-env .env.smtp --demo --smtp --firebase
python3 stack.py --smtp-env .env.smtp --demo --proxy --smtp --firebase config
python3 stack.py --smtp-env .env.smtp --demo --proxy --smtp --firebase up
python3 check_services.py --smtp-env .env.smtp --demo --smtp --firebase --container
python3 stack.py --smtp-env .env.smtp --demo --proxy --smtp --firebase check
```

`check_services.py` kiểm tra file/project/mount. Để kiểm tra lại OAuth/API/quyền trên VPS, cài dependency riêng cho `check_firebase.py` theo [hướng dẫn Firebase](FIREBASE_SETUP.md), rồi chạy từ `Infra/vps`:

```bash
/opt/homely-private/firebase-check-venv/bin/python -B check_firebase.py --env-file .env --smtp-env .env.smtp --demo --output /opt/homely-private/fcm-api-results.json
```

Thư mục/output phải mới khi chạy lại. Công cụ luôn dùng `validate_only=true`, không gửi tới điện thoại và không ghi token/private key vào kết quả. Nghiệm thu delivery cần đăng ký token từ APK Roomly và tạo sự kiện nghiệp vụ thật.

## 6. Kiểm tra từ máy FE rồi bàn giao

Từ máy **ngoài VPS**, chạy với IP thật:

```powershell
python .\Infra\vps\check_public.py --origin https://203.0.113.10
```

WSS có thể kiểm tra thêm bằng access token hiện hành trong biến môi trường **`HOMELY_ACCESS_TOKEN`** rồi chạy `--websocket`; không đặt token trong URL hoặc tham số dòng lệnh. Checker mở WSS với Authorization, chờ STOMP CONNECTED, đóng socket; không gửi chat. Chat giữa hai máy và FCM vẫn cần nghiệm thu riêng.

File **`Infra/vps/generated/proxy/fe-connection.env`** chứa URL công khai, không chứa mật khẩu/token, có thể gửi riêng cho thành viên FE sau khi checker PASS. Xem [bàn giao FE](FE_BACKEND_HANDOFF_08_10_2026.md). Không gửi `.env` thay cho file kết nối FE.

## 7. Điều kiện đánh dấu mục 3–4 hoàn thành

- **Mục 3, code/config:** cấu hình Nginx/Compose/checker có sẵn. **Nghiệm thu online:** chứng chỉ IP hợp lệ, hai mạng gọi được HTTPS, WSS bằng token thật hoạt động, limiter phân biệt IP và không nhận XFF giả.
- **Mục 4, code/config:** SMTP/Firebase overlay và guard có sẵn. **Nghiệm thu dịch vụ:** đăng ký/xác minh nhận email thật; sự kiện nghiệp vụ gửi push tới Roomly đúng người nhận, foreground/background và logout/chuyển tài khoản được kiểm tra.
- Kiểm thử fixture/local không được ghi thành VPS/SMTP/FCM thật đã PASS. Môi trường báo cáo vẫn có seed/demo/sandbox, không tự trở thành production.

Giữ cùng flags `--demo --proxy --smtp --firebase` trong mọi lệnh vận hành sau khi đã bật đủ dịch vụ. Nếu bỏ flags lúc `up`, Compose có thể đưa backend trở về cấu hình cũ. Backup/restore và tích hợp FE có điều kiện nghiệm thu riêng tại các runbook và TEST_PLAN.md.

## 8. Rollback và dữ liệu

Ghi tag/image ID, manifest, env và backup trước khi đổi bản. Rollback ứng dụng cần xét tương thích schema; không tự hạ migration hoặc xóa volume. Phục hồi vào project mới và đối chiếu ID/ảnh/account trước khi đổi proxy. Xem [BACKUP_RESTORE_09_10_2026.md](BACKUP_RESTORE_09_10_2026.md). RAM/log/restart limits đã thử local không thay thế theo dõi máy đích.
