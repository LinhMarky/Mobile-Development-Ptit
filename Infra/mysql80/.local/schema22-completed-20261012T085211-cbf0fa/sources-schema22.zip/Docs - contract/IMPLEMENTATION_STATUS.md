# Hiện trạng, đánh giá và việc còn lại của dự án

**Nghiệm thu V22 — 12/10/2026:** Đã nâng `roomly_local80` lên 22 migration, **31 bảng ứng dụng + Flyway = 32 bảng**, 347 cột. Backend native `http://127.0.0.1:18091` health UP, Hibernate validate. **282 test backend H2/MySQL 8.0.45 đạt, 0 failure/error/skipped; 24 test công cụ native và 14 test đóng gói đạt.** Đối chiếu 31 phép chiếu dữ liệu thật, 23 bộ đếm identity, 81 paths/components OpenAPI và 7 HTTP request trước/sau đều đạt; 165 file Android, 52 DTO cũ, enum công khai và V1–V21 giữ nguyên byte. Dữ liệu thật hiện chỉ có danh mục tiện ích, chưa có booking/payment; kiểm tra nâng cấp có dữ liệu nghiệp vụ dùng fixture riêng, không được hiểu là nghiệm thu dữ liệu giao dịch production.

Thiết kế hiện tại: [DATABASE.md](DATABASE.md), [ERD sáu trang](DATABASE.drawio), [đối chiếu và quyết định](DATABASE_REFACTOR.md). Bằng chứng: `backend/target/local-mysql80/schema22-tests-20261011T201116-b230c8.json`, `backend/target/local-mysql80/schema22-runtime-20261012T084745-a5907c.json`, `backend/target/local-mysql80/normalize-20261011T201134-14dc6f.json`. Backup trước nâng cấp: `Infra/mysql80/.local/before-schema22-20261011T124959-bb8ebe/`; snapshot hoàn tất ngoài build: `Infra/mysql80/.local/schema22-completed-*/`. Chưa chạy lại E2E điện thoại, gửi mail/FCM thật, MinIO hoặc Docker/VPS/MySQL 8.4 trong đợt này.

## Lịch sử nghiệm thu V21

**Nghiệm thu V21 — 11/10/2026 19:23 VN:** Đã áp dụng vào `roomly_local80`, 13 bảng/21 migration, 243 cột, health UP. 278 test H2/MySQL 8.0.45 đạt, 0 failure/error/skipped; 22 test công cụ native và 14 test đóng gói đạt. Test migration đối chiếu từng trường JSON, các cột quan hệ, cursors, Unicode/JSON/binary, ID/version và identity counters của database V20 có dữ liệu giả. Test cập nhật chỉ JSON xác nhận dữ liệu/version được lưu; JSON payment giữ đúng cờ `isTest=false`. Database thật giữ số hàng ở bảng còn lại; read markers chuyển vào conversation. 81 paths/components OpenAPI, 165 file Android, 17 controller, 52 DTO, 31 service ngoài ChatService, application.properties, openapi.yaml và V1–V20 giữ nguyên byte so với backup trước V21.

Bằng chứng V21: `backend\target\local-mysql80\schema21-tests-20261011T122142-77d83a.json` và `backend\target\local-mysql80\schema21-runtime-20261011T122316-28f12e.json`. Backup trước nâng cấp: `Infra\mysql80\.local\before-schema21-20261011T104634-dfb970`; snapshot hoàn tất ngoài build: `Infra/mysql80/.local/schema21-completed-*/`. DDL mới: `backend\target\local-mysql80\schema-20261011T122251-c25224.sql`. Bản Docker/VPS chứa V21 chưa được build/kiểm thử; mail/FCM/MinIO và E2E điện thoại không được nghiệm thu lại trong đợt schema này.

## Lịch sử nghiệm thu trước V21

Cập nhật 11/10/2026, 13:12 VN cho đợt tối ưu V20. Đây là nơi tổng hợp hiện trạng và bằng chứng, thay các báo cáo ngày/phase cũ. Contract **v1.6.0** vẫn là nguồn quy tắc nghiệp vụ. Các mốc Gmail/FCM/image và đánh giá FE bên dưới ghi nhận lần nghiệm thu 09/10; không coi là đã kiểm thử lại toàn bộ app trong đợt đổi schema.

**Hiện tại V20:** Vẫn 14 bảng, tổng cột **329→283**; bốn bảng chung giảm **222→176 cột**, index giảm **108→95**. Các cột cùng nghĩa dùng chung; enum/quan hệ có ràng buộc khác nhau giữ riêng. Đã áp dụng V20, giữ số hàng, ID và liên kết; tất cả bảng có comment, tên index/constraint theo ý nghĩa. Backend native `http://127.0.0.1:18091` health **UP**, Hibernate `validate`, API tìm phòng/tiện ích và Swagger 200, profile thiếu auth 401 đúng wrapper. OpenAPI trước/sau vẫn **81 paths và cùng components**. 165 file Android, 17 controller, 32 service, 52 DTO, application.properties, openapi.yaml và V1–V19 giữ nguyên byte so với backup trước V20.

**275 test H2/MySQL 8.0.45 đạt, 0 failure/error/skipped; 19 test công cụ đạt.** Có test nâng cấp V19 đã có dữ liệu, Unicode/JSON/binary, quan hệ booking–payment vòng, refresh rotation và identity counter. V20 giữ dữ liệu V19 đang dùng, cần dừng writers và backup; giới hạn database trống thuộc bước V18→V19. Source/JAR V20 đã kiểm chứng native, chưa build/kiểm chứng image Docker/MySQL 8.4 mới. Mail/push/ảnh và E2E Android không được nghiệm thu lại trong đợt này. Sơ đồ, SQL mẫu và đánh đổi tại [SCHEMA_14_TABLES.md](SCHEMA_14_TABLES.md).

Các đoạn V19 tiếp theo là mốc lịch sử trước đợt tối ưu này.

**Kết quả mới 10/10:** Đã chuyển database native `roomly_local80` từ 37 xuống **14 bảng vật lý, gồm Flyway**, bằng V19 sau backup. **273 test backend/H2/MySQL 8.0.45 đạt, 0 failure/error/skipped** và **16 test công cụ đạt**. Backend tại `http://127.0.0.1:18091` health **UP**, Hibernate `validate`; Swagger, OpenAPI, tìm phòng và tiện ích HTTP 200, profile thiếu auth trả 401 đúng wrapper. OpenAPI trước/sau có cùng **81 paths và components**. 165 file Android, 17 controller, 32 service, 52 DTO, application.properties và V1–V18 giữ nguyên byte so với backup trước gộp; thay đổi nằm ở entity/persistence và một query khóa lifecycle. Thiết kế và đánh đổi tại [SCHEMA_14_TABLES.md](SCHEMA_14_TABLES.md).

V19 chỉ nhận database chưa có dữ liệu nghiệp vụ; không có migration tự động dữ liệu production đang dùng. Native profile này tắt FCM/job/demo, không xác nhận gửi mail/push/ảnh hoặc E2E điện thoại. Chưa build/kiểm chứng image Docker/VPS mới chứa V19; các hash image 09/10 bên dưới thuộc phiên bản trước gộp bảng.

## 1. Nhận định tổng thể

Backend đã có các luồng chính, bảo vệ quyền/trạng thái, kiểm thử giao dịch và bộ công cụ vận hành local. Những phần làm tốt gồm global response thống nhất, refresh rotation gắn installation, chống xử lý trùng, lịch sử chat bền vững, outbox FCM và kiểm chứng MySQL/MinIO qua recreate/restore.

**Chưa thể coi toàn bộ app hoàn chỉnh hoặc sẵn sàng production.** Điểm yếu lớn nhất là Roomly chưa nối dữ liệu/session thật, chưa có nghiệm thu hai thiết bị và chưa có endpoint VPS. Các P1 nghiệp vụ bên dưới vẫn cần xử lý; test backend đạt không tự đóng những vấn đề này. Thanh toán/refund/settlement đang là sandbox, không chuyển tiền thật.

| Thành phần | Hiện trạng |
| --- | --- |
| Backend chung | `backend`: Java 17, Spring Boot 3.3.2, MySQL 8.4 trong Docker/VPS và native 8.0.45; schema V21/13 bảng, MinIO, MySQL outbox + FCM; không Kafka |
| App chính | `Frontend-Mobile-App`: Roomly, package `com.example.roomly`; thành viên FE phụ trách ghép API |
| Client tham khảo | `Homely-android`, package `com.example.homely`; kết quả build/lint của client này không phải nghiệm thu Roomly |
| Stack local đã thử | Project `homely-vps-check-20261008`, API `http://127.0.0.1:18089`; không phải URL dùng trực tiếp trên điện thoại/mạng ngoài |
| Dịch vụ thật local | Gmail TLS/auth đã xác thực lại; FCM `roomly-6d99d` OAuth/API V1 validate-only HTTP 200 đạt. Chưa nghiệm thu push tới thiết bị |
| Triển khai | Image, backup–restore và runbook đã chuẩn bị; chưa có VPS/IP/HTTPS công khai |

## 2. Phạm vi backend hiện có

| Nội dung | Hành vi hiện tại |
| --- | --- |
| Kiến trúc | Java 17 / Spring Boot 3.3.2 / MySQL / MinIO; MySQL outbox + Firebase Admin SDK gửi FCM. Không dùng Kafka; không thêm lưu nhu cầu tìm phòng. |
| REST | Contract v1.6, mặc định `/api/v1`, cấu hình qua apiPrefix. HTTP JSON có envelope `{statusCode,message,data}`; DTO/page/array nằm trong data, DTO giữ snake_case. 200 không DTO có data=null; 204/205/304 rỗng, media binary. PageResponse bên trong data giữ page 0-based, size tối đa 50. |
| Lỗi | ApiProblems tạo ProblemDTO chung; HTTP application/json envelope, data chứa ProblemDTO, no-store; field_errors gồm field/reason; trace_id + timestamp; 405/406/415 giữ semantics. STOMP giữ ProblemDTO trực tiếp. |
| Tiền | JSON response là chuỗi số nguyên VND, ví dụ `"3000000"`; phép tính trong backend dùng BigDecimal, database DECIMAL(18,0). |
| Idempotency | POST rooms/listings/wishlist/conversations/admin/notifications/bookings/payments/viewings/viewing-slots/reviews/reports cần key. Retry cùng key+payload replay response đã bọc; payload khác 409. Snapshot legacy được bọc khi replay mà không chạy mutation lần hai. GET lấy trạng thái mới; auth/multipart không dùng filter này. |
| Tìm kiếm | Một endpoint GET `/listings`: query, room_type, min/max_rent_vnd, min/max_area_m2, province_code, amenity_ids, latitude/longitude/radius_km và sort. `nearest` cần tọa độ. Không có endpoint riêng `/listings/nearby`. |
| Booking | PENDING hết hạn sau 24 giờ; APPROVED giữ phòng 48 giờ; payment attempt tối đa 15 phút và không vượt hạn giữ. Sau cọc có 7 ngày để bàn giao. Quá hạn bàn giao mở một case. |
| Thanh toán | Chỉ payment SUCCEEDED đúng booking/amount và được phân bổ mới xác nhận cọc. Webhook muộn sinh refund sandbox, không hồi sinh booking hết hạn/hủy. UUID event + hash payload chống xử lý trùng. |
| Hết hạn payment | Job mặc định 60 giây/lượt, tối đa 100 candidate; mỗi payment một transaction, khóa room → booking → payment và kiểm tra lại trạng thái/deadline. Không giải phóng hold còn hiệu lực khi chỉ một lượt payment hết hạn. |
| Thông báo nghiệp vụ | BookingTransitions ghi inbox cho hai thành viên khi đổi trạng thái. Payment gửi kết quả cho payer, dùng tham chiếu booking; webhook replay không tạo trùng thông báo. Inbox + outbox cùng transaction với nghiệp vụ. |
| Webhook mock | Chỉ đăng ký route khi MOCK_PAYMENT_ENABLED=true; bắt buộc HMAC-SHA256 trên raw body qua X-Mock-Signature. Secret tối thiểu 32 ký tự. Không nuốt mọi lỗi thành HTTP 200. |
| Demo payment | POST `/payments/{id}/simulate` chỉ khi DEMO_ENABLED=true và chỉ payer của payment được gọi; không thu tiền thật. |
| Case | REFUND_TENANT hoàn toàn bộ; FORFEIT_DEPOSIT hoàn 0; SPLIT cần tenant_refund_vnd nguyên, lớn hơn 0 và nhỏ hơn deposit. Lưu phần tenant/host, kết thúc booking, giải phóng phòng cùng transaction. NO_ACTION chỉ ghi kết luận. Phần host retained là sổ ghi nhận sandbox, không chuyển khoản thật. |
| Media | Attach kiểm tra host/verified/room ownership/purpose; không sửa ảnh khi phòng HELD. Người ngoài không xem ảnh tin ẩn. URL `/{apiPrefix}/media/{id}/content` dùng cấu hình và được kiểm tra quyền mỗi lần đọc. |
| Điều khoản | Sửa listing/fees cần trạng thái cho sửa; phòng HELD khóa thay đổi. Booking snapshot bao gồm fees. Khóa room dùng chung cho booking/catalog/viewing để tuần tự hóa mutation. |
| FCM | Inbox + delivery cùng transaction, worker gửi ngoài transaction, retry/lease/invalid token/preferences. Project roomly-6d99d và OAuth/API V1 validate-only 200 đã đạt. Đăng ký token chỉ nhận ANDROID, installation_id không trắng/tối đa 36; chưa có regex UUID. Roomly phải kiểm tra recipient/mở đúng đối tượng; nhận push thiết bị chưa nghiệm thu. |
| Auth | Secret JWT bắt buộc, access TTL 15 phút, ID tài khoản kiểm tra ở HTTP/service/STOMP. SMTP lỗi rollback đăng ký, trả 503; resend lỗi giữ token cũ. Auth có giới hạn IP/identity. Refresh rotation khóa actor trước session và giữ installation. Logout thu hồi refresh session và device; access JWT còn theo TTL nếu tài khoản vẫn active. |
| Người dùng hiện tại | Các service dùng UserResolver + AccountAccessService, kiểm tra tài khoản trong database; principal chưa authenticated/anonymous không được giải thành user. |
| Xóa tài khoản | Bộ điều kiện dùng chung khi nhận/xử lý, gồm report chưa giải quyết và refund chưa SUCCEEDED. Pending chặn mutation; job khóa lifecycle và rooms, kiểm tra lại rồi anonymize/thu hồi sessions và devices/archive tin. FAILED có thể thử lại; lịch sử giao dịch giữ nguyên. |
| Retention / metrics | Batch 200/nhóm, xóa refresh/OTT/idempotency hết hạn và push terminal sau 30 ngày; giữ lịch sử. Metrics push/retention qua Actuator, ADMIN được kiểm tra từ DB. |

Các endpoint, trạng thái và trường dữ liệu chính xác xem [PROJECT_CONTRACT.md](PROJECT_CONTRACT.md) và [openapi.yaml](openapi.yaml). Không suy ra mọi endpoint dự kiến đã có chỉ từ bảng phạm vi này; các sai khác chưa chốt nằm tại [CONTRACT_GAPS.md](CONTRACT_GAPS.md).

## 3. Bằng chứng đã chạy

Các đường dẫn dưới đây là bằng chứng local dưới `backend/target`, Git ignore. Mỗi dòng ghi đúng thời điểm chạy; giữ bản sao trước khi Maven clean/dọn build output. Bản verify 08/10 được giữ riêng khi chạy lại ngày 09/10.

| Mốc / phạm vi | Kết quả và giới hạn | Bằng chứng local |
| --- | --- | --- |
| 11/10, 12:59 VN, Maven package V20 | **275 test, 0 failure/error/skipped**, H2 + native MySQL 8.0.45 riêng; gồm nâng cấp V19 đã có dữ liệu và refresh rotation | `local-mysql80/schema20-tests-20261011T055916-d642ec.json`; log riêng dưới `Infra/mysql80/.local/schema14-test-20261011T055645-e45d03/` |
| 11/10, 13:12 VN, runtime V20 | **14 bảng, 20 migration**, 329→283 cột, index bốn bảng chung 108→95; số hàng giữ nguyên, bảng có comment, health UP; HTTP/OpenAPI và nguồn FE/service/DTO/V1–V19 không đổi | `local-mysql80/schema20-runtime-20261011T061205-1462a7.json`, `schema-20261011T061205-a62098.sql` |
| 11/10, công cụ V20 | **19 test offline đạt**, thêm bảo vệ backup đầy đủ, build/migration khớp và chấp nhận dữ liệu V19 | `Infra/mysql80/test_local_mysql.py` |
| 11/10, 12:21 VN, kiểm tra lại và bàn giao schema | Vẫn **14 bảng, 0 views, 19 migration**, health UP và 81 paths/components không đổi. Đã xuất DDL thật, lưu nguồn/báo cáo/manifest ngoài thư mục build | `local-mysql80/schema14-runtime-20261011T052124-d9c854.json`, `schema-20261011T052128-4811b8.sql`; archive `Infra/mysql80/.local/schema14-completed-20261011T052128-ae2fb5/` |
| 11/10, đóng gói release | **14 test packaging offline đạt** sau khi thêm `SCHEMA_14_TABLES.md` vào allowlist; không build/deploy image Docker mới | `Infra/vps/test_package_release.py` |
| 10/10, 22:53 VN, Maven package schema V19 | **273 test, 0 failure/error/skipped**; H2 + native MySQL 8.0.45 riêng tại 13307, gồm guard dữ liệu V18 và FK đúng loại; JAR đóng gói đạt | `local-mysql80/schema14-tests-20261010T155349-64fc7f.json`; log riêng dưới `Infra/mysql80/.local/schema14-test-20261010T155158-deb97a/` |
| 10/10, 23:00 VN, runtime native sau gộp | MySQL80/3306, **14 base tables, 0 views, 19 migration**; health UP, Hibernate validate; HTTP/API và 81 paths/components không đổi; source/backup checksum đã đối chiếu | `local-mysql80/schema14-runtime-20261010T160017-91275b.json`, `compact-20261010T155537-906fbd.json` cùng thư mục |
| 10/10, công cụ native | **16 test offline đạt**, kiểm tra không ghi đè schema/tài khoản, bảo vệ secret, backup/checksum và chỉ chấp nhận JAR/migration đã qua native tests | `Infra/mysql80/test_local_mysql.py` |
| 08/10, Maven verify | **249 test, 30 suite, 0 failure/error/skipped**; H2 và MySQL **8.4.11**, schema test riêng; đóng gói JAR đạt | `backend-verification/result-20261008.json`, `maven-verify-20261008.log` |
| 09/10, 17:58:32 VN, Maven verify mới | **255 test, 30 suite, 0 failure/error/skipped**; H2 + MySQL 8.4.11, bốn suite MySQL auth/chat migration/retention/business đều chạy; JAR đạt. Auth 21 test gồm input thiết bị sai và giữ default ANDROID | `backend-verification/result.json`, `maven-verify.log` |
| 08/10, HTTP nghiệp vụ | Auth rotation/logout; catalog/moderation/privacy; tiền dạng string; booking replay/conflict; deposit guard, payment sandbox, handover và inbox đạt | `Infra/Test-Demo.ps1` và log/report của lượt verify |
| 08/10, hạ tầng Docker | Health, SMTP qua Mailpit ở mốc này, MinIO/ảnh private, 429/deletion; recreate giữ phòng ID 6, ảnh ID 2 và attachment/bytes | `backend-verification/infrastructure-results.json`, `persistence-results.json` |
| 09/10, proxy fixture | 5 kiểm tra cấu hình và HTTPS/WSS/STOMP với fixture đạt; chặn metrics public, 413/502 JSON, bỏ query token khỏi access log. Chứng chỉ fixture không phải chứng chỉ VPS | `backend-verification/proxy-integration/result.json` |
| 09/10, dịch vụ/preflight | 7 trường hợp Compose/preflight và 6 kiểm tra SMTP offline đạt; kiểm tra TLS mode, project/file Firebase và escaping secret | `backend-verification/service-preflight-49d631a3/result.json` và báo cáo SMTP |
| 09/10, 01:50–01:52 VN, Gmail | TLS/auth/Inbox thật; đăng ký/xác minh đúng user ID 5, verified=true, mã dùng lại 400; logout rồi refresh 400 | `backend-verification/real-email-20261009/results.json`; [runbook SMTP](MAIL_REAL_CHECK_09_10_2026.md) |
| 09/10, 11:23 VN, restore | MySQL + MinIO sang project mới; phòng/ảnh/verified user giữ đúng; từ chối ghi đè target đạt. Target thử đã dừng, volume được giữ | `backend-verification/restore-results-20261009.json`; [runbook backup](BACKUP_RESTORE_09_10_2026.md) |
| 09/10, 15:10 VN, đóng gói | 4 image linux/amd64, archive/manifest có checksum; không chứa env/key/backup/source app | `backend-verification/pre-vps-release-20261009`; [bộ release và triển khai](VPS_HTTPS_SMTP_FCM_08_10_2026.md) |
| 09/10, 17:21:24 VN, Firebase local | `FCM_ENABLED=true`, project khớp Android; mount read-only và non-root đọc được; Gmail, image, volume và dữ liệu giữ nguyên; chưa gửi thử tới điện thoại | `backend-verification/firebase-runtime-results-20261009.json`; [Firebase](FIREBASE_SETUP.md) |
| 09/10, 17:59:13 VN, FCM API thật | OAuth thành công; FCM API V1 trả HTTP 200 cho validate-only. Xác nhận credential/API/quyền gửi, không giao notification | `backend-verification/fcm-network-20261009/fcm-api-results-20261009.json` |
| 09/10, 18:03:52 VN, image mới | Image vps-verified-20261009-fcm chạy healthy; DB/MinIO/Mailpit container và data volumes giữ nguyên; phòng 6/ảnh 2/user 5 giữ đúng. Gmail/FCM còn bật; input thiết bị sai trả wrapper 400, logout/refresh đạt | `backend-verification/fcm-backend-handoff-results-20261009.json` |
| 09/10, công cụ trước bàn giao | **50 test offline đạt**: FCM preflight 21, config 6, packaging 14, backup 9; đóng gói gồm tool mới và đủ 17 tài liệu | `Infra/vps/test_check_firebase.py`, `test_configuration.py`, `test_package_release.py`, `test_backup_restore.py` |
| Công cụ backup/đóng gói | 9 test backup + 14 test packaging offline đạt; 14 test packaging chạy lại sau dọn danh sách tài liệu đạt | `Infra/vps/test_backup_restore.py`, `test_package_release.py` |
| Homely tham khảo | 6 JVM test, APK build và lint đạt, 0 error/2 warning sau dọn lint; còn gợi ý AGP/OkHttp. Không phải Roomly hoặc E2E thiết bị | `Homely-android/lint-cleanup-verify.log` |

Đường dẫn viết ngắn `backend-verification/...` và `local-mysql80/...` ở bảng nằm dưới `backend/target/`. Runtime 09/10 ghi nhận **82 paths**; profile native trước/sau V19 ghi nhận **81 paths giống nhau**. Bản YAML có thể chứa route mock có điều kiện; số path theo profile/lần build không phải tiêu chí hoàn thành hoặc số bảng.

### Dấu vết bản backend hiện tại, 09/10

- Git HEAD khi verify: `cc849325bae8eb73b3825c3872e3cf7c43e0acba`; workspace có thay đổi nên HEAD không đủ mô tả toàn bộ bản đã thử.
- Source/build manifest SHA-256: `F3AD7DF471514983A5A8F9396F236106F90E5B2B4821F9DE7A85B8DBF1881587`.
- JAR local SHA-256: `2155AEA089B497E133B9A629D1BFBFB0112DE7347301B36F2AEDC431B13499D7`.
- Image `homely-backend:vps-verified-20261009-fcm`: `sha256:2560655cc7570382c279af21ce76d8f8d383eeb7acdff60003535405bbf75e49`.
- JAR trong image SHA-256: `2ce90aa6365af73650f8f3a38bb49657e066b80d91b677d7664859058142786f`. Đây là hai lượt build độc lập, không gộp hash JAR local và Docker. Tag/hash ngày 08/10 trong runbook release cũ chỉ dùng đối chiếu.

## 4. P1 còn mở

| Hạng mục | Vấn đề / hướng xử lý và điều kiện nghiệm thu |
| --- | --- |
| Report | Kiểm tra target tồn tại, visibility/ownership và membership khi report message; bổ sung queue/detail cho admin. Test target không có/không thuộc quyền và xử lý từ danh sách thật |
| Media recovery | Upload object thành công nhưng ghi DB thất bại; xóa storage lỗi nhưng DB đã DELETED; rollback DB sau khi đã xóa object. Cần compensation/retry bền vững và test lỗi ở từng bước |
| Idempotency PROCESSING | Có thể kẹt sau crash. Cần đối soát kết quả mutation trước khi retry; không xóa/expire claim tùy tiện hoặc đổi key để chạy lại nghiệp vụ |
| Roomly auth/session | Login/refresh/logout bằng API thật, lưu user/installation đúng và khôi phục sau process restart. Refresh bị từ chối thì dọn session/socket/cache; lỗi mạng/503 tạm thời không tự logout |
| Roomly host/catalog | ID thật và enum đúng; ward tùy chọn gửi null hoặc bỏ đồng bộ hai trường. Giữ tiến độ room → listing → submit qua retry để tránh tạo trùng |
| Roomly viewing/chat | Dùng `viewing_slot_id` thật và slot host cách hiện tại ít nhất 24 giờ; chat before/after cursor, reconnect/dedup và phân trang quá 50 bản ghi |
| Firebase/APK | OAuth/API V1 đã đạt. Còn ghép SDK/service/token, permission/channel và recipient filter; nghiệm thu sự kiện backend trên hai thiết bị. Validate-only không đóng nghiệm thu thiết bị |
| VPS public | IP/máy đích, HTTPS/WSS có CA tin cậy, SMTP/FCM từ máy đích và hai mạng ngoài. Chưa có bằng chứng online |

## 5. P2 và cải thiện bảo trì

- Xác minh WebP bằng RIFF + WEBP, parser/dimension; giảm N+1 của unread conversation và listing amenities.
- Rà scheduled job: batch có giới hạn, transaction nhỏ theo item, kiểm tra lại trạng thái dưới lock. Luồng case quá hạn có `NO_ACTION` cần chốt khả năng tự mở lại và thêm kiểm thử tương ứng.
- FE dùng lỗi có kiểu: `code`, `field_errors`, `Retry-After`; DTO notification preference rõ ràng. Cache theo user, lifecycle/process recreation, retry FCM, resource/image/accessibility và bản release HTTPS cần nghiệm thu.
- Email outbox là cải thiện tiếp theo. SMTP hiện gửi đồng bộ; đã xử lý lỗi gửi/rollback nhưng chưa bảo đảm atomic nếu DB commit lỗi sau khi mail đã gửi.
- Bổ sung CI Android và kiểm thử thiết bị ổn định. Workflow có trong repository không chứng minh CI đã chạy trên GitHub; connected test/emulator trước đó chưa đạt nghiệm thu.
- Nâng dependency có regression test; các cảnh báo Flyway/MySQL, open-in-view hoặc Thymeleaf không tự biến mất vì suite đạt. Rà log chẩn đoán và stack trace có kiểm soát.
- Dọn Gradle cache/crash output đang được Git theo dõi bằng một thay đổi riêng; không gộp vào thao tác xóa tài liệu.

## 6. Giới hạn vận hành cần nói đúng khi báo cáo

- Simple broker và rate limit trong process: chạy **một backend instance**. Chưa có bảo đảm delivery đa instance hoặc realtime exactly-once; REST phục hồi history.
- Logout thu hồi refresh/device, access JWT còn theo TTL nếu tài khoản active. Anonymize tài khoản vẫn giữ lịch sử tài chính và một phần chat/report; không đồng nghĩa xóa mọi dữ liệu.
- Profile prod có guard, nhưng môi trường đang thử là demo/sandbox. SMTP laptop không chứng minh outbound SMTP VPS, fixture TLS không chứng minh HTTPS public, SENT FCM không chứng minh điện thoại đã hiện thông báo.
- Backup local đã phục hồi được, chưa có lịch backup tự động/PITR/nghiệm thu mất máy. Image archive không chứa dữ liệu, env hay credential. MinIO build từ nguồn pin cần giữ thông tin nguồn/license tại [Infra/minio/README.md](../Infra/minio/README.md).

## 7. Thứ tự hoàn thiện tiếp

1. Credential/OAuth/API V1 đã đạt; giữ credential riêng, thay App Password Gmail đã chia sẻ trước khi dùng chính thức. Không cần bật lại API của project hiện tại.
2. Backend xử lý P1 report/media/idempotency; FE song song nối auth, catalog/ảnh, chat/viewing và FCM theo [bàn giao](FE_BACKEND_HANDOFF_08_10_2026.md).
3. Nghiệm thu APK thật, hai tài khoản/thiết bị và bằng chứng ID/trạng thái; chạy lại các kiểm tra bị ảnh hưởng khi đổi code. Nếu backend đổi, build/tag/đóng gói bản mới.
4. Cuối cùng chép release + cấu hình riêng tới VPS, kiểm tra HTTPS/WSS/SMTP/FCM từ mạng ngoài theo [runbook](VPS_HTTPS_SMTP_FCM_08_10_2026.md). Dùng [TEST_PLAN.md](TEST_PLAN.md) để ghi kết quả; không lấy timeline ngày báo cáo cũ làm điều kiện PASS.
