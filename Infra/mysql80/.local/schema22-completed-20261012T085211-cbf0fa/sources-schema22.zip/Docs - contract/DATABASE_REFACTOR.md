# Rà soát và refactor database/backend — 12/10/2026

## Phương án đã chọn và đã áp dụng

Chọn **Entity → cột → bảng nghiệp vụ trực tiếp**, giữ DTO/API v1.6.0. Đây là phương án phù hợp nhất để nhóm tự đọc và sửa: muốn tìm payment thì mở `payments`/`Payment`/`PaymentService`; không cần học discriminator, khóa ngoại có loại, lớp Details và JSON Schema trước.

V21 có 13 bảng nhưng 4 bảng chứa nhiều đối tượng có vòng đời khác nhau. V22 có **32 bảng gồm Flyway**. Số bảng tăng có chủ đích; không coi đó là giảm số bảng. Nếu giữ tất cả chức năng/API đã chốt, ép dưới 15 bảng sẽ tái tạo chính các bảng đa loại và cơ chế JSON mà yêu cầu mới muốn bỏ. Yêu cầu mới ưu tiên độ đơn giản thật và thay thế giới hạn bảng cũ.

Không thêm công nghệ, framework repository, event bus, lớp domain trung gian hoặc state-machine framework. Tiếp tục Spring Boot/JPA/MySQL, MinIO, SMTP và MySQL outbox/FCM đang có. Thanh toán vẫn là sandbox; chưa triển khai cổng tiền thật.

## Đã đọc và phân loại

Đã đối chiếu Entity/Repository/Service/Controller, migration V1–V21, test, PROJECT_CONTRACT, OpenAPI và Android chính tại `Frontend-Mobile-App`. `Homely-android` là client tham khảo. Audit có danh sách/hash nguồn và các lời gọi Android; việc không có màn hình Android gọi một endpoint không được dùng làm lý do xóa chức năng backend đã chốt.

| Phân loại | Thành phần | Quyết định và lý do |
|---|---|---|
| Đang dùng từ Android | Auth/profile/device token, phòng/tin/tiện ích/ảnh/yêu thích, chủ phòng, hẹn xem, chat | Giữ giao thức và luồng, chỉ đổi lưu trữ bên trong. |
| Nghiệp vụ đã chốt, backend/test đang chạy | Booking/cọc/bàn giao, case, refund, review, report, admin, inbox | Giữ dù Android hiện chưa gọi đầy đủ các nhóm này. |
| Bảo mật/đồng thời | Refresh rotation, one-time token, lifecycle lock, room/booking/payment locks, idempotency, webhook receipt, outbox retry | Giữ vì mỗi phần bảo vệ một lỗi cụ thể; không nhập các vòng đời này làm một. |
| Cơ chế lưu trữ dư thừa | 4 root đa loại, 18 Details POJO, 96 getter/setter chuyển tiếp, `record_type`, `*_kind`, Details.schemaVersion | Bỏ; kiểu bảng/cột và FK thể hiện đối tượng trực tiếp. |
| Thông tin trùng | `users.suspended` và status; `users.refresh_token` không dùng; Role Entity/Repository/danh mục | Status là nguồn duy nhất; session ở refresh_tokens; role là enum trong bảng nối. Guard từ chối legacy mơ hồ trước DDL. |
| Dự phòng công khai | VNPAY/MOMO, một số enum xử lý trung gian | Giữ giá trị API nhưng không tạo adapter/job/luồng mới. Không tuyên bố các cổng tiền này đã tích hợp. |

`auth_email_jobs [RECOVERED]` vẫn là mô tả chưa triển khai trong tài liệu cũ, không phải bảng còn thiếu phải tự thêm vào lần refactor này. SMTP hiện có timeout và rollback khi gửi lỗi; không tạo thêm kiến trúc mail outbox hoặc Kafka.

## Đối chiếu trước → sau

| Hạng mục | V21 trước refactor | V22 sau refactor | Ý nghĩa |
|---|---:|---:|---|
| Bảng vật lý, gồm Flyway | 13 | 32 | Tách đối tượng khác vòng đời, không che quan hệ trong JSON. |
| Tổng cột | 243 | 347 | Tăng do mỗi bảng có ID/version/timestamps riêng và thuộc tính trực tiếp; không quảng cáo giảm tổng cột. |
| Bảng rộng nhất | rental_records: 65 cột | bookings: 28 cột | Không còn phải đọc các cột thanh toán/hẹn xem/case trong bảng booking. |
| Root JPA SINGLE_TABLE | 4 | 0 | Bỏ cây kế thừa chỉ phục vụ ép bảng. |
| Details POJO | 18 | 0 | Sửa thuộc tính không cần đồng bộ Entity + Details + JSON Schema. |
| Getter/setter chuyển tiếp Details | 96 | 0 | Entity chứa trực tiếp dữ liệu. |
| File Java production | 268 | 247 | Xóa 24 file, thêm 3 file, giảm ròng 21 file. |
| Dòng Java production | 12871 | 12387 | Giảm 484 dòng, đo với backup trước đợt này. |
| Entity | 34 | 29 | Bỏ 4 root và Role; thêm DTO không phải Entity. |
| Trạng thái tài khoản lưu trùng | status + suspended | status | `isSuspended()` suy ra từ status; không còn cập nhật hai nguồn. |
| Nơi lưu refresh token | session table + cột legacy | refresh_tokens | Không còn cột legacy không dùng trên User. |
| Enum API / Android cần đổi | — | 0 | Enum công khai giữ byte, Android giữ 165 file nguồn. |

Các số đếm dòng/file đo trong `backend/src/main/java`; không so với Git HEAD vì workspace đã có các thay đổi từ những đợt trước.

| Cấu trúc trước | Cấu trúc sau | Lý do không gộp tiếp |
|---|---|---|
| account_records: 7 loại, gồm ROLE | 6 bảng tài khoản riêng; role_name trong user_roles | Phiên đăng nhập, token một lần, thiết bị, preferences, job xóa và lock không có cùng vòng đời. |
| catalog_items: AMENITY/FEE/WISHLIST | amenities/listing_fees/wishlist_items | Danh mục dùng chung, phí thuộc listing, yêu thích thuộc user/room. |
| rental_records: 8 loại | bookings/cases/history/slots/viewings/payments/refunds/webhook_receipts | Booking khác lần thử payment; refund khác payment; lịch sử và webhook không bị ghi đè bởi trạng thái mới. |
| activity_records: 6 loại | notifications/push_deliveries/audit_logs/idempotency_keys/reviews/reports | Inbox khác lần gửi thiết bị; review khác report; chống trùng khác audit. |
| rooms, listings, media, conversations, messages và bảng nối | Giữ trách nhiệm; sửa FK tới bảng đích mới khi cần | Không đổi mô hình đang có chỉ để làm đẹp sơ đồ. |
| Controller trả Amenity/NotificationPreferences Entity | AmenityResponse/NotificationPreferencesResponse | Không để JPA mapping quyết định JSON công khai. |
| RefundService.processRefund không có caller | Bỏ wrapper và dependency repository của wrapper | Dùng `refund` hiện có dưới lock context, không thêm tầng trung gian. |

## Từng bảng, quan hệ và trạng thái

Vai trò **tất cả 32 bảng**, ERD tổng quan và ERD nhỏ theo tài khoản, phòng/tin, thuê/cọc, chat/FCM, review/audit nằm tại [DATABASE.md](DATABASE.md). Sơ đồ chỉnh sửa được có sáu trang tại [DATABASE.drawio](DATABASE.drawio).

Quan hệ Entity chủ yếu một chiều từ bản ghi con tới chủ thể. Không tạo collection ngược để tiện vẽ ERD. Giữ `User.lifecycleLock` vì cascade/PrePersist tạo khóa khi tạo user; giữ Room.amenities và Listing.fees vì đang dùng để đọc/cập nhật dữ liệu con. Các liên kết ID hiện có như allocated_payment_id/outbox vẫn có FK trong MySQL; không bắt buộc biến mọi FK thành quan hệ hai chiều JPA.

Các trạng thái nghiệp vụ/API giữ nguyên. Đã giảm trạng thái/cơ chế **nội bộ lưu trữ** (`record_type`, khóa có loại, Details version, cờ suspended), không nhập CANCELLED và EXPIRED hoặc PENDING và APPROVED vì nguyên nhân/quyền/hạn giữ phòng khác nhau.

| Nhóm trạng thái | Luồng tối thiểu đang có | Nơi kiểm tra/ghi |
|---|---|---|
| User | ACTIVE ↔ SUSPENDED; DELETED kết thúc | AdminService, AccountDeletionProcessor, UserResolver/AuthService. |
| Room/Listing | Phòng AVAILABLE/HELD/RENTED; tin có duyệt/ẩn/hết hạn riêng | RoomService, ListingService, AdminService, BookingService/PaymentService và job. |
| Booking | PENDING → APPROVED → CONFIRMED → COMPLETED; CANCELLED/EXPIRED ở nhánh cho phép | BookingService, PaymentService, BookingTransitions; không tạo engine chuyển trạng thái mới. |
| ViewingSlot/Viewing | OPEN → BOOKED hoặc CANCELLED; hẹn REQUESTED → CONFIRMED → COMPLETED hoặc bên liên quan hủy | ViewingService; giữ NO_SHOW trong API, không thêm job chỉ để dùng enum. |
| Payment/Refund | Payment PENDING → SUCCEEDED/FAILED/EXPIRED; refund có kết quả riêng | PaymentService, RefundService, retention/expiry jobs. |
| Case/Report | Tạo mở/chờ xử lý → admin kết luận | BookingService, ReportService, AdminService; các giá trị IN_REVIEW/CLOSED/REVIEWING/DISMISSED không bị xóa âm thầm khỏi enum. |
| Deletion/Idempotency | PENDING/PROCESSING/kết quả; HTTP PROCESSING/COMPLETED | Worker retry/lease và IdempotencyFilter/Store; không gộp thành một cờ đã xong. |
| Push delivery | PENDING → PROCESSING → SENT/FAILED/SKIPPED; retry về PENDING | PushWorker/PushDeliveryRepository; PROCESSING có lease để phục hồi worker. |
| Media | READY → ATTACHED hoặc DELETED | MediaService/job; chưa gắn tài nguyên khác với đã xóa. |

Enum là giá trị cố định, không tạo bảng tra cứu cho mỗi enum. `amenities` giữ bảng vì có ID/nội dung/icon đang được API và room_amenities tham chiếu. Inventory các enum bên dưới giúp tra cứu; sự tồn tại của một giá trị không đồng nghĩa đã có một endpoint chuyển tới nó.

| Enum | Giá trị giữ nguyên |
|---|---|
| `PaymentProvider` | `MOCK_SANDBOX`, `VNPAY`, `MOMO` |
| `PaymentStatus` | `PENDING`, `SUCCEEDED`, `FAILED`, `EXPIRED` |
| `RefundReason` | `HOST_REJECTED`, `BOOKING_EXPIRED`, `CASE_DECISION`, `SYSTEM_ERROR` |
| `RefundStatus` | `PENDING`, `SUCCEEDED`, `FAILED` |
| `NotificationType` | `BOOKING_CREATED`, `BOOKING_APPROVED`, `BOOKING_REJECTED`, `BOOKING_CONFIRMED`, `BOOKING_COMPLETED`, `BOOKING_CANCELLED`, `BOOKING_EXPIRED`, `VIEWING_REQUESTED`, `VIEWING_CONFIRMED`, `VIEWING_CANCELLED`, `VIEWING_COMPLETED`, `NEW_REVIEW`, `NEW_MESSAGE`, `REPORT_RESOLVED`, `LISTING_APPROVED`, `LISTING_REJECTED`, `LISTING_SUSPENDED`, `BOOKING_CASE_RESOLVED`, `USER_SUSPENDED`, `USER_RESTORED`, `PAYMENT_SUCCEEDED`, `PAYMENT_FAILED`, `PAYMENT_EXPIRED`, `PAYMENT_REFUNDED`, `SYSTEM_ANNOUNCEMENT` |
| `MediaPurpose` | `ROOM_PHOTO`, `ROOM_VIDEO`, `AVATAR`, `CHAT_IMAGE`, `REPORT_EVIDENCE` |
| `MediaStatus` | `READY`, `ATTACHED`, `DELETED` |
| `ReportStatus` | `PENDING`, `REVIEWING`, `RESOLVED`, `DISMISSED` |
| `ViewingSlotStatus` | `OPEN`, `BOOKED`, `CANCELLED` |
| `ViewingStatus` | `REQUESTED`, `CONFIRMED`, `COMPLETED`, `CANCELLED_BY_TENANT`, `CANCELLED_BY_HOST`, `NO_SHOW` |
| `IdempotencyStatus` | `PROCESSING`, `COMPLETED` |
| `MessageContentType` | `TEXT`, `IMAGE`, `SYSTEM` |
| `ListingStatus` | `DRAFT`, `PENDING_REVIEW`, `REJECTED`, `PUBLISHED`, `HIDDEN`, `SUSPENDED`, `EXPIRED`, `ARCHIVED` |
| `RoomAvailability` | `AVAILABLE`, `HELD`, `RENTED` |
| `RoomType` | `SINGLE_ROOM`, `STUDIO`, `MINI_APARTMENT` |
| `ActorType` | `SYSTEM`, `TENANT`, `HOST`, `ADMIN` |
| `BookingCaseDecision` | `REFUND_TENANT`, `FORFEIT_DEPOSIT`, `SPLIT`, `NO_ACTION` |
| `BookingCaseType` | `DEPOSIT_DISPUTE`, `HANDOVER_OVERDUE`, `NO_SHOW`, `OTHER` |
| `BookingStatus` | `PENDING`, `APPROVED`, `CONFIRMED`, `COMPLETED`, `CANCELLED`, `EXPIRED` |
| `CaseStatus` | `OPEN`, `IN_REVIEW`, `RESOLVED`, `CLOSED` |
| `UserStatus` | `ACTIVE`, `SUSPENDED`, `DELETED` |
| `DeletionStatus` | `PENDING`, `PROCESSING`, `COMPLETED`, `FAILED` |
| `Platform` | `ANDROID` |
| `OneTimeTokenPurpose` | `EMAIL_VERIFICATION`, `PASSWORD_RESET` |
| `RoleName` | `ROLE_TENANT`, `ROLE_HOST`, `ROLE_ADMIN` |

## Nguồn chính, dữ liệu lặp có lý do và tính đúng đắn

- `users.status` quyết định quyền hoạt động; roles chỉ lưu tại user_roles. Token phiên chỉ lưu hash ở refresh_tokens. Preferences độc lập vì API có ID/version và expected_version.
- Listing là giá hiện tại; booking snapshot là điều khoản đã chấp nhận. Host/tenant/room trong booking là các bên của giao dịch, không lấy lại lịch sử từ tin đã sửa. `payments.booking_id` là lần thử thuộc booking; `bookings.allocated_payment_id` chọn lần thành công được phân bổ.
- Booking giữ trạng thái hiện hành, history ghi actor/reason/trace/time. Snapshot, history, payment, refund, webhook và audit không bị loại bỏ để giảm bảng.
- Room availability còn diễn tả chủ tự đánh dấu đã cho thuê ngoài hệ thống; không được thay toàn bộ bằng truy vấn booking. Khi giữ/hủy/hết hạn phòng, service cập nhật booking và availability cùng transaction với khóa phòng.
- Conversation preview/sequence/read cursors phục vụ danh sách/unread; ChatService khóa hội thoại và cập nhật cùng transaction với message. Không thêm read_markers trở lại.
- Inbox và outbox riêng: notification có thể đọc rồi nhưng lần gửi FCM chưa thành công; một notification gửi nhiều thiết bị. Gộp chúng sẽ mất retry độc lập.

Hai unique constraint trên booking có mục đích khác nhau và **đều được giữ**: `UNIQUE(active_room_id)` chỉ cho một APPROVED/CONFIRMED giữ phòng; `UNIQUE(tenant_id,open_room_id)` chặn cùng tenant tạo nhiều PENDING/APPROVED/CONFIRMED cho một phòng. Nhiều tenant gửi PENDING cho cùng phòng vẫn hợp lệ. Lock theo thứ tự room → booking → payment; @Version và điều kiện quyền vẫn được giữ.

Review vẫn cần booking COMPLETED đúng tenant, unique theo booking và rating 1..5. Webhook provider/event_id + payload hash chống gửi trùng/xung đột. Payment pending unique theo booking, refund unique theo payment; request replay giữ snapshot response cũ theo contract. Truy cập dữ liệu kiểm tra actor/owner/account status trước replay. Đây là điều kiện đúng nghiệp vụ, không phải phần enterprise để xóa.

## Code và migration đã thực hiện

- Thêm [V22__direct_business_tables.sql](../backend/src/main/resources/db/migration/V22__direct_business_tables.sql); V1–V21 bất biến. Tạo/sao chép 23 bảng đích, so sánh từng trường NULL-safe và row count, giữ ID/version/identity counters, tạo FK/unique/check rồi mới bỏ bốn bảng đã thay thế. Không reset/drop database, không tắt FK để ép chạy.
- Chuyển 23 Entity con sang bảng trực tiếp; bỏ AccountRecord/CatalogRecord/RentalRecord/ActivityRecord và 18 Details class. RoleName là enum collection; bỏ Role/RoleRepository và seed danh mục role. Sửa fixture theo cùng mô hình.
- Bỏ suspended/refresh_token legacy trên User và guard cập nhật hai nguồn. Guard migration từ chối refresh_token legacy khác NULL, suspended/status không khớp hoặc role lạ; không tự xóa dữ liệu mơ hồ.
- Tách DTO amenities/preferences, giữ đủ tên/kiểu trường và schema OpenAPI. Preferences dùng saveAndFlush trước mapping để response version đúng; test PATCH, đọc lại và expected_version cũ trả 409.
- Thêm UtcInstantTextConverter: 11 mốc lịch sử trước đây ở JSON dùng VARCHAR(40) chứa UTC ISO để **giữ nguyên nanosecond**, Java vẫn là Instant. Mốc dùng lọc/index/job giữ DATETIME(3). Đây là đánh đổi bảo toàn dữ liệu: không dùng so sánh chuỗi trực tiếp cho truy vấn thời gian các cột lịch sử này; nếu cần truy vấn sau này phải thiết kế chuyển kiểu/độ chính xác rõ ràng.
- Chỉ còn JSON tài liệu ở terms_snapshot và audit.detail; không có Details/schemaVersion lưu trữ cho mỗi đối tượng.
- Native helper có `normalize`: kiểm tra backup/checksum, đúng SQL/JAR đã test, schema V21/13 bảng, và không còn session ứng dụng trước nâng cấp. `inspect_database.sql`, DDL export, runner và tài liệu đóng gói theo V22.

## Kiểm chứng thực tế

**Nghiệm thu V22 — 12/10/2026:** Đã nâng `roomly_local80` lên 22 migration, **31 bảng ứng dụng + Flyway = 32 bảng**, 347 cột. Backend native `http://127.0.0.1:18091` health UP, Hibernate validate. **282 test backend H2/MySQL 8.0.45 đạt, 0 failure/error/skipped; 24 test công cụ native và 14 test đóng gói đạt.** Đối chiếu 31 phép chiếu dữ liệu thật, 23 bộ đếm identity, 81 paths/components OpenAPI và 7 HTTP request trước/sau đều đạt; 165 file Android, 52 DTO cũ, enum công khai và V1–V21 giữ nguyên byte. Dữ liệu thật hiện chỉ có danh mục tiện ích, chưa có booking/payment; kiểm tra nâng cấp có dữ liệu nghiệp vụ dùng fixture riêng, không được hiểu là nghiệm thu dữ liệu giao dịch production.

Thiết kế hiện tại: [DATABASE.md](DATABASE.md), [ERD sáu trang](DATABASE.drawio), [đối chiếu và quyết định](DATABASE_REFACTOR.md). Bằng chứng: `backend/target/local-mysql80/schema22-tests-20261011T201116-b230c8.json`, `backend/target/local-mysql80/schema22-runtime-20261012T084745-a5907c.json`, `backend/target/local-mysql80/normalize-20261011T201134-14dc6f.json`. Backup trước nâng cấp: `Infra/mysql80/.local/before-schema22-20261011T124959-bb8ebe/`; snapshot hoàn tất ngoài build: `Infra/mysql80/.local/schema22-completed-*/`. Chưa chạy lại E2E điện thoại, gửi mail/FCM thật, MinIO hoặc Docker/VPS/MySQL 8.4 trong đợt này.


| Kiểm tra | Kết quả và giới hạn |
|---|---|
| Backend H2 + MySQL native | 282 test, không skip; gồm booking cạnh tranh, cọc/case/refund/review, phân quyền, refresh rotation, idempotency, chat và FCM outbox. |
| V21 có dữ liệu → V22 | Fixture đủ các loại, quan hệ booking–payment vòng, Unicode/nội dung nhiều dòng, JSON/binary, số tiền, ID/version/counter; so sánh từng field. Boolean false, timestamp nguyên giây và nanosecond đều giữ đúng. |
| Ràng buộc DB | Ghi SQL trực tiếp sai FK/required/review duplicate/read cursor/role/boolean bị từ chối; hai booking duyệt đồng thời chỉ một giữ phòng. |
| Guard legacy | V21 status/suspended mâu thuẫn bị từ chối trước tạo bảng nghiệp vụ; 13 bảng và dữ liệu nguồn còn nguyên. |
| Database thật | 31 phép chiếu trước/sau và 23 identity counters đạt; có 15 amenities, chưa có giao dịch thật. |
| API trước/sau | 81 paths và toàn bộ components OpenAPI bằng nhau; 7 HTTP request bằng status/content-type/body. Chỉ chuẩn hóa giá trị timestamp/trace UUID của lỗi, vẫn kiểm tra kiểu/định dạng và giữ tên trường. |
| HTTP mẫu | Amenities list/detail 200, listings page 200, listing/viewing-slot không tồn tại 404, profile/notifications thiếu JWT 401. Các workflow có auth/mutation được kiểm tra bằng integration tests trên DB thử. |
| Mã FE/DTO/enum | 165 file Android, 52 DTO cũ, enum công khai và 21 migration cũ bằng byte với backup. Đây là bằng chứng server/source; không thay cho chạy app trên điện thoại. |
| Công cụ | 24 unit test native helper, 14 unit test packager đạt. JAR/SQL được đối chiếu SHA-256 với chính report native; không dùng JAR build bỏ qua test. |

DDL thực tế: `backend/target/local-mysql80/schema-20261012T084918-beda3d.sql`. Các report/DDL/audit được lưu thêm ngoài target để Maven clean không xóa bằng chứng.

## Thay đổi contract tối thiểu có thể cân nhắc — chưa thực hiện

Chỉ khi muốn bỏ bảng notification_preferences: đổi GET/PATCH `/api/v1/profile/notification-preferences` thành bốn boolean không có ID/version/expected_version và gộp vào users. FE settings phải bỏ đọc id/version và bỏ gửi expected_version; mất optimistic locking độc lập, hoặc phải dùng User version làm phát sinh conflict hồ sơ. Android hiện chưa gọi nhóm endpoint này, nhưng contract đã công bố. Tiết kiệm một bảng không bù được thay đổi ý nghĩa cập nhật nên **phương án chọn vẫn giữ bảng/API**. Không có đề xuất phá contract nào được áp dụng âm thầm.

## Điểm chưa xác minh và việc cần làm khi triển khai

1. Chưa chạy E2E trên điện thoại, mail thật, push FCM thật, MinIO và Docker/VPS/MySQL 8.4 trong đợt refactor. Những nghiệm thu cũ không được tính là đã test lại bản này.
2. Đã chứng minh nâng cấp V21 có dữ liệu và cài mới qua chuỗi migration. V19 vẫn từ chối database V18 có nghiệp vụ; trường hợp đó cần migration dữ liệu riêng, không reset để né guard.
3. MySQL DDL có implicit commit. Backup và dừng mọi writer là bắt buộc; nếu migration bị gián đoạn giữa chừng, kiểm tra trạng thái và khôi phục theo backup được duyệt, không tự Flyway repair/clean hoặc chạy lại mù quáng. Bản migration không phải một transaction DDL nguyên tử.
4. Media/report/audit vẫn có tham chiếu đa loại vốn có, được Service kiểm tra; không tuyên bố mọi liên kết đều có FK đa bảng. VNPAY/MOMO và enum dự phòng không được nghiệm thu như chức năng hoàn tất.
5. Khi deploy: build image mới từ source V22, backup và dừng backend/job cũ trước nâng schema. Không chạy JAR/image V21 với DB V22; không import DDL lên DB đang có dữ liệu. Xem runbook native/VPS.

Để trình bày dự án, bắt đầu từ sơ đồ tổng quan phòng → tin → hẹn/booking → payment; dùng trang tài khoản, chat/FCM và kỹ thuật khi giải thích bảo mật/chống lỗi. Không cần học 32 bảng cùng lúc, nhưng mỗi bảng phụ đều có lý do cụ thể ở hướng dẫn database.
