# Lịch sử schema 14 bảng — V19/V20

**Tài liệu lịch sử:** Thiết kế hiện hành V22/32 bảng tại [DATABASE.md](DATABASE.md), [DATABASE_REFACTOR.md](DATABASE_REFACTOR.md) và [DATABASE.drawio](DATABASE.drawio). Yêu cầu mới thay thế giới hạn dưới 15 bảng; các quyết định/số liệu V19/V20 bên dưới được giữ để tra cứu.

Quyết định của chủ dự án: dưới 15 bảng, giữ đầy đủ chức năng và API; chấp nhận sửa lớp persistence. Đây là thay đổi schema nội bộ, không đổi giao thức HTTP/STOMP, DTO, enum hay đường dẫn API v1.6. Không thay đổi code Android để thích nghi schema.

**Cập nhật 11/10/2026:** V20 thay cách đặt tên và dùng chung cột, giữ nguyên 14 bảng. Tổng số cột giảm **329 → 283**; bốn bảng gộp giảm **222 → 176 cột**. Không bỏ trường nghiệp vụ, chuyển dữ liệu sang một JSON tổng hợp hoặc thay logic API để giảm số cột.

| Bảng gộp | V19 | V20 | Cải thiện chính |
| --- | ---: | ---: | --- |
| account_records | 42 | 31 | Dùng chung thời gian, token hash/expiry và thông tin phiên; giữ owner riêng khi có unique constraint |
| catalog_items | 15 | 15 | Bỏ tên lặp như `fee_fee_code`; tên cột ngắn, giữ quan hệ và unique |
| rental_records | 107 | 82 | Dùng chung room/host/tenant/booking, thời gian và số tiền có cùng ý nghĩa |
| activity_records | 58 | 48 | Dùng chung actor, target và thời gian; giữ trường riêng của inbox/push/request/review/report |

`booking_status`, `payment_status`, `refund_status` vẫn riêng vì có enum và luồng khác nhau. `device_user_id`, `preference_user_id`, `deletion_user_id`, `lifecycle_user_id` vẫn có tên riêng để giữ đúng cardinality và unique; không ép mọi quan hệ thành một `user_id`.

## Nhìn theo nhóm nghiệp vụ

Sơ đồ này giúp tìm bảng theo chức năng; không liệt kê toàn bộ khóa ngoại và quan hệ tự tham chiếu.

```mermaid
flowchart TB
    subgraph ACCOUNT["Tài khoản"]
        U[users]
        UR[user_roles]
        AR[account_records]
        U --> UR --> AR
    end
    subgraph CATALOG["Phòng và tin đăng"]
        R[rooms]
        L[listings]
        RA[room_amenities]
        CI[catalog_items]
        R --> L
        R --> RA --> CI
    end
    subgraph RENTAL["Thuê, xem phòng và thanh toán"]
        RR[rental_records]
    end
    subgraph CHAT["Nhắn tin"]
        C[conversations]
        M[messages]
        RM[read_markers]
        C --> M
        C --> RM
    end
    subgraph ACTIVITY["Thông báo và lịch sử hoạt động"]
        A[activity_records]
    end
    subgraph SUPPORT["Tệp và vận hành"]
        ME[media]
        F[flyway_schema_history]
    end
    U --> R
    R --> RR
    R --> C
    AR -. "thiết bị nhận push" .-> A
    L -. "ảnh" .-> ME
```

## Danh sách đầy đủ

| STT | Bảng vật lý | Nội dung |
| --- | --- | --- |
| 1 | users | Tài khoản, hồ sơ, trạng thái, optimistic version |
| 2 | user_roles | Vai trò được cấp cho từng tài khoản |
| 3 | account_records | Vai trò, refresh/one-time/device token, preferences, yêu cầu xóa và hàng khóa lifecycle |
| 4 | rooms | Phòng, địa chỉ, vị trí, điều khoản và trạng thái còn trống |
| 5 | room_amenities | Liên kết phòng–tiện ích |
| 6 | catalog_items | Danh mục tiện ích, phí tin đăng, wishlist |
| 7 | listings | Tin đăng và trạng thái duyệt/hiển thị |
| 8 | media | Metadata ảnh/tệp; nội dung vẫn ở MinIO |
| 9 | rental_records | Booking, lịch sử booking, tranh chấp, slot/hẹn xem, payment, refund, webhook receipt |
| 10 | conversations | Hội thoại và sequence |
| 11 | messages | Tin nhắn và client_message_id chống gửi trùng |
| 12 | read_markers | Sequence đã đọc riêng theo thành viên hội thoại |
| 13 | activity_records | Inbox notification, FCM delivery, audit, idempotency, review và report |
| 14 | flyway_schema_history | Lịch sử/checksum migration; bảng kỹ thuật |

Tổng: **13 bảng ứng dụng + 1 bảng Flyway = 14 bảng**. Không dùng view để che bảng, không bỏ FCM hay nghiệp vụ thanh toán/tranh chấp.

## Cách mapping

Bốn lớp gốc `AccountRecord`, `CatalogRecord`, `RentalRecord`, `ActivityRecord` dùng JPA `SINGLE_TABLE`, phân loại bằng `record_type`. 24 entity cụ thể vẫn giữ tên, property và repository riêng. Ví dụ `RefreshTokenRepository` chỉ đọc/xóa `REFRESH_TOKEN`; `PaymentRepository` chỉ thao tác `PAYMENT`. Service không truy vấn một kho JSON tổng hợp.

Từ V20, cột cùng kiểu dữ liệu và ý nghĩa được dùng chung, như `created_at`, `updated_at`, `room_id`, `host_id`. Cột có ý nghĩa hoặc ràng buộc khác nhau vẫn giữ tên riêng. ID do bảng gốc cấp; ID/version dùng lại accessor đã có. FE tiếp tục coi ID là giá trị định danh, không suy luận thứ tự hoặc số lượng từ khoảng ID.

Unique của token là `(record_type, token_hash)`: refresh và mã xác minh không vô tình chặn nhau. Unique của thiết bị vẫn dựa trên owner thiết bị và installation; một installation được giữ nhiều refresh token lịch sử. Các index trùng đã được gộp, index/constraint có tên theo bảng và cột thay vì số thứ tự. Tất cả 14 bảng có comment giải thích vai trò.

Các cột riêng của một loại phải nullable ở mức bảng vì loại khác không dùng chúng. `CHECK` theo `record_type` giữ ràng buộc bắt buộc của từng loại. Các khóa ngoại tới bảng dùng chung kèm loại đích cố định: gán nhầm lifecycle lock thành role hoặc booking thành payment bị database từ chối. Unique index và generated column cho giữ phòng, pending payment, open case và thiết bị active được giữ trong migration.

Hàng khóa lifecycle vẫn là bản ghi riêng với tài khoản, dù dùng chung `account_records`; optimistic version và khóa pessimistic vẫn hoạt động. Khóa giao dịch, retry FCM, idempotency và cursor chat không bị thay bằng dữ liệu chỉ lưu trong RAM.

Đổi lại, bốn bảng dùng chung rộng hơn và ít chuẩn hóa hơn bản 37 bảng. Đây là sự đánh đổi để đạt giới hạn số bảng và giữ ít thay đổi service; số bảng ít hơn không tự chứng minh thiết kế tốt hơn. Khi cần tách lại để mở rộng, giữ repository/DTO và viết migration riêng.

Tham khảo cách mapping chuẩn: [Hibernate ORM 6.5 — Single table inheritance](https://docs.jboss.org/hibernate/orm/6.5/userguide/html_single/Hibernate_User_Guide.html#entity-inheritance-single-table).

## Nâng cấp và dữ liệu

**V20 hiện tại:** Giữ nguyên V1–V19 và thêm `V20__simplify_shared_columns.sql`. Migration sao chép sang bảng tạm, kiểm tra số hàng và từng giá trị có ý nghĩa, kiểm tra FK rồi đổi tên bảng cùng một bước. Giữ ID, version, liên kết, Unicode/JSON/binary và giá trị AUTO_INCREMENT; bỏ bản sao cũ sau khi đối chiếu. Lấy dữ liệu theo `CASE record_type`, không `COALESCE` các cột cũ có default ngoài subtype.

V20 hỗ trợ database V19 đã có dữ liệu, khác giới hạn V19. Phải dừng ứng dụng ghi và backup trước khi nâng cấp. Lệnh native `local_mysql.py simplify` kiểm tra backup/checksum và đúng JAR/migration đã qua native tests; helper từ chối nếu còn session ứng dụng. MySQL DDL gồm nhiều bước, không có rollback toàn bộ khi bị ngắt; cần kiểm tra trạng thái và backup trước khi phục hồi, không tự repair/reset.

**Lịch sử V19:** Chuyển một database V18 **chưa có dữ liệu người dùng/giao dịch** sang 14 bảng. ID và nội dung danh mục role/amenity được giữ nguyên. Ba bảng cũ chưa có entity/luồng sử dụng (`listing_status_history`, `viewing_status_history`, `case_evidence`) được loại cùng các bảng đã gộp; lịch sử booking và audit đang được code sử dụng vẫn được lưu.

V19 kiểm tra dữ liệu trước khi tạo bảng mới hoặc bỏ bảng cũ. Có dữ liệu nghiệp vụ thì dừng; không tự xóa dữ liệu để đạt số bảng. Cần một đợt migration dữ liệu có mapping ID/backup riêng nếu nâng cấp database đang sử dụng. Không dùng V19 để reset database production.

Database local đã được sao lưu trước đợt thay đổi tại `Infra/mysql80/.local/before-schema14-20261010T152703-d69fc6/` (SQL đầy đủ, mã nguồn và manifest SHA-256; đã Git ignore và giới hạn quyền Windows). MySQL80 hiện có vẫn chạy trên 3306. Kiểm thử native dùng một tiến trình MySQL riêng ở 13307, dữ liệu riêng và được tắt sau kiểm thử.

Kết quả kiểm thử và nghiệm thu hiện hành cập nhật tại `IMPLEMENTATION_STATUS.md`; phần này mô tả thiết kế, không tự xác nhận test đã PASS.

## Mốc V19 trước tối ưu — 11/10/2026, 12:21 VN

Đã áp dụng V19 vào `roomly_local80` trên MySQL80/3306 và kiểm tra lại lúc 12:21 VN ngày 11/10: **14 base tables, 0 views, 19 migration thành công, health UP**. OpenAPI có cùng 81 paths/components trước và sau; API tìm phòng/tiện ích và Swagger trả 200, profile thiếu auth trả 401 đúng wrapper. 273 test backend/H2/MySQL và 16 test công cụ đạt; 14 test đóng gói release cũng đạt sau khi thêm tài liệu này vào allowlist. Kết quả runtime không xác nhận mail/ảnh/push trên native profile hoặc E2E Android.

- DDL xuất từ database thật, không dữ liệu người dùng và không `DROP TABLE`: `backend/target/local-mysql80/schema-20261011T052128-4811b8.sql`.
- Report kiểm tra lại: `backend/target/local-mysql80/schema14-runtime-20261011T052124-d9c854.json`; Flyway validate: `check-20261011T052126-2761e3.json` cùng thư mục.
- Bản lưu ngoài build: `Infra/mysql80/.local/schema14-completed-20261011T052128-ae2fb5/`, gồm DDL, báo cáo, 548 file nguồn trong ZIP và manifest SHA-256; Git ignore, chỉ tài khoản Windows setup đọc được. Đây là snapshot lúc bàn giao; backup trước nâng cấp giữ riêng ở đường dẫn trên.

Mở Workbench → Schemas → refresh `roomly_local80` → Tables để xem 14 bảng. Có thể chạy các truy vấn chỉ đọc trong `Infra/mysql80/inspect_database.sql`. Swagger native: `http://127.0.0.1:18091/swagger-ui/index.html`. Không cần chạy lại setup hay import DDL vào database này.

## Tra cứu V20 trong Workbench

Chọn đúng `record_type` và các cột cần đọc, thay vì kéo ngang mọi cột bằng `SELECT *`:

```sql
SELECT id, user_id, installation_id, expires_at
FROM account_records WHERE record_type = 'REFRESH_TOKEN'
ORDER BY id DESC LIMIT 20;

SELECT id, room_id, tenant_id, host_id, booking_status, created_at
FROM rental_records WHERE record_type = 'BOOKING'
ORDER BY id DESC LIMIT 20;

SELECT id, notification_type, title, is_read, created_at
FROM activity_records WHERE record_type = 'NOTIFICATION'
ORDER BY id DESC LIMIT 20;
```

Các cột `*_kind` là phần kỹ thuật để FK trỏ đúng loại entity; không sửa thủ công. Danh sách enum/DTO/state transition vẫn lấy từ contract, không suy từ tên cột.

**Kiểm thử V20:** 275 test H2/MySQL 8.0.45 đạt, 0 failure/error/skipped; 19 test công cụ native đạt. Test migration dùng database V19 có dữ liệu giả của 24 loại entity (gồm seed ROLE/AMENITY), quan hệ booking–payment vòng, hai refresh cùng installation, tiếng Việt, JSON/binary và identity counter 5000. So sánh toàn bộ property được entity sử dụng cùng chín bảng còn lại trước/sau. Bằng chứng runtime và đường dẫn DDL mới cập nhật tại [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md).

**Runtime V20, 11/10/2026, 13:12 VN:** Đã áp dụng vào `roomly_local80`: 14 bảng, 20 migration, 283 cột, index bốn bảng chung 108→95, health UP. 81 paths/components và số hàng giữ nguyên. DDL hiện tại: `backend/target/local-mysql80/schema-20261011T061205-a62098.sql`; report: `schema20-runtime-20261011T061205-1462a7.json` cùng thư mục. Bản lưu nguồn/DDL/báo cáo ngoài build ở `Infra/mysql80/.local/schema20-completed-*/`, có manifest SHA-256. DDL V19 ở mốc cũ phía trên chỉ dùng đối chiếu; không import vào database V20.
