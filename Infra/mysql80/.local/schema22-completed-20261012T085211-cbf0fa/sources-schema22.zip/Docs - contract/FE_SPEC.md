# FRONTEND SPECIFICATIONS (FE_SPEC)

**Persistence 12/10/2026:** V22 thay schema nội bộ, giữ API v1.6/JSON/enum/status/pagination; Android không cần sửa cho đợt này. OpenAPI/HTTP đã đối chiếu, E2E trên điện thoại chưa test lại. [Báo cáo và giới hạn](DATABASE_REFACTOR.md).

**Vai trò:** Tài liệu hướng dẫn thiết kế, kiến trúc và UI Behavior cho ứng dụng Android Native.  
**Tham chiếu Business Rules & API:** Mọi logic nghiệp vụ và cấu trúc dữ liệu phải tuân theo `PROJECT_CONTRACT.md`.

**HTTP hiện tại (v1.6):** Client cần lấy payload từ `data` một lần, bao gồm login/refresh/upload. UI nhận DTO/page; lỗi đọc `data.detail/code`. STOMP giữ payload DTO trực tiếp. Auth có thể trả 429 kèm Retry-After hoặc 503 EMAIL_UNAVAILABLE. Sau yêu cầu xóa, 403 ACCOUNT_DELETION_PENDING chặn thao tác thường; GET /auth/delete-account vẫn trả trạng thái. Khi xóa hoàn tất, token không còn hợp lệ.

**Hiện trạng 09/10/2026:** App chính là Roomly trong `Frontend-Mobile-App`, package `com.example.roomly`. `ApiClient`/`ApiEnvelope`/`ChatSocket` và bằng chứng Android cũ thuộc client tham khảo `Homely-android`; không chứng minh Roomly đã ghép API. Kiến trúc/luồng dưới đây là đặc tả cần triển khai. Roomly đã có JSON Firebase, còn cần tích hợp login/session/API/FCM và nghiệm thu APK. Xem [bàn giao FE](FE_BACKEND_HANDOFF_08_10_2026.md), [Firebase](FIREBASE_SETUP.md) và [hiện trạng](IMPLEMENTATION_STATUS.md).

---

## 1. FE Architecture

- **Platform:** Android Native (Java)
- **UI Framework:** XML Layouts + ViewBinding
- **Networking:** Retrofit + OkHttp
- **Image Loading:** Glide
- **Maps:** Google Maps SDK
- **Realtime:** STOMP over WebSocket (dùng thư viện STOMP client hỗ trợ Java)
- **Architecture Pattern:** MVVM (Model-View-ViewModel)
- **State Management:** LiveData hoặc StateFlow
- **Naming Conventions:**
  - XML IDs: `snake_case` với tiền tố thành phần (`btn_submit`, `tv_title`, `rv_list`, `edt_search`).
  - Java Classes: `PascalCase`.

---

## 2. Authentication & Session

- **Flow cơ bản:** Splash → Kiểm tra Token → (Có Token hợp lệ) → Main / (Không Token) → Khách (Guest mode) hoặc Login.
- **Lưu trữ Token:** Access Token (thời gian sống ngắn) và Refresh Token (sống dài) lưu trong EncryptedSharedPreferences.
- **Xử lý 401 (TOKEN_EXPIRED):**
  - Retrofit Authenticator tự động lấy `refresh_token` gọi API `AUTH03`.
  - Nếu thành công, lưu token mới và retry request gốc với Idempotency-Key/client_message_id nguyên vẹn.
  - Nếu request refresh hợp lệ bị server từ chối vì token hết hạn/đã thu hồi, xóa local session/socket/cache của user và đưa về Login. Backend hiện trả `400 VALIDATION_FAILED` qua handler chung, chưa có code `INVALID_REFRESH_TOKEN` riêng. Lỗi mạng hoặc 503 tạm thời cần cho retry, không tự coi refresh token đã bị thu hồi.
- **Xử lý 403 (EMAIL_NOT_VERIFIED):**
  - Đẩy user sang `SCREEN-AUTH-VERIFY`, không tự động retry request.
- **Logout:** Gọi API `AUTH04`, xóa token local, ngắt STOMP connection, hủy subscribe FCM, điều hướng về Guest mode.

---

## 3. Navigation & User Flows

- **App Structure (Bottom Navigation):**
  - **Khám phá** (Tìm kiếm, Bản đồ)
  - **Đã lưu** (Wishlist)
  - **Tin nhắn** (Danh sách Conversation)
  - **Lịch trình** (Viewings, Bookings)
  - **Cá nhân** (Profile, Switch Host/Tenant mode)

- **Chế độ Host / Tenant:**
  - Nút chuyển chế độ ở tab Cá nhân.
  - Đổi chế độ = Đổi UI Bottom Navigation. Không phải đổi token (quyền được BE tự động cấp nếu User là Host hợp lệ).

---

## 4. Screen Catalog & Screen Specifications

Mọi màn hình đều phải tuân thủ xử lý 4 trạng thái UI: `Loading`, `Content`, `Empty`, `Error/Offline`.

### SCREEN-SEARCH-LIST (Danh sách tìm kiếm)
- **Purpose:** Hiển thị phòng trống theo bộ lọc.
- **Actor:** Guest, Tenant.
- **Entry points:** Bottom Nav (Khám phá).
- **API:** `CAT05 (GET /listings)`.
- **UI Sections:**
  - Thanh tìm kiếm (Text, Quận/Huyện).
  - Nút Filter (mở Modal lọc).
  - Danh sách thẻ phòng (RecyclerView) chứa giá, diện tích, location, hình cover.
- **Actions:**
  - Chạm vào thẻ → `SCREEN-ROOM-DETAIL`.
  - Bấm icon tim → Gọi `CAT11` (Save) / `CAT12` (Unsave).
- **Business Rule:** Source: PROJECT_CONTRACT BR-03.
- **Error Handling:** 422 Filter lỗi (hiện snackbar). Mất mạng hiện layout offline.

### SCREEN-ROOM-DETAIL (Chi tiết phòng)
- **Purpose:** Xem chi tiết toàn bộ, phí, cọc, tiện ích, review.
- **Actor:** Guest, Tenant.
- **API:** `CAT07 (GET /listings/{id})`.
- **UI Sections:**
  - Carousel ảnh, Nút Save, Nút Share.
  - Thông tin giá, diện tích, rule.
  - Danh sách fee chi tiết (tính tổng minh họa nếu có occupant_count).
  - Chủ phòng (Avatar, Tên, Rate).
  - Bản đồ mini.
  - Call To Action (CTA): "Hẹn xem" (Nửa phụ) và "Yêu cầu thuê" (Nửa chính).
- **Business Rule:** Source: PROJECT_CONTRACT BR-04.
- **CTA Conditions:** Nếu `availability != AVAILABLE`, disable CTA và ghi "Đang giữ / Đã thuê".

### SCREEN-VIEWING-SCHEDULE (Hẹn xem)
- **Purpose:** Tenant chọn slot thời gian rảnh của Host để đặt hẹn.
- **Actor:** Tenant (Verified).
- **API:** `VIEW01 (GET viewing-slots)`, `VIEW05 (POST viewings)`.
- **UI Sections:** Calendar week view, danh sách slot `OPEN` trong ngày.
- **Actions:** Chọn slot → Nhập note → Submit.
- **Business Rule:** Source: PROJECT_CONTRACT BR-05.

### SCREEN-BOOKING-CREATE (Tạo yêu cầu thuê)
- **Purpose:** Gửi yêu cầu giữ phòng tới Host.
- **Actor:** Tenant (Verified).
- **API:** `BOOK01 (POST /bookings)` + Yêu cầu gửi kèm Idempotency-Key.
- **UI Sections:**
  - Tóm tắt snapshot tiền (Rent, Deposit, Fees).
  - Chọn ngày dọn vào (từ lịch).
  - Số lượng người, số lượng xe.
  - Submit button.
- **Business Rule:** Source: PROJECT_CONTRACT BR-06, BR-07.
- **Error Handling:** Trả về 409 `ROOM_NOT_AVAILABLE` hoặc `TERMS_CHANGED` → Tải lại dữ liệu chi tiết, không tự động force user đồng ý.

### SCREEN-CHAT (Phòng chat)
- **Purpose:** Nhắn tin giữa Tenant và Host.
- **Actor:** Tenant, Host.
- **API (REST):** `CHAT04 (GET messages)`.
- **API (WebSocket):** Gửi frame STOMP lên `/ws`.
- **UI Sections:** Toolbar (Room info, Host info), Message List, Input bar.
- **Realtime Chat Rule:**
  - Tin nhắn do mình gửi hiển thị ngay "Đang gửi" (màu nhạt).
  - Có ACK từ broker → Hiển thị bình thường.
  - Lỗi mạng → Retry button (giữ nguyên `client_message_id`).
- **Business Rule:** Source: PROJECT_CONTRACT BR-11.

---

## 5. UI State & Action Permission Matrix

- Hành động Mutation (Tạo, Sửa, Xóa) bắt buộc:
  - Tài khoản phải **Verified**.
  - Kiểm tra kết nối mạng trước khi request.
  - Vô hiệu hóa (Disable) nút bấm ngay sau khi click, hiển thị indicator (chống spam click) nhưng gửi kèm `Idempotency-Key`.
- Hành động chỉ dành cho người tạo/sở hữu (Ví dụ: Edit Review, Cancel Booking) chỉ được hiển thị button nếu `user_id` khớp với `actor_id` trong DTO.

---

## 6. Form Validation (FE UX)

*Dù FE có validation, Backend vẫn là chốt chặn cuối.*

- **Email:** Regex email hợp lệ.
- **Password:** >= 12 ký tự (chưa cần chữ hoa/đặc biệt nếu BE không ép, nhưng tuân thủ BR).
- **Money:** Ngăn nhập ký tự không phải số. FE tự động format `#,### ₫` khi hiển thị, nhưng khi gọi API phải gỡ format, gửi đúng string số nguyên (`"3000000"`).
- **Ngày tháng:** Không cho phép chọn ngày quá khứ, giới hạn hiển thị calendar theo quy tắc ở `BR-05` và `BR-06`.

---

## 7. Error Handling (Client Side)

Ánh xạ từ `RFC 9457 ProblemDTO` của Backend:

| Lỗi BE (HTTP + Code) | Xử lý trên UI Android |
|---|---|
| `400 INVALID_JSON` | Crash/Log Analytics (Lỗi dev). |
| `400 VALIDATION_FAILED` | Highlight các TextInputs bị lỗi dựa vào mảng `field_errors`. Hiển thị thông báo. |
| `401 TOKEN_EXPIRED` | Authenticator tự động lấy token mới. |
| `401 INVALID_CREDENTIALS`| "Tên đăng nhập hoặc mật khẩu không đúng." |
| `403 EMAIL_NOT_VERIFIED` | Hiển thị modal "Vui lòng xác minh email để tiếp tục", nút dẫn ra Email Verify. |
| `404 RESOURCE_NOT_FOUND` | Hiển thị màn hình Empty State "Dữ liệu không tồn tại hoặc đã bị xóa". |
| `409 ROOM_NOT_AVAILABLE` | Popup: "Phòng này đã có người giữ. Vui lòng chọn phòng khác." Load lại trang. |
| `409 TERMS_CHANGED` | Popup: "Chủ phòng vừa cập nhật giá/điều kiện. Vui lòng xem lại." Load lại trang. |
| `429 RATE_LIMITED` | "Bạn thao tác quá nhanh. Vui lòng thử lại sau X giây." (Đọc Retry-After). |
| `500 INTERNAL_ERROR` | "Hệ thống đang gặp sự cố. Vui lòng thử lại sau." |
| Mất mạng (Timeout/IOException) | "Không có kết nối mạng. Vui lòng kiểm tra lại." |

---

## 8. Notification & Deep Linking

- **FCM (Firebase Cloud Messaging):** Backend đã xác thực OAuth và kiểm tra thật API V1 trả HTTP 200 với `validate_only:true` ngày 09/10/2026; chưa gửi push tới điện thoại. Roomly cần messaging service, permission/channel và đăng ký token theo session thật; nghiệm thu foreground/background sau khi tích hợp. AUTH10 chỉ nhận `platform: "ANDROID"` (mặc định khi bỏ trường), `installation_id` không trắng và tối đa 36 ký tự. Nên dùng UUID ổn định theo lần cài đặt; backend hiện không áp regex UUID cho trường này.
- Payload hiện tại là data-only: `notification_id`, `recipient_id`, `title`, `body`, `ref_type`, `ref_id`, tất cả là string. Không dùng bản nháp `target_type`/`target_id` hoặc field `type` để parse push.
- **Deep Link Navigation:** kiểm tra `recipient_id` khớp user đang đăng nhập cả khi hiển thị và khi bấm; dùng `ref_type`/`ref_id` mở màn hình đã tích hợp rồi tải trạng thái thật từ API. Ref chưa hỗ trợ mở inbox. Deduplicate bằng notification ID và người nhận.
- Không có producer lưu nhu cầu/tìm phòng phù hợp. Hướng dẫn token/logout và các trường hợp nghiệm thu tại [FIREBASE_SETUP.md](FIREBASE_SETUP.md).
- **Quy tắc:** Bấm vào Push không bao giờ thực hiện thẳng mutation API, chỉ dùng để mở màn hình xem trạng thái.
> **Cập nhật 03/10/2026:** Hiện trạng triển khai và các quyết định thay thế mô tả cũ nằm tại [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md). FCM dùng MySQL outbox; hướng dẫn tại [FIREBASE_SETUP.md](FIREBASE_SETUP.md). Các mốc kiểm chứng trước đây là lịch sử, không phải nghiệm thu bản hiện tại.
