# Database Roomly — thiết kế hiện hành V22

Yêu cầu hiện hành là đơn giản hóa thật, không giới hạn số bảng tùy tiện. V22 có **31 bảng ứng dụng và 1 bảng Flyway**. Mỗi đối tượng có vòng đời riêng nằm ở một bảng rõ tên; không còn bảng đa loại, `record_type`, cột `*_kind` hoặc lớp JSON `Details`.

Đọc nhận định, đối chiếu trước/sau, kiểm tra tương thích và giới hạn tại [DATABASE_REFACTOR.md](DATABASE_REFACTOR.md). Sơ đồ kéo/thả có sáu trang tại [DATABASE.drawio](DATABASE.drawio); mở bằng diagrams.net → File → Open From → Device. Sơ đồ tổng quan tập trung vào quan hệ chính; các sơ đồ nhỏ không vẽ lại mọi FK tới User.

## Vai trò mỗi bảng

| Nhóm | Bảng | Một câu giải thích |
|---|---|---|
| Tài khoản | `users` | Lưu hồ sơ và trạng thái duy nhất của người dùng. |
| Tài khoản | `user_roles` | Gán các vai trò enum TENANT/HOST/ADMIN cho người dùng. |
| Tài khoản | `refresh_tokens` | Lưu hash phiên đăng nhập để xoay vòng và thu hồi refresh token. |
| Tài khoản | `one_time_tokens` | Lưu hash mã dùng một lần để xác minh email hoặc đặt lại mật khẩu. |
| Tài khoản | `device_tokens` | Gắn thiết bị FCM đang hoạt động với đúng người dùng hiện tại. |
| Tài khoản | `notification_preferences` | Lưu các lựa chọn nhận thông báo có version cập nhật riêng. |
| Tài khoản | `account_deletion_requests` | Theo dõi yêu cầu xóa tài khoản và kết quả xử lý nền. |
| Tài khoản | `account_lifecycle_locks` | Tuần tự hóa thao tác người dùng với quá trình xóa tài khoản. |
| Phòng/tin đăng | `rooms` | Lưu phòng vật lý, chủ phòng, địa chỉ và tình trạng cho thuê. |
| Phòng/tin đăng | `listings` | Lưu tin quảng cáo, giá, duyệt tin và thời hạn hiển thị. |
| Phòng/tin đăng | `amenities` | Lưu danh mục tiện ích có ID, tên và icon cho bộ lọc/phòng. |
| Phòng/tin đăng | `room_amenities` | Gán tiện ích cho phòng bằng khóa ngoại. |
| Phòng/tin đăng | `listing_fees` | Lưu các khoản phí phụ của một tin đăng. |
| Phòng/tin đăng | `wishlist_items` | Lưu một phòng yêu thích duy nhất cho mỗi người dùng. |
| Phòng/tin đăng | `media` | Lưu metadata và khóa file ảnh/video trong MinIO. |
| Hẹn xem | `viewing_slots` | Lưu khung giờ mà chủ phòng cho phép hẹn xem. |
| Hẹn xem | `viewings` | Lưu cuộc hẹn của khách và kết quả xem phòng. |
| Thuê phòng | `bookings` | Lưu yêu cầu thuê, snapshot điều khoản và tiến độ bàn giao. |
| Thuê phòng | `booking_status_history` | Ghi ai đã đổi trạng thái booking, lúc nào và vì sao. |
| Thuê phòng | `booking_cases` | Lưu tranh chấp và kết luận phân bổ tiền cọc. |
| Thanh toán | `payments` | Lưu từng lần thanh toán cọc sandbox và kết quả của nó. |
| Thanh toán | `refunds` | Lưu khoản hoàn lại duy nhất và số tiền thực tế của một payment. |
| Thanh toán | `payment_webhook_receipts` | Ghi event nhà cung cấp đã xử lý để chống webhook trùng/xung đột. |
| Chat | `conversations` | Lưu hai thành viên, số thứ tự và vị trí đã đọc của hội thoại. |
| Chat | `messages` | Lưu nội dung chat và mã gửi của client để chống tin nhắn trùng. |
| Thông báo | `notifications` | Lưu nội dung thông báo trong hộp thư của từng người dùng. |
| Thông báo | `push_deliveries` | Theo dõi gửi FCM tới từng thiết bị với lease và retry. |
| Tương tác | `reviews` | Lưu đánh giá duy nhất của một booking đã hoàn thành. |
| Tương tác | `reports` | Lưu báo cáo vi phạm và kết quả xử lý của admin. |
| Kỹ thuật | `audit_logs` | Ghi lại thao tác quản trị để kiểm tra và giải thích lịch sử. |
| Kỹ thuật | `idempotency_keys` | Ghi kết quả HTTP để gửi lại cùng thao tác không tạo giao dịch mới. |
| Kỹ thuật | `flyway_schema_history` | Ghi migration đã áp dụng và checksum của chúng. |

## ERD tổng quan

```mermaid
erDiagram
    users ||--o{ rooms : hosts
    rooms ||--o| listings : advertises
    rooms ||--o{ bookings : requests
    bookings ||--o{ payments : attempts
    payments ||--o| refunds : refunds
    bookings ||--o{ booking_cases : disputes
    bookings ||--o{ booking_status_history : history
    bookings ||--o| reviews : verified_review
    rooms ||--o{ viewing_slots : offers
    viewing_slots ||--o{ viewings : appointments
    rooms ||--o{ conversations : context
    conversations ||--o{ messages : contains
    users ||--o{ notifications : inbox
    notifications ||--o{ push_deliveries : devices
```

## Các sơ đồ nhỏ

### Tài khoản và bảo mật

```mermaid
erDiagram
    users ||--o{ user_roles : enum_roles
    users ||--o{ refresh_tokens : sessions
    users ||--o{ one_time_tokens : verify_or_reset
    users ||--o{ device_tokens : FCM
    users ||--o| notification_preferences : settings
    users ||--o| account_deletion_requests : deletion
    users ||--|| account_lifecycle_locks : serialize_mutations
```

### Phòng và tin đăng

```mermaid
erDiagram
    users ||--o{ rooms : host
    rooms ||--o| listings : advertises
    listings ||--o{ listing_fees : costs
    rooms ||--o{ room_amenities : has
    amenities ||--o{ room_amenities : assigned
    users ||--o{ wishlist_items : saves
    rooms ||--o{ wishlist_items : saved_room
    users ||--o{ media : uploads
```

`media.resource_type/resource_id` giữ API gắn ảnh hiện có; dịch vụ kiểm tra loại tài nguyên và quyền sở hữu. Đây là tham chiếu đa loại có chủ đích, không phải FK MySQL tới nhiều bảng.

### Thuê phòng và giao dịch

```mermaid
erDiagram
    rooms ||--o{ bookings : requested
    bookings ||--o{ booking_status_history : records
    bookings ||--o{ booking_cases : disputed
    bookings ||--o{ payments : attempts
    payments ||--o| refunds : refunded
    payments |o--o{ payment_webhook_receipts : events
    bookings |o--o| payments : allocated_payment
    rooms ||--o{ viewing_slots : offers
    viewing_slots ||--o{ viewings : appointments
```

`bookings.allocated_payment_id` chọn payment thành công được phân bổ; `payments.booking_id` ghi booking của từng lần thử. Hai liên kết có ý nghĩa khác nhau, không phải hai nguồn cho cùng thông tin.

### Chat và FCM

```mermaid
erDiagram
    users ||--o{ conversations : tenant_or_host
    conversations ||--o{ messages : contains
    users ||--o{ notifications : inbox
    users ||--o{ device_tokens : devices
    notifications ||--o{ push_deliveries : sends
    device_tokens ||--o{ push_deliveries : receives
```

### Đánh giá, báo cáo và kiểm tra lịch sử

```mermaid
erDiagram
    bookings ||--o| reviews : completed_stay
    users ||--o{ reviews : reviewer
    rooms ||--o{ reviews : reviewed
    users ||--o{ reports : reporter
    users |o--o{ audit_logs : actor
```

`reports.target_type/target_id` và mục tiêu audit là tham chiếu đa loại đã có; Service kiểm tra tài nguyên. `idempotency_keys` lưu dấu vân tay của actor/method/path/client key và kết quả HTTP, không tạo thêm quan hệ User cần đồng bộ.

## Dữ liệu nào là nguồn chính?

- Tài khoản: `users.status`; `isSuspended()` chỉ suy ra từ status. Vai trò là enum trong `user_roles`.
- Phòng và tin: Room là tài sản; Listing là quảng cáo có duyệt/hết hạn. Hai vòng đời khác nhau nên giữ hai bảng.
- Giá hiện tại nằm ở Listing/fees; giá và điều khoản đã chấp nhận nằm trong Booking snapshot để lịch sử không đổi khi chủ sửa tin.
- Booking giữ trạng thái hiện hành; history ghi các lần chuyển. Payment/refund ghi tiền; case ghi kết luận phân bổ cọc.
- Conversation giữ số thứ tự, preview và hai vị trí đã đọc. ChatService cập nhật chúng cùng transaction với Message, khóa hội thoại trước khi cấp sequence.
- Inbox Notification và delivery FCM có vòng đời riêng: một thông báo có thể gửi tới nhiều thiết bị và phải retry độc lập.

## JSON và quan hệ

Chỉ còn JSON cho `bookings.terms_snapshot` và `audit_logs.detail`: nội dung của chúng là tài liệu có cấu trúc. ID/quan hệ, token, trạng thái, số tiền, nội dung hiển thị và thời gian đều là cột trực tiếp. Không dùng JSON/chuỗi ID để né bảng nối. Response HTTP được dựng từ DTO, không trả Entity amenities/preferences ra ngoài.

11 mốc lịch sử chuyển từ JSON được giữ dưới dạng UTC ISO `VARCHAR(40)` qua `UtcInstantTextConverter`, Java/API vẫn là `Instant`; cách này giữ nguyên nanosecond. Mốc dùng lọc/index/job tiếp tục `DATETIME(3)`. Không lọc/sắp xếp trực tiếp các chuỗi lịch sử có độ dài phần lẻ khác nhau như cột thời gian SQL; xem đánh đổi trong báo cáo refactor.

## Mở Workbench và đọc dữ liệu

Refresh schema `roomly_local80`; không import DDL đè database đang chạy. Có thể chạy [inspect_database.sql](../Infra/mysql80/inspect_database.sql):

```sql
SELECT id, room_id, tenant_id, host_id, status, rent_vnd, deposit_vnd
FROM bookings ORDER BY id DESC LIMIT 20;

SELECT id, user_id, notification_type, title, is_read
FROM notifications ORDER BY id DESC LIMIT 20;

SELECT b.id, b.status, p.id AS payment_id, p.status AS payment_status,
       p.amount_vnd, r.amount_vnd AS refunded_vnd
FROM bookings b
LEFT JOIN payments p ON p.booking_id=b.id
LEFT JOIN refunds r ON r.payment_id=p.id
ORDER BY b.id DESC, p.id DESC LIMIT 20;
```

## Nâng cấp và mở rộng

V22 sao chép đủ các đối tượng từ V21 sang bảng riêng, đối chiếu từng cột bằng so sánh NULL-safe, giữ ID/version/thời gian/AUTO_INCREMENT, tạo lại FK trước khi bỏ các bảng đa loại đã thay thế. Không reset/drop database. V1–V21 không sửa checksum. Có guard từ chối dữ liệu legacy mơ hồ thay vì tự xóa: refresh_token cũ khác NULL hoặc status và suspended không khớp. Phải xử lý riêng trường hợp đó trước khi nâng cấp.

Thêm một thuộc tính nội bộ: thêm field vào Entity và migration mới; chỉ sửa DTO khi thực sự muốn công khai trường đó. Không cần tạo Details/JSON Schema hoặc sửa bảng dùng chung của nhiều nghiệp vụ. Các enum công khai giữ nguyên để FE ổn định; không xây thêm luồng xử lý cho các giá trị dự phòng chưa dùng.

V22 chỉ nghiệm thu từ V21 và cài mới qua chuỗi migration hiện có. V19 có guard từ chối V18 đã chứa nghiệp vụ; không thể dùng V22 để vượt qua guard đó. Kết quả triển khai, test và những môi trường chưa xác minh nằm tại [DATABASE_REFACTOR.md](DATABASE_REFACTOR.md).
