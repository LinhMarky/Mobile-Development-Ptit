# Tài liệu dự án Roomly

Cập nhật 12/10/2026. Backend chung ở `backend`; app chính **Roomly** ở `Frontend-Mobile-App` (`com.example.roomly`). `Homely-android` là client tham khảo. Contract hiện tại **v1.6.0**, HTTP JSON dùng `{statusCode,message,data}`; MySQL outbox + FCM, không Kafka.

Schema **V22** có **31 bảng ứng dụng + Flyway = 32 bảng**. Bỏ bảng đa loại/Details, Entity dùng cột trực tiếp; role enum, status tài khoản một nguồn. **282 test H2/MySQL 8.0.45 đạt**, 24 test công cụ native và 14 test đóng gói đạt. OpenAPI/HTTP đối chiếu trước–sau, Android/DTO cũ giữ nguyên; giới hạn nghiệm thu tại [DATABASE_REFACTOR.md](DATABASE_REFACTOR.md). Sơ đồ và vai trò mỗi bảng tại [DATABASE.md](DATABASE.md).

Mốc kiểm chứng 09/10, trước V22: backend local MySQL 8.4 có **255 test đạt**; Gmail TLS/auth, backup–restore DB/ảnh và **FCM OAuth/API V1 validate-only HTTP 200** đạt. Image tại thời điểm đó đã chạy, đăng ký thiết bị sai trả 400 đúng wrapper. **Roomly chưa ghép API/FCM đầy đủ; push trên điện thoại và VPS/HTTPS công khai chưa nghiệm thu.** Không dùng mốc này để kết luận image V22 đã chạy. Phạm vi, bằng chứng và P1/P2 còn mở tại [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md).

## Đọc theo công việc

| Công việc | Tài liệu |
| --- | --- |
| Xem hiện trạng, bằng chứng và việc cần làm tiếp | [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md) |
| Quy tắc nghiệp vụ, DTO, enum và API | [PROJECT_CONTRACT.md](PROJECT_CONTRACT.md), [openapi.yaml](openapi.yaml) |
| Kiến trúc backend / Android | [BE_SPEC.md](BE_SPEC.md), [FE_SPEC.md](FE_SPEC.md) |
| Database V22, vai trò từng bảng và sơ đồ kéo/thả | [DATABASE.md](DATABASE.md), [DATABASE.drawio](DATABASE.drawio) |
| Ghép Roomly với backend | [FE_BACKEND_HANDOFF_08_10_2026.md](FE_BACKEND_HANDOFF_08_10_2026.md), [GLOBAL_RESPONSE_WRAPPER.md](GLOBAL_RESPONSE_WRAPPER.md) |
| Chat, reconnect và STOMP | [CHAT.md](CHAT.md) |
| Admin, inbox và notification | [ADMIN_NOTIFICATIONS.md](ADMIN_NOTIFICATIONS.md) |
| Firebase, SDK/token Android, USB/emulator và nghiệm thu push | [FIREBASE_SETUP.md](FIREBASE_SETUP.md) |
| SMTP Gmail và kiểm tra email thật | [MAIL_REAL_CHECK_09_10_2026.md](MAIL_REAL_CHECK_09_10_2026.md) |
| Đóng gói image, triển khai VPS, HTTPS/WSS | [VPS_HTTPS_SMTP_FCM_08_10_2026.md](VPS_HTTPS_SMTP_FCM_08_10_2026.md) |
| Backup và phục hồi DB + MinIO | [BACKUP_RESTORE_09_10_2026.md](BACKUP_RESTORE_09_10_2026.md) |
| Nghiệm thu và vấn đề cần chốt | [TEST_PLAN.md](TEST_PLAN.md), [CONTRACT_GAPS.md](CONTRACT_GAPS.md) |
| Lịch sử thay đổi giao thức | [CHANGELOG.md](CHANGELOG.md) |

## Cách duy trì tài liệu

Business rules và giao thức nằm trong contract/OpenAPI; các spec và hướng dẫn dẫn chiếu tới đó. Kết quả đã chạy và giới hạn nằm trong `IMPLEMENTATION_STATUS.md`; kịch bản trong test plan không tự chứng minh đã PASS. Ghi nhận mâu thuẫn/chưa chốt tại `CONTRACT_GAPS.md` trước khi thay rule.

Các báo cáo ngày cũ, lịch phase và hướng dẫn trùng đã được gộp. Tên có ngày của các runbook được giữ để tránh đổi đường dẫn, nội dung hiện hành lấy theo ngày cập nhật trong file. Credential, token, env riêng, backup dữ liệu và build output không đưa vào tài liệu/Git/bộ bàn giao FE.

Hướng dẫn chạy local tại [Infra/README.md](../Infra/README.md); công cụ vận hành tại [Infra/vps/README.md](../Infra/vps/README.md). Theo yêu cầu chủ dự án, hoàn thiện local và APK trước, triển khai VPS là bước cuối.
