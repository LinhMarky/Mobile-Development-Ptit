package com.homely.rental.common.persistence;

import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

import static org.assertj.core.api.Assertions.*;

/** Real constraints and upgrade guard. Uses the explicitly selected isolated MySQL schemas. */
@EnabledIfEnvironmentVariable(named = "HOMELY_TEST_MYSQL_URL", matches = ".+")
class CompactSchemaMysqlTest {
    private static String url() { return System.getenv("HOMELY_TEST_MYSQL_URL"); }
    private static String user() { return System.getenv().getOrDefault("HOMELY_TEST_MYSQL_USER", "root"); }
    private static String password() { return System.getenv().getOrDefault("HOMELY_TEST_MYSQL_PASSWORD", ""); }
    private static Connection connect() throws SQLException { return DriverManager.getConnection(url(), user(), password()); }

    @BeforeAll static void migrate() {
        Flyway.configure().dataSource(url(), user(), password()).cleanDisabled(true)
                .baselineOnMigrate(false).load().migrate();
    }

    @Test void cohesiveBusinessTablesAndNoCompatibilityViews() throws Exception {
        try (var connection = connect(); var sql = connection.createStatement()) {
            var tables = new ArrayList<String>();
            try (var rows = sql.executeQuery("SELECT table_name FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type='BASE TABLE'")) {
                while (rows.next()) tables.add(rows.getString(1));
            }
            assertThat(tables).containsExactlyInAnyOrder("users", "user_roles", "rooms", "room_amenities",
                    "listings", "media", "conversations", "messages", "flyway_schema_history",
                    "refresh_tokens", "one_time_tokens", "device_tokens", "notification_preferences",
                    "account_deletion_requests", "account_lifecycle_locks", "amenities", "listing_fees",
                    "wishlist_items", "bookings", "booking_cases", "booking_status_history", "viewing_slots",
                    "viewings", "payments", "refunds", "payment_webhook_receipts", "notifications",
                    "push_deliveries", "audit_logs", "idempotency_keys", "reviews", "reports");
            try (var rows = sql.executeQuery("SELECT COUNT(*) FROM information_schema.views WHERE table_schema=DATABASE()")) {
                rows.next(); assertThat(rows.getInt(1)).isZero();
            }
        }
    }

    @Test void requiredTokenFieldsAreEnforcedByDatabase() throws Exception {
        try (var connection = connect(); var sql = connection.createStatement()) {
            assertThatThrownBy(() -> sql.executeUpdate("INSERT INTO one_time_tokens(expires_at) VALUES(NOW())"))
                    .isInstanceOf(SQLException.class);
            assertThatThrownBy(() -> sql.executeUpdate("INSERT INTO refresh_tokens(token_hash) VALUES('missing-user')"))
                    .isInstanceOf(SQLException.class);
        }
    }

    @Test void fixedRolesRejectUnknownRoleNamesAndUnknownUsers() throws Exception {
        try (var connection = connect(); var sql = connection.createStatement()) {
            connection.setAutoCommit(false);
            try {
                sql.executeUpdate("INSERT INTO users(email,password,full_name) VALUES('schema14-fk@example.test','hash','FK test')");
                long userId;
                try (var rows = sql.executeQuery("SELECT LAST_INSERT_ID()")) { rows.next(); userId = rows.getLong(1); }
                assertThatThrownBy(() -> sql.executeUpdate("INSERT INTO user_roles(user_id,role_name) VALUES(" + userId + ",'UNKNOWN')"))
                        .isInstanceOf(SQLException.class);
                assertThatThrownBy(() -> sql.executeUpdate("INSERT INTO user_roles(user_id,role_name) VALUES(-1,'ROLE_ADMIN')"))
                        .isInstanceOf(SQLException.class);
            } finally { connection.rollback(); }
        }
    }

    @Test
    @EnabledIfEnvironmentVariable(named = "HOMELY_SCHEMA14_GUARD_URL", matches = ".+roomly_schema14_guard.*")
    void v19RefusesExistingUserDataBeforeDroppingOrCreatingApplicationTables() throws Exception {
        String guardUrl = System.getenv("HOMELY_SCHEMA14_GUARD_URL");
        Flyway.configure().dataSource(guardUrl, user(), password()).cleanDisabled(true)
                .baselineOnMigrate(false).target("18").load().migrate();
        try (var connection = DriverManager.getConnection(guardUrl, user(), password()); var sql = connection.createStatement()) {
            sql.executeUpdate("INSERT INTO users(email,password,full_name) VALUES('preserve@example.test','hash','Keep me')");
            assertThatThrownBy(() -> Flyway.configure().dataSource(guardUrl, user(), password())
                    .cleanDisabled(true).baselineOnMigrate(false).load().migrate()).isInstanceOf(RuntimeException.class);
            try (var rows = sql.executeQuery("SELECT COUNT(*) FROM users WHERE email='preserve@example.test'")) {
                rows.next(); assertThat(rows.getInt(1)).isEqualTo(1);
            }
            try (var rows = sql.executeQuery("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type='BASE TABLE'")) {
                rows.next(); assertThat(rows.getInt(1)).isEqualTo(37);
            }
            try (var rows = sql.executeQuery("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name IN ('account_records','catalog_items','rental_records','activity_records')")) {
                rows.next(); assertThat(rows.getInt(1)).isZero();
            }
        }
    }
}
