package com.homely.rental.common.persistence;

import com.homely.rental.auth.entity.*;
import com.homely.rental.auth.repository.*;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ContextConfiguration;

import java.time.Instant;
import java.util.UUID;

import static org.assertj.core.api.Assertions.*;

@DataJpaTest(showSql = false, properties = {"spring.flyway.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop", "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.H2Dialect"})
@ContextConfiguration(classes = CompactPersistenceTest.Config.class)
class CompactPersistenceTest {
    @Configuration
    @EntityScan("com.homely.rental")
    @EnableJpaRepositories("com.homely.rental")
    @Import(com.homely.rental.common.config.AuditConfig.class)
    static class Config { }

    @Autowired UserRepository users;
    @Autowired OneTimeTokenRepository tokens;
    @Autowired RefreshTokenRepository refreshTokens;
    @Autowired NotificationPreferenceRepository preferences;
    @Autowired AccountLifecycleLockRepository lifecycle;
    @Autowired AccountDeletionRequestRepository deletionRequests;
    @Autowired EntityManager em;

    private User user() {
        User user = new User();
        user.setEmail(UUID.randomUUID() + "@example.test");
        user.setPassword("test-password-hash");
        user.setFullName("Persistence test");
        return users.saveAndFlush(user);
    }

    private OneTimeToken token(User user) {
        OneTimeToken token = new OneTimeToken();
        token.setUser(user);
        token.setTokenHash(UUID.randomUUID().toString());
        token.setPurpose(OneTimeToken.OneTimeTokenPurpose.EMAIL_VERIFICATION);
        token.setExpiresAt(Instant.now().minusSeconds(60));
        return tokens.saveAndFlush(token);
    }

    @Test void enumRolesPersistWithTheUserAndLifecycleLock() {
        User user = user();
        user.getRoles().add(RoleName.ROLE_HOST);
        user.getRoles().add(RoleName.ROLE_TENANT);
        users.saveAndFlush(user);
        em.clear();
        User loaded = users.findById(user.getId()).orElseThrow();
        assertThat(loaded.getRoles()).containsExactlyInAnyOrder(RoleName.ROLE_HOST, RoleName.ROLE_TENANT);
        assertThat(loaded.isHost()).isTrue();
        assertThat(loaded.isAdmin()).isFalse();
        assertThat(lifecycle.lock(user.getId())).isPresent();
    }

    @Test void expiryBulkDeletePreservesRolesPreferencesAndLifecycleLocks() {
        User user = user();
        user.getRoles().add(RoleName.ROLE_TENANT); users.saveAndFlush(user);
        NotificationPreference preference = new NotificationPreference(); preference.setUser(user);
        preferences.saveAndFlush(preference);
        token(user);
        assertThat(tokens.deleteExpiredTokens(Instant.now())).isEqualTo(1);
        em.clear();
        assertThat(tokens.count()).isZero();
        assertThat(users.findById(user.getId()).orElseThrow().getRoles()).contains(RoleName.ROLE_TENANT);
        assertThat(preferences.findByUserId(user.getId())).isPresent();
        assertThat(lifecycle.lock(user.getId())).isPresent();
    }

    @Test void clearingUserRolesDoesNotDeleteTokensOrLifecycleLocks() {
        User user = user();
        user.getRoles().add(RoleName.ROLE_HOST); users.saveAndFlush(user);
        OneTimeToken token = token(user);
        user.getRoles().clear(); users.saveAndFlush(user);
        em.clear();
        assertThat(users.findById(user.getId()).orElseThrow().getRoles()).isEmpty();
        assertThat(tokens.findById(token.getId())).isPresent();
        assertThat(lifecycle.lock(user.getId())).isPresent();
    }

    @Test void refreshRotationKeepsHistoryForOneInstallationAndSeparateTokenPurposes() {
        User user = user();
        String installation = UUID.randomUUID().toString();
        for (String hash : new String[]{"a".repeat(64), "b".repeat(64)}) {
            RefreshToken refresh = new RefreshToken();
            refresh.setUser(user);
            refresh.setInstallationId(installation);
            refresh.setDeviceName("Test phone");
            refresh.setTokenHash(hash);
            refresh.setExpiresAt(Instant.now().plusSeconds(3600));
            refreshTokens.saveAndFlush(refresh);
        }
        OneTimeToken verification = token(user);
        verification.setTokenHash("a".repeat(64));
        tokens.saveAndFlush(verification);
        em.clear();
        assertThat(refreshTokens.count()).isEqualTo(2);
        assertThat(tokens.findByTokenHashAndUsedFalse("a".repeat(64))).isPresent();
    }

    @Test void historicalInstantKeepsNanosecondsAcrossJpaRoundTrip() {
        AccountDeletionRequest request = new AccountDeletionRequest();
        request.setUser(user());
        request.setCompletedAt(Instant.parse("2026-10-11T18:00:00.123456789Z"));
        deletionRequests.saveAndFlush(request);
        Long id = request.getId();
        em.clear();
        assertThat(deletionRequests.findById(id).orElseThrow().getCompletedAt())
                .isEqualTo(Instant.parse("2026-10-11T18:00:00.123456789Z"));
    }

    @Test void updatingPreferencesIsPersistedAndVersioned() {
        User user = user();
        NotificationPreference preference = new NotificationPreference();
        preference.setUser(user);
        preferences.saveAndFlush(preference);
        Long id = preference.getId();
        em.clear();
        NotificationPreference loaded = preferences.findById(id).orElseThrow();
        int beforeVersion = loaded.getVersion();
        loaded.setChatPush(false);
        loaded.setTransactionEmail(false);
        em.flush();
        em.clear();
        NotificationPreference saved = preferences.findById(id).orElseThrow();
        assertThat(saved.isChatPush()).isFalse();
        assertThat(saved.isTransactionEmail()).isFalse();
        assertThat(saved.isTransactionPush()).isTrue();
        assertThat(saved.getVersion()).isEqualTo(beforeVersion + 1);
    }
}
