package com.homely.rental.common.persistence;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import java.sql.*;
import java.util.*;
import static org.assertj.core.api.Assertions.*;

/** Populated upgrades: business history, cross-table cycles and values must all survive. */
@EnabledIfEnvironmentVariable(named="HOMELY_SCHEMA22_UPGRADE_URL", matches=".+roomly_schema22_upgrade.*")
class DirectBusinessTablesMysqlTest {
    private static final ObjectMapper JSON = new ObjectMapper();
    private static String user() { return System.getenv().getOrDefault("HOMELY_TEST_MYSQL_USER", "root"); }
    private static String password() { return System.getenv().getOrDefault("HOMELY_TEST_MYSQL_PASSWORD", ""); }
    private static Flyway flyway(String url, String target) {
        return Flyway.configure().dataSource(url,user(),password()).target(target).cleanDisabled(true).load();
    }
    private static JsonNode resource(String name) throws Exception {
        try(var stream=DirectBusinessTablesMysqlTest.class.getResourceAsStream("/schema/"+name)) {
            return JSON.readTree(Objects.requireNonNull(stream));
        }
    }
    private static void populatedV21(String url) throws Exception {
        flyway(url,"19").migrate();
        JsonNode fixture=resource("v19-upgrade-fixture.json");
        try(var connection=DriverManager.getConnection(url,user(),password());var sql=connection.createStatement()) {
            for(JsonNode row:fixture.get("rows")) SchemaSimplificationMysqlTest.insert(connection,row);
            sql.executeUpdate("UPDATE rental_records SET booking_allocated_payment_id="+fixture.get("payment_id").asLong()+" WHERE id="+fixture.get("booking_id").asLong());
        }
        flyway(url,"21").migrate();
    }
    private static Map<String,List<List<String>>> snapshot(Connection connection,JsonNode projections,String stage) throws SQLException {
        var result=new LinkedHashMap<String,List<List<String>>>();
        for(var entry:projections.properties())
            result.put(entry.getKey(),SchemaSimplificationMysqlTest.read(connection,entry.getValue().get(stage).asText()));
        return result;
    }

    @Test void populatedV21PreservesEveryEntityFieldIdentityCounterAndRelationship() throws Exception {
        String url=System.getenv("HOMELY_SCHEMA22_UPGRADE_URL");
        populatedV21(url);
        JsonNode projections=resource("v22-upgrade-projections.json");
        try(var connection=DriverManager.getConnection(url,user(),password());var sql=connection.createStatement()) {
            for(String root:List.of("account_records","catalog_items","rental_records","activity_records"))
                sql.execute("ALTER TABLE "+root+" AUTO_INCREMENT=10000");
            // False must not become true when leaving JSON storage.
            sql.executeUpdate("UPDATE rental_records SET details=JSON_SET(details,'$.isTest',CAST('false' AS JSON)),updated_at=updated_at WHERE record_type='PAYMENT'");
            sql.executeUpdate("UPDATE rental_records SET details=JSON_SET(details,'$.succeededAt','2026-10-11T18:00:00.123456789Z'),updated_at=updated_at WHERE record_type='PAYMENT'");
            sql.executeUpdate("UPDATE rental_records SET details=JSON_SET(details,'$.completedAt','2026-10-11T18:00:00Z'),updated_at=updated_at WHERE record_type='REFUND'");
            var before=snapshot(connection,projections,"before");
            flyway(url,"22").migrate();
            var after=snapshot(connection,projections,"after");
            for(var entry:before.entrySet())
                assertThat(after.get(entry.getKey())).as(entry.getKey()).isEqualTo(entry.getValue());
            for(var entry:projections.properties()) if(entry.getValue().has("table")) {
                String table=entry.getValue().get("table").asText();
                try(var rows=sql.executeQuery("SELECT AUTO_INCREMENT FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='"+table+"'")) {
                    rows.next(); assertThat(rows.getLong(1)).as(table).isGreaterThanOrEqualTo(10000);
                }
            }
            try(var rows=sql.executeQuery("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND (column_name='record_type' OR column_name LIKE '%\\_kind' OR column_name='details')")) {
                rows.next(); assertThat(rows.getInt(1)).isZero();
            }
            // Real FK targets, uniqueness and required columns continue to protect direct SQL writes.
            for(String invalid:List.of(
                    "UPDATE payments SET booking_id=-1",
                    "UPDATE push_deliveries SET device_id=-1",
                    "UPDATE reviews SET booking_id=-1",
                    "UPDATE notifications SET title=NULL",
                    "UPDATE notification_preferences SET transaction_push=2",
                    "UPDATE notification_preferences SET transaction_email=2",
                    "UPDATE notification_preferences SET chat_push=2",
                    "UPDATE notification_preferences SET recommendation_push=2",
                    "UPDATE payments SET is_test=2",
                    "INSERT INTO user_roles(user_id,role_name) VALUES(1,'UNKNOWN')",
                    "INSERT INTO reviews(booking_id,reviewer_id,room_id,rating,visible) SELECT booking_id,reviewer_id,room_id,rating,visible FROM reviews LIMIT 1",
                    "UPDATE conversations SET host_read_sequence=sequence+1"))
                assertThatThrownBy(()->sql.executeUpdate(invalid)).as(invalid).isInstanceOf(SQLException.class);
        }
    }

    @Test
    @EnabledIfEnvironmentVariable(named="HOMELY_SCHEMA22_GUARD_URL", matches=".+roomly_schema22_guard.*")
    void ambiguousLegacyAccountStateIsRejectedBeforeBusinessDdl() throws Exception {
        String url=System.getenv("HOMELY_SCHEMA22_GUARD_URL");
        populatedV21(url);
        try(var connection=DriverManager.getConnection(url,user(),password());var sql=connection.createStatement()) {
            sql.executeUpdate("UPDATE users SET suspended=1,status='ACTIVE' WHERE id=1");
            assertThatThrownBy(()->flyway(url,"22").migrate()).isInstanceOf(RuntimeException.class);
            try(var rows=sql.executeQuery("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type='BASE TABLE'")) {
                rows.next(); assertThat(rows.getInt(1)).isEqualTo(13);
            }
            try(var rows=sql.executeQuery("SELECT COUNT(*) FROM account_records")) {
                rows.next(); assertThat(rows.getInt(1)).isPositive();
            }
            try(var rows=sql.executeQuery("SELECT suspended,status FROM users WHERE id=1")) {
                rows.next(); assertThat(rows.getBoolean(1)).isTrue(); assertThat(rows.getString(2)).isEqualTo("ACTIVE");
            }
        }
    }
}
