package com.homely.rental.auth.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * Stores FCM device tokens for push notifications (AUTH10).
 */
@Entity
@Table(name = "device_tokens", uniqueConstraints = {
        @UniqueConstraint(name = "uk_device_tokens_1", columnNames = {"user_id", "installation_id"})
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DeviceToken {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "token", length = 4096, columnDefinition = "TEXT", nullable = false)
    private String token;

    @Enumerated(EnumType.STRING)
    @Column(name = "platform", length = 10, nullable = false)
    private Platform platform = Platform.ANDROID;

    @Column(name = "installation_id", length = 36, nullable = false)
    private String installationId;

    @Column(name = "active", nullable = false)
    private boolean active = true;

    @Column(name = "created_at", updatable = false, nullable = true)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at", nullable = true)
    private Instant updatedAt = Instant.now();

    public enum Platform {
        ANDROID
    }

    @Column(name = "device_name", nullable = false, length = 100)
    private String deviceName;

}
