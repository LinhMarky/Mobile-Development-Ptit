package com.homely.rental.payment.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "refunds", uniqueConstraints = {
        @UniqueConstraint(name = "uk_refunds_1", columnNames = {"payment_id"}),
        @UniqueConstraint(name = "uk_refunds_2", columnNames = {"provider_refund_id"})
})
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Refund {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payment_id", nullable = false)
    private Payment payment;

    @Column(name = "provider_refund_id", length = 100, nullable = true)
    private String providerRefundId;

    @Column(name = "amount_vnd", precision = 18, scale = 0, nullable = false)
    private BigDecimal amountVnd;

    @Enumerated(EnumType.STRING)
    @Column(name = "refund_reason", length = 30, nullable = true)
    private RefundReason reason;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 20, nullable = false)
    private RefundStatus status = RefundStatus.PENDING;

    @Column(name = "attempt_count", nullable = false)
    private int attemptCount = 0;

    @Column(name = "next_attempt_at", nullable = true)
    private Instant nextAttemptAt;

    @Column(name = "created_at", updatable = false, nullable = true)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at", nullable = true)
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }

    @Column(name = "last_error_code", nullable = true, length = 100)
    private String lastErrorCode;

    @Convert(converter = com.homely.rental.common.persistence.UtcInstantTextConverter.class)
    @Column(name = "completed_at", nullable = true, length = 40)
    private Instant completedAt;

}
