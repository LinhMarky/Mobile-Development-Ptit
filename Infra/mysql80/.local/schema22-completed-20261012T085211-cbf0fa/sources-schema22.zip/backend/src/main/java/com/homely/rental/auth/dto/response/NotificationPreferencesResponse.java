package com.homely.rental.auth.dto.response;

import com.homely.rental.auth.entity.NotificationPreference;
import io.swagger.v3.oas.annotations.media.Schema;

/** Stable public shape, independent of how preferences are stored. */
@Schema(name = "NotificationPreference")
public record NotificationPreferencesResponse(
        Long id, int version, boolean transactionPush, boolean transactionEmail,
        boolean chatPush, boolean recommendationPush) {
    public static NotificationPreferencesResponse from(NotificationPreference preferences) {
        return new NotificationPreferencesResponse(preferences.getId(), preferences.getVersion(),
                preferences.isTransactionPush(), preferences.isTransactionEmail(),
                preferences.isChatPush(), preferences.isRecommendationPush());
    }
}
