package com.homely.rental.auth.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;

/** A separate lock row keeps account lifecycle locks away from user foreign keys. */
@Entity
@Table(name = "account_lifecycle_locks", uniqueConstraints = {
        @UniqueConstraint(name = "uk_account_lifecycle_locks_1", columnNames = {"user_id"})
})
@Getter
@NoArgsConstructor
public class AccountLifecycleLock {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    public AccountLifecycleLock(User user) { this.user = user; }
}
