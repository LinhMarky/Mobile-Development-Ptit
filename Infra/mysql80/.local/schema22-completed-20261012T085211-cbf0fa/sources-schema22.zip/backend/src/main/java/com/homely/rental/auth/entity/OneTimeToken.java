package com.homely.rental.auth.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * One-time token for email verification and password reset flows (SEC-03).
 */
@Entity
@Table(name = "one_time_tokens", uniqueConstraints = {
        @UniqueConstraint(name = "uk_one_time_tokens_1", columnNames = {"token_hash"})
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OneTimeToken {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;

    @Column(name = "token_hash", length = 64, nullable = false)
    private String tokenHash;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(name = "purpose", length = 30, nullable = false)
    private OneTimeTokenPurpose purpose;

    @Column(name = "used", nullable = false)
    private boolean used = false;

    @Column(name = "expires_at", nullable = false)
    private Instant expiresAt;

    @Column(name = "created_at", updatable = false, nullable = true)
    private Instant createdAt = Instant.now();

    public enum OneTimeTokenPurpose {
        EMAIL_VERIFICATION,
        PASSWORD_RESET
    }
}
