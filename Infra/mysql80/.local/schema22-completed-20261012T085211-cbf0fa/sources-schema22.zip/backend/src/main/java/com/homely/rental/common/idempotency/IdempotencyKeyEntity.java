package com.homely.rental.common.idempotency;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * Stores idempotency keys to prevent duplicate processing of POST mutation requests.
 * Key = Idempotency-Key header + principal.id + request_path.
 */
@Entity
@Table(name = "idempotency_keys", uniqueConstraints = {
        @UniqueConstraint(name = "uk_idempotency_keys_1", columnNames = {"idempotency_key"})
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class IdempotencyKeyEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;

    /** SHA-256 of principal, HTTP method, request path and client key. */
    @Column(name = "idempotency_key", length = 512, nullable = false)
    private String idempotencyKey;

    @Column(name = "request_hash", length = 64, nullable = true)
    private String requestHash;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 20, nullable = false)
    private IdempotencyStatus status = IdempotencyStatus.PROCESSING;

    @Column(name = "expires_at", nullable = false)
    private Instant expiresAt;

    @Column(name = "created_at", updatable = false, nullable = true)
    private Instant createdAt = Instant.now();

    public enum IdempotencyStatus {
        PROCESSING,
        COMPLETED
    }

    @Column(name = "response_content_type", nullable = true, length = 255)
    private String responseContentType;

    @Column(name = "response_location", nullable = true, columnDefinition = "TEXT")
    private String responseLocation;

    @Column(name = "response_status_code", nullable = true)
    private Integer responseStatusCode;

    @Column(name = "response_body", nullable = true)
    private String responseBody;

}
