package com.homely.rental.booking.entity;

import com.homely.rental.auth.entity.User;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(name = "booking_cases")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class BookingCase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "booking_id", nullable = false)
    private Booking booking;

    @Enumerated(EnumType.STRING)
    @Column(name = "type", length = 30, nullable = false)
    private BookingCaseType type;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "opened_by", nullable = true)
    private User openedBy;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 20, nullable = false)
    private CaseStatus status = CaseStatus.OPEN;

    @Enumerated(EnumType.STRING)
    @Column(name = "decision", length = 30, nullable = true)
    private BookingCaseDecision decision;
    @Column(name = "tenant_refund_vnd", precision=18, scale=0, nullable = true)
    private java.math.BigDecimal tenantRefundVnd;
    @Column(name = "host_retained_vnd", precision=18, scale=0, nullable = true)
    private java.math.BigDecimal hostRetainedVnd;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "resolved_by", nullable = true)
    private User resolvedBy;

    @Column(name = "created_at", updatable = false, nullable = true)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at", nullable = true)
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }

    @Column(name = "description", nullable = false, columnDefinition = "TEXT")
    private String description;

    @Column(name = "resolution_note", nullable = true, columnDefinition = "TEXT")
    private String resolutionNote;

    @Convert(converter = com.homely.rental.common.persistence.UtcInstantTextConverter.class)
    @Column(name = "resolved_at", nullable = true, length = 40)
    private Instant resolvedAt;

}
