package com.homely.rental.common.persistence;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import java.time.Instant;

/**
 * Preserve the exact UTC instant previously stored in V21 JSON, including nanoseconds.
 * Used only for historical fields that are not filtered/indexed; job deadlines stay DATETIME.
 */
@Converter
public class UtcInstantTextConverter implements AttributeConverter<Instant, String> {
    @Override public String convertToDatabaseColumn(Instant value) {
        return value == null ? null : value.toString();
    }

    @Override public Instant convertToEntityAttribute(String value) {
        return value == null ? null : Instant.parse(value);
    }
}
