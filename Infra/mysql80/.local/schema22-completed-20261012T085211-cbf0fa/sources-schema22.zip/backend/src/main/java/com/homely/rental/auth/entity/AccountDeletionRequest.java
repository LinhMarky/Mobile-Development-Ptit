package com.homely.rental.auth.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * Account deletion request entity (§2.8).
 * Tracks user-initiated account deletion with status lifecycle.
 */
@Entity
@Table(name = "account_deletion_requests", uniqueConstraints = {
        @UniqueConstraint(name = "uk_account_deletion_requests_1", columnNames = {"user_id"})
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccountDeletionRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 20, nullable = false)
    private DeletionStatus status = DeletionStatus.PENDING;

    @Column(name = "created_at", updatable = false, nullable = true)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at", nullable = true)
    private Instant updatedAt = Instant.now();

    public enum DeletionStatus {
        PENDING,
        PROCESSING,
        COMPLETED,
        FAILED
    }

    @Column(name = "reason", nullable = false, length = 1000)
    private String reason = "";

    @Column(name = "failure_code", nullable = true, length = 100)
    private String failureCode;

    @Convert(converter = com.homely.rental.common.persistence.UtcInstantTextConverter.class)
    @Column(name = "completed_at", nullable = true, length = 40)
    private Instant completedAt;

}
