package com.homely.rental.catalog.controller;

import com.homely.rental.catalog.dto.response.AmenityResponse;
import com.homely.rental.catalog.repository.AmenityRepository;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Amenity controller (CAT14).
 * Public endpoint for listing all available amenities.
 */
@RestController
@RequestMapping(path = "${apiPrefix}/amenities")
@RequiredArgsConstructor
public class AmenityController {

    private final AmenityRepository amenityRepository;

    @GetMapping
    @Operation(summary = "List all amenities")
    public ResponseEntity<List<AmenityResponse>> getAllAmenities() {
        return ResponseEntity.ok(amenityRepository.findAll().stream().map(AmenityResponse::from).toList());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get amenity detail")
    public ResponseEntity<AmenityResponse> getAmenity(@PathVariable Long id) {
        return ResponseEntity.ok(AmenityResponse.from(amenityRepository.findById(id)
                .orElseThrow(() -> new com.homely.rental.common.exception.ResourceNotFoundException("Amenity", id))));
    }
}
