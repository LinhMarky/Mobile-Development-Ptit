-- V22: direct tables and columns, fixed role enums, one account status source.
-- Stop writers and take a full backup. MySQL DDL is not transactional.
-- Copy and verify before removing old storage. Never disable FK checks or reset data.
CREATE TEMPORARY TABLE schema22_guard (ok INT NOT NULL, CONSTRAINT ck_schema22_guard CHECK(ok=1));
-- Refuse ambiguous legacy account data instead of discarding or guessing it.
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM users WHERE refresh_token IS NOT NULL OR suspended <> (status='SUSPENDED');
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM account_records WHERE record_type='ROLE' AND BINARY role_name NOT IN ('ROLE_TENANT','ROLE_HOST','ROLE_ADMIN');
SELECT AUTO_INCREMENT INTO @account_records_next FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='account_records';
SELECT AUTO_INCREMENT INTO @catalog_items_next FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='catalog_items';
SELECT AUTO_INCREMENT INTO @rental_records_next FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='rental_records';
SELECT AUTO_INCREMENT INTO @activity_records_next FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='activity_records';

-- REFRESH_TOKEN
CREATE TABLE `refresh_tokens` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `token_hash` varchar(64) NOT NULL,
    `user_id` bigint NOT NULL,
    `installation_id` varchar(36) NOT NULL,
    `expires_at` datetime(3) NOT NULL,
    `revoked` tinyint(1) NOT NULL DEFAULT '0',
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `device_name` varchar(100) NOT NULL,
    UNIQUE KEY `uk_refresh_tokens_1` (`token_hash`),
    KEY `ix_refresh_tokens_1` (`expires_at`),
    KEY `ix_refresh_tokens_2` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='RefreshToken - direct business storage';
INSERT INTO `refresh_tokens` (`id`,`version`,`token_hash`,`user_id`,`installation_id`,`expires_at`,`revoked`,`created_at`,`device_name`)
SELECT s.id,s.version,s.`token_hash`,s.`user_id`,s.`installation_id`,s.`expires_at`,s.`revoked`,s.`created_at`,CASE WHEN JSON_EXTRACT(s.details,'$.deviceName') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.deviceName'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.deviceName')) END FROM `account_records` s WHERE s.record_type='REFRESH_TOKEN';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `account_records` s LEFT JOIN `refresh_tokens` d ON d.id=s.id WHERE s.record_type='REFRESH_TOKEN' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`token_hash` <=> s.`token_hash` AND d.`user_id` <=> s.`user_id` AND d.`installation_id` <=> s.`installation_id` AND d.`expires_at` <=> s.`expires_at` AND d.`revoked` <=> s.`revoked` AND d.`created_at` <=> s.`created_at` AND d.`device_name` <=> CASE WHEN JSON_EXTRACT(s.details,'$.deviceName') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.deviceName'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.deviceName')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `refresh_tokens`)=(SELECT COUNT(*) FROM `account_records` WHERE record_type='REFRESH_TOKEN'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `refresh_tokens` AUTO_INCREMENT=',@account_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- ONE_TIME_TOKEN
CREATE TABLE `one_time_tokens` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `token_hash` varchar(64) NOT NULL,
    `user_id` bigint NOT NULL,
    `purpose` varchar(30) NOT NULL,
    `used` tinyint(1) NOT NULL DEFAULT '0',
    `expires_at` datetime(3) NOT NULL,
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    UNIQUE KEY `uk_one_time_tokens_1` (`token_hash`),
    KEY `ix_one_time_tokens_1` (`expires_at`),
    KEY `ix_one_time_tokens_2` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='OneTimeToken - direct business storage';
INSERT INTO `one_time_tokens` (`id`,`version`,`token_hash`,`user_id`,`purpose`,`used`,`expires_at`,`created_at`)
SELECT s.id,s.version,s.`token_hash`,s.`user_id`,s.`token_purpose`,s.`used`,s.`expires_at`,s.`created_at` FROM `account_records` s WHERE s.record_type='ONE_TIME_TOKEN';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `account_records` s LEFT JOIN `one_time_tokens` d ON d.id=s.id WHERE s.record_type='ONE_TIME_TOKEN' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`token_hash` <=> s.`token_hash` AND d.`user_id` <=> s.`user_id` AND d.`purpose` <=> s.`token_purpose` AND d.`used` <=> s.`used` AND d.`expires_at` <=> s.`expires_at` AND d.`created_at` <=> s.`created_at`));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `one_time_tokens`)=(SELECT COUNT(*) FROM `account_records` WHERE record_type='ONE_TIME_TOKEN'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `one_time_tokens` AUTO_INCREMENT=',@account_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- DEVICE_TOKEN
CREATE TABLE `device_tokens` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `user_id` bigint NOT NULL,
    `token` text NOT NULL,
    `platform` varchar(10) NOT NULL DEFAULT 'ANDROID',
    `installation_id` varchar(36) NOT NULL,
    `active` tinyint(1) NOT NULL DEFAULT '1',
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `device_name` varchar(100) NOT NULL,
    `active_installation_id` varchar(36) GENERATED ALWAYS AS (IF(active,installation_id,NULL)) STORED,
    `active_token_hash` varchar(64) GENERATED ALWAYS AS (IF(active,SHA2(token,256),NULL)) STORED,
    UNIQUE KEY `uk_device_tokens_1` (`user_id`,`installation_id`),
    UNIQUE KEY `uk_device_tokens_2` (`active_installation_id`),
    UNIQUE KEY `uk_device_tokens_3` (`active_token_hash`),
    KEY `ix_device_tokens_1` (`user_id`,`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='DeviceToken - direct business storage';
INSERT INTO `device_tokens` (`id`,`version`,`user_id`,`token`,`platform`,`installation_id`,`active`,`created_at`,`updated_at`,`device_name`)
SELECT s.id,s.version,s.`device_user_id`,s.`fcm_token`,s.`platform`,s.`installation_id`,s.`device_active`,s.`created_at`,s.`updated_at`,CASE WHEN JSON_EXTRACT(s.details,'$.deviceName') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.deviceName'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.deviceName')) END FROM `account_records` s WHERE s.record_type='DEVICE_TOKEN';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `account_records` s LEFT JOIN `device_tokens` d ON d.id=s.id WHERE s.record_type='DEVICE_TOKEN' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`user_id` <=> s.`device_user_id` AND d.`token` <=> s.`fcm_token` AND d.`platform` <=> s.`platform` AND d.`installation_id` <=> s.`installation_id` AND d.`active` <=> s.`device_active` AND d.`created_at` <=> s.`created_at` AND d.`updated_at` <=> s.`updated_at` AND d.`device_name` <=> CASE WHEN JSON_EXTRACT(s.details,'$.deviceName') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.deviceName'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.deviceName')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `device_tokens`)=(SELECT COUNT(*) FROM `account_records` WHERE record_type='DEVICE_TOKEN'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `device_tokens` AUTO_INCREMENT=',@account_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- PREFERENCES
CREATE TABLE `notification_preferences` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `user_id` bigint NOT NULL,
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `transaction_push` tinyint(1) NOT NULL DEFAULT '1',
    `transaction_email` tinyint(1) NOT NULL DEFAULT '1',
    `chat_push` tinyint(1) NOT NULL DEFAULT '1',
    `recommendation_push` tinyint(1) NOT NULL DEFAULT '1',
    CONSTRAINT `ck_preferences_booleans` CHECK (
        transaction_push IN (0,1) AND transaction_email IN (0,1)
        AND chat_push IN (0,1) AND recommendation_push IN (0,1)),
    UNIQUE KEY `uk_notification_preferences_1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='NotificationPreference - direct business storage';
INSERT INTO `notification_preferences` (`id`,`version`,`user_id`,`created_at`,`updated_at`,`transaction_push`,`transaction_email`,`chat_push`,`recommendation_push`)
SELECT s.id,s.version,s.`preference_user_id`,s.`created_at`,s.`updated_at`,CASE WHEN JSON_EXTRACT(s.details,'$.transactionPush') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.transactionPush'))='NULL' THEN NULL ELSE IF(JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.transactionPush'))='true',1,0) END,CASE WHEN JSON_EXTRACT(s.details,'$.transactionEmail') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.transactionEmail'))='NULL' THEN NULL ELSE IF(JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.transactionEmail'))='true',1,0) END,CASE WHEN JSON_EXTRACT(s.details,'$.chatPush') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.chatPush'))='NULL' THEN NULL ELSE IF(JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.chatPush'))='true',1,0) END,CASE WHEN JSON_EXTRACT(s.details,'$.recommendationPush') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.recommendationPush'))='NULL' THEN NULL ELSE IF(JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.recommendationPush'))='true',1,0) END FROM `account_records` s WHERE s.record_type='PREFERENCES';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `account_records` s LEFT JOIN `notification_preferences` d ON d.id=s.id WHERE s.record_type='PREFERENCES' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`user_id` <=> s.`preference_user_id` AND d.`created_at` <=> s.`created_at` AND d.`updated_at` <=> s.`updated_at` AND d.`transaction_push` <=> CASE WHEN JSON_EXTRACT(s.details,'$.transactionPush') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.transactionPush'))='NULL' THEN NULL ELSE IF(JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.transactionPush'))='true',1,0) END AND d.`transaction_email` <=> CASE WHEN JSON_EXTRACT(s.details,'$.transactionEmail') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.transactionEmail'))='NULL' THEN NULL ELSE IF(JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.transactionEmail'))='true',1,0) END AND d.`chat_push` <=> CASE WHEN JSON_EXTRACT(s.details,'$.chatPush') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.chatPush'))='NULL' THEN NULL ELSE IF(JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.chatPush'))='true',1,0) END AND d.`recommendation_push` <=> CASE WHEN JSON_EXTRACT(s.details,'$.recommendationPush') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.recommendationPush'))='NULL' THEN NULL ELSE IF(JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.recommendationPush'))='true',1,0) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `notification_preferences`)=(SELECT COUNT(*) FROM `account_records` WHERE record_type='PREFERENCES'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `notification_preferences` AUTO_INCREMENT=',@account_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- DELETION_REQUEST
CREATE TABLE `account_deletion_requests` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `user_id` bigint NOT NULL,
    `status` varchar(20) NOT NULL DEFAULT 'PENDING',
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `reason` varchar(1000) NOT NULL DEFAULT '',
    `failure_code` varchar(100) NULL,
    `completed_at` varchar(40) NULL,
    UNIQUE KEY `uk_account_deletion_requests_1` (`user_id`),
    KEY `ix_account_deletion_requests_1` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='AccountDeletionRequest - direct business storage';
INSERT INTO `account_deletion_requests` (`id`,`version`,`user_id`,`status`,`created_at`,`updated_at`,`reason`,`failure_code`,`completed_at`)
SELECT s.id,s.version,s.`deletion_user_id`,s.`deletion_status`,s.`created_at`,s.`updated_at`,CASE WHEN JSON_EXTRACT(s.details,'$.reason') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.reason'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.reason')) END,CASE WHEN JSON_EXTRACT(s.details,'$.failureCode') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.failureCode'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.failureCode')) END,CASE WHEN JSON_EXTRACT(s.details,'$.completedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.completedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.completedAt')) END FROM `account_records` s WHERE s.record_type='DELETION_REQUEST';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `account_records` s LEFT JOIN `account_deletion_requests` d ON d.id=s.id WHERE s.record_type='DELETION_REQUEST' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`user_id` <=> s.`deletion_user_id` AND d.`status` <=> s.`deletion_status` AND d.`created_at` <=> s.`created_at` AND d.`updated_at` <=> s.`updated_at` AND d.`reason` <=> CASE WHEN JSON_EXTRACT(s.details,'$.reason') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.reason'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.reason')) END AND d.`failure_code` <=> CASE WHEN JSON_EXTRACT(s.details,'$.failureCode') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.failureCode'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.failureCode')) END AND d.`completed_at` <=> CASE WHEN JSON_EXTRACT(s.details,'$.completedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.completedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.completedAt')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `account_deletion_requests`)=(SELECT COUNT(*) FROM `account_records` WHERE record_type='DELETION_REQUEST'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `account_deletion_requests` AUTO_INCREMENT=',@account_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- LIFECYCLE_LOCK
CREATE TABLE `account_lifecycle_locks` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `user_id` bigint NOT NULL,
    UNIQUE KEY `uk_account_lifecycle_locks_1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='AccountLifecycleLock - direct business storage';
INSERT INTO `account_lifecycle_locks` (`id`,`version`,`user_id`)
SELECT s.id,s.version,s.`lifecycle_user_id` FROM `account_records` s WHERE s.record_type='LIFECYCLE_LOCK';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `account_records` s LEFT JOIN `account_lifecycle_locks` d ON d.id=s.id WHERE s.record_type='LIFECYCLE_LOCK' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`user_id` <=> s.`lifecycle_user_id`));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `account_lifecycle_locks`)=(SELECT COUNT(*) FROM `account_records` WHERE record_type='LIFECYCLE_LOCK'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `account_lifecycle_locks` AUTO_INCREMENT=',@account_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- AMENITY
CREATE TABLE `amenities` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` varchar(100) NOT NULL,
    `category` varchar(50) NULL,
    `icon` varchar(100) NULL,
    UNIQUE KEY `uk_amenities_1` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Amenity - direct business storage';
INSERT INTO `amenities` (`id`,`name`,`category`,`icon`)
SELECT s.id,s.`name`,s.`category`,CASE WHEN JSON_EXTRACT(s.details,'$.icon') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.icon'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.icon')) END FROM `catalog_items` s WHERE s.record_type='AMENITY';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `catalog_items` s LEFT JOIN `amenities` d ON d.id=s.id WHERE s.record_type='AMENITY' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`name` <=> s.`name` AND d.`category` <=> s.`category` AND d.`icon` <=> CASE WHEN JSON_EXTRACT(s.details,'$.icon') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.icon'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.icon')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `amenities`)=(SELECT COUNT(*) FROM `catalog_items` WHERE record_type='AMENITY'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `amenities` AUTO_INCREMENT=',@catalog_items_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- LISTING_FEE
CREATE TABLE `listing_fees` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `listing_id` bigint NOT NULL,
    `fee_code` varchar(50) NOT NULL,
    `fee_mode` varchar(20) NOT NULL DEFAULT 'FIXED',
    `amount_vnd` decimal(18,0) NOT NULL,
    `sort_order` int NOT NULL DEFAULT '0',
    `unit_name` varchar(50) NULL,
    `note` varchar(500) NULL,
    KEY `ix_listing_fees_1` (`listing_id`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ListingFee - direct business storage';
INSERT INTO `listing_fees` (`id`,`listing_id`,`fee_code`,`fee_mode`,`amount_vnd`,`sort_order`,`unit_name`,`note`)
SELECT s.id,s.`listing_id`,s.`fee_code`,s.`fee_mode`,s.`amount_vnd`,s.`sort_order`,CASE WHEN JSON_EXTRACT(s.details,'$.unitName') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.unitName'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.unitName')) END,CASE WHEN JSON_EXTRACT(s.details,'$.note') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.note'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.note')) END FROM `catalog_items` s WHERE s.record_type='LISTING_FEE';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `catalog_items` s LEFT JOIN `listing_fees` d ON d.id=s.id WHERE s.record_type='LISTING_FEE' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`listing_id` <=> s.`listing_id` AND d.`fee_code` <=> s.`fee_code` AND d.`fee_mode` <=> s.`fee_mode` AND d.`amount_vnd` <=> s.`amount_vnd` AND d.`sort_order` <=> s.`sort_order` AND d.`unit_name` <=> CASE WHEN JSON_EXTRACT(s.details,'$.unitName') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.unitName'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.unitName')) END AND d.`note` <=> CASE WHEN JSON_EXTRACT(s.details,'$.note') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.note'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.note')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `listing_fees`)=(SELECT COUNT(*) FROM `catalog_items` WHERE record_type='LISTING_FEE'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `listing_fees` AUTO_INCREMENT=',@catalog_items_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- WISHLIST_ITEM
CREATE TABLE `wishlist_items` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id` bigint NOT NULL,
    `room_id` bigint NOT NULL,
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    UNIQUE KEY `uk_wishlist_items_1` (`user_id`,`room_id`),
    KEY `ix_wishlist_items_1` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='WishlistItem - direct business storage';
INSERT INTO `wishlist_items` (`id`,`user_id`,`room_id`,`created_at`)
SELECT s.id,s.`user_id`,s.`room_id`,s.`created_at` FROM `catalog_items` s WHERE s.record_type='WISHLIST_ITEM';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `catalog_items` s LEFT JOIN `wishlist_items` d ON d.id=s.id WHERE s.record_type='WISHLIST_ITEM' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`user_id` <=> s.`user_id` AND d.`room_id` <=> s.`room_id` AND d.`created_at` <=> s.`created_at`));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `wishlist_items`)=(SELECT COUNT(*) FROM `catalog_items` WHERE record_type='WISHLIST_ITEM'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `wishlist_items` AUTO_INCREMENT=',@catalog_items_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- BOOKING
CREATE TABLE `bookings` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `tenant_id` bigint NOT NULL,
    `host_id` bigint NOT NULL,
    `room_id` bigint NOT NULL,
    `listing_id` bigint NOT NULL,
    `status` varchar(20) NOT NULL DEFAULT 'PENDING',
    `occupant_count` int NOT NULL DEFAULT '1',
    `rent_vnd` decimal(18,0) NOT NULL,
    `deposit_vnd` decimal(18,0) NOT NULL DEFAULT '0',
    `terms_snapshot` json NOT NULL,
    `snapshot_schema_version` int NOT NULL DEFAULT '1',
    `request_expires_at` datetime(3) NOT NULL,
    `hold_expires_at` datetime(3) NULL,
    `handover_due_at` datetime(3) NULL,
    `allocated_payment_id` bigint NULL,
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `desired_move_in` date NULL,
    `note` varchar(1000) NULL,
    `tenant_terms_accepted_at` varchar(40) NULL,
    `tenant_handover_confirmed_at` varchar(40) NULL,
    `host_handover_confirmed_at` varchar(40) NULL,
    `completed_at` varchar(40) NULL,
    `cancelled_at` varchar(40) NULL,
    `last_reason` varchar(1000) NULL,
    `open_room_id` bigint GENERATED ALWAYS AS (IF(status IN ('PENDING','APPROVED','CONFIRMED'),room_id,NULL)) STORED,
    `active_room_id` bigint GENERATED ALWAYS AS (IF(status IN ('APPROVED','CONFIRMED'),room_id,NULL)) STORED,
    UNIQUE KEY `uk_bookings_1` (`tenant_id`,`open_room_id`),
    UNIQUE KEY `uk_bookings_2` (`active_room_id`),
    UNIQUE KEY `uk_bookings_3` (`allocated_payment_id`),
    KEY `ix_bookings_1` (`tenant_id`,`created_at`),
    KEY `ix_bookings_2` (`host_id`,`created_at`),
    KEY `ix_bookings_3` (`status`,`request_expires_at`),
    KEY `ix_bookings_4` (`status`,`hold_expires_at`),
    KEY `ix_bookings_5` (`status`,`handover_due_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Booking - direct business storage';
INSERT INTO `bookings` (`id`,`version`,`tenant_id`,`host_id`,`room_id`,`listing_id`,`status`,`occupant_count`,`rent_vnd`,`deposit_vnd`,`terms_snapshot`,`snapshot_schema_version`,`request_expires_at`,`hold_expires_at`,`handover_due_at`,`allocated_payment_id`,`created_at`,`updated_at`,`desired_move_in`,`note`,`tenant_terms_accepted_at`,`tenant_handover_confirmed_at`,`host_handover_confirmed_at`,`completed_at`,`cancelled_at`,`last_reason`)
SELECT s.id,s.version,s.`tenant_id`,s.`host_id`,s.`room_id`,s.`listing_id`,s.`booking_status`,s.`occupant_count`,s.`rent_vnd`,s.`deposit_vnd`,s.`terms_snapshot`,s.`snapshot_schema_version`,s.`request_expires_at`,s.`hold_expires_at`,s.`handover_due_at`,s.`allocated_payment_id`,s.`created_at`,s.`updated_at`,CASE WHEN JSON_EXTRACT(s.details,'$.desiredMoveIn') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.desiredMoveIn'))='NULL' THEN NULL ELSE STR_TO_DATE(JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.desiredMoveIn')),'%Y-%m-%d') END,CASE WHEN JSON_EXTRACT(s.details,'$.note') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.note'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.note')) END,CASE WHEN JSON_EXTRACT(s.details,'$.tenantTermsAcceptedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.tenantTermsAcceptedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.tenantTermsAcceptedAt')) END,CASE WHEN JSON_EXTRACT(s.details,'$.tenantHandoverConfirmedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.tenantHandoverConfirmedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.tenantHandoverConfirmedAt')) END,CASE WHEN JSON_EXTRACT(s.details,'$.hostHandoverConfirmedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.hostHandoverConfirmedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.hostHandoverConfirmedAt')) END,CASE WHEN JSON_EXTRACT(s.details,'$.completedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.completedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.completedAt')) END,CASE WHEN JSON_EXTRACT(s.details,'$.cancelledAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.cancelledAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.cancelledAt')) END,CASE WHEN JSON_EXTRACT(s.details,'$.lastReason') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.lastReason'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.lastReason')) END FROM `rental_records` s WHERE s.record_type='BOOKING';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `rental_records` s LEFT JOIN `bookings` d ON d.id=s.id WHERE s.record_type='BOOKING' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`tenant_id` <=> s.`tenant_id` AND d.`host_id` <=> s.`host_id` AND d.`room_id` <=> s.`room_id` AND d.`listing_id` <=> s.`listing_id` AND d.`status` <=> s.`booking_status` AND d.`occupant_count` <=> s.`occupant_count` AND d.`rent_vnd` <=> s.`rent_vnd` AND d.`deposit_vnd` <=> s.`deposit_vnd` AND d.`terms_snapshot` <=> s.`terms_snapshot` AND d.`snapshot_schema_version` <=> s.`snapshot_schema_version` AND d.`request_expires_at` <=> s.`request_expires_at` AND d.`hold_expires_at` <=> s.`hold_expires_at` AND d.`handover_due_at` <=> s.`handover_due_at` AND d.`allocated_payment_id` <=> s.`allocated_payment_id` AND d.`created_at` <=> s.`created_at` AND d.`updated_at` <=> s.`updated_at` AND d.`desired_move_in` <=> CASE WHEN JSON_EXTRACT(s.details,'$.desiredMoveIn') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.desiredMoveIn'))='NULL' THEN NULL ELSE STR_TO_DATE(JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.desiredMoveIn')),'%Y-%m-%d') END AND d.`note` <=> CASE WHEN JSON_EXTRACT(s.details,'$.note') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.note'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.note')) END AND d.`tenant_terms_accepted_at` <=> CASE WHEN JSON_EXTRACT(s.details,'$.tenantTermsAcceptedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.tenantTermsAcceptedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.tenantTermsAcceptedAt')) END AND d.`tenant_handover_confirmed_at` <=> CASE WHEN JSON_EXTRACT(s.details,'$.tenantHandoverConfirmedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.tenantHandoverConfirmedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.tenantHandoverConfirmedAt')) END AND d.`host_handover_confirmed_at` <=> CASE WHEN JSON_EXTRACT(s.details,'$.hostHandoverConfirmedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.hostHandoverConfirmedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.hostHandoverConfirmedAt')) END AND d.`completed_at` <=> CASE WHEN JSON_EXTRACT(s.details,'$.completedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.completedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.completedAt')) END AND d.`cancelled_at` <=> CASE WHEN JSON_EXTRACT(s.details,'$.cancelledAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.cancelledAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.cancelledAt')) END AND d.`last_reason` <=> CASE WHEN JSON_EXTRACT(s.details,'$.lastReason') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.lastReason'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.lastReason')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `bookings`)=(SELECT COUNT(*) FROM `rental_records` WHERE record_type='BOOKING'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `bookings` AUTO_INCREMENT=',@rental_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- BOOKING_CASE
CREATE TABLE `booking_cases` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `booking_id` bigint NOT NULL,
    `type` varchar(30) NOT NULL,
    `opened_by` bigint NULL,
    `status` varchar(20) NOT NULL DEFAULT 'OPEN',
    `decision` varchar(30) NULL,
    `tenant_refund_vnd` decimal(18,0) NULL,
    `host_retained_vnd` decimal(18,0) NULL,
    `resolved_by` bigint NULL,
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `description` text NOT NULL,
    `resolution_note` text NULL,
    `resolved_at` varchar(40) NULL,
    `open_booking_id` bigint GENERATED ALWAYS AS (IF(status IN ('OPEN','IN_REVIEW'),booking_id,NULL)) STORED,
    UNIQUE KEY `uk_booking_cases_1` (`open_booking_id`),
    KEY `ix_booking_cases_1` (`booking_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='BookingCase - direct business storage';
INSERT INTO `booking_cases` (`id`,`version`,`booking_id`,`type`,`opened_by`,`status`,`decision`,`tenant_refund_vnd`,`host_retained_vnd`,`resolved_by`,`created_at`,`updated_at`,`description`,`resolution_note`,`resolved_at`)
SELECT s.id,s.version,s.`booking_id`,s.`case_type`,s.`opened_by`,s.`case_status`,s.`case_decision`,s.`tenant_refund_vnd`,s.`host_retained_vnd`,s.`resolved_by`,s.`created_at`,s.`updated_at`,CASE WHEN JSON_EXTRACT(s.details,'$.description') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.description'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.description')) END,CASE WHEN JSON_EXTRACT(s.details,'$.resolutionNote') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.resolutionNote'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.resolutionNote')) END,CASE WHEN JSON_EXTRACT(s.details,'$.resolvedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.resolvedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.resolvedAt')) END FROM `rental_records` s WHERE s.record_type='BOOKING_CASE';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `rental_records` s LEFT JOIN `booking_cases` d ON d.id=s.id WHERE s.record_type='BOOKING_CASE' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`booking_id` <=> s.`booking_id` AND d.`type` <=> s.`case_type` AND d.`opened_by` <=> s.`opened_by` AND d.`status` <=> s.`case_status` AND d.`decision` <=> s.`case_decision` AND d.`tenant_refund_vnd` <=> s.`tenant_refund_vnd` AND d.`host_retained_vnd` <=> s.`host_retained_vnd` AND d.`resolved_by` <=> s.`resolved_by` AND d.`created_at` <=> s.`created_at` AND d.`updated_at` <=> s.`updated_at` AND d.`description` <=> CASE WHEN JSON_EXTRACT(s.details,'$.description') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.description'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.description')) END AND d.`resolution_note` <=> CASE WHEN JSON_EXTRACT(s.details,'$.resolutionNote') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.resolutionNote'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.resolutionNote')) END AND d.`resolved_at` <=> CASE WHEN JSON_EXTRACT(s.details,'$.resolvedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.resolvedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.resolvedAt')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `booking_cases`)=(SELECT COUNT(*) FROM `rental_records` WHERE record_type='BOOKING_CASE'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `booking_cases` AUTO_INCREMENT=',@rental_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- BOOKING_HISTORY
CREATE TABLE `booking_status_history` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `booking_id` bigint NOT NULL,
    `from_status` varchar(30) NULL,
    `to_status` varchar(30) NOT NULL,
    `actor_id` bigint NULL,
    `actor_type` varchar(20) NOT NULL,
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `reason` varchar(1000) NULL,
    `trace_id` varchar(64) NOT NULL,
    KEY `ix_booking_status_history_1` (`booking_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='BookingStatusHistory - direct business storage';
INSERT INTO `booking_status_history` (`id`,`version`,`booking_id`,`from_status`,`to_status`,`actor_id`,`actor_type`,`created_at`,`reason`,`trace_id`)
SELECT s.id,s.version,s.`booking_id`,s.`from_status`,s.`to_status`,s.`actor_id`,s.`actor_type`,s.`created_at`,CASE WHEN JSON_EXTRACT(s.details,'$.reason') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.reason'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.reason')) END,CASE WHEN JSON_EXTRACT(s.details,'$.traceId') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.traceId'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.traceId')) END FROM `rental_records` s WHERE s.record_type='BOOKING_HISTORY';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `rental_records` s LEFT JOIN `booking_status_history` d ON d.id=s.id WHERE s.record_type='BOOKING_HISTORY' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`booking_id` <=> s.`booking_id` AND d.`from_status` <=> s.`from_status` AND d.`to_status` <=> s.`to_status` AND d.`actor_id` <=> s.`actor_id` AND d.`actor_type` <=> s.`actor_type` AND d.`created_at` <=> s.`created_at` AND d.`reason` <=> CASE WHEN JSON_EXTRACT(s.details,'$.reason') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.reason'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.reason')) END AND d.`trace_id` <=> CASE WHEN JSON_EXTRACT(s.details,'$.traceId') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.traceId'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.traceId')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `booking_status_history`)=(SELECT COUNT(*) FROM `rental_records` WHERE record_type='BOOKING_HISTORY'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `booking_status_history` AUTO_INCREMENT=',@rental_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- VIEWING_SLOT
CREATE TABLE `viewing_slots` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `room_id` bigint NOT NULL,
    `host_id` bigint NOT NULL,
    `start_at` datetime(3) NOT NULL,
    `end_at` datetime(3) NOT NULL,
    `status` varchar(20) NOT NULL DEFAULT 'OPEN',
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    KEY `ix_viewing_slots_1` (`room_id`,`status`,`start_at`),
    KEY `ix_viewing_slots_2` (`host_id`,`start_at`),
    CONSTRAINT `ck_viewing_slots_1` CHECK (end_at > start_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ViewingSlot - direct business storage';
INSERT INTO `viewing_slots` (`id`,`version`,`room_id`,`host_id`,`start_at`,`end_at`,`status`,`created_at`,`updated_at`)
SELECT s.id,s.version,s.`room_id`,s.`host_id`,s.`start_at`,s.`end_at`,s.`slot_status`,s.`created_at`,s.`updated_at` FROM `rental_records` s WHERE s.record_type='VIEWING_SLOT';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `rental_records` s LEFT JOIN `viewing_slots` d ON d.id=s.id WHERE s.record_type='VIEWING_SLOT' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`room_id` <=> s.`room_id` AND d.`host_id` <=> s.`host_id` AND d.`start_at` <=> s.`start_at` AND d.`end_at` <=> s.`end_at` AND d.`status` <=> s.`slot_status` AND d.`created_at` <=> s.`created_at` AND d.`updated_at` <=> s.`updated_at`));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `viewing_slots`)=(SELECT COUNT(*) FROM `rental_records` WHERE record_type='VIEWING_SLOT'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `viewing_slots` AUTO_INCREMENT=',@rental_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- VIEWING
CREATE TABLE `viewings` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `viewing_slot_id` bigint NOT NULL,
    `tenant_id` bigint NOT NULL,
    `room_id` bigint NOT NULL,
    `host_id` bigint NOT NULL,
    `status` varchar(30) NOT NULL DEFAULT 'REQUESTED',
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `note` varchar(1000) NULL,
    `cancelled_reason` varchar(1000) NULL,
    `completed_at` varchar(40) NULL,
    KEY `ix_viewings_1` (`tenant_id`,`created_at`),
    KEY `ix_viewings_2` (`host_id`,`created_at`),
    KEY `ix_viewings_3` (`viewing_slot_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Viewing - direct business storage';
INSERT INTO `viewings` (`id`,`version`,`viewing_slot_id`,`tenant_id`,`room_id`,`host_id`,`status`,`created_at`,`updated_at`,`note`,`cancelled_reason`,`completed_at`)
SELECT s.id,s.version,s.`viewing_slot_id`,s.`tenant_id`,s.`room_id`,s.`host_id`,s.`viewing_status`,s.`created_at`,s.`updated_at`,CASE WHEN JSON_EXTRACT(s.details,'$.note') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.note'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.note')) END,CASE WHEN JSON_EXTRACT(s.details,'$.cancelledReason') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.cancelledReason'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.cancelledReason')) END,CASE WHEN JSON_EXTRACT(s.details,'$.completedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.completedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.completedAt')) END FROM `rental_records` s WHERE s.record_type='VIEWING';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `rental_records` s LEFT JOIN `viewings` d ON d.id=s.id WHERE s.record_type='VIEWING' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`viewing_slot_id` <=> s.`viewing_slot_id` AND d.`tenant_id` <=> s.`tenant_id` AND d.`room_id` <=> s.`room_id` AND d.`host_id` <=> s.`host_id` AND d.`status` <=> s.`viewing_status` AND d.`created_at` <=> s.`created_at` AND d.`updated_at` <=> s.`updated_at` AND d.`note` <=> CASE WHEN JSON_EXTRACT(s.details,'$.note') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.note'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.note')) END AND d.`cancelled_reason` <=> CASE WHEN JSON_EXTRACT(s.details,'$.cancelledReason') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.cancelledReason'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.cancelledReason')) END AND d.`completed_at` <=> CASE WHEN JSON_EXTRACT(s.details,'$.completedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.completedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.completedAt')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `viewings`)=(SELECT COUNT(*) FROM `rental_records` WHERE record_type='VIEWING'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `viewings` AUTO_INCREMENT=',@rental_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- PAYMENT
CREATE TABLE `payments` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `booking_id` bigint NOT NULL,
    `payer_id` bigint NOT NULL,
    `provider` varchar(20) NOT NULL DEFAULT 'MOCK_SANDBOX',
    `provider_payment_id` varchar(100) NULL,
    `amount_vnd` decimal(18,0) NOT NULL,
    `currency` char(3) NOT NULL DEFAULT 'VND',
    `status` varchar(20) NOT NULL DEFAULT 'PENDING',
    `expires_at` datetime(3) NOT NULL,
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `succeeded_at` varchar(40) NULL,
    `failure_code` varchar(100) NULL,
    `is_test` tinyint(1) NOT NULL DEFAULT '1',
    CONSTRAINT `ck_payment_is_test` CHECK (is_test IN (0,1)),
    `pending_booking_id` bigint GENERATED ALWAYS AS (IF(status='PENDING',booking_id,NULL)) STORED,
    UNIQUE KEY `uk_payments_1` (`provider_payment_id`),
    UNIQUE KEY `uk_payments_2` (`pending_booking_id`),
    KEY `ix_payments_1` (`booking_id`,`created_at`),
    KEY `ix_payments_2` (`status`,`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Payment - direct business storage';
INSERT INTO `payments` (`id`,`version`,`booking_id`,`payer_id`,`provider`,`provider_payment_id`,`amount_vnd`,`currency`,`status`,`expires_at`,`created_at`,`updated_at`,`succeeded_at`,`failure_code`,`is_test`)
SELECT s.id,s.version,s.`booking_id`,s.`payer_id`,s.`provider`,s.`provider_payment_id`,s.`amount_vnd`,s.`currency`,s.`payment_status`,s.`expires_at`,s.`created_at`,s.`updated_at`,CASE WHEN JSON_EXTRACT(s.details,'$.succeededAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.succeededAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.succeededAt')) END,CASE WHEN JSON_EXTRACT(s.details,'$.failureCode') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.failureCode'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.failureCode')) END,CASE WHEN JSON_EXTRACT(s.details,'$.isTest') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.isTest'))='NULL' THEN NULL ELSE IF(JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.isTest'))='true',1,0) END FROM `rental_records` s WHERE s.record_type='PAYMENT';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `rental_records` s LEFT JOIN `payments` d ON d.id=s.id WHERE s.record_type='PAYMENT' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`booking_id` <=> s.`booking_id` AND d.`payer_id` <=> s.`payer_id` AND d.`provider` <=> s.`provider` AND d.`provider_payment_id` <=> s.`provider_payment_id` AND d.`amount_vnd` <=> s.`amount_vnd` AND d.`currency` <=> s.`currency` AND d.`status` <=> s.`payment_status` AND d.`expires_at` <=> s.`expires_at` AND d.`created_at` <=> s.`created_at` AND d.`updated_at` <=> s.`updated_at` AND d.`succeeded_at` <=> CASE WHEN JSON_EXTRACT(s.details,'$.succeededAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.succeededAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.succeededAt')) END AND d.`failure_code` <=> CASE WHEN JSON_EXTRACT(s.details,'$.failureCode') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.failureCode'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.failureCode')) END AND d.`is_test` <=> CASE WHEN JSON_EXTRACT(s.details,'$.isTest') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.isTest'))='NULL' THEN NULL ELSE IF(JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.isTest'))='true',1,0) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `payments`)=(SELECT COUNT(*) FROM `rental_records` WHERE record_type='PAYMENT'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `payments` AUTO_INCREMENT=',@rental_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- REFUND
CREATE TABLE `refunds` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `payment_id` bigint NOT NULL,
    `provider_refund_id` varchar(100) NULL,
    `amount_vnd` decimal(18,0) NOT NULL,
    `refund_reason` varchar(30) NULL,
    `status` varchar(20) NOT NULL DEFAULT 'PENDING',
    `attempt_count` int NOT NULL DEFAULT '0',
    `next_attempt_at` datetime(3) NULL,
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `last_error_code` varchar(100) NULL,
    `completed_at` varchar(40) NULL,
    UNIQUE KEY `uk_refunds_1` (`payment_id`),
    UNIQUE KEY `uk_refunds_2` (`provider_refund_id`),
    KEY `ix_refunds_1` (`status`,`next_attempt_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Refund - direct business storage';
INSERT INTO `refunds` (`id`,`version`,`payment_id`,`provider_refund_id`,`amount_vnd`,`refund_reason`,`status`,`attempt_count`,`next_attempt_at`,`created_at`,`updated_at`,`last_error_code`,`completed_at`)
SELECT s.id,s.version,s.`refund_payment_id`,s.`provider_refund_id`,s.`amount_vnd`,s.`refund_reason`,s.`refund_status`,s.`attempt_count`,s.`next_attempt_at`,s.`created_at`,s.`updated_at`,CASE WHEN JSON_EXTRACT(s.details,'$.lastErrorCode') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.lastErrorCode'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.lastErrorCode')) END,CASE WHEN JSON_EXTRACT(s.details,'$.completedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.completedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.completedAt')) END FROM `rental_records` s WHERE s.record_type='REFUND';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `rental_records` s LEFT JOIN `refunds` d ON d.id=s.id WHERE s.record_type='REFUND' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`payment_id` <=> s.`refund_payment_id` AND d.`provider_refund_id` <=> s.`provider_refund_id` AND d.`amount_vnd` <=> s.`amount_vnd` AND d.`refund_reason` <=> s.`refund_reason` AND d.`status` <=> s.`refund_status` AND d.`attempt_count` <=> s.`attempt_count` AND d.`next_attempt_at` <=> s.`next_attempt_at` AND d.`created_at` <=> s.`created_at` AND d.`updated_at` <=> s.`updated_at` AND d.`last_error_code` <=> CASE WHEN JSON_EXTRACT(s.details,'$.lastErrorCode') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.lastErrorCode'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.lastErrorCode')) END AND d.`completed_at` <=> CASE WHEN JSON_EXTRACT(s.details,'$.completedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.completedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.completedAt')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `refunds`)=(SELECT COUNT(*) FROM `rental_records` WHERE record_type='REFUND'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `refunds` AUTO_INCREMENT=',@rental_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- WEBHOOK_RECEIPT
CREATE TABLE `payment_webhook_receipts` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `provider` varchar(20) NOT NULL,
    `event_id` char(36) NOT NULL,
    `payment_id` bigint NULL,
    `payload_hash` binary(32) NOT NULL,
    `outcome` varchar(30) NULL,
    `processed_at` datetime(3) NOT NULL,
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    UNIQUE KEY `uk_payment_webhook_receipts_1` (`provider`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='WebhookReceipt - direct business storage';
INSERT INTO `payment_webhook_receipts` (`id`,`version`,`provider`,`event_id`,`payment_id`,`payload_hash`,`outcome`,`processed_at`,`created_at`)
SELECT s.id,s.version,s.`event_provider`,s.`event_id`,s.`webhook_payment_id`,s.`payload_hash`,s.`outcome`,s.`processed_at`,s.`created_at` FROM `rental_records` s WHERE s.record_type='WEBHOOK_RECEIPT';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `rental_records` s LEFT JOIN `payment_webhook_receipts` d ON d.id=s.id WHERE s.record_type='WEBHOOK_RECEIPT' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`provider` <=> s.`event_provider` AND d.`event_id` <=> s.`event_id` AND d.`payment_id` <=> s.`webhook_payment_id` AND d.`payload_hash` <=> s.`payload_hash` AND d.`outcome` <=> s.`outcome` AND d.`processed_at` <=> s.`processed_at` AND d.`created_at` <=> s.`created_at`));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `payment_webhook_receipts`)=(SELECT COUNT(*) FROM `rental_records` WHERE record_type='WEBHOOK_RECEIPT'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `payment_webhook_receipts` AUTO_INCREMENT=',@rental_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- NOTIFICATION
CREATE TABLE `notifications` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `user_id` bigint NOT NULL,
    `notification_type` varchar(50) NOT NULL,
    `ref_type` varchar(50) NULL,
    `ref_id` bigint NULL,
    `is_read` tinyint(1) NOT NULL DEFAULT '0',
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `title` varchar(255) NOT NULL,
    `body` text NULL,
    KEY `ix_notifications_1` (`user_id`,`created_at`,`id`),
    KEY `ix_notifications_2` (`user_id`,`is_read`,`created_at`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Notification - direct business storage';
INSERT INTO `notifications` (`id`,`version`,`user_id`,`notification_type`,`ref_type`,`ref_id`,`is_read`,`created_at`,`title`,`body`)
SELECT s.id,s.version,s.`user_id`,s.`notification_type`,s.`ref_type`,s.`ref_id`,s.`is_read`,s.`created_at`,CASE WHEN JSON_EXTRACT(s.details,'$.title') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.title'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.title')) END,CASE WHEN JSON_EXTRACT(s.details,'$.body') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.body'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.body')) END FROM `activity_records` s WHERE s.record_type='NOTIFICATION';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `activity_records` s LEFT JOIN `notifications` d ON d.id=s.id WHERE s.record_type='NOTIFICATION' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`user_id` <=> s.`user_id` AND d.`notification_type` <=> s.`notification_type` AND d.`ref_type` <=> s.`ref_type` AND d.`ref_id` <=> s.`ref_id` AND d.`is_read` <=> s.`is_read` AND d.`created_at` <=> s.`created_at` AND d.`title` <=> CASE WHEN JSON_EXTRACT(s.details,'$.title') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.title'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.title')) END AND d.`body` <=> CASE WHEN JSON_EXTRACT(s.details,'$.body') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.body'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.body')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `notifications`)=(SELECT COUNT(*) FROM `activity_records` WHERE record_type='NOTIFICATION'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `notifications` AUTO_INCREMENT=',@activity_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- PUSH_DELIVERY
CREATE TABLE `push_deliveries` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `notification_id` bigint NOT NULL,
    `device_id` bigint NOT NULL,
    `status` varchar(20) NOT NULL DEFAULT 'PENDING',
    `attempts` int NOT NULL DEFAULT '0',
    `next_attempt_at` datetime(3) NOT NULL,
    `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `last_error` varchar(100) NULL,
    UNIQUE KEY `uk_push_deliveries_1` (`notification_id`,`device_id`),
    KEY `ix_push_deliveries_1` (`status`,`next_attempt_at`,`id`),
    KEY `ix_push_deliveries_2` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PushDelivery - direct business storage';
INSERT INTO `push_deliveries` (`id`,`version`,`notification_id`,`device_id`,`status`,`attempts`,`next_attempt_at`,`created_at`,`last_error`)
SELECT s.id,s.version,s.`notification_id`,s.`device_id`,s.`delivery_status`,s.`attempts`,s.`next_attempt_at`,s.`created_at`,CASE WHEN JSON_EXTRACT(s.details,'$.lastError') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.lastError'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.lastError')) END FROM `activity_records` s WHERE s.record_type='PUSH_DELIVERY';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `activity_records` s LEFT JOIN `push_deliveries` d ON d.id=s.id WHERE s.record_type='PUSH_DELIVERY' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`notification_id` <=> s.`notification_id` AND d.`device_id` <=> s.`device_id` AND d.`status` <=> s.`delivery_status` AND d.`attempts` <=> s.`attempts` AND d.`next_attempt_at` <=> s.`next_attempt_at` AND d.`created_at` <=> s.`created_at` AND d.`last_error` <=> CASE WHEN JSON_EXTRACT(s.details,'$.lastError') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.lastError'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.lastError')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `push_deliveries`)=(SELECT COUNT(*) FROM `activity_records` WHERE record_type='PUSH_DELIVERY'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `push_deliveries` AUTO_INCREMENT=',@activity_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- AUDIT_LOG
CREATE TABLE `audit_logs` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `actor_id` bigint NULL,
    `actor_type` varchar(20) NOT NULL,
    `action` varchar(100) NOT NULL,
    `target_type` varchar(50) NOT NULL,
    `target_id` bigint NOT NULL,
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `detail` json NULL,
    `ip_address` varchar(45) NULL,
    `trace_id` varchar(64) NULL,
    KEY `ix_audit_logs_1` (`target_type`,`target_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='AuditLog - direct business storage';
INSERT INTO `audit_logs` (`id`,`version`,`actor_id`,`actor_type`,`action`,`target_type`,`target_id`,`created_at`,`detail`,`ip_address`,`trace_id`)
SELECT s.id,s.version,s.`actor_id`,s.`actor_type`,s.`action`,s.`target_type`,s.`target_id`,s.`created_at`,CASE WHEN JSON_EXTRACT(s.details,'$.detail') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.detail'))='NULL' THEN NULL ELSE CAST(JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.detail')) AS JSON) END,CASE WHEN JSON_EXTRACT(s.details,'$.ipAddress') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.ipAddress'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.ipAddress')) END,CASE WHEN JSON_EXTRACT(s.details,'$.traceId') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.traceId'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.traceId')) END FROM `activity_records` s WHERE s.record_type='AUDIT_LOG';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `activity_records` s LEFT JOIN `audit_logs` d ON d.id=s.id WHERE s.record_type='AUDIT_LOG' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`actor_id` <=> s.`actor_id` AND d.`actor_type` <=> s.`actor_type` AND d.`action` <=> s.`action` AND d.`target_type` <=> s.`target_type` AND d.`target_id` <=> s.`target_id` AND d.`created_at` <=> s.`created_at` AND d.`detail` <=> CASE WHEN JSON_EXTRACT(s.details,'$.detail') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.detail'))='NULL' THEN NULL ELSE CAST(JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.detail')) AS JSON) END AND d.`ip_address` <=> CASE WHEN JSON_EXTRACT(s.details,'$.ipAddress') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.ipAddress'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.ipAddress')) END AND d.`trace_id` <=> CASE WHEN JSON_EXTRACT(s.details,'$.traceId') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.traceId'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.traceId')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `audit_logs`)=(SELECT COUNT(*) FROM `activity_records` WHERE record_type='AUDIT_LOG'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `audit_logs` AUTO_INCREMENT=',@activity_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- IDEMPOTENCY
CREATE TABLE `idempotency_keys` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `idempotency_key` varchar(512) NOT NULL,
    `request_hash` varchar(64) NULL,
    `status` varchar(20) NOT NULL DEFAULT 'PROCESSING',
    `expires_at` datetime(3) NOT NULL,
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `response_content_type` varchar(255) NULL,
    `response_location` text NULL,
    `response_status_code` int NULL,
    `response_body` longtext NULL,
    UNIQUE KEY `uk_idempotency_keys_1` (`idempotency_key`),
    KEY `ix_idempotency_keys_1` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='IdempotencyKeyEntity - direct business storage';
INSERT INTO `idempotency_keys` (`id`,`version`,`idempotency_key`,`request_hash`,`status`,`expires_at`,`created_at`,`response_content_type`,`response_location`,`response_status_code`,`response_body`)
SELECT s.id,s.version,s.`idempotency_key`,s.`request_hash`,s.`request_status`,s.`expires_at`,s.`created_at`,CASE WHEN JSON_EXTRACT(s.details,'$.responseContentType') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.responseContentType'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.responseContentType')) END,CASE WHEN JSON_EXTRACT(s.details,'$.responseLocation') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.responseLocation'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.responseLocation')) END,CASE WHEN JSON_EXTRACT(s.details,'$.responseStatusCode') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.responseStatusCode'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.responseStatusCode')) END,CASE WHEN JSON_EXTRACT(s.details,'$.responseBody') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.responseBody'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.responseBody')) END FROM `activity_records` s WHERE s.record_type='IDEMPOTENCY';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `activity_records` s LEFT JOIN `idempotency_keys` d ON d.id=s.id WHERE s.record_type='IDEMPOTENCY' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`idempotency_key` <=> s.`idempotency_key` AND d.`request_hash` <=> s.`request_hash` AND d.`status` <=> s.`request_status` AND d.`expires_at` <=> s.`expires_at` AND d.`created_at` <=> s.`created_at` AND d.`response_content_type` <=> CASE WHEN JSON_EXTRACT(s.details,'$.responseContentType') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.responseContentType'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.responseContentType')) END AND d.`response_location` <=> CASE WHEN JSON_EXTRACT(s.details,'$.responseLocation') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.responseLocation'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.responseLocation')) END AND d.`response_status_code` <=> CASE WHEN JSON_EXTRACT(s.details,'$.responseStatusCode') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.responseStatusCode'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.responseStatusCode')) END AND d.`response_body` <=> CASE WHEN JSON_EXTRACT(s.details,'$.responseBody') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.responseBody'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.responseBody')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `idempotency_keys`)=(SELECT COUNT(*) FROM `activity_records` WHERE record_type='IDEMPOTENCY'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `idempotency_keys` AUTO_INCREMENT=',@activity_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- REVIEW
CREATE TABLE `reviews` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `booking_id` bigint NOT NULL,
    `reviewer_id` bigint NOT NULL,
    `room_id` bigint NOT NULL,
    `rating` int NOT NULL,
    `visible` tinyint(1) NOT NULL DEFAULT '1',
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `comment` text NULL,
    `hide_reason` varchar(500) NULL,
    UNIQUE KEY `uk_reviews_1` (`booking_id`),
    KEY `ix_reviews_1` (`room_id`,`visible`,`created_at`),
    CONSTRAINT `ck_reviews_1` CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Review - direct business storage';
INSERT INTO `reviews` (`id`,`version`,`booking_id`,`reviewer_id`,`room_id`,`rating`,`visible`,`created_at`,`updated_at`,`comment`,`hide_reason`)
SELECT s.id,s.version,s.`booking_id`,s.`actor_id`,s.`room_id`,s.`rating`,s.`visible`,s.`created_at`,s.`updated_at`,CASE WHEN JSON_EXTRACT(s.details,'$.comment') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.comment'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.comment')) END,CASE WHEN JSON_EXTRACT(s.details,'$.hideReason') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.hideReason'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.hideReason')) END FROM `activity_records` s WHERE s.record_type='REVIEW';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `activity_records` s LEFT JOIN `reviews` d ON d.id=s.id WHERE s.record_type='REVIEW' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`booking_id` <=> s.`booking_id` AND d.`reviewer_id` <=> s.`actor_id` AND d.`room_id` <=> s.`room_id` AND d.`rating` <=> s.`rating` AND d.`visible` <=> s.`visible` AND d.`created_at` <=> s.`created_at` AND d.`updated_at` <=> s.`updated_at` AND d.`comment` <=> CASE WHEN JSON_EXTRACT(s.details,'$.comment') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.comment'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.comment')) END AND d.`hide_reason` <=> CASE WHEN JSON_EXTRACT(s.details,'$.hideReason') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.hideReason'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.hideReason')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `reviews`)=(SELECT COUNT(*) FROM `activity_records` WHERE record_type='REVIEW'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `reviews` AUTO_INCREMENT=',@activity_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;

-- REPORT
CREATE TABLE `reports` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version` int NOT NULL DEFAULT '0',
    `reporter_id` bigint NOT NULL,
    `target_type` varchar(50) NOT NULL,
    `target_id` bigint NOT NULL,
    `reason_code` varchar(50) NOT NULL,
    `status` varchar(20) NOT NULL DEFAULT 'PENDING',
    `resolved_by` bigint NULL,
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `description` text NULL,
    `resolution_note` varchar(1000) NULL,
    `resolved_at` varchar(40) NULL,
    KEY `ix_reports_1` (`status`,`created_at`),
    KEY `ix_reports_2` (`target_type`,`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Report - direct business storage';
INSERT INTO `reports` (`id`,`version`,`reporter_id`,`target_type`,`target_id`,`reason_code`,`status`,`resolved_by`,`created_at`,`updated_at`,`description`,`resolution_note`,`resolved_at`)
SELECT s.id,s.version,s.`actor_id`,s.`target_type`,s.`target_id`,s.`reason_code`,s.`report_status`,s.`resolved_by`,s.`created_at`,s.`updated_at`,CASE WHEN JSON_EXTRACT(s.details,'$.description') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.description'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.description')) END,CASE WHEN JSON_EXTRACT(s.details,'$.resolutionNote') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.resolutionNote'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.resolutionNote')) END,CASE WHEN JSON_EXTRACT(s.details,'$.resolvedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.resolvedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.resolvedAt')) END FROM `activity_records` s WHERE s.record_type='REPORT';
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM `activity_records` s LEFT JOIN `reports` d ON d.id=s.id WHERE s.record_type='REPORT' AND (d.id IS NULL OR NOT (d.`id` <=> s.id AND d.`version` <=> s.version AND d.`reporter_id` <=> s.`actor_id` AND d.`target_type` <=> s.`target_type` AND d.`target_id` <=> s.`target_id` AND d.`reason_code` <=> s.`reason_code` AND d.`status` <=> s.`report_status` AND d.`resolved_by` <=> s.`resolved_by` AND d.`created_at` <=> s.`created_at` AND d.`updated_at` <=> s.`updated_at` AND d.`description` <=> CASE WHEN JSON_EXTRACT(s.details,'$.description') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.description'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.description')) END AND d.`resolution_note` <=> CASE WHEN JSON_EXTRACT(s.details,'$.resolutionNote') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.resolutionNote'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.resolutionNote')) END AND d.`resolved_at` <=> CASE WHEN JSON_EXTRACT(s.details,'$.resolvedAt') IS NULL OR JSON_TYPE(JSON_EXTRACT(s.details,'$.resolvedAt'))='NULL' THEN NULL ELSE JSON_UNQUOTE(JSON_EXTRACT(s.details,'$.resolvedAt')) END));
INSERT INTO schema22_guard SELECT IF((SELECT COUNT(*) FROM `reports`)=(SELECT COUNT(*) FROM `activity_records` WHERE record_type='REPORT'),1,0);
SET @schema22_ddl=CONCAT('ALTER TABLE `reports` AUTO_INCREMENT=',@activity_records_next);
PREPARE schema22_stmt FROM @schema22_ddl;
EXECUTE schema22_stmt;
DEALLOCATE PREPARE schema22_stmt;
ALTER TABLE `refresh_tokens` ADD CONSTRAINT `fk_refresh_tokens_user_id` FOREIGN KEY (`user_id`) REFERENCES `users`(id);
ALTER TABLE `one_time_tokens` ADD CONSTRAINT `fk_one_time_tokens_user_id` FOREIGN KEY (`user_id`) REFERENCES `users`(id);
ALTER TABLE `device_tokens` ADD CONSTRAINT `fk_device_tokens_user_id` FOREIGN KEY (`user_id`) REFERENCES `users`(id);
ALTER TABLE `notification_preferences` ADD CONSTRAINT `fk_notification_preferences_user_id` FOREIGN KEY (`user_id`) REFERENCES `users`(id);
ALTER TABLE `account_deletion_requests` ADD CONSTRAINT `fk_account_deletion_requests_user_id` FOREIGN KEY (`user_id`) REFERENCES `users`(id);
ALTER TABLE `account_lifecycle_locks` ADD CONSTRAINT `fk_account_lifecycle_locks_user_id` FOREIGN KEY (`user_id`) REFERENCES `users`(id);
ALTER TABLE `listing_fees` ADD CONSTRAINT `fk_listing_fees_listing_id` FOREIGN KEY (`listing_id`) REFERENCES `listings`(id);
ALTER TABLE `wishlist_items` ADD CONSTRAINT `fk_wishlist_items_user_id` FOREIGN KEY (`user_id`) REFERENCES `users`(id);
ALTER TABLE `wishlist_items` ADD CONSTRAINT `fk_wishlist_items_room_id` FOREIGN KEY (`room_id`) REFERENCES `rooms`(id);
ALTER TABLE `bookings` ADD CONSTRAINT `fk_bookings_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `users`(id);
ALTER TABLE `bookings` ADD CONSTRAINT `fk_bookings_host_id` FOREIGN KEY (`host_id`) REFERENCES `users`(id);
ALTER TABLE `bookings` ADD CONSTRAINT `fk_bookings_room_id` FOREIGN KEY (`room_id`) REFERENCES `rooms`(id);
ALTER TABLE `bookings` ADD CONSTRAINT `fk_bookings_listing_id` FOREIGN KEY (`listing_id`) REFERENCES `listings`(id);
ALTER TABLE `bookings` ADD CONSTRAINT `fk_bookings_allocated_payment_id` FOREIGN KEY (`allocated_payment_id`) REFERENCES `payments`(id);
ALTER TABLE `booking_cases` ADD CONSTRAINT `fk_booking_cases_booking_id` FOREIGN KEY (`booking_id`) REFERENCES `bookings`(id);
ALTER TABLE `booking_cases` ADD CONSTRAINT `fk_booking_cases_opened_by` FOREIGN KEY (`opened_by`) REFERENCES `users`(id);
ALTER TABLE `booking_cases` ADD CONSTRAINT `fk_booking_cases_resolved_by` FOREIGN KEY (`resolved_by`) REFERENCES `users`(id);
ALTER TABLE `booking_status_history` ADD CONSTRAINT `fk_booking_status_history_booking_id` FOREIGN KEY (`booking_id`) REFERENCES `bookings`(id);
ALTER TABLE `booking_status_history` ADD CONSTRAINT `fk_booking_status_history_actor_id` FOREIGN KEY (`actor_id`) REFERENCES `users`(id);
ALTER TABLE `viewing_slots` ADD CONSTRAINT `fk_viewing_slots_room_id` FOREIGN KEY (`room_id`) REFERENCES `rooms`(id);
ALTER TABLE `viewing_slots` ADD CONSTRAINT `fk_viewing_slots_host_id` FOREIGN KEY (`host_id`) REFERENCES `users`(id);
ALTER TABLE `viewings` ADD CONSTRAINT `fk_viewings_viewing_slot_id` FOREIGN KEY (`viewing_slot_id`) REFERENCES `viewing_slots`(id);
ALTER TABLE `viewings` ADD CONSTRAINT `fk_viewings_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `users`(id);
ALTER TABLE `viewings` ADD CONSTRAINT `fk_viewings_room_id` FOREIGN KEY (`room_id`) REFERENCES `rooms`(id);
ALTER TABLE `viewings` ADD CONSTRAINT `fk_viewings_host_id` FOREIGN KEY (`host_id`) REFERENCES `users`(id);
ALTER TABLE `payments` ADD CONSTRAINT `fk_payments_booking_id` FOREIGN KEY (`booking_id`) REFERENCES `bookings`(id);
ALTER TABLE `payments` ADD CONSTRAINT `fk_payments_payer_id` FOREIGN KEY (`payer_id`) REFERENCES `users`(id);
ALTER TABLE `refunds` ADD CONSTRAINT `fk_refunds_payment_id` FOREIGN KEY (`payment_id`) REFERENCES `payments`(id);
ALTER TABLE `payment_webhook_receipts` ADD CONSTRAINT `fk_payment_webhook_receipts_payment_id` FOREIGN KEY (`payment_id`) REFERENCES `payments`(id);
ALTER TABLE `notifications` ADD CONSTRAINT `fk_notifications_user_id` FOREIGN KEY (`user_id`) REFERENCES `users`(id);
ALTER TABLE `push_deliveries` ADD CONSTRAINT `fk_push_deliveries_notification_id` FOREIGN KEY (`notification_id`) REFERENCES `notifications`(id);
ALTER TABLE `push_deliveries` ADD CONSTRAINT `fk_push_deliveries_device_id` FOREIGN KEY (`device_id`) REFERENCES `device_tokens`(id);
ALTER TABLE `audit_logs` ADD CONSTRAINT `fk_audit_logs_actor_id` FOREIGN KEY (`actor_id`) REFERENCES `users`(id);
ALTER TABLE `reviews` ADD CONSTRAINT `fk_reviews_booking_id` FOREIGN KEY (`booking_id`) REFERENCES `bookings`(id);
ALTER TABLE `reviews` ADD CONSTRAINT `fk_reviews_reviewer_id` FOREIGN KEY (`reviewer_id`) REFERENCES `users`(id);
ALTER TABLE `reviews` ADD CONSTRAINT `fk_reviews_room_id` FOREIGN KEY (`room_id`) REFERENCES `rooms`(id);
ALTER TABLE `reports` ADD CONSTRAINT `fk_reports_reporter_id` FOREIGN KEY (`reporter_id`) REFERENCES `users`(id);
ALTER TABLE `reports` ADD CONSTRAINT `fk_reports_resolved_by` FOREIGN KEY (`resolved_by`) REFERENCES `users`(id);
ALTER TABLE user_roles ADD COLUMN role_name VARCHAR(20) NULL;
UPDATE user_roles ur JOIN account_records r ON r.id=ur.role_id AND r.record_type='ROLE' SET ur.role_name=r.role_name;
INSERT INTO schema22_guard SELECT IF(COUNT(*)=0,1,0) FROM user_roles ur LEFT JOIN account_records r ON r.id=ur.role_id WHERE ur.role_name IS NULL OR NOT (ur.role_name <=> r.role_name);
-- Replace the two external references into the old polymorphic roots.
ALTER TABLE `room_amenities` DROP FOREIGN KEY `fk_room_amenities_amenity`;
ALTER TABLE `user_roles` DROP FOREIGN KEY `fk_user_roles_role`;
ALTER TABLE `room_amenities` DROP CHECK `ck_room_amenities_kind`;
ALTER TABLE `user_roles` DROP CHECK `ck_user_roles_kind`;
ALTER TABLE user_roles DROP PRIMARY KEY, DROP COLUMN role_id, DROP COLUMN role_id_kind, MODIFY role_name VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, ADD PRIMARY KEY(user_id,role_name), ADD CONSTRAINT ck_user_roles_name CHECK(role_name IN ('ROLE_TENANT','ROLE_HOST','ROLE_ADMIN'));
ALTER TABLE room_amenities DROP COLUMN amenity_id_kind, ADD CONSTRAINT fk_room_amenities_amenity FOREIGN KEY(amenity_id) REFERENCES amenities(id);
ALTER TABLE users DROP COLUMN refresh_token, DROP COLUMN suspended;
ALTER TABLE `activity_records` DROP FOREIGN KEY `fk_activity_device`;
ALTER TABLE `activity_records` DROP FOREIGN KEY `fk_activity_notification`;
ALTER TABLE `rental_records` DROP FOREIGN KEY `fk_rental_allocated_payment`;
ALTER TABLE `rental_records` DROP FOREIGN KEY `fk_rental_booking`;
ALTER TABLE `rental_records` DROP FOREIGN KEY `fk_rental_refund_payment`;
ALTER TABLE `rental_records` DROP FOREIGN KEY `fk_rental_viewing_slot`;
ALTER TABLE `rental_records` DROP FOREIGN KEY `fk_rental_webhook_payment`;
DROP TABLE `account_records`,`catalog_items`,`rental_records`,`activity_records`;
DROP TEMPORARY TABLE schema22_guard;
