package com.homely.rental.payment.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;

@Entity @Table(name = "payment_webhook_receipts", uniqueConstraints = {
        @UniqueConstraint(name = "uk_payment_webhook_receipts_1", columnNames = {"provider", "event_id"})
})
@Getter @Setter @NoArgsConstructor
public class WebhookReceipt {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;

    @Column(name = "provider", length=20, nullable = false) private String provider;
    @Column(name = "event_id", columnDefinition="CHAR(36)", nullable = false) private String eventId;
    @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name = "payment_id", nullable = true) private Payment payment;
    @Column(name = "payload_hash", columnDefinition="BINARY(32)", nullable = false) private byte[] payloadHash;
    @Column(name = "outcome", length=30, nullable = true) private String outcome;
    @Column(name = "processed_at", nullable = false) private Instant processedAt = Instant.now();
    @Column(name = "created_at", nullable = true) private Instant createdAt = Instant.now();
}
