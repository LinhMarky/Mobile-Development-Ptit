package com.homely.rental.notification.entity;

import com.homely.rental.auth.entity.User;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(name = "notifications")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(name = "notification_type", length = 50, nullable = false)
    private NotificationType type;

    /** Reference type: "booking", "viewing", "review", "listing", "message" */
    @Column(name = "ref_type", length = 50, nullable = true)
    private String refType;

    @Column(name = "ref_id", nullable = true)
    private Long refId;

    @Column(name = "is_read", nullable = false)
    private boolean isRead = false;

    @Column(name = "created_at", updatable = false, nullable = true)
    private Instant createdAt = Instant.now().truncatedTo(java.time.temporal.ChronoUnit.MILLIS);

    @Column(name = "title", nullable = false, length = 255)
    private String title;

    @Column(name = "body", nullable = true, columnDefinition = "TEXT")
    private String body;

}
