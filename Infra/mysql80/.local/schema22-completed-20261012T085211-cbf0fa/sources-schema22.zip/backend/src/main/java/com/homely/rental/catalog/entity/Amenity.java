package com.homely.rental.catalog.entity;

import com.homely.rental.common.entity.AbstractAuditingEntity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Amenity entity for rooms (CAT14).
 * Represents a facility/feature that can be associated with rooms.
 */
@Entity
@Table(name = "amenities", uniqueConstraints = {
        @UniqueConstraint(name = "uk_amenities_1", columnNames = {"name"})
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Amenity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", length = 100, nullable = false)
    private String name;

    @Column(name = "category", length = 50, nullable = true)
    private String category;

    @Column(name = "icon", nullable = true, length = 100)
    private String icon;

}
