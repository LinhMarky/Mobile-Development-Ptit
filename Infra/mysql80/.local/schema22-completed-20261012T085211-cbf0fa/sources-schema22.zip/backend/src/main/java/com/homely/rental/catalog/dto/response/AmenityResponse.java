package com.homely.rental.catalog.dto.response;

import com.homely.rental.catalog.entity.Amenity;
import io.swagger.v3.oas.annotations.media.Schema;

/** Public amenity fields, independent of JPA metadata. */
@Schema(name = "Amenity")
public record AmenityResponse(Long id, String name, String category, String icon) {
    public static AmenityResponse from(Amenity amenity) {
        return new AmenityResponse(amenity.getId(), amenity.getName(), amenity.getCategory(), amenity.getIcon());
    }
}
