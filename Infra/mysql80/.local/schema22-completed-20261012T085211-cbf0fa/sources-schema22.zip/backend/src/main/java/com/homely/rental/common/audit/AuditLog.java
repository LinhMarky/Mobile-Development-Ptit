package com.homely.rental.common.audit;

import com.homely.rental.auth.entity.User;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(name = "audit_logs")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "actor_id", nullable = true)
    private User actor;

    @Column(name = "actor_type", length = 20, nullable = false)
    private String actorType;

    @Column(name = "action", length = 100, nullable = false)
    private String action;

    @Column(name = "target_type", length = 50, nullable = false)
    private String targetType;

    @Column(name = "target_id", nullable = false)
    private Long targetId;

    @Column(name = "created_at", updatable = false, nullable = true)
    private Instant createdAt = Instant.now();

    @Column(name = "detail", nullable = true, columnDefinition = "JSON")
    private String detail;

    @Column(name = "ip_address", nullable = true, length = 45)
    private String ipAddress;

    @Column(name = "trace_id", nullable = true, length = 64)
    private String traceId;

    @lombok.Builder
    public static AuditLog create(User actor, String actorType, String action, String targetType,
                                  Long targetId, String detail, String ipAddress, String traceId, Instant createdAt) {
        AuditLog log = new AuditLog();
        log.setActor(actor); log.setActorType(actorType); log.setAction(action);
        log.setTargetType(targetType); log.setTargetId(targetId); log.setDetail(detail);
        log.setIpAddress(ipAddress); log.setTraceId(traceId);
        if (createdAt != null) log.setCreatedAt(createdAt);
        return log;
    }
}
