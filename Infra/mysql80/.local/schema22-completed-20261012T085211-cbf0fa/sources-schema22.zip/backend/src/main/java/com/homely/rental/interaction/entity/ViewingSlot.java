package com.homely.rental.interaction.entity;

import com.homely.rental.auth.entity.User;
import com.homely.rental.catalog.entity.Room;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(name = "viewing_slots")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class ViewingSlot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "room_id", nullable = false)
    private Room room;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "host_id", nullable = false)
    private User host;

    @Column(name = "start_at", nullable = false)
    private Instant startAt;

    @Column(name = "end_at", nullable = false)
    private Instant endAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 20, nullable = false)
    private ViewingSlotStatus status = ViewingSlotStatus.OPEN;

    @Column(name = "created_at", updatable = false, nullable = true)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at", nullable = true)
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }
}
