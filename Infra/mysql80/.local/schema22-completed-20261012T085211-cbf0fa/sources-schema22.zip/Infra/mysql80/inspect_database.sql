-- Read-only inspection of V22. Never import a dump over the running database.
USE roomly_local80;

SELECT table_name, table_rows AS estimated_rows FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_type='BASE TABLE' ORDER BY table_name;
SELECT version, description, success FROM flyway_schema_history ORDER BY installed_rank;

SELECT id, email, full_name, status, version FROM users ORDER BY id DESC LIMIT 20;
SELECT user_id, role_name FROM user_roles ORDER BY user_id, role_name LIMIT 40;
SELECT id, host_id, unit_code, room_type, availability FROM rooms ORDER BY id DESC LIMIT 20;
SELECT id, room_id, title, status, rent_vnd, deposit_vnd FROM listings ORDER BY id DESC LIMIT 20;
SELECT id, listing_id, fee_code, fee_mode, amount_vnd FROM listing_fees ORDER BY listing_id, sort_order LIMIT 40;

SELECT id, room_id, tenant_id, host_id, status, rent_vnd, deposit_vnd FROM bookings ORDER BY id DESC LIMIT 20;
SELECT id, booking_id, from_status, to_status, actor_id, reason, created_at
FROM booking_status_history ORDER BY id DESC LIMIT 20;

SELECT b.id AS booking_id, b.status AS booking_status, p.id AS payment_id,
       p.status AS payment_status, p.amount_vnd, r.amount_vnd AS refunded_vnd
FROM bookings b LEFT JOIN payments p ON p.booking_id=b.id
LEFT JOIN refunds r ON r.payment_id=p.id ORDER BY b.id DESC, p.id DESC LIMIT 20;

SELECT id, room_id, host_id, start_at, end_at, status FROM viewing_slots ORDER BY start_at DESC LIMIT 20;
SELECT id, viewing_slot_id, tenant_id, status FROM viewings ORDER BY id DESC LIMIT 20;
SELECT id, tenant_id, host_id, sequence, tenant_read_sequence, host_read_sequence
FROM conversations ORDER BY id DESC LIMIT 20;
SELECT id, user_id, notification_type, title, is_read FROM notifications ORDER BY id DESC LIMIT 20;
SELECT id, notification_id, device_id, status, attempts, next_attempt_at
FROM push_deliveries ORDER BY id DESC LIMIT 20;

-- Do not display password/token hashes, FCM tokens or idempotency response bodies.
