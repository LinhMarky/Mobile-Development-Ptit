[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$workspace = Split-Path -Parent $PSScriptRoot
$backend = Join-Path $workspace 'backend'
$output = Join-Path $backend 'target/backend-verification'
[IO.Directory]::CreateDirectory($output) | Out-Null
$project = 'homely-verify-' + [guid]::NewGuid().ToString('N').Substring(0, 12)
$composeFile = Join-Path $output ($project + '.yaml')
$envFile = Join-Path $output ($project + '.env')
$logFile = Join-Path $output 'maven-verify.log'
$utf8 = [Text.UTF8Encoding]::new($false)

function Invoke-Docker([string[]]$Arguments) {
    $ErrorActionPreference = 'Continue'
    $lines = @(& docker @Arguments 2>&1 | ForEach-Object { $_.ToString() })
    $code = $LASTEXITCODE
    if ($code -ne 0) { throw ('Docker command failed (exit ' + $code + '): ' + $Arguments[0]) }
    return $lines
}

# This project is generated for each run; it never uses the application database.
$compose = @'
services:
  mysql:
    image: mysql:8.4
    command: [--innodb-buffer-pool-size=128M, --max-connections=50]
    environment:
      MYSQL_DATABASE: homely_verify
      MYSQL_ROOT_PASSWORD: ${VERIFY_MYSQL_PASSWORD:?Required}
    ports: ["127.0.0.1::3306"]
    tmpfs: [/var/lib/mysql]
    mem_limit: 768m
    logging:
      driver: json-file
      options: {max-size: "5m", max-file: "2"}
    healthcheck:
      test: [CMD-SHELL, "mysqladmin ping -h 127.0.0.1 --silent"]
      interval: 3s
      timeout: 3s
      retries: 40
'@
$random = New-Object byte[] 32
$rng = [Security.Cryptography.RandomNumberGenerator]::Create()
try { $rng.GetBytes($random) } finally { $rng.Dispose() }
$password = [Convert]::ToBase64String($random)
[IO.File]::WriteAllText($composeFile, $compose, $utf8)
[IO.File]::WriteAllText($envFile, ('VERIFY_MYSQL_PASSWORD=' + $password + "`n"), $utf8)
$dockerCompose = @('compose', '--project-name', $project, '--env-file', $envFile, '-f', $composeFile)
$variables = @('HOMELY_TEST_MYSQL_URL', 'HOMELY_TEST_MYSQL_USER', 'HOMELY_TEST_MYSQL_PASSWORD', 'MAVEN_OPTS')
$previousEnvironment = @{}
foreach ($name in $variables) { $previousEnvironment[$name] = [Environment]::GetEnvironmentVariable($name, 'Process') }
$started = [DateTime]::UtcNow
$created = $false
$resultFile = Join-Path $output 'result.json'
$pending = [ordered]@{ started_utc = $started.ToString('o'); status = 'running'; pass = $false }
[IO.File]::WriteAllText($resultFile, ($pending | ConvertTo-Json), $utf8)

try {
    $null = Invoke-Docker ($dockerCompose + @('config', '--quiet'))
    $created = $true
    Write-Output ('Starting isolated MySQL test project: ' + $project)
    $null = Invoke-Docker ($dockerCompose + @('up', '-d', '--wait', '--wait-timeout', '180'))
    $endpoint = (Invoke-Docker ($dockerCompose + @('port', 'mysql', '3306')) | Select-Object -Last 1).Trim()
    if ($endpoint -notmatch '^127\.0\.0\.1:(\d+)$') { throw 'Unexpected MySQL test port binding.' }
    $port = $Matches[1]
    $env:HOMELY_TEST_MYSQL_URL = 'jdbc:mysql://127.0.0.1:' + $port + '/homely_verify?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true'
    $env:HOMELY_TEST_MYSQL_USER = 'root'
    $env:HOMELY_TEST_MYSQL_PASSWORD = $password
    $env:MAVEN_OPTS = '-Xmx512m -XX:ActiveProcessorCount=2'
    $mysqlId = (Invoke-Docker ($dockerCompose + @('ps', '-q', 'mysql')) | Select-Object -Last 1).Trim()
    $versionOutput = (Invoke-Docker @('exec', $mysqlId, 'mysqld', '--version') | Select-Object -Last 1).Trim()
    if ($versionOutput -notmatch '\bVer\s+(8\.4\.\d+)') { throw 'The isolated test server is not MySQL 8.4.' }
    $mysqlVersion = $Matches[1]

    Write-Output ('Running Maven verify with MySQL ' + $mysqlVersion + '. Log: ' + $logFile)
    Push-Location $backend
    try {
        $ErrorActionPreference = 'Continue'
        & .\mvnw.cmd -B -ntp verify '-DargLine=-Xmx768m -XX:ActiveProcessorCount=2 -Dspring.test.context.cache.maxSize=4' *> $logFile
        $mavenExit = $LASTEXITCODE
        $ErrorActionPreference = 'Stop'
    } finally { Pop-Location }
    if ($mavenExit -ne 0) { throw ('Maven verify failed. Inspect the local log: ' + $logFile) }

    $tests = 0; $failures = 0; $errors = 0; $skipped = 0; $suiteCount = 0
    $mysqlSuites = @()
    $reports = Get-ChildItem -LiteralPath (Join-Path $backend 'target/surefire-reports') -Filter 'TEST-*.xml'
    foreach ($report in $reports) {
        if ($report.LastWriteTimeUtc -lt $started) { continue }
        [xml]$xml = Get-Content -LiteralPath $report.FullName -Raw -Encoding UTF8
        $suite = $xml.testsuite
        $tests += [int]$suite.tests; $failures += [int]$suite.failures
        $errors += [int]$suite.errors; $skipped += [int]$suite.skipped; $suiteCount++
        if ($suite.name -match 'Mysql' -and [int]$suite.tests -gt [int]$suite.skipped) { $mysqlSuites += $suite.name }
    }
    if ($tests -eq 0 -or $failures -ne 0 -or $errors -ne 0 -or $skipped -ne 0) { throw 'The current test reports are not a complete passing run.' }
    if ($mysqlSuites.Count -lt 4) { throw 'Expected real-MySQL suites did not run.' }

    $jar = Join-Path $backend 'target/rental-0.0.1-SNAPSHOT.jar'
    if (-not (Test-Path -LiteralPath $jar)) { throw 'Packaged backend JAR is missing.' }
    $sourceLines = @()
    $sourceFiles = @(Get-ChildItem -LiteralPath (Join-Path $backend 'src') -File -Recurse)
    $sourceFiles += Get-ChildItem -LiteralPath (Join-Path $backend '.mvn') -File -Recurse
    $sourceFiles += Get-Item -LiteralPath (Join-Path $backend 'pom.xml'), (Join-Path $backend 'Dockerfile'), (Join-Path $backend 'mvnw.cmd')
    foreach ($file in ($sourceFiles | Sort-Object FullName)) {
        $relative = $file.FullName.Substring($backend.Length + 1).Replace('\', '/')
        $sourceLines += $relative + ' ' + (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash
    }
    $sourceManifest = Join-Path $output 'source-sha256.txt'
    [IO.File]::WriteAllLines($sourceManifest, $sourceLines, $utf8)
    $revision = (& git -C $workspace rev-parse HEAD).Trim()
    $result = [ordered]@{
        started_utc = $started.ToString('o'); completed_utc = [DateTime]::UtcNow.ToString('o')
        contract_version = '1.6.0'; git_revision = $revision
        source_sha256 = (Get-FileHash -LiteralPath $sourceManifest -Algorithm SHA256).Hash
        jar_sha256 = (Get-FileHash -LiteralPath $jar -Algorithm SHA256).Hash
        mysql_version = $mysqlVersion; mysql_suites = $mysqlSuites
        suites = $suiteCount; tests = $tests; failures = $failures; errors = $errors; skipped = $skipped
        pass = $true
    }
    [IO.File]::WriteAllText($resultFile, ($result | ConvertTo-Json -Depth 4), $utf8)
    Write-Output ("PASS: {0} tests, {1} suites; real MySQL; packaged JAR. Report: {2}" -f $tests, $suiteCount, $resultFile)
} catch {
    $failed = [ordered]@{ started_utc = $started.ToString('o'); completed_utc = [DateTime]::UtcNow.ToString('o'); status = 'failed'; pass = $false }
    [IO.File]::WriteAllText($resultFile, ($failed | ConvertTo-Json), $utf8)
    throw
} finally {
    foreach ($name in $variables) { [Environment]::SetEnvironmentVariable($name, $previousEnvironment[$name], 'Process') }
    if ($created) {
        # Only the random project created above is cleaned up; its MySQL data is tmpfs.
        try { $null = Invoke-Docker ($dockerCompose + @('down', '--timeout', '10')) }
        catch { Write-Warning ('Could not stop isolated test project ' + $project + '. Check Docker locally.') }
    }
    Remove-Item -LiteralPath $envFile -ErrorAction SilentlyContinue
}
