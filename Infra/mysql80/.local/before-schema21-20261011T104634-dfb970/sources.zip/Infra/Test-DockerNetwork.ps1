[CmdletBinding()]
param(
    [string]$ComposeFile = '',
    [string]$ProjectName = ''
)

$ErrorActionPreference = 'Stop'
if (-not $ComposeFile) { $ComposeFile = Join-Path $PSScriptRoot 'compose.yaml' }

# Read-only diagnostics. Never print the complete environment or docker inspect JSON.
function Invoke-DockerRead([string[]]$Arguments) {
    # Windows PowerShell can turn native stderr into ErrorRecord objects.
    $ErrorActionPreference = 'Continue'
    $lines = @(& docker @Arguments 2>&1 | ForEach-Object { $_.ToString() })
    $code = $LASTEXITCODE
    return [pscustomobject]@{ Lines = $lines; ExitCode = $code }
}

function Get-ServiceName($Container) {
    return $Container.Config.Labels.'com.docker.compose.service'
}

function Get-NetworkNames($Container) {
    return @($Container.NetworkSettings.Networks.PSObject.Properties.Name)
}

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw 'Docker CLI was not found. Install/start Docker Desktop first.'
}

$resolvedFile = (Resolve-Path -LiteralPath $ComposeFile).Path
$composeArguments = @('compose', '-f', $resolvedFile)
if ($ProjectName) { $composeArguments += @('--project-name', $ProjectName) }

Write-Output ('Diagnostic time (UTC): ' + [DateTime]::UtcNow.ToString('o'))
Write-Output ('Compose file: ' + $resolvedFile)
$context = Invoke-DockerRead @('context', 'show')
if ($context.ExitCode -eq 0) { Write-Output ('Docker context: ' + ($context.Lines -join ' ')) }

# config --services prints only names, without expanding secrets into this report.
$services = Invoke-DockerRead ($composeArguments + @('config', '--services'))
if ($services.ExitCode -ne 0) {
    throw 'Cannot read Compose service names. Check the Compose file and required Infra/.env variables locally; do not paste .env.'
}
Write-Output ('Configured services: ' + ($services.Lines -join ', '))

$containerIds = Invoke-DockerRead ($composeArguments + @('ps', '-a', '-q'))
if ($containerIds.ExitCode -ne 0) {
    throw 'Cannot query containers. Check that Docker Desktop is running and this Docker context can reach its engine.'
}
$ids = @($containerIds.Lines | Where-Object { $_ -match '^[0-9a-f]{12,64}$' })
if ($ids.Count -eq 0) {
    Write-Output 'FINDING: No containers found for this Compose project/context. Check where Compose was started and whether a different project name was used.'
    return
}

$inspection = Invoke-DockerRead (@('inspect') + $ids)
if ($inspection.ExitCode -ne 0) {
    throw 'Cannot inspect containers; a container may have been removed during the check. Run this script again.'
}
$containers = ConvertFrom-Json -InputObject ($inspection.Lines -join [Environment]::NewLine)

foreach ($container in $containers) {
    $health = 'not configured'
    if ($container.State.Health) { $health = $container.State.Health.Status }
    $service = Get-ServiceName $container
    $project = $container.Config.Labels.'com.docker.compose.project'
    Write-Output ''
    Write-Output ("Service: {0}; container: {1}; project: {2}" -f $service, $container.Name.TrimStart('/'), $project)
    Write-Output ("State: {0}; health: {1}; exit: {2}; OOMKilled: {3}; restarts: {4}" -f $container.State.Status, $health, $container.State.ExitCode, $container.State.OOMKilled, $container.RestartCount)
    Write-Output ("Started: {0}; finished: {1}" -f $container.State.StartedAt, $container.State.FinishedAt)
    foreach ($network in $container.NetworkSettings.Networks.PSObject.Properties) {
        Write-Output ("Network: {0}; aliases: {1}" -f $network.Name, (@($network.Value.Aliases) -join ', '))
    }
}

$backends = @($containers | Where-Object { (Get-ServiceName $_) -eq 'backend' })
$databases = @($containers | Where-Object { (Get-ServiceName $_) -eq 'mysql' })
$findings = @()
if ($backends.Count -eq 0) { $findings += 'The backend container is missing from this project.' }
if ($databases.Count -eq 0) { $findings += 'The mysql container is missing from this project; its service hostname cannot be checked.' }

foreach ($backend in $backends) {
    $environment = @{}
    foreach ($entry in $backend.Config.Env) {
        $parts = $entry -split '=', 2
        if ($parts.Count -eq 2) { $environment[$parts[0]] = $parts[1] }
    }
    $databaseHost = 'localhost'
    $databasePort = '3306'
    if ($environment['MYSQL_HOST']) { $databaseHost = $environment['MYSQL_HOST'] }
    if ($environment['MYSQL_PORT']) { $databasePort = $environment['MYSQL_PORT'] }

    Write-Output ''
    Write-Output ("Backend database settings: MYSQL_HOST={0}; MYSQL_PORT={1}" -f $databaseHost, $databasePort)
    if ($environment['SPRING_DATASOURCE_URL']) {
        # Spring can override the MYSQL_HOST-based URL. Display only host and port.
        try {
            $datasource = [Uri]($environment['SPRING_DATASOURCE_URL'] -replace '^jdbc:', '')
            if (-not $datasource.Host) { throw 'No hostname' }
            $databaseHost = $datasource.Host
            Write-Output ("SPRING_DATASOURCE_URL overrides the database target: host={0}; port={1}" -f $datasource.Host, $datasource.Port)
        } catch {
            $findings += 'SPRING_DATASOURCE_URL is set but its hostname could not be parsed. Inspect this setting locally; its value is omitted.'
            $databaseHost = ''
        }
    }
    if ($environment['SPRING_APPLICATION_JSON'] -or $environment['JAVA_TOOL_OPTIONS']) {
        Write-Output 'Additional JVM/Spring settings are present. Check locally for datasource overrides; their values are omitted.'
    }
    if ($databaseHost -in @('localhost', '127.0.0.1', '::1')) {
        $findings += 'The backend targets loopback inside its own container. For this Compose MySQL service, use MYSQL_HOST=mysql and container port 3306.'
    }
    if ($backend.State.Status -ne 'running') {
        $findings += 'The backend is not running. DNS cannot be tested inside it; inspect the filtered startup logs below.'
    }

    $backendNetworks = Get-NetworkNames $backend
    foreach ($database in $databases) {
        if ($database.State.Status -ne 'running') {
            $findings += 'MySQL is not running. Its service DNS entry may be unavailable; inspect its state and logs.'
        } elseif ($database.State.Health -and $database.State.Health.Status -ne 'healthy') {
            $findings += 'MySQL is running but is not healthy yet.'
        }
        $databaseNetworks = Get-NetworkNames $database
        $sharedNetworks = @($backendNetworks | Where-Object { $_ -in $databaseNetworks })
        Write-Output ('Shared backend/MySQL networks: ' + ($sharedNetworks -join ', '))
        if ($sharedNetworks.Count -eq 0) {
            $findings += 'Backend and MySQL do not share a Docker network. The mysql service hostname will not resolve between these containers.'
        } else {
            $hasMysqlAlias = $false
            foreach ($networkName in $sharedNetworks) {
                if ('mysql' -in @($database.NetworkSettings.Networks.$networkName.Aliases)) { $hasMysqlAlias = $true }
            }
            if (-not $hasMysqlAlias) { $findings += 'MySQL has no mysql alias on a shared network. Check the Compose network configuration.' }
        }
    }

    if ($backend.State.Status -eq 'running' -and $databaseHost) {
        $dns = Invoke-DockerRead @('exec', $backend.Id, 'getent', 'hosts', $databaseHost)
        if ($dns.ExitCode -eq 0) {
            Write-Output ('DNS lookup succeeded: ' + ($dns.Lines -join ' '))
        } elseif ($dns.ExitCode -eq 2) {
            $findings += ('DNS lookup failed inside backend for host: ' + $databaseHost)
        } else {
            Write-Output ("DNS lookup could not run (exit {0}); the container may have stopped or getent may be unavailable." -f $dns.ExitCode)
        }
    }
}

Write-Output ''
Write-Output 'Relevant recent log events (last 15 minutes, at most 100 lines per service):'
$logs = Invoke-DockerRead ($composeArguments + @('logs', '--no-color', '--timestamps', '--since=15m', '--tail=100', 'backend', 'mysql'))
if ($logs.ExitCode -eq 0) {
    # Output fixed event labels rather than raw messages, which can contain secrets.
    $events = [ordered]@{
        'java.net.UnknownHostException: mysql' = 'MySQL hostname lookup failed'
        'UnknownHostException' = 'A hostname lookup failed'
        'Communications link failure' = 'MySQL communication failed'
        'Connection refused' = 'A connection was refused'
        'Access denied for user' = 'Database authentication was rejected'
        'APPLICATION FAILED TO START' = 'Spring application startup failed'
        'Started RentalApplication' = 'Backend startup completed'
        'ready for connections' = 'MySQL is ready for connections'
        'OutOfMemoryError|Cannot allocate memory' = 'A memory allocation failure was logged'
    }
    $eventCount = 0
    foreach ($line in $logs.Lines) {
        foreach ($pattern in $events.Keys) {
            if ($line -match $pattern) {
                $source = 'unknown service'
                $timestamp = 'timestamp unavailable'
                if ($line -match '^([^|]+)\|\s*(\S+)') { $source = $Matches[1].Trim(); $timestamp = $Matches[2] }
                Write-Output ("{0} | {1} | {2}" -f $source, $timestamp, $events[$pattern])
                $eventCount++
                break
            }
        }
    }
    if ($eventCount -eq 0) { Write-Output 'No matching events in this log window. Older errors are outside this report.' }
} else {
    Write-Output 'Recent logs could not be read; check whether these services exist in the selected Compose file.'
}

Write-Output ''
if ($findings.Count -gt 0) {
    $findings | Select-Object -Unique | ForEach-Object { Write-Output ('FINDING: ' + $_) }
} else {
    Write-Output 'No current container/network problem found. A successful DNS lookup does not verify database connectivity or explain an earlier failure.'
}
Write-Output 'No services, configuration, or data were changed. OOMKilled reflects container state, not a full crash history.'
