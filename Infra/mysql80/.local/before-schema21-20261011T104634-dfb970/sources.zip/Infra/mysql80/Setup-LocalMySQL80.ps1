[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$workspace = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
Set-Location -LiteralPath $workspace
try {
    Write-Host 'Roomly: prepare a separate database on native MySQL 8.0.'
    Write-Host 'Existing databases and source code will not be overwritten.'
    & python -B (Join-Path $PSScriptRoot 'local_mysql.py') setup
    if ($LASTEXITCODE -ne 0) { throw 'Setup did not finish.' }
    Write-Host ''
    Write-Host 'Setup PASS. See Infra/mysql80/README.md for Workbench connection.'
    Write-Host 'Start separate backend: python -B ./Infra/mysql80/local_mysql.py run'
} catch {
    Write-Host 'Setup could not finish. Keep this window open and report the error, never the password.'
} finally {
    Read-Host 'Press Enter to close'
}
