# MySQL 8.0 cài trực tiếp trên máy và Workbench CE

Bộ này tạo database riêng **roomly_local80** trên MySQL Server 8.0, dùng đúng 20 migration trong backend. Công cụ không sinh lại Entity/Repository, không sửa application.properties hoặc profile Docker/VPS. Workbench CE là công cụ mở database; Spring Boot kết nối tới MySQL Server. Lớp persistence đã được tối ưu riêng, xem [schema 14 bảng, sơ đồ và SQL mẫu](../../Docs%20-%20contract/SCHEMA_14_TABLES.md).

**Hiện tại V20, 11/10/2026:** Vẫn 14 bảng, tổng cột 329→283; gộp cột/index trùng, tên rõ và comment cho bảng. 275 test backend/H2/MySQL 8.0.45 đạt, không skip; 19 test công cụ đạt. V20 giữ dữ liệu/ID/version/liên kết của V19. Các mốc V19/273 test bên dưới là lịch sử trước tối ưu, không phải số test hiện tại.

Runtime V20: `backend/target/local-mysql80/schema20-runtime-20261011T061205-1462a7.json`, DDL `schema-20261011T061205-a62098.sql` cùng thư mục. Số hàng và 81 paths/components giữ nguyên, health UP; index bốn bảng chung giảm 108→95. Bản lưu nguồn/DDL/báo cáo và manifest SHA-256 ngoài build ở `Infra/mysql80/.local/schema20-completed-*/`.

Database native đã áp dụng V20. Không chạy lại setup, xóa schema hay import DDL. Với database V19 khác đã có backup đầy đủ và report native khớp JAR/migration, dừng ứng dụng ghi trước rồi dùng:

~~~powershell
python -B ./Infra/mysql80/local_mysql.py simplify
~~~

Helper chỉ nhận V19→V20 (hoặc kiểm tra V20 đã áp dụng), từ chối thiếu backup/test/checksum và session ứng dụng còn chạy. V20 kiểm tra các giá trị sao chép trước thay bảng; cần xem trạng thái/backup nếu DDL bị ngắt. Bản backup trước tối ưu local tại `Infra/mysql80/.local/before-schema20-20261011T053319-9faab5/`. Chế độ `compact` bên dưới là bước V18→V19 cũ, không dùng thay `simplify`.

Đã kiểm chứng ngày 10/10/2026 sau nâng cấp V19: MySQL Community Server **8.0.45**, dịch vụ **MySQL80**, cổng **3306**; đăng nhập bằng tài khoản ứng dụng `roomly_local80@127.0.0.1` thành công. Schema có **14 bảng** (13 bảng ứng dụng + `flyway_schema_history`), **19/19 migration** thành công. Backend khởi động với Hibernate `validate`; health `UP`, Swagger/OpenAPI, API tìm phòng/tiện ích đều HTTP 200. Global response vẫn là `statusCode`, `message`, `data`; 81 paths và components của OpenAPI không đổi so với trước nâng cấp.

Bằng chứng: `backend/target/local-mysql80/schema14-runtime-20261010T160017-91275b.json`. **273 test H2/MySQL đạt, 0 failure/error/skipped**, bao gồm 55 test MySQL opt-in trước đây và các kiểm tra gộp bảng mới; 16 test an toàn của công cụ đạt. So sánh với backup xác nhận 165 file Android, 17 controller, 32 service, 52 DTO và V1–V18 không đổi. Report `runtime-verification-20261010T151926-11fa3a.json` ghi nhận bước setup V18/37 bảng trước đợt gộp, không phải hiện trạng mới. Chưa kiểm chứng MinIO, email hoặc push trên tiến trình native này.

Kiểm tra lại 11/10/2026, 12:21 VN: vẫn PASS 14 bảng/19 migration/health UP, API không đổi. Report mới `backend/target/local-mysql80/schema14-runtime-20261011T052124-d9c854.json`; DDL thật `schema-20261011T052128-4811b8.sql` cùng thư mục. Bản lưu nguồn/DDL/báo cáo có manifest SHA-256 nằm ngoài build tại `Infra/mysql80/.local/schema14-completed-20261011T052128-ae2fb5/`. Refresh Schemas trong Workbench để cập nhật danh sách; không import lại DDL hoặc chạy setup lại.

## 1. Tạo database bằng mật khẩu nhập ẩn

Từ thư mục gốc D:/BACKEND/Mobile, mở PowerShell:

~~~powershell
powershell -NoProfile -ExecutionPolicy Bypass -File ./Infra/mysql80/Setup-LocalMySQL80.ps1
~~~

Nhập mật khẩu MySQL root ngay trong cửa sổ đó. Không gửi mật khẩu vào chat. Mật khẩu không hiện khi gõ.

Setup chỉ tạo schema/user mới khi cả hai chưa tồn tại; dừng nếu trùng tên. Backend dùng user roomly_local80 chỉ có quyền trong schema tương ứng. Mật khẩu root không lưu; credential ứng dụng ngẫu nhiên được giữ tại Infra/mysql80/.local/connection-private.json, thư mục riêng theo tài khoản Windows đã chạy setup và đã Git ignore. Cấu hình nằm ngoài backend/target để `mvn clean` không xóa mất. Chạy setup và backend bằng cùng tài khoản Windows; lỗi quyền truy cập sẽ dừng trước khi thao tác database.

Nếu mất config nhưng database đã tồn tại, không xóa database/user để chạy lại. Cần kiểm tra kết nối và khôi phục credential riêng.

Setup yêu cầu Python, MySQL client và JDK17. JAR backend phải được build trước:

~~~powershell
cd backend
$env:JAVA_HOME = 'C:/Program Files/Java/jdk-17'
./mvnw.cmd -o -B -ntp package
~~~

Không cần build lại nếu JAR hiện tại đã có và khớp code. Script migrate dùng thư viện Flyway/MySQL/Jackson từ chính JAR đó, SQL migration từ source hiện tại.

## 2. Mở trên MySQL Workbench 8.0 CE

Tạo connection mới bằng dấu +:

| Trường | Giá trị |
| --- | --- |
| Connection Name | Roomly Local MySQL80 |
| Connection Method | Standard (TCP/IP) |
| Hostname | 127.0.0.1 |
| Port | 3306 |
| Username | root để kiểm tra bằng mật khẩu bạn đã biết |
| Default Schema | roomly_local80 |

Chọn Test Connection, nhập mật khẩu trên máy. Sau khi setup PASS, refresh Schemas, mở roomly_local80 → Tables. Mở inspect_database.sql trong thư mục này và chạy các truy vấn chỉ đọc để xem phiên bản, bảng, migration và khóa ngoại.

Backend sử dụng tài khoản riêng roomly_local80; việc mở Workbench bằng root không đổi user backend.

## 3. Schema và SQL được sinh

Flyway tạo bảng theo V1–V20, lưu checksum/version trong flyway_schema_history. Giữ Hibernate ddl-auto=validate; không bật create/update, không clean hoặc baseline một schema cũ. Từ V19, 24 entity dùng bốn bảng chung có `record_type`; V20 dùng chung cột cùng nghĩa và giữ repository riêng. Các bảng/token/history cũ trong contract mô tả mô hình logic.

Database local V18 đã được sao lưu đầy đủ vào `Infra/mysql80/.local/before-schema14-20261010T152703-d69fc6/` trước khi gộp: SQL, sources.zip và manifest SHA-256. Công cụ `compact` yêu cầu backup đúng database, không có dữ liệu nghiệp vụ, checksum SQL đúng và bản JAR/migration khớp báo cáo native test PASS. V19 còn kiểm tra dữ liệu thực tế trước DDL, không chỉ tin backup. Chế độ này đã được thực thi cho `roomly_local80`; **không cần chạy lại setup/xóa database**.

Lệnh dành cho bản V18 trống đã được backup và kiểm thử đầy đủ:

~~~powershell
python -B ./Infra/mysql80/local_mysql.py compact
~~~

V19 giữ seed role/amenity; dừng khi có user/giao dịch. Nếu database V18 đang có dữ liệu, cần migration dữ liệu được rà soát riêng. Không xóa dữ liệu hoặc sửa checksum lịch sử để ép nâng cấp.

Sau setup, file schema-*.sql trong backend/target/local-mysql80 là DDL xuất từ database thật, không có dữ liệu người dùng và bỏ DROP TABLE. Dùng để đọc, dựng ER diagram hoặc làm tài liệu; không import lại đè database đang dùng và không coi bản DDL này là lịch sử Flyway.

Các thao tác riêng, từ gốc repository:

~~~powershell
python -B ./Infra/mysql80/local_mysql.py check
python -B ./Infra/mysql80/local_mysql.py export-schema
~~~

Mỗi report/output có tên mới. Migrate từ chối schema có bảng mà không có lịch sử Flyway, hoặc schema đã có bảng nhưng còn migration mới. Nâng cấp schema cũ cần quy trình backup/kiểm tra riêng. Setup mới trên database hoàn toàn trống chạy đủ V1–V20; dữ liệu demo chỉ được tạo sau migration nếu profile cho phép.

## 4. Chạy backend kết nối database này

~~~powershell
python -B ./Infra/mysql80/local_mysql.py run
~~~

Backend local riêng dùng http://127.0.0.1:18091; Swagger /swagger-ui/index.html, health /actuator/health. Profile local-mysql80 chỉ được nạp bằng lệnh trên. Cổng khác 18089 nên không dừng/thay backend Docker. Lệnh từ chối cổng đã có chương trình dùng.

Database mới bắt đầu trống, demo seed/mock payment/FCM/job xóa dữ liệu tắt. Dịch vụ MinIO/SMTP là phần riêng; thiếu chúng thì ảnh/email chưa thể hoạt động. Cấu hình Gmail/Firebase/Docker hiện có được giữ nguyên.

Nếu sau đó chọn backend local này cho điện thoại USB, dùng adb reverse tcp:18091 tcp:18091 và build Roomly với -PROOMLY_API_URL=http://127.0.0.1:18091/api/v1/. Không kết nối app Android trực tiếp tới MySQL.

## 5. Bảo toàn và kiểm chứng

Trước bước MySQL đã lưu bản nguồn tại backend/target/local-mysql80/sources-before-mysql80-*.zip. Công cụ không đổi mật khẩu root, không restart MySQL, không DROP/TRUNCATE database hiện có và không reset volume Docker. Database mới được tạo bằng DDL MySQL nên nếu một bước setup bị ngắt, có thể còn schema/user mới chưa hoàn tất; công cụ dừng để kiểm tra, không tự xóa.

Kiểm thử công cụ không chạm database:

~~~powershell
python -B -m unittest discover -s ./Infra/mysql80 -p test_local_mysql.py -v
~~~

Chạy toàn bộ backend/H2/MySQL bằng server thử riêng ở cổng **13307**, không dừng dịch vụ MySQL80/3306:

~~~powershell
python -B ./Infra/mysql80/test_schema14_mysql.py
~~~

Cần dừng tiến trình backend dùng JAR trước khi build lại trên Windows để tránh khóa file. Runner giữ tên `test_schema14_mysql.py` vì kiểm tra schema 14 bảng, hiện chạy V20. Runner tạo datadir/database thử riêng dưới `.local`, đặt mật khẩu root thử ngẫu nhiên, chạy Maven offline `package`, lưu report/checksum ở `backend/target/local-mysql80/schema20-tests-*.json` rồi tắt chính server thử đó. Cổng bận thì dừng, không tắt chương trình khác. Lần đạt gần nhất: `schema20-tests-20261011T055916-d642ec.json`, 275 test đạt. Có cả database guard V18 từ chối V19 và database V19 có dữ liệu giả để kiểm tra V20 giữ dữ liệu. Report V19 trước đó vẫn giữ riêng theo ngày.

Tham khảo [MySQL: kết nối bằng command options](https://dev.mysql.com/doc/refman/8.0/en/connecting.html), [MySQL: option files](https://dev.mysql.com/doc/refman/8.0/en/option-files.html), [Flyway: MySQL](https://documentation.red-gate.com/flyway/reference/database-driver-reference/mysql).
