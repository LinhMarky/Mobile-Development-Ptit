"""Create a private SMTP env file; read its password locally with a hidden prompt."""

import argparse
from email.utils import parseaddr
import getpass
import os
from pathlib import Path
import warnings


def dotenv_value(value: str) -> str:
    if any(character in value for character in ("\r", "\n", "\x00")):
        raise ValueError("Env values must be single-line strings")
    # In dotenv double quotes, \$ prevents interpolation; backslashes/quotes are escaped.
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"').replace("$", "\\$") + '"'


def email_address(value: str) -> str:
    address = parseaddr(value)[1]
    if "@" not in address or any(character in value for character in ("\r", "\n")):
        raise ValueError("Use a valid email address")
    return address


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gmail", action="store_true", help="smtp.gmail.com:587 with STARTTLS and an App Password")
    parser.add_argument("--host", help="Required for other providers")
    parser.add_argument("--port", type=int, default=587)
    parser.add_argument("--tls", choices=("starttls", "ssl"), default="starttls")
    parser.add_argument("--username", required=True)
    parser.add_argument("--sender", help="Authorized sender email; defaults to username")
    parser.add_argument("--recipient", help="Optional email address for later test delivery")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / ".env.smtp")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Output already exists; it was not changed. Edit the private file locally to rotate credentials.")
    host = "smtp.gmail.com" if args.gmail else args.host
    if not host or "://" in host or any(character.isspace() for character in host):
        parser.error("Provide an SMTP hostname, without URL or spaces")
    if not 1 <= args.port <= 65535:
        parser.error("Invalid SMTP port")
    try:
        sender = email_address(args.sender or args.username)
        recipient = email_address(args.recipient) if args.recipient else ""
        if args.gmail:
            email_address(args.username)
    except ValueError as error:
        parser.error(str(error))
    # getpass otherwise falls back to an echoed input when no secure terminal exists.
    with warnings.catch_warnings():
        warnings.simplefilter("error", getpass.GetPassWarning)
        try:
            password = getpass.getpass("Gmail App Password (hidden): " if args.gmail else "SMTP password (hidden): ")
        except getpass.GetPassWarning:
            parser.error("Run this command directly in an interactive terminal; password input was not read")
    if args.gmail:
        password = password.replace(" ", "")
        if len(password) != 16 or not password.isascii() or not password.isalnum():
            parser.error("Use the 16-character Gmail App Password, not your regular Google password")
    if not password:
        parser.error("Password is required")
    starttls = args.gmail or args.tls == "starttls"
    values = {"SMTP_HOST": host, "SMTP_PORT": "587" if args.gmail else str(args.port),
              "SMTP_USERNAME": args.username, "SMTP_PASSWORD": password, "MAIL_FROM": sender,
              "SMTP_STARTTLS": str(starttls).lower(), "SMTP_SSL": str(not starttls).lower(),
              "SMTP_TEST_RECIPIENT": recipient}
    try:
        content = "# Private SMTP credentials; never commit, paste or print this file.\n"
        content += "".join(f"{key}={dotenv_value(value)}\n" for key, value in values.items())
        descriptor = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except (ValueError, OSError):
        parser.error("Could not create the private file; existing files were not replaced")
    with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
        stream.write(content)
    print(f"Created {args.output}; password was not printed. No email was sent.")
    print("Supply this file with --smtp-env when running the SMTP checker and VPS stack commands.")


if __name__ == "__main__":
    main()
