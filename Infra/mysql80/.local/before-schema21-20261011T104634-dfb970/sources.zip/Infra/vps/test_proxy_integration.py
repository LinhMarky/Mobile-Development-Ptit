"""Test real Nginx with an isolated local HTTP/STOMP fixture, not application data."""

import argparse
import base64
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import shutil
import ssl
import subprocess
import threading
import time
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import uuid

from check_public import exact, websocket
from render_proxy import render


class Fixture(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def do_GET(self):
        if self.path == "/ws" and self.headers.get("Upgrade", "").lower() == "websocket":
            if self.headers.get("Authorization") != "Bearer fixture":
                self.send_error(401)
                return
            accept = base64.b64encode(hashlib.sha1((self.headers["Sec-WebSocket-Key"] + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()
            self.send_response(101)
            self.send_header("Upgrade", "websocket")
            self.send_header("Connection", "Upgrade")
            self.send_header("Sec-WebSocket-Accept", accept)
            self.end_headers()
            self.wfile.flush()
            _, length = exact(self.rfile, 2)
            mask = exact(self.rfile, 4)
            payload = exact(self.rfile, length & 0x7F)
            payload = bytes(value ^ mask[index % 4] for index, value in enumerate(payload))
            if payload.startswith(b"CONNECT\n"):
                reply = b"CONNECTED\nversion:1.2\n\n\x00"
                self.wfile.write(bytes([0x81, len(reply)]) + reply)
                self.wfile.flush()
            self.close_connection = True
            return
        body = json.dumps({"path": self.path, "forwarded_for": self.headers.get("X-Forwarded-For"),
                           "scheme": self.headers.get("X-Forwarded-Proto"), "forwarded": self.headers.get("Forwarded"),
                           "authorization": self.headers.get("Authorization")}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def run(*arguments: str) -> str:
    result = subprocess.run(list(arguments), capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(f"Test command failed: {arguments[0]} {arguments[1:3]}\n{result.stderr[-1800:]}")
    return result.stdout.strip()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--nginx-image", default="nginx:1.28-alpine")
    args = parser.parse_args()
    root = args.output_dir.resolve()
    root.mkdir(parents=True, exist_ok=True)
    certificate_dir = root / "letsencrypt" / "live" / "homely-api"
    certificate_dir.mkdir(parents=True, exist_ok=True)
    openssl = shutil.which("openssl")
    if not openssl:
        raise RuntimeError("OpenSSL is required for an isolated one-day test certificate")
    run(openssl, "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1", "-subj", "/CN=127.0.0.1",
        "-addext", "subjectAltName=IP:127.0.0.1", "-keyout", str(certificate_dir / "privkey.pem"), "-out", str(certificate_dir / "fullchain.pem"))
    server = ThreadingHTTPServer(("127.0.0.1", 0), Fixture)
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, daemon=True).start()
    bootstrap, tls = render("127.0.0.1", server.server_port)
    # Windows Docker Desktop reaches the local fixture through host.docker.internal.
    # The actual VPS template retains host Nginx -> 127.0.0.1 as rendered.
    tls = tls.replace(f"http://127.0.0.1:{server.server_port}", f"http://host.docker.internal:{server.server_port}")
    (root / "bootstrap.conf").write_text(bootstrap, encoding="utf-8", newline="\n")
    (root / "tls.conf").write_text(tls, encoding="utf-8", newline="\n")
    mount = ["--mount", f"type=bind,source={root / 'letsencrypt'},target=/etc/letsencrypt,readonly"]
    name = "homely-proxy-test-" + uuid.uuid4().hex[:10]
    results = {"scope": "Nginx with HTTP/STOMP fixture; no real VPS, backend, SMTP or Firebase", "status": "running"}
    (root / "result.json").write_text(json.dumps(results, indent=2))
    try:
        for file in ("bootstrap.conf", "tls.conf"):
            run("docker", "run", "--rm", *mount, "--mount", f"type=bind,source={root / file},target=/etc/nginx/conf.d/default.conf,readonly",
                args.nginx_image, "nginx", "-t")
        print("PASS Nginx: bootstrap and TLS configurations pass nginx -t")
        run("docker", "run", "-d", "--name", name, "-p", "127.0.0.1::443", "--memory", "128m", *mount,
            "--mount", f"type=bind,source={root / 'tls.conf'},target=/etc/nginx/conf.d/default.conf,readonly", args.nginx_image)
        binding = run("docker", "port", name, "443/tcp").splitlines()[0]
        origin = "https://" + binding
        context = ssl.create_default_context(cafile=str(certificate_dir / "fullchain.pem"))
        request = Request(origin + "/api/v1/echo?token=fixture-secret-query", headers={"X-Forwarded-For": "198.51.100.99", "Forwarded": "for=198.51.100.99;proto=http", "X-Forwarded-Proto": "http", "Authorization": "Bearer fixture"})
        response = None
        for _ in range(20):
            try:
                response = urlopen(request, context=context, timeout=5)
                break
            except OSError:
                time.sleep(0.25)
        if response is None:
            raise RuntimeError("Nginx could not reach the loopback HTTP fixture")
        with response:
            body = json.load(response)
        assert body["path"] == "/api/v1/echo?token=fixture-secret-query"
        assert body["forwarded_for"] and body["forwarded_for"] != "198.51.100.99"
        assert body["scheme"] == "https" and body["forwarded"] is None
        assert body["authorization"] == "Bearer fixture"
        print("PASS HTTPS proxy: path/query and auth preserved; spoofed IP/protocol headers replaced")
        websocket(origin, context, "fixture")
        import http.client
        connection = http.client.HTTPSConnection("127.0.0.1", int(binding.rsplit(":", 1)[1]), context=context, timeout=10)
        connection.request("POST", "/api/v1/media/upload", headers={"Content-Length": str(61 * 1024 * 1024)})
        oversized = connection.getresponse()
        body = json.loads(oversized.read())
        assert oversized.status == 413 and body["statusCode"] == 413 and body["data"]["trace_id"]
        connection.close()
        print("PASS upload guard: oversized declared body rejected with HTTP 413 JSON envelope")
        try:
            urlopen(origin + "/actuator/metrics", context=context, timeout=5)
            raise AssertionError("Metrics are public")
        except HTTPError as error:
            assert error.code == 404
        access_log = run("docker", "exec", name, "cat", "/var/log/nginx/homely-access.log")
        assert "fixture-secret-query" not in access_log
        print("PASS proxy privacy: metrics blocked; access log omits query tokens")
        server.shutdown()
        server.server_close()
        try:
            urlopen(origin + "/api/v1/echo", context=context, timeout=10)
            raise AssertionError("Unavailable fixture unexpectedly responded")
        except HTTPError as error:
            body = json.load(error)
            assert error.code == 502 and body["statusCode"] == 502 and body["data"]["trace_id"]
        print("PASS unavailable upstream: HTTP 502 JSON envelope")
        results["status"] = "passed"
        results["nginx_image"] = args.nginx_image
        results["checks"] = ["syntax", "TLS", "paths", "header_spoofing", "authorization", "WSS_STOMP", "upload_413", "metrics_privacy", "log_privacy", "upstream_502"]
    finally:
        server.shutdown()
        server.server_close()
        subprocess.run(["docker", "rm", "-f", name], capture_output=True)
        if results["status"] != "passed":
            results["status"] = "failed"
        (root / "result.json").write_text(json.dumps(results, indent=2) + "\n")
    print("PASS isolated proxy integration; only this test container was removed.")


if __name__ == "__main__":
    main()
