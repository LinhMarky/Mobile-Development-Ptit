"""Render host Nginx configuration and public FE URLs; never modify system files."""

import argparse
import ipaddress
import json
from pathlib import Path
import re


def validate_host(value: str) -> str:
    value = value.strip().lower()
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        labels = value.split(".")
        if len(labels) < 2 or len(value) > 253 or not all(
            re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label) for label in labels
        ):
            raise ValueError("Use an IPv4 address or DNS hostname, without URL, port or path")
        if all(label.isdigit() for label in labels):
            raise ValueError("Invalid IPv4 address")
        return value
    if address.version != 4:
        raise ValueError("This deployment recipe supports public IPv4; IPv6 requires a separate listener")
    return str(address)


def trusted_regex(addresses: list[str]) -> str:
    exact = {str(ipaddress.ip_address(value)) for value in addresses}
    if not exact:
        raise ValueError("Provide exact proxy IP addresses; CIDR ranges and wildcards are not accepted")
    return "^(" + "|".join(re.escape(value) for value in sorted(exact)) + ")$"


def error_locations(statuses: tuple[int, ...]) -> str:
    locations = []
    for status in statuses:
        detail = "Request body is too large" if status == 413 else "Backend is temporarily unavailable"
        code = "REQUEST_TOO_LARGE" if status == 413 else "SERVICE_UNAVAILABLE"
        title = {413: "Payload Too Large", 502: "Bad Gateway", 503: "Service Unavailable", 504: "Gateway Timeout"}[status]
        problem = {"type": "urn:problem:" + code.lower().replace("_", "-"), "title": title, "status": status,
                   "detail": detail, "instance": "/", "code": code, "field_errors": [],
                   "trace_id": "$request_id", "timestamp": "$time_iso8601"}
        body = json.dumps({"statusCode": status, "message": detail, "data": problem}, separators=(",", ":"))
        locations.append(f"""
    error_page {status} = @homely_{status};
    location @homely_{status} {{
        default_type application/json;
        add_header Cache-Control no-store always;
        return {status} '{body}';
    }}
""")
    return "".join(locations)


def proxy_locations(port: int) -> str:
    return f"""
    client_max_body_size 60m;
    client_body_timeout 120s;
    proxy_connect_timeout 5s;
    proxy_send_timeout 120s;
    proxy_read_timeout 120s;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Host $host;
    proxy_set_header X-Forwarded-Port $server_port;
    proxy_set_header X-Forwarded-Proto $scheme;
    # Replace untrusted client headers: do not use $proxy_add_x_forwarded_for here.
    proxy_set_header X-Forwarded-For $remote_addr;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header Forwarded "";
    proxy_set_header Connection "";
    proxy_intercept_errors off;

    location = /actuator/health {{
        proxy_pass http://127.0.0.1:{port};
    }}
    location /actuator {{ return 404; }}
    location = /ws {{
        proxy_pass http://127.0.0.1:{port};
        # Nginx inherits proxy_set_header only if none are set in this location.
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Host $host;
        proxy_set_header X-Forwarded-Port $server_port;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header Forwarded "";
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
        proxy_buffering off;
    }}
    location / {{
        # No trailing slash: preserve /api/v1, media and OpenAPI paths.
        proxy_pass http://127.0.0.1:{port};
    }}
"""


def render(host: str, port: int) -> tuple[str, str]:
    challenge = """
    location ^~ /.well-known/acme-challenge/ {
        root /var/www/homely-acme;
        default_type text/plain;
        try_files $uri =404;
    }
"""
    # Log path without query strings: verify-email tokens must not enter access logs.
    logging = """log_format homely_safe '$remote_addr [$time_local] "$request_method $uri $server_protocol" '
                       '$status $body_bytes_sent rt=$request_time';
"""
    bootstrap = logging + f"""server {{
    listen 80;
    server_name {host};
    access_log /var/log/nginx/homely-access.log homely_safe;
    error_log /var/log/nginx/homely-error.log warn;
{challenge}{error_locations((503,))}
    # Do not accept passwords or tokens over HTTP while provisioning TLS.
    location / {{ return 503; }}
}}
"""
    tls = logging + f"""server {{
    listen 80;
    server_name {host};
    access_log /var/log/nginx/homely-access.log homely_safe;
{challenge}
    location / {{ return 308 https://{host}$request_uri; }}
}}

server {{
    listen 443 ssl;
    server_name {host};
    ssl_certificate /etc/letsencrypt/live/homely-api/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/homely-api/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_session_cache shared:HomelyTLS:10m;
    ssl_session_timeout 1d;
    ssl_session_tickets off;
    access_log /var/log/nginx/homely-access.log homely_safe;
    error_log /var/log/nginx/homely-error.log warn;
    add_header X-Content-Type-Options nosniff always;
{proxy_locations(port)}{error_locations((413, 502, 503, 504))}
}}
"""
    return bootstrap, tls


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True, help="Public VPS IPv4 address or DNS hostname")
    parser.add_argument("--api-port", type=int, default=8080)
    parser.add_argument("--trusted-proxy", action="append", required=True, help="Exact IP; repeat for loopback and Docker bridge gateway")
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent / "generated" / "proxy")
    args = parser.parse_args()
    try:
        host = validate_host(args.host)
        regex = trusted_regex(args.trusted_proxy)
        if not 1 <= args.api_port <= 65535:
            raise ValueError("API port must be between 1 and 65535")
    except ValueError as error:
        parser.error(str(error))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    bootstrap, tls = render(host, args.api_port)
    files = {
        "nginx-bootstrap.conf": bootstrap,
        "nginx-tls.conf": tls,
        # Single quotes preserve the regex backslashes in Docker Compose dotenv parsing.
        "proxy.env": f"PUBLIC_ORIGIN=https://{host}\nTRUSTED_PROXY_REGEX='{regex}'\n",
        "fe-connection.env": f"API_ORIGIN=https://{host}\nAPI_BASE_URL=https://{host}/api/v1/\nWS_URL=wss://{host}/ws\nSWAGGER_URL=https://{host}/swagger-ui/index.html\nOPENAPI_URL=https://{host}/v3/api-docs\n",
    }
    for name, content in files.items():
        (args.output_dir / name).write_text(content, encoding="utf-8", newline="\n")
    print(f"Rendered {args.output_dir}; system Nginx, certificates and existing secrets were not changed.")
    print("Install bootstrap first, obtain a trusted certificate, then install TLS configuration.")


if __name__ == "__main__":
    main()
