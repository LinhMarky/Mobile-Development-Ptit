"""Offline tests: no Docker daemon, real credentials, OAuth or FCM calls."""

from contextlib import redirect_stderr, redirect_stdout
import io
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import MagicMock, Mock, patch

import check_firebase as check


PROJECT = "roomly-test-project"
PRIVATE_VALUE = "DO_NOT_PRINT_PRIVATE_KEY_OR_REMOTE_BODY"


class FirebaseConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.credential = self.directory / "service-account.json"
        self.metadata = {
            "type": "service_account",
            "project_id": PROJECT,
            "client_email": "test@roomly-test-project.iam.gserviceaccount.com",
            "private_key_id": "fake-id",
            "private_key": "-----BEGIN PRIVATE KEY-----\n" + PRIVATE_VALUE,
            "token_uri": check.OAUTH_URL,
        }
        self.backend = {
            "environment": {
                "FCM_ENABLED": "true", "FIREBASE_PROJECT_ID": PROJECT,
                "GOOGLE_APPLICATION_CREDENTIALS": check.CREDENTIAL_TARGET,
            },
            "volumes": [{
                "type": "bind", "source": str(self.credential), "target": check.CREDENTIAL_TARGET,
                "read_only": True, "bind": {"create_host_path": False},
            }],
        }
        self.write_credential()

    def write_credential(self):
        self.credential.write_text(json.dumps(self.metadata), encoding="utf-8")

    def assert_configuration_rejected(self):
        with self.assertRaises(check.PreflightError) as caught:
            check.validate_configuration(self.backend)
        self.assertEqual("CONFIGURATION_INVALID", caught.exception.code)
        self.assertNotIn(PRIVATE_VALUE, str(caught.exception))

    def test_accepts_existing_readonly_matching_service_account(self):
        self.assertEqual((PROJECT, self.credential), check.validate_configuration(self.backend))

    def test_rejects_cross_project_service_account(self):
        self.metadata["project_id"] = "another-project"
        self.write_credential()
        self.assert_configuration_rejected()

    def test_rejects_foreign_oauth_endpoint(self):
        for endpoint in ("https://attacker.example/token", "https://oauth2.googleapis.com/token?key=secret", None):
            with self.subTest(endpoint=endpoint):
                self.metadata["token_uri"] = endpoint
                self.write_credential()
                self.assert_configuration_rejected()

    def test_rejects_foreign_universe_and_unsafe_project_path(self):
        self.metadata["universe_domain"] = "attacker.example"
        self.write_credential()
        self.assert_configuration_rejected()
        self.metadata.pop("universe_domain")
        self.write_credential()
        self.backend["environment"]["FIREBASE_PROJECT_ID"] = "valid-project/../../foreign"
        self.assert_configuration_rejected()

    def test_rejects_missing_file_disabled_fcm_and_writable_mount(self):
        self.backend["environment"]["FCM_ENABLED"] = "false"
        self.assert_configuration_rejected()
        self.backend["environment"]["FCM_ENABLED"] = "true"
        self.backend["volumes"][0]["read_only"] = False
        self.assert_configuration_rejected()
        self.backend["volumes"][0]["read_only"] = True
        self.credential.unlink()
        self.assert_configuration_rejected()

    def test_malformed_private_json_does_not_escape_validation(self):
        self.credential.write_text('{"private_key": "' + PRIVATE_VALUE, encoding="utf-8")
        self.assert_configuration_rejected()

    def test_compose_always_selects_firebase_and_optional_smtp(self):
        env_file = self.directory / ".env"
        smtp_file = self.directory / ".env.smtp"
        env_file.touch()
        smtp_file.touch()
        args = SimpleNamespace(env_file=env_file, smtp_env=smtp_file, demo=True, prod=False)
        self.backend["environment"]["TEST_LITERAL"] = "dollar$$value"
        resolved = SimpleNamespace(returncode=0, stdout=json.dumps({"services": {"backend": self.backend}}))
        with patch.object(check.subprocess, "run", return_value=resolved) as run:
            backend = check.compose_backend(args)
        command = run.call_args.args[0]
        self.assertEqual(2, command.count("--env-file"))
        self.assertTrue(any(item.endswith("compose.demo.yaml") for item in command))
        self.assertTrue(any(item.endswith("compose.smtp.yaml") for item in command))
        self.assertTrue(any(item.endswith("compose.firebase.yaml") for item in command))
        self.assertEqual(["config", "--format", "json"], command[-3:])
        self.assertEqual("dollar$value", backend["environment"]["TEST_LITERAL"])
        self.assertEqual({"capture_output": True, "text": True, "timeout": 30, "check": False}, run.call_args.kwargs)

    def test_compose_failure_hides_output_and_missing_file_never_invokes_docker(self):
        env_file = self.directory / ".env"
        env_file.touch()
        args = SimpleNamespace(env_file=env_file, smtp_env=None, demo=False, prod=True)
        failed = SimpleNamespace(returncode=1, stdout=PRIVATE_VALUE, stderr=PRIVATE_VALUE)
        with patch.object(check.subprocess, "run", return_value=failed):
            with self.assertRaises(check.PreflightError) as caught:
                check.compose_backend(args)
        self.assertEqual("COMPOSE_UNAVAILABLE", caught.exception.code)
        self.assertNotIn(PRIVATE_VALUE, str(caught.exception))
        env_file.unlink()
        with patch.object(check.subprocess, "run") as run:
            with self.assertRaises(check.PreflightError):
                check.compose_backend(args)
        run.assert_not_called()


class FirebaseNetworkTests(unittest.TestCase):
    def setUp(self):
        self.credentials = Mock(token=PRIVATE_VALUE)
        self.credentials_type = Mock()
        self.credentials_type.from_service_account_file.return_value = self.credentials
        self.oauth_session = Mock()
        self.api_session = Mock()
        self.response = Mock(status_code=200)
        self.api_session.post.return_value = self.response
        self.requests = Mock()
        first_context = MagicMock()
        second_context = MagicMock()
        first_context.__enter__.return_value = self.oauth_session
        second_context.__enter__.return_value = self.api_session
        self.requests.Session.side_effect = [first_context, second_context]
        self.request_type = Mock()
        self.dependencies = patch.object(check, "load_dependencies", return_value=(
            self.requests, self.credentials_type, self.request_type,
        ))
        self.dependencies.start()
        self.addCleanup(self.dependencies.stop)

    def run_check(self):
        return check.check_api(PROJECT, Path("fake-service-account.json"))

    def test_success_is_validation_only_with_fixed_url_scope_and_sanitized_result(self):
        result = self.run_check()
        self.assertTrue(result["pass"])
        self.assertTrue(result["oauth_authenticated"])
        self.assertTrue(result["fcm_api_verified"])
        self.assertTrue(result["validate_only"])
        self.assertFalse(result["phone_delivery_verified"])
        self.assertEqual(200, result["http_status"])
        self.assertNotIn(PRIVATE_VALUE, json.dumps(result))
        self.credentials_type.from_service_account_file.assert_called_once_with(
            "fake-service-account.json", scopes=[check.FCM_SCOPE],
        )
        call = self.api_session.post.call_args
        self.assertEqual(f"https://fcm.googleapis.com/v1/projects/{PROJECT}/messages:send", call.args[0])
        self.assertIs(True, call.kwargs["verify"])
        self.assertIs(False, call.kwargs["allow_redirects"])
        self.assertEqual((5, 15), call.kwargs["timeout"])
        payload = call.kwargs["json"]
        self.assertIs(True, payload["validate_only"])
        self.assertEqual("roomly-backend-preflight", payload["message"]["topic"])
        self.assertNotIn("token", payload["message"])
        self.assertEqual({"notification_id", "recipient_id", "title", "body", "ref_type", "ref_id"}, set(payload["message"]["data"]))
        self.assertTrue(all(isinstance(value, str) for value in payload["message"]["data"].values()))
        self.assertEqual({"priority": "HIGH", "ttl": "3600s"}, payload["message"]["android"])
        self.response.json.assert_not_called()

    def test_oauth_transport_forces_tls_timeout_and_rejects_redirect_target(self):
        request = Mock()
        bounded = check.VerifiedOAuthRequest(request)
        bounded(check.OAUTH_URL, method="POST", body="body", headers={"test": "value"}, timeout=999, verify=False)
        self.assertEqual((5, 15), request.call_args.kwargs["timeout"])
        self.assertIs(True, request.call_args.kwargs["verify"])
        self.assertIs(False, request.call_args.kwargs["allow_redirects"])
        for url, method in (("https://attacker.example/token", "POST"), (check.OAUTH_URL, "GET")):
            with self.assertRaises(check.PreflightError):
                bounded(url, method=method)
        self.assertEqual(1, request.call_count)

    def test_oauth_denial_hides_exception_and_never_calls_fcm(self):
        self.credentials.refresh.side_effect = RuntimeError(PRIVATE_VALUE)
        result = self.run_check()
        self.assertFalse(result["oauth_authenticated"])
        self.assertFalse(result["pass"])
        self.assertEqual("OAUTH_AUTHENTICATION_FAILED", result["error_code"])
        self.assertNotIn(PRIVATE_VALUE, json.dumps(result))
        self.api_session.post.assert_not_called()

    def test_disabled_api_reason_is_allowlisted_without_remote_messages(self):
        self.response.status_code = 403
        self.response.json.return_value = {"error": {
            "status": "PERMISSION_DENIED", "message": PRIVATE_VALUE,
            "details": [{"reason": "SERVICE_DISABLED", "metadata": {"secret": PRIVATE_VALUE}}],
        }}
        result = self.run_check()
        self.assertEqual("SERVICE_DISABLED", result["error_code"])
        self.assertTrue(result["oauth_authenticated"])
        self.assertFalse(result["fcm_api_verified"])
        self.assertNotIn(PRIVATE_VALUE, json.dumps(result))

    def test_permission_denial_is_allowlisted(self):
        self.response.status_code = 403
        self.response.json.return_value = {"error": {"status": "PERMISSION_DENIED", "message": PRIVATE_VALUE}}
        result = self.run_check()
        self.assertEqual("PERMISSION_DENIED", result["error_code"])
        self.assertEqual(403, result["http_status"])
        self.assertNotIn(PRIVATE_VALUE, json.dumps(result))

    def test_unknown_remote_error_is_sanitized(self):
        self.response.status_code = 502
        self.response.json.return_value = {"error": {"status": PRIVATE_VALUE, "message": PRIVATE_VALUE}}
        result = self.run_check()
        self.assertEqual("FCM_REJECTED", result["error_code"])
        self.assertNotIn(PRIVATE_VALUE, json.dumps(result))

    def test_network_error_is_sanitized(self):
        self.api_session.post.side_effect = RuntimeError(PRIVATE_VALUE)
        result = self.run_check()
        self.assertEqual("NETWORK_FAILED", result["error_code"])
        self.assertTrue(result["oauth_authenticated"])
        self.assertNotIn(PRIVATE_VALUE, json.dumps(result))


class FirebaseCliTests(unittest.TestCase):
    def test_missing_optional_dependencies_has_safe_actionable_message(self):
        import builtins
        original_import = builtins.__import__

        def import_without_requests(name, *args, **kwargs):
            if name == "requests":
                raise ImportError(PRIVATE_VALUE)
            return original_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=import_without_requests):
            with self.assertRaises(check.PreflightError) as caught:
                check.load_dependencies()
        self.assertEqual("DEPENDENCIES_MISSING", caught.exception.code)
        self.assertIn("requirements-firebase.txt", str(caught.exception))
        self.assertNotIn(PRIVATE_VALUE, str(caught.exception))

    def test_cli_writes_fresh_sanitized_evidence_and_rejects_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "evidence.json"
            result = check.evidence(PROJECT)
            result.update(oauth_authenticated=True, fcm_api_verified=True, http_status=200, **{"pass": True})
            stdout, stderr = io.StringIO(), io.StringIO()
            with patch.object(check, "compose_backend", return_value={}), patch.object(
                check, "validate_configuration", return_value=(PROJECT, Path("fake.json")),
            ), patch.object(check, "run_preflight", return_value=result) as network:
                with redirect_stdout(stdout), redirect_stderr(stderr):
                    self.assertEqual(0, check.main(["--demo", "--output", str(output)]))
                    original = output.read_bytes()
                    self.assertEqual(1, check.main(["--demo", "--output", str(output)]))
                network.assert_called_once()
            self.assertEqual(original, output.read_bytes())
            saved = json.loads(original)
            self.assertTrue(saved["pass"])
            self.assertTrue(saved["validate_only"])
            self.assertFalse(saved["phone_delivery_verified"])
            self.assertNotIn(PRIVATE_VALUE, stdout.getvalue() + stderr.getvalue())

    def test_cli_configuration_failure_does_not_print_exception(self):
        stdout, stderr = io.StringIO(), io.StringIO()
        with patch.object(check, "compose_backend", side_effect=RuntimeError(PRIVATE_VALUE)):
            with redirect_stdout(stdout), redirect_stderr(stderr):
                self.assertEqual(1, check.main([]))
        self.assertIn("CHECK_FAILED", stdout.getvalue())
        self.assertNotIn(PRIVATE_VALUE, stdout.getvalue() + stderr.getvalue())

    def test_standalone_requires_both_arguments_and_rejects_compose_flags(self):
        invalid_options = [
            ["--credential-file", "fake.json"], ["--project-id", PROJECT],
        ]
        standalone = ["--credential-file", "fake.json", "--project-id", PROJECT]
        for extra in (["--demo"], ["--prod"], ["--env-file", ".env"], ["--smtp-env", ".env.smtp"]):
            invalid_options.append(standalone + extra)
        for options in invalid_options:
            with self.subTest(options=options), redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as caught:
                    check.parse_args(options)
                self.assertEqual(2, caught.exception.code)

    def test_standalone_never_requires_docker_or_compose_env(self):
        result = check.evidence(PROJECT)
        result.update(oauth_authenticated=True, fcm_api_verified=True, http_status=200, **{"pass": True})
        with patch.object(check, "compose_backend") as compose, patch.object(
            check, "validate_service_account", return_value=(PROJECT, Path("fake.json")),
        ), patch.object(check, "run_preflight", return_value=result) as network:
            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                status = check.main(["--credential-file", "fake.json", "--project-id", PROJECT])
        self.assertEqual(0, status)
        compose.assert_not_called()
        network.assert_called_once_with(PROJECT, Path("fake.json"))

    def test_run_preflight_validates_metadata_before_network(self):
        with patch.object(check, "validate_service_account", side_effect=check.PreflightError("CONFIGURATION_INVALID")):
            with patch.object(check, "check_api") as network:
                with self.assertRaises(check.PreflightError):
                    check.run_preflight(PROJECT, "fake.json")
        network.assert_not_called()


if __name__ == "__main__":
    unittest.main()
