"""Check HTTPS API and optionally an authenticated WSS/STOMP handshake from outside VPS."""

import argparse
import base64
import hashlib
import json
import os
import socket
import ssl
import struct
import sys
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def http(origin: str, path: str, status: int, context: ssl.SSLContext, as_json: bool = True):
    try:
        response = urlopen(Request(origin + path), timeout=20, context=context)
    except HTTPError as error:
        response = error
    with response:
        require(response.status == status, f"Unexpected HTTP status for {path}: {response.status}")
        return json.load(response) if as_json else response.read()


def exact(stream, size: int) -> bytes:
    data = bytearray()
    while len(data) < size:
        chunk = stream.read(size - len(data))
        require(bool(chunk), "WebSocket closed before the expected frame")
        data.extend(chunk)
    return bytes(data)


def send_frame(connection, payload: bytes, opcode: int = 1) -> None:
    mask = os.urandom(4)
    length = len(payload)
    prefix = bytes([0x80 | opcode, 0x80 | length]) if length < 126 else bytes([0x80 | opcode, 0xFE]) + struct.pack("!H", length)
    connection.sendall(prefix + mask + bytes(value ^ mask[index % 4] for index, value in enumerate(payload)))


def websocket(origin: str, context: ssl.SSLContext, token: str) -> None:
    target = urlsplit(origin)
    key = base64.b64encode(os.urandom(16)).decode("ascii")
    with socket.create_connection((target.hostname, target.port or 443), timeout=20) as raw:
        with context.wrap_socket(raw, server_hostname=target.hostname) as connection:
            connection.settimeout(20)
            handshake = (
                f"GET /ws HTTP/1.1\r\nHost: {target.netloc}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n"
                f"Authorization: Bearer {token}\r\n\r\n"
            )
            connection.sendall(handshake.encode("ascii"))
            stream = connection.makefile("rb")
            status = stream.readline(4096)
            require(b" 101 " in status, "Authenticated WSS handshake did not return 101")
            headers = {}
            for _ in range(100):
                line = stream.readline(8192)
                if line == b"\r\n":
                    break
                require(bool(line), "Incomplete WSS handshake")
                name, value = line.decode("ascii").split(":", 1)
                headers[name.lower()] = value.strip()
            expected = base64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("ascii")).digest()).decode("ascii")
            require(headers.get("sec-websocket-accept") == expected, "Invalid WebSocket accept key")
            send_frame(connection, b"CONNECT\naccept-version:1.2\nheart-beat:0,0\n\n\x00")
            for _ in range(10):
                first, second = exact(stream, 2)
                length = second & 0x7F
                if length == 126:
                    length = struct.unpack("!H", exact(stream, 2))[0]
                elif length == 127:
                    length = struct.unpack("!Q", exact(stream, 8))[0]
                require(not second & 0x80 and length <= 65536, "Invalid or oversized server WebSocket frame")
                payload = exact(stream, length)
                opcode = first & 0x0F
                if opcode == 9:
                    send_frame(connection, payload, 10)
                    continue
                require(opcode != 8, "Server closed WSS before STOMP CONNECTED")
                if opcode == 1 and payload.lstrip(b"\r\n").startswith(b"CONNECTED\n"):
                    send_frame(connection, b"DISCONNECT\n\n\x00")
                    send_frame(connection, struct.pack("!H", 1000), 8)
                    print("PASS WSS: trusted TLS, authenticated HTTP Upgrade=101, STOMP CONNECTED")
                    return
            raise ValueError("STOMP CONNECTED was not received")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--origin", required=True, help="HTTPS origin without /api/v1, e.g. https://<VPS-IP>")
    parser.add_argument("--websocket", action="store_true", help="Use HOMELY_ACCESS_TOKEN from environment; never put tokens in command arguments")
    parser.add_argument("--ca-file", help="Optional trusted CA file for an isolated local proxy test; never disables verification")
    args = parser.parse_args()
    target = urlsplit(args.origin)
    require(target.scheme == "https" and bool(target.hostname) and target.path in ("", "/") and not target.query and not target.fragment and not target.username,
            "Provide only an HTTPS origin")
    origin = args.origin.rstrip("/")
    context = ssl.create_default_context(cafile=args.ca_file)
    require(http(origin, "/actuator/health", 200, context).get("status") == "UP", "Backend health is not UP")
    api = http(origin, "/v3/api-docs", 200, context)
    require(api["info"]["version"] == "1.6.0", "Unexpected API version")
    listing = http(origin, "/api/v1/listings?page=0&size=1", 200, context)
    require(set(listing) == {"statusCode", "message", "data"} and listing["statusCode"] == 200, "Search success envelope changed")
    require(isinstance(listing["data"]["data"], list), "Listing page data is not an array")
    for path in ("/api/v1/profile", "/ws"):
        error = http(origin, path, 401, context)
        require(set(error) == {"statusCode", "message", "data"} and error["statusCode"] == 401 and error["data"]["trace_id"], "Unauthenticated JSON envelope changed")
    require(b"swagger" in http(origin, "/swagger-ui/index.html", 200, context, False).lower(), "Swagger UI is unavailable")
    http(origin, "/actuator/metrics", 404, context, False)
    print(f"PASS HTTPS: trusted TLS; health; API {api['info']['version']}; wrapper; guest search; 401; Swagger; private metrics")
    if args.websocket:
        token = os.environ.get("HOMELY_ACCESS_TOKEN", "")
        require(bool(token) and "\r" not in token and "\n" not in token, "Set HOMELY_ACCESS_TOKEN to a current access token")
        websocket(origin, context, token)
    else:
        print("Authenticated WSS not checked; run --websocket with a current access token.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError) as error:
        print(f"FAIL public endpoint check: {error}", file=sys.stderr)
        sys.exit(1)
