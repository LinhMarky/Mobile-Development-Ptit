"""Exercise registration/verification using real email on an explicitly selected test backend."""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import secrets
import sys
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
import uuid


class FlowError(RuntimeError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise FlowError(message)


def api(origin: str, path: str, body=None, token: str = "", expected: int = 200) -> dict:
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    data = json.dumps(body).encode() if body is not None else None
    request = Request(origin + "/api/v1" + path, data=data, headers=headers, method="POST" if body is not None else "GET")
    try:
        response = urlopen(request, timeout=30)
    except HTTPError as error:
        response = error
    with response:
        envelope = json.load(response)
        require(set(envelope) == {"statusCode", "message", "data"}, "HTTP envelope changed")
        require(response.status == expected and envelope["statusCode"] == expected, f"Unexpected HTTP status for {path}: {response.status}")
        return envelope["data"]


def save_private(path: Path, state: dict, create: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | (os.O_EXCL if create else os.O_TRUNC)
    descriptor = os.open(path, flags, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
        json.dump(state, stream, indent=2)
        stream.write("\n")


def require_identity(user: dict, state: dict, source: str) -> None:
    require(user["id"] == state["user_id"] and user["email"].casefold() == state["email"].casefold(),
            f"{source} does not identify the registered test account")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("begin", "verify", "check-session"),
                        help="check-session repeats identity/session checks only after a successful verification report")
    parser.add_argument("--origin", required=True)
    parser.add_argument("--state-file", type=Path, required=True, help="Private file in an ignored folder; contains the test account's password")
    parser.add_argument("--email", help="Explicit real recipient account to register; required by begin")
    parser.add_argument("--token-file", type=Path, help="Private file containing only the email verification code; required by verify")
    args = parser.parse_args()
    target = urlsplit(args.origin)
    require(target.scheme == "https" or (target.scheme == "http" and target.hostname in ("localhost", "127.0.0.1", "::1")), "Use HTTPS, or loopback HTTP only for the isolated local test stack")
    require(bool(target.hostname) and target.path in ("", "/") and not target.query and not target.username, "Provide an origin without paths or credentials")
    origin = args.origin.rstrip("/")
    report_path = args.state_file.parent / "results.json"
    previous_report = None
    if args.action == "begin":
        require(bool(args.email) and "@" in args.email, "Choose a real recipient with --email")
        require(not args.state_file.exists(), "State file already exists; no registration/email was attempted")
        state = {"origin": origin, "email": args.email, "password": secrets.token_urlsafe(24),
                 "installation_id": str(uuid.uuid4()), "registered": False}
        save_private(args.state_file, state, create=True)
        user = api(origin, "/auth/register", {"email": state["email"], "password": state["password"], "full_name": "Real SMTP acceptance"}, expected=201)
        state.update(registered=True, user_id=user["id"])
        save_private(args.state_file, state)
        require(user["email_verified"] is False, "Registration unexpectedly verified the account")
    else:
        require(args.state_file.is_file(), "Supply an existing private state file")
        state = json.loads(args.state_file.read_text(encoding="utf-8"))
        require(state.get("origin") == origin and state.get("registered") is True, "State does not belong to a registered test account on this origin")
        if args.action == "verify":
            require(bool(args.token_file) and args.token_file.is_file(), "Supply an existing private token file")
            code = args.token_file.read_text(encoding="utf-8-sig").strip()
            require(bool(code) and len(code) <= 256 and "\n" not in code and "\r" not in code, "Token file must contain only the email verification code")
            api(origin, "/auth/verify-email", {"token": code})
            api(origin, "/auth/verify-email", {"token": code}, expected=400)
        else:
            require(report_path.is_file(), "check-session requires the previous successful verification report")
            previous_report = json.loads(report_path.read_text(encoding="utf-8"))
            require(previous_report.get("origin") == origin and previous_report.get("user_id") == state["user_id"]
                    and previous_report.get("verification") == "passed" and previous_report.get("token_reuse_rejected") is True,
                    "Previous report does not prove verification and used-code rejection for this account")
    login = api(origin, "/auth/login", {"email": state["email"], "password": state["password"],
                "installation_id": state["installation_id"], "device_name": "Real email acceptance"})
    require_identity(login["user"], state, "Login")
    profile = api(origin, "/profile", token=login["access_token"])
    require_identity(profile, state, "Profile")
    expected_verified = args.action != "begin"
    require(profile["email_verified"] is expected_verified, "Server profile verification flag is incorrect")
    api(origin, "/auth/logout", {"refresh_token": login["refresh_token"]}, token=login["access_token"])
    api(origin, "/auth/refresh", {"refresh_token": login["refresh_token"]}, expected=400)
    completed_at = datetime.now(timezone.utc).isoformat()
    verification_completed_at = completed_at if expected_verified else None
    if previous_report is not None:
        verification_completed_at = previous_report.get("verification_timestamp_utc") or previous_report["timestamp_utc"]
    report = {"timestamp_utc": completed_at, "origin": origin, "user_id": state["user_id"],
              "registration": "passed", "login": "passed", "logout": "passed", "email_verified": expected_verified,
              "account_identity": "passed", "logout_refresh_rejected": True,
              "verification": "passed" if expected_verified else "pending_inbox_code", "token_reuse_rejected": True if expected_verified else None,
              "verification_timestamp_utc": verification_completed_at,
              "scope": "Real backend registration email; actual inbox receipt requires the user"}
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if args.action == "check-session":
        print("PASS verified account: login/profile identity, verified flag, logout and rejected refresh; previous verification evidence preserved")
    elif expected_verified:
        print("PASS real email flow: verification, used-code rejection, verified profile, login and logout")
    else:
        print("PASS real backend: register=201; verification mail submitted; profile unverified; login/logout")
        print("Waiting for the verification code from the actual inbox; save it to a private token file, never chat.")
    print(f"Safe result: {report_path}. Private state was not printed.")


if __name__ == "__main__":
    try:
        main()
    except FlowError as error:
        print(f"FAIL email flow: {error}", file=sys.stderr)
        sys.exit(1)
    except (OSError, ValueError, KeyError):
        print("FAIL email flow: request/state error; credentials and email code were omitted.", file=sys.stderr)
        sys.exit(1)
