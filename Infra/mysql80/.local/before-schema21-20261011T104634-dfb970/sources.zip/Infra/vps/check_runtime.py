"""Read-only acceptance checks for the running VPS stack and public API contract."""

import argparse
import json
from pathlib import Path
import subprocess
import sys
from urllib.error import HTTPError
from urllib.request import urlopen

from compose_config import read_compose_json


def docker(*arguments: str) -> str:
    result = subprocess.run(["docker", *arguments], capture_output=True, text=True, check=False)
    if result.returncode:
        raise RuntimeError(f"Docker {arguments[0]} failed; inspect Docker locally (secrets are omitted)")
    return result.stdout


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def request_json(url: str, expected_status: int = 200) -> dict:
    try:
        response = urlopen(url, timeout=15)
    except HTTPError as error:
        response = error
    with response:
        require(response.status == expected_status, f"Unexpected HTTP status for {url}: {response.status}")
        return json.load(response)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env-file", type=Path, default=Path(__file__).resolve().parent / ".env")
    parser.add_argument("--smtp-env", type=Path, help="Optional private SMTP env file")
    parser.add_argument("--proxy-env", type=Path, help="Generated proxy.env; also selects compose.proxy.yaml")
    parser.add_argument("--smtp", action="store_true", help="Also select the real SMTP override")
    parser.add_argument("--firebase", action="store_true", help="Also select the Firebase override")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--demo", action="store_true")
    mode.add_argument("--prod", action="store_true")
    args = parser.parse_args()
    if args.prod and args.smtp:
        parser.error("Production already enforces SMTP STARTTLS; do not select the demo SMTP override")
    directory = Path(__file__).resolve().parent
    compose = ["compose", "--env-file", str(args.env_file.resolve())]
    if args.smtp_env:
        compose += ["--env-file", str(args.smtp_env.resolve())]
    if args.proxy_env:
        compose += ["--env-file", str(args.proxy_env.resolve())]
    compose += ["-f", str(directory / "compose.yaml")]
    if args.demo:
        compose += ["-f", str(directory / "compose.demo.yaml")]
    elif args.prod:
        compose += ["-f", str(directory / "compose.prod.yaml")]
    if args.proxy_env:
        compose += ["-f", str(directory / "compose.proxy.yaml")]
    if args.smtp:
        compose += ["-f", str(directory / "compose.smtp.yaml")]
    if args.firebase:
        compose += ["-f", str(directory.parent / "compose.firebase.yaml")]
    # config output doubles literal dollars for round-tripping; docker inspect does not.
    configuration = read_compose_json(docker(*compose, "config", "--format", "json"))
    identifiers = docker(*compose, "ps", "-a", "-q").split()
    require(bool(identifiers), "No containers found for this VPS project")
    containers = json.loads(docker("inspect", *identifiers))
    services = {item["Config"]["Labels"]["com.docker.compose.service"]: item for item in containers}
    required_services = ["mysql", "minio", "backend"]
    if args.demo:
        required_services.append("mailpit")
    for name in required_services:
        require(name in services, f"Missing {name} container")
        container = services[name]
        state, settings = container["State"], container["HostConfig"]
        require(state["Status"] == "running", f"{name} is not running")
        require(state.get("Health", {}).get("Status") == "healthy", f"{name} is not healthy")
        require(settings["RestartPolicy"]["Name"] == "unless-stopped", f"{name} has no expected restart policy")
        require(settings["Memory"] > 0, f"{name} has no memory limit")
        log = settings["LogConfig"]
        require(log["Type"] == "json-file" and log["Config"].get("max-size") and log["Config"].get("max-file"),
                f"{name} has no bounded JSON log configuration")
        print(f"PASS {name}: healthy; restart=unless-stopped; memory_limit={settings['Memory'] // (1024 * 1024)} MiB; bounded logs")

    for name, container in services.items():
        for bindings in container["NetworkSettings"]["Ports"].values():
            for binding in bindings or []:
                require(binding["HostIp"] in ("127.0.0.1", "::1"), f"{name} exposes a port beyond loopback")
                require(name not in ("mysql", "minio"), f"{name} publishes a data-service port")
    backend = services["backend"]
    require(backend["Config"]["Image"] == configuration["services"]["backend"]["image"],
            "Running backend image does not match the selected Compose tag")
    environment = dict(item.split("=", 1) for item in backend["Config"]["Env"])
    expected_profile = "prod" if args.prod else "vps"
    require(environment.get("SPRING_PROFILES_ACTIVE") == expected_profile,
            "Running profile does not match the selected environment")
    expected_demo = "true" if args.demo else "false"
    for setting in ("DEMO_ENABLED", "DEMO_SEED"):
        require(environment.get(setting) == expected_demo, f"Running {setting} does not match the selected environment")
    require(environment.get("MOCK_PAYMENT_ENABLED") == "false", "Mock payment is enabled unexpectedly")
    expected_environment = configuration["services"]["backend"]["environment"]
    if args.proxy_env:
        for setting in ("SERVER_FORWARD_HEADERS_STRATEGY", "SERVER_TOMCAT_REMOTEIP_INTERNAL_PROXIES", "HOMELY_CHAT_ALLOWED_ORIGINS"):
            require(environment.get(setting) == expected_environment.get(setting), f"Running proxy setting {setting} differs from Compose")
        require(environment.get("SERVER_TOMCAT_REMOTEIP_INTERNAL_PROXIES", "") not in ("", ".*"), "Proxy trust must use exact configured addresses")
        print("PASS backend proxy configuration: NATIVE forwarding; explicit trusted proxy addresses; public chat origin")
    for setting in ("FCM_ENABLED", "SMTP_HOST", "SMTP_PORT", "SMTP_USERNAME", "SMTP_PASSWORD", "MAIL_FROM",
                    "SPRING_MAIL_PROPERTIES_MAIL_SMTP_SSL_ENABLE", "SPRING_MAIL_PROPERTIES_MAIL_SMTP_SSL_CHECKSERVERIDENTITY"):
        require(environment.get(setting) == expected_environment.get(setting), f"Running service setting {setting} differs from Compose")
    if args.firebase:
        require(any(mount["Destination"] == "/run/secrets/firebase-service-account.json" and not mount["RW"]
                    for mount in backend["Mounts"]), "Firebase credential mount missing or writable")
    if args.prod:
        require(any(mount["Destination"] == "/run/secrets/mysql-truststore.p12" and not mount["RW"]
                    for mount in backend["Mounts"]), "Production truststore mount is missing or writable")
        require(any(mount["Destination"] == "/etc/mysql/tls" and not mount["RW"]
                    for mount in services["mysql"]["Mounts"]), "Production MySQL TLS mount is missing or writable")
        require("--require-secure-transport=ON" in services["mysql"]["Config"]["Cmd"],
                "Production MySQL secure transport is not required")
    require(backend["HostConfig"]["ReadonlyRootfs"], "Backend root filesystem is writable")
    require(backend["Config"]["User"] not in ("", "root", "0"), "Backend runs as root")
    require("/tmp" in backend["HostConfig"]["Tmpfs"], "Backend writable temporary directory is missing")
    for name, destination in (("mysql", "/var/lib/mysql"), ("minio", "/data")):
        require(any(mount["Type"] == "volume" and mount["Destination"] == destination for mount in services[name]["Mounts"]),
                f"{name} has no persistent data volume")
        require(bool(set(backend["NetworkSettings"]["Networks"]) & set(services[name]["NetworkSettings"]["Networks"])),
                f"Backend does not share a network with {name}")
    print("PASS isolation: loopback API; private database/storage; non-root read-only backend; persistent volumes")

    binding = next(item for item in backend["NetworkSettings"]["Ports"]["8080/tcp"] if item["HostIp"] == "127.0.0.1")
    origin = "http://127.0.0.1:" + binding["HostPort"]
    require(request_json(origin + "/actuator/health").get("status") == "UP", "Backend health is not UP")
    api = request_json(origin + "/v3/api-docs")
    require(api["info"]["version"] == "1.6.0", "Unexpected API contract version")
    schema = api["components"]["schemas"]["RestResponseProblemDTO"]
    require(set(schema["properties"]) == {"statusCode", "message", "data"}, "OpenAPI error envelope changed")
    listing = request_json(origin + "/api/v1/listings?page=0&size=1")
    require(set(listing) == {"statusCode", "message", "data"} and listing["statusCode"] == 200, "Search JSON envelope changed")
    require(isinstance(listing["data"]["data"], list), "Search page data is not a list")
    unauthenticated = request_json(origin + "/api/v1/profile", 401)
    require(set(unauthenticated) == {"statusCode", "message", "data"} and unauthenticated["statusCode"] == 401,
            "Unauthenticated JSON envelope changed")
    require(unauthenticated["data"]["status"] == 401 and unauthenticated["data"]["code"] and unauthenticated["data"]["trace_id"],
            "Unauthenticated ProblemDTO is incomplete")
    print(f"PASS HTTP: health UP; API 1.6.0 ({len(api['paths'])} paths); success/error envelopes; guest search and 401")
    print("No configuration, services or data were changed by this checker.")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        sys.exit(1)
