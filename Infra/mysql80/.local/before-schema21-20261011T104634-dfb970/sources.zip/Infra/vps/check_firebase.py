"""Authenticate to FCM and validate a message without delivering a notification."""

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import sys

from check_services import ConfigurationError, validate_firebase
from compose_config import read_compose_json


OAUTH_URL = "https://oauth2.googleapis.com/token"
FCM_SCOPE = "https://www.googleapis.com/auth/firebase.messaging"
CREDENTIAL_TARGET = "/run/secrets/firebase-service-account.json"
NETWORK_TIMEOUT = (5, 15)
PROJECT_ID = re.compile(r"[a-z][a-z0-9-]{4,28}[a-z0-9]\Z")

DIAGNOSES = {
    "CONFIGURATION_INVALID": "Check the Firebase project and existing read-only service-account mount.",
    "COMPOSE_UNAVAILABLE": "Docker Compose could not resolve the selected configuration; check local env files.",
    "DEPENDENCIES_MISSING": "Install dependencies: python -m pip install -r Infra/vps/requirements-firebase.txt",
    "OAUTH_AUTHENTICATION_FAILED": "Google OAuth authentication failed; check the service account, key, clock and network.",
    "NETWORK_FAILED": "FCM could not be reached over verified TLS; check the network and system clock.",
    "SERVICE_DISABLED": "Enable Firebase Cloud Messaging API (V1) for this Firebase project, then retry.",
    "PERMISSION_DENIED": "The service account needs cloudmessaging.messages.create permission in this project.",
    "UNAUTHENTICATED": "FCM rejected the OAuth credential; check that the service-account key is still active.",
    "RESOURCE_EXHAUSTED": "FCM quota was exhausted; wait before retrying.",
    "INVALID_ARGUMENT": "FCM rejected the validation request; review the preflight message format.",
    "UNAVAILABLE": "FCM is temporarily unavailable; retry later.",
    "INTERNAL": "FCM returned a server error; retry later.",
    "NOT_FOUND": "Check that this is the intended Firebase project and that FCM is available for it.",
    "FCM_REJECTED": "FCM rejected the validation request; check API enablement and service-account permissions.",
    "OUTPUT_UNAVAILABLE": "The output must be a new file in an existing writable directory.",
    "CHECK_FAILED": "The preflight could not complete; inspect the configuration locally without sharing secrets.",
}


class PreflightError(Exception):
    """Only fixed diagnosis codes may cross the credential/network boundary."""

    def __init__(self, code):
        self.code = code if code in DIAGNOSES else "CHECK_FAILED"
        super().__init__(DIAGNOSES[self.code])


def evidence(project=None):
    return {
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "firebase_project_id": project,
        "oauth_authenticated": False,
        "validate_only": True,
        "http_status": None,
        "fcm_api_verified": False,
        "phone_delivery_verified": False,
        "pass": False,
    }


def compose_backend(args):
    directory = Path(__file__).resolve().parent
    if not args.env_file.is_file() or (args.smtp_env and not args.smtp_env.is_file()):
        raise PreflightError("CONFIGURATION_INVALID")
    command = ["docker", "compose", "--env-file", str(args.env_file.resolve())]
    if args.smtp_env:
        command += ["--env-file", str(args.smtp_env.resolve())]
    command += ["-f", str(directory / "compose.yaml")]
    if args.demo:
        command += ["-f", str(directory / "compose.demo.yaml")]
    elif args.prod:
        command += ["-f", str(directory / "compose.prod.yaml")]
    if args.smtp_env:
        command += ["-f", str(directory / "compose.smtp.yaml")]
    command += ["-f", str(directory.parent / "compose.firebase.yaml"), "config", "--format", "json"]
    try:
        resolved = subprocess.run(command, capture_output=True, text=True, timeout=30, check=False)
        if resolved.returncode != 0:
            raise PreflightError("COMPOSE_UNAVAILABLE")
        return read_compose_json(resolved.stdout)["services"]["backend"]
    except PreflightError:
        raise
    except (OSError, ValueError, KeyError, TypeError, subprocess.TimeoutExpired):
        raise PreflightError("COMPOSE_UNAVAILABLE") from None


def validate_service_account(path, project):
    """Validate metadata before any OAuth exchange, in either CLI mode."""
    try:
        if not isinstance(project, str) or not PROJECT_ID.fullmatch(project):
            raise PreflightError("CONFIGURATION_INVALID")
        validate_firebase(path, project)
        credential = json.loads(path.read_text(encoding="utf-8"))
        if (credential.get("token_uri") != OAUTH_URL
                or credential.get("universe_domain", "googleapis.com") != "googleapis.com"):
            raise PreflightError("CONFIGURATION_INVALID")
        return project, path
    except PreflightError:
        raise
    except (ConfigurationError, OSError, ValueError, KeyError, TypeError):
        raise PreflightError("CONFIGURATION_INVALID") from None


def validate_configuration(backend):
    """Return only the checked project and local credential path."""
    try:
        environment = backend["environment"]
        project = environment.get("FIREBASE_PROJECT_ID", "")
        if str(environment.get("FCM_ENABLED", "")).lower() != "true":
            raise PreflightError("CONFIGURATION_INVALID")
        if environment.get("GOOGLE_APPLICATION_CREDENTIALS") != CREDENTIAL_TARGET:
            raise PreflightError("CONFIGURATION_INVALID")
        mount = next(item for item in backend["volumes"] if item.get("target") == CREDENTIAL_TARGET)
        if (mount.get("type") != "bind" or mount.get("read_only") is not True
                or mount.get("bind", {}).get("create_host_path", False)):
            raise PreflightError("CONFIGURATION_INVALID")
        path = Path(mount["source"])
        return validate_service_account(path, project)
    except PreflightError:
        raise
    except (ConfigurationError, OSError, ValueError, KeyError, TypeError, StopIteration):
        raise PreflightError("CONFIGURATION_INVALID") from None


def load_dependencies():
    try:
        import requests
        from google.auth.transport.requests import Request
        from google.oauth2.service_account import Credentials
        return requests, Credentials, Request
    except ImportError:
        raise PreflightError("DEPENDENCIES_MISSING") from None


def validation_payload():
    # Every value matches the backend gateway's string data/Android options.
    # This fixed synthetic topic is never subscribed or delivered to by this tool.
    return {
        "validate_only": True,
        "message": {
            "topic": "roomly-backend-preflight",
            "data": {
                "notification_id": "0",
                "recipient_id": "0",
                "title": "Roomly FCM preflight",
                "body": "Validation only; no phone notification is sent.",
                "ref_type": "PREFLIGHT",
                "ref_id": "0",
            },
            "android": {"priority": "HIGH", "ttl": "3600s"},
        },
    }


class VerifiedOAuthRequest:
    """Google auth may contact only the fixed token endpoint with bounded TLS."""

    def __init__(self, request):
        self.request = request

    def __call__(self, url, method="GET", body=None, headers=None, **kwargs):
        if url != OAUTH_URL or method.upper() != "POST":
            raise PreflightError("OAUTH_AUTHENTICATION_FAILED")
        return self.request(
            url, method=method, body=body, headers=headers,
            timeout=NETWORK_TIMEOUT, verify=True, allow_redirects=False,
        )


def rejection_code(response):
    """Read only recognized machine codes; never retain a remote message/body."""
    allowed = {
        "SERVICE_DISABLED", "PERMISSION_DENIED", "UNAUTHENTICATED", "RESOURCE_EXHAUSTED",
        "INVALID_ARGUMENT", "UNAVAILABLE", "INTERNAL", "NOT_FOUND",
    }
    try:
        error = response.json().get("error", {})
        reasons = [item.get("reason") for item in error.get("details", []) if isinstance(item, dict)]
        if "SERVICE_DISABLED" in reasons:
            return "SERVICE_DISABLED"
        status = error.get("status")
        if isinstance(status, str) and status in allowed:
            return status
    except (ValueError, TypeError, AttributeError):
        pass
    return "FCM_REJECTED"


def check_api(project, credential_path):
    result = evidence(project)
    requests, credentials_type, request_type = load_dependencies()
    try:
        # Separate sessions avoid carrying OAuth request state into the FCM API.
        with requests.Session() as oauth_session:
            credentials = credentials_type.from_service_account_file(
                str(credential_path), scopes=[FCM_SCOPE],
            )
            credentials.refresh(VerifiedOAuthRequest(request_type(session=oauth_session)))
            if not credentials.token:
                raise PreflightError("OAUTH_AUTHENTICATION_FAILED")
    except Exception:
        # Auth exceptions can include key material, request data or remote bodies.
        result["error_code"] = "OAUTH_AUTHENTICATION_FAILED"
        return result
    result["oauth_authenticated"] = True
    try:
        with requests.Session() as api_session:
            response = api_session.post(
                f"https://fcm.googleapis.com/v1/projects/{project}/messages:send",
                headers={"Authorization": f"Bearer {credentials.token}"},
                json=validation_payload(), timeout=NETWORK_TIMEOUT, verify=True,
                allow_redirects=False,
            )
            status = int(response.status_code)
            result["http_status"] = status if 100 <= status <= 599 else None
            if status == 200:
                result["fcm_api_verified"] = True
                result["pass"] = True
            else:
                result["error_code"] = rejection_code(response)
    except Exception:
        result["error_code"] = "NETWORK_FAILED"
    result["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
    return result


def run_preflight(project, credential_path):
    """Validate a local service account, authenticate and call FCM validate_only."""
    project, credential_path = validate_service_account(Path(credential_path), project)
    return check_api(project, credential_path)


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env-file", type=Path, help="Compose env file (default: Infra/vps/.env)")
    parser.add_argument("--smtp-env", type=Path, help="Apply the running stack's private SMTP overlay, if used")
    parser.add_argument("--credential-file", type=Path, help="Standalone mode: existing service-account JSON")
    parser.add_argument("--project-id", help="Standalone mode: matching Firebase project ID")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--demo", action="store_true")
    mode.add_argument("--prod", action="store_true")
    parser.add_argument("--output", type=Path, help="Write sanitized evidence to a new JSON file")
    args = parser.parse_args(argv)
    if bool(args.credential_file) != bool(args.project_id):
        parser.error("Standalone mode requires both --credential-file and --project-id")
    if args.credential_file and (args.env_file or args.smtp_env or args.demo or args.prod):
        parser.error("Standalone mode cannot include Compose env, SMTP or demo/prod options")
    if args.env_file is None:
        args.env_file = Path(__file__).resolve().parent / ".env"
    return args


def main(argv=None):
    args = parse_args(argv)
    result = evidence()
    try:
        if args.output and (args.output.exists() or not args.output.parent.is_dir()):
            raise PreflightError("OUTPUT_UNAVAILABLE")
        if args.credential_file:
            project, credential_path = validate_service_account(args.credential_file, args.project_id)
        else:
            project, credential_path = validate_configuration(compose_backend(args))
        result["firebase_project_id"] = project
        result = run_preflight(project, credential_path)
    except PreflightError as error:
        result["error_code"] = error.code
    except Exception:
        result["error_code"] = "CHECK_FAILED"
    result["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
    if args.output and result.get("error_code") != "OUTPUT_UNAVAILABLE":
        try:
            # Exclusive creation never overwrites an existing evidence/config file.
            with args.output.open("x", encoding="utf-8") as output:
                json.dump(result, output, indent=2)
                output.write("\n")
        except OSError:
            result["pass"] = False
            result["error_code"] = "OUTPUT_UNAVAILABLE"
    print(json.dumps(result, indent=2))
    if result.get("error_code"):
        print("FAIL: " + DIAGNOSES[result["error_code"]], file=sys.stderr)
    else:
        print("PASS: FCM authenticated and accepted validation. Phone delivery is not verified.")
    return 0 if result["pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
