"""Create test room/media and recreate this demo stack to verify persistent volumes."""

import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import uuid

from check_runtime import docker, require
from compose_config import read_compose_json


PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=")


def api(origin: str, method: str, path: str, token: str = "", data=None,
        expected_status: int = 200, content_type: str = "application/json", raw: bool = False):
    headers = {"Content-Type": content_type}
    if token:
        headers["Authorization"] = "Bearer " + token
    if method == "POST" and not path.startswith(("/auth/", "/media/")):
        headers["Idempotency-Key"] = str(uuid.uuid4())
    body = data if isinstance(data, bytes) else json.dumps(data).encode() if data is not None else None
    request = Request(origin + "/api/v1" + path, data=body, headers=headers, method=method)
    try:
        response = urlopen(request, timeout=30)
    except HTTPError as error:
        response = error
    with response:
        require(response.status == expected_status, f"Unexpected HTTP status for {method} {path}: {response.status}")
        if raw:
            require(response.headers.get_content_type() == "image/png", "Unexpected media content type")
            return response.read()
        envelope = json.load(response)
        require(set(envelope) == {"statusCode", "message", "data"} and envelope["statusCode"] == expected_status,
                f"Invalid JSON envelope for {method} {path}")
        return envelope["data"]


def containers(compose: list[str]) -> dict:
    identifiers = docker(*compose, "ps", "-a", "-q").split()
    require(bool(identifiers), "Start the selected demo stack before testing persistence")
    items = json.loads(docker("inspect", *identifiers))
    return {item["Config"]["Labels"]["com.docker.compose.service"]: item for item in items}


def snapshot(services: dict) -> dict:
    result = {}
    for name in ("backend", "mysql", "minio"):
        require(name in services, f"Missing {name} container")
        item = services[name]
        require(item["State"].get("Health", {}).get("Status") == "healthy", f"{name} is not healthy")
        result[name] = {
            "container_id": item["Id"], "image_id": item["Image"],
            "volumes": {mount["Destination"]: mount["Name"] for mount in item["Mounts"] if mount["Type"] == "volume"},
        }
    return result


def login(origin: str, password: str) -> str:
    session = api(origin, "POST", "/auth/login", data={
        "email": "host@homely.test", "password": password,
        "installation_id": str(uuid.uuid4()), "device_name": "VPS persistence acceptance",
    })
    return session["access_token"]


def upload(origin: str, token: str) -> dict:
    boundary = "homely-" + uuid.uuid4().hex
    body = (
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"purpose\"\r\n\r\nROOM_PHOTO\r\n"
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"persistence.png\"\r\n"
        "Content-Type: image/png\r\n\r\n"
    ).encode() + PNG + f"\r\n--{boundary}--\r\n".encode()
    return api(origin, "POST", "/media/upload", token, body, 201, "multipart/form-data; boundary=" + boundary)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    directory = Path(__file__).resolve().parent
    parser.add_argument("--env-file", type=Path, default=directory / ".env")
    parser.add_argument("--confirm-project", required=True, help="Exact demo project name whose containers may be recreated")
    parser.add_argument("--output", type=Path, required=True, help="Path for acceptance evidence, without credentials")
    args = parser.parse_args()
    compose = ["compose", "--env-file", str(args.env_file.resolve()), "-f", str(directory / "compose.yaml"),
               "-f", str(directory / "compose.demo.yaml")]
    configuration = read_compose_json(docker(*compose, "config", "--format", "json"))
    require(configuration["name"] == args.confirm_project, "Confirmation does not match the selected Compose project")
    services = containers(compose)
    backend = services.get("backend", {})
    environment = dict(item.split("=", 1) for item in backend.get("Config", {}).get("Env", []))
    require(environment.get("SPRING_PROFILES_ACTIVE") == "vps" and environment.get("DEMO_ENABLED") == "true"
            and environment.get("DEMO_SEED") == "true" and environment.get("SMTP_HOST") == "mailpit",
            "This check only recreates an already-running VPS demo stack with Mailpit")
    require(all(item["Config"]["Labels"]["com.docker.compose.project"] == args.confirm_project
                for item in services.values()), "Container project mismatch")
    before = snapshot(services)
    binding = next(item for item in backend["NetworkSettings"]["Ports"]["8080/tcp"] if item["HostIp"] == "127.0.0.1")
    origin = "http://127.0.0.1:" + binding["HostPort"]
    started = datetime.now(timezone.utc).isoformat()
    # Credentials stay in memory and are never included in the evidence or console output.
    password = environment["DEMO_PASSWORD"]
    token = login(origin, password)
    unit_code = "PERSIST_" + uuid.uuid4().hex[:12].upper()
    room = api(origin, "POST", "/rooms", token, {
        "unit_code": unit_code, "room_type": "SINGLE_ROOM", "area_m2": 25, "max_occupants": 2, "amenity_ids": [],
        "address": {"line": "VPS persistence acceptance", "province_code": "HN", "province_name": "Ha Noi"},
        "location": {"latitude": 21.0285, "longitude": 105.8542},
    }, 201)
    media = upload(origin, token)
    api(origin, "POST", f"/media/attach/room/{room['id']}", token, {"media_ids": [media["id"]]})
    content_path = f"/media/{media['id']}/content"
    require(api(origin, "GET", content_path, token, raw=True) == PNG, "Initial media bytes do not match")
    print(f"Created test room {room['id']} and media {media['id']}; recreating project {args.confirm_project}", flush=True)
    # Deliberately recreate MySQL and MinIO too; no volume deletion or secret regeneration.
    docker(*compose, "up", "-d", "--no-build", "--force-recreate", "--wait", "--wait-timeout", "300")
    after = snapshot(containers(compose))
    for name in before:
        require(before[name]["container_id"] != after[name]["container_id"], f"{name} was not recreated")
        require(before[name]["image_id"] == after[name]["image_id"], f"{name} image changed during the check")
        require(before[name]["volumes"] == after[name]["volumes"], f"{name} persistent volume changed")
    token = login(origin, password)
    restored = api(origin, "GET", f"/rooms/{room['id']}", token)
    require(restored["id"] == room["id"] and restored["unit_code"] == unit_code, "Committed room was not retained")
    media_list = api(origin, "GET", f"/media/room/{room['id']}", token)
    require(any(item["id"] == media["id"] for item in media_list), "Committed media attachment was not retained")
    require(api(origin, "GET", content_path, token, raw=True) == PNG, "Stored media bytes changed after recreation")
    evidence = {
        "started_utc": started, "completed_utc": datetime.now(timezone.utc).isoformat(),
        "project": args.confirm_project, "room_id": room["id"], "media_id": media["id"],
        "media_sha256": hashlib.sha256(PNG).hexdigest(), "before": before, "after": after,
        "database_retained": True, "media_attachment_retained": True, "media_bytes_retained": True, "pass": True,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8")
    print(f"PASS: committed room, attachment and identical media bytes survived container recreation. Evidence: {args.output}")
    print("Test room/media were retained for inspection; no volumes were deleted.")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError, StopIteration) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        sys.exit(1)
