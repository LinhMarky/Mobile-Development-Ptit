"""Offline recovery safety tests; all data and Docker responses are fixtures."""

import argparse
import copy
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

import backup_restore as recovery


def configuration() -> dict:
    mysql = {"MYSQL_DATABASE": "homely", "MYSQL_USER": "homely", "MYSQL_PASSWORD": "fixture-app$$cash${literal}",
             "MYSQL_ROOT_PASSWORD": "fixture-root-credential"}
    minio = {"MINIO_ROOT_USER": "fixture-storage-user", "MINIO_ROOT_PASSWORD": "fixture-storage-credential"}
    backend = {"MYSQL_DB": "homely", "MYSQL_USER": "homely", "MYSQL_PASSWORD": mysql["MYSQL_PASSWORD"],
               "MINIO_ACCESS_KEY": minio["MINIO_ROOT_USER"], "MINIO_SECRET_KEY": minio["MINIO_ROOT_PASSWORD"],
               "JWT_SECRET": "fixture-jwt-value-with-at-least-thirty-two-characters",
               "SPRING_PROFILES_ACTIVE": "vps", "DEMO_ENABLED": "true", "DEMO_SEED": "true", "FCM_ENABLED": "false",
               "SMTP_HOST": "mailpit", "SMTP_PORT": "1025"}
    return {"name": "fixture-source", "services": {
        "mysql": {"image": "mysql:8.4", "environment": mysql},
        "minio": {"image": "homely-minio-source:release-2025-04-22", "environment": minio},
        "backend": {"image": "homely-backend:fixture", "environment": backend},
        "mailpit": {"image": "axllent/mailpit:v1.31.3", "environment": {}},
    }, "volumes": {"mysql_data": {"name": "fixture-source_mysql_data"}, "minio_data": {"name": "fixture-source_minio_data"}},
            "networks": {"default": {"name": "fixture-source_default"}}}


def containers(config: dict, stopped: str = "", target: bool = False) -> dict:
    result = {}
    for index, name in enumerate((*recovery.CORE, "mailpit")):
        identifier = "abcdef"[index] * 64
        result[name] = {
            "Id": identifier, "Image": "sha256:" + "fedcba"[index] * 64,
            "Config": {"Image": config["services"][name]["image"],
                       "Env": [key + "=" + value for key, value in config["services"][name]["environment"].items()],
                       "Labels": {"com.docker.compose.project": config["name"], "com.docker.compose.service": name}},
            "State": {"Status": "created" if target else "exited" if stopped == name else "running", "Health": {"Status": "healthy"}},
            "HostConfig": {"PortBindings": {}}, "Mounts": [],
        }
        if name in ("mysql", "minio"):
            result[name]["Mounts"] = [{"Type": "volume", "Destination": "/data" if name == "minio" else "/var/lib/mysql",
                                       "Name": config["name"] + "_" + name + "_data"}]
    return result


def args(**changes):
    values = {"demo": True, "prod": False, "proxy": False, "smtp": False, "firebase": False,
              "confirm_project": "fixture-source", "confirm_target": "fixture-restore", "api_port": 18080,
              "mailpit_port": 18025, "restore_test": True, "settings_dir": None}
    return argparse.Namespace(**(values | changes))


SQL = (b"-- MySQL dump 10.13 Distrib 8.4\n-- Host: localhost    Database: homely\n"
       b"CREATE TABLE `rooms` (`id` bigint);\nINSERT INTO `rooms` VALUES (6);\n-- Dump completed on 2026-01-01\n")


def archive_bytes(name: str = "./.minio.sys/config/settings.json", kind: bytes = tarfile.REGTYPE) -> bytes:
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode="w") as archive:
        root = tarfile.TarInfo(".")
        root.type = tarfile.DIRTYPE
        archive.addfile(root)
        member = tarfile.TarInfo(name)
        member.type = kind
        if kind == tarfile.REGTYPE:
            content = b"fixture storage metadata"
            member.size = len(content)
            archive.addfile(member, io.BytesIO(content))
        else:
            member.linkname = "../../outside"
            archive.addfile(member)
    return stream.getvalue()


def make_backup(path: Path, config: dict | None = None) -> dict:
    config = config or configuration()
    path.mkdir()
    (path / "mysql.sql").write_bytes(SQL)
    (path / "minio.tar").write_bytes(archive_bytes())
    services = containers(config)
    salt = "a" * 64
    manifest = {
        "format_version": 1, "created_utc": "2026-01-01T00:00:00+00:00", "source_project": config["name"],
        "database": "homely", "selection": recovery.selection(args()), "fingerprint_salt": salt,
        "configuration_sha256": recovery.fingerprint(config, salt),
        "services": {name: {"image_ref": item["Config"]["Image"], "image_id": item["Image"], "container_id": item["Id"]}
                     for name, item in services.items()},
        "volumes": {name: {"name": config["name"] + "_" + name + "_data", "destination": "/data" if name == "minio" else "/var/lib/mysql"}
                    for name in ("mysql", "minio")},
        "artifacts": {name: recovery.artifact(path / name) for name in ("mysql.sql", "minio.tar")},
    }
    (path / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    return manifest


class RecoveryTests(unittest.TestCase):
    def test_archive_rejects_traversal_links_and_special_files(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "minio.tar"
            cases = [("../outside", tarfile.REGTYPE), ("/absolute", tarfile.REGTYPE),
                     ("./a/../../outside", tarfile.REGTYPE), ("C:/outside", tarfile.REGTYPE),
                     ("a\\outside", tarfile.REGTYPE), ("symlink", tarfile.SYMTYPE),
                     ("hardlink", tarfile.LNKTYPE), ("device", tarfile.CHRTYPE), ("pipe", tarfile.FIFOTYPE)]
            for name, kind in cases:
                with self.subTest(name=name, kind=kind), self.assertRaises(RuntimeError):
                    path.write_bytes(archive_bytes(name, kind))
                    recovery.validate_archive(path)
            path.write_bytes(archive_bytes())
            recovery.validate_archive(path)

    def test_checksum_corruption_rejected_before_any_docker_call(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "backup"
            make_backup(path)
            (path / "mysql.sql").write_bytes(SQL + b"corrupt")
            with patch.object(recovery, "docker") as docker, self.assertRaisesRegex(RuntimeError, "checksum"):
                recovery.restore(args(input=path), ["compose"], configuration())
            docker.assert_not_called()

    def test_sql_schema_switch_mismatch_and_incomplete_dump_are_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "mysql.sql"
            cases = [SQL.replace(b"Database: homely", b"Database: other"), SQL + b"USE mysql;\n",
                     SQL + b"DROP DATABASE homely;\n", SQL.replace(b"-- Dump completed on", b"-- Interrupted on")]
            for content in cases:
                with self.subTest(content=content), self.assertRaises(RuntimeError):
                    path.write_bytes(content)
                    recovery.validate_sql(path, "homely")
            path.write_bytes(SQL)
            recovery.validate_sql(path, "homely")

    def test_duplicate_json_and_unexpected_secret_fields_are_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "backup"
            manifest = make_backup(path)
            manifest["environment"] = {"PASSWORD": "fixture"}
            with self.assertRaisesRegex(RuntimeError, "schema"):
                recovery.validate_manifest(manifest)
            with self.assertRaisesRegex(RuntimeError, "duplicate"):
                json.loads('{"a":1,"a":2}', object_pairs_hook=recovery.reject_duplicate_keys)

    def test_source_or_existing_target_is_refused_without_mutations(self):
        with tempfile.TemporaryDirectory() as root:
            manifest = make_backup(Path(root) / "backup")
            with patch.object(recovery, "docker") as docker, self.assertRaisesRegex(RuntimeError, "DIFFERENT"):
                recovery.require_new_target("fixture-source", manifest)
            docker.assert_not_called()
            for existing in ("container", "volume", "network"):
                calls = []

                def respond(*command, **_):
                    calls.append(command)
                    if existing == "container" and command[0] == "ps":
                        return "fixture-container"
                    if existing == "volume" and command[:2] == ("volume", "ls") and "--filter" not in command:
                        return "fixture-restore_mysql_data"
                    if existing == "network" and command[:2] == ("network", "ls"):
                        return "fixture-restore_default"
                    return ""

                with self.subTest(existing=existing), patch.object(recovery, "docker", side_effect=respond), self.assertRaises(RuntimeError):
                    recovery.require_new_target("fixture-restore", manifest)
                self.assertTrue(all(call[0] in ("ps", "volume", "network") for call in calls))

    def test_changed_private_storage_credentials_refuse_restore(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "backup"
            make_backup(path)
            changed = configuration()
            changed["services"]["minio"]["environment"]["MINIO_ROOT_PASSWORD"] = "fixture-changed"
            changed["services"]["backend"]["environment"]["MINIO_SECRET_KEY"] = "fixture-changed"
            with patch.object(recovery, "docker") as docker, self.assertRaisesRegex(RuntimeError, "credentials differ"):
                recovery.restore(args(input=path), ["compose"], changed)
            docker.assert_not_called()

    def test_backup_resumes_original_running_services_even_when_dump_fails(self):
        config = configuration()
        for stopped in ("", "backend", "minio"):
            services = containers(config, stopped=stopped)
            calls = []

            def respond(*command, **kwargs):
                calls.append(command)
                if command[0] == "ps":
                    return services["minio" if "minio" in command[3] else "mysql"]["Id"][:12]
                if command[0] == "exec":
                    raise RuntimeError("Fixture dump failure")
                return ""

            with self.subTest(stopped=stopped), tempfile.TemporaryDirectory() as root:
                with patch.object(recovery, "inspect_project", return_value=services), patch.object(recovery, "docker", side_effect=respond), patch.object(recovery, "wait_healthy"):
                    with self.assertRaisesRegex(RuntimeError, "Fixture dump failure"):
                        recovery.backup(args(output=Path(root) / "backup"), ["compose"], config)
                starts = [call[1] for call in calls if call[0] == "start"]
                self.assertEqual([services[name]["Id"] for name in ("minio", "backend") if name != stopped], starts)
                self.assertNotIn(services["mysql"]["Id"], starts)

    def test_backup_manifest_and_command_arguments_do_not_contain_credentials(self):
        config = configuration()
        services = containers(config)
        calls = []

        def respond(*command, **kwargs):
            calls.append(command)
            if command[0] == "ps":
                return services["minio" if "minio" in command[3] else "mysql"]["Id"][:12]
            if "stdout" in kwargs:
                kwargs["stdout"].write(SQL if command[0] == "exec" else archive_bytes())
            return ""

        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "backup"
            with patch.object(recovery, "inspect_project", return_value=services), patch.object(recovery, "docker", side_effect=respond), patch.object(recovery, "wait_healthy"):
                recovery.backup(args(output=path), ["compose"], config)
            manifest = recovery.load_backup(path)
            self.assertEqual({"manifest.json", "mysql.sql", "minio.tar"}, {item.name for item in path.iterdir()})
            serialized = json.dumps(manifest) + repr(calls)
            for key in ("MYSQL_PASSWORD", "MINIO_SECRET_KEY", "JWT_SECRET"):
                self.assertNotIn(config["services"]["backend"]["environment"][key], serialized)
            self.assertNotIn(config["services"]["mysql"]["environment"]["MYSQL_ROOT_PASSWORD"], serialized)
            stops = [call[3] for call in calls if call[0] == "stop"]
            self.assertEqual([services["backend"]["Id"], services["minio"]["Id"]], stops)
            tar_call = next(call for call in calls if call[0] == "run")
            self.assertIn("type=volume,source=fixture-source_minio_data,target=/data,readonly", tar_call)
            self.assertNotIn("fixture-source_mysql_data", " ".join(tar_call))

    def test_restore_starts_backend_only_after_both_data_restores(self):
        source_config = configuration()
        calls = []
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "backup"
            manifest = make_backup(path, source_config)
            target = copy.deepcopy(source_config)
            target["name"] = "fixture-restore"
            for name, item in manifest["services"].items():
                target["services"][name]["image"] = item["image_id"]
            target["volumes"] = {name + "_data": {"name": "fixture-restore_" + name + "_data"} for name in ("mysql", "minio")}
            target["networks"] = {"default": {"name": "fixture-restore_default"}}
            target["services"]["backend"]["environment"].update({"DEMO_SEED": "false", "FCM_ENABLED": "false", "SMTP_PASSWORD": ""})
            target["services"]["backend"]["ports"] = [{"host_ip": "127.0.0.1", "target": 8080, "published": "18080"}]
            target["services"]["mailpit"]["ports"] = [{"host_ip": "127.0.0.1", "target": 8025, "published": "18025"}]
            created = containers(target, target=True)
            healthy = containers(target)

            def respond(*command, **kwargs):
                calls.append(command)
                if command[:2] == ("image", "inspect"):
                    return json.dumps([{"Id": command[2]}])
                if "config" in command:
                    return json.dumps(target).replace("$", "$$")
                if "stdin" in kwargs:
                    self.assertEqual(SQL if command[0] == "exec" else archive_bytes(), kwargs["stdin"].read())
                return ""

            with patch.object(recovery, "docker", side_effect=respond), patch.object(recovery, "inspect_project", side_effect=[created, healthy]), patch.object(recovery, "wait_healthy"):
                recovery.restore(args(input=path), ["compose"], source_config)
            import_index = next(index for index, call in enumerate(calls) if call[0] == "exec")
            minio_index = next(index for index, call in enumerate(calls) if call[0] == "run" and "exec tar -xpf" in call[-1])
            full_up = next(index for index, call in enumerate(calls) if "up" in call and "--no-deps" not in call)
            self.assertLess(import_index, full_up)
            self.assertLess(minio_index, full_up)
            self.assertTrue(all("down" not in call and "rm" not in call for call in calls))
            settings = Path(root) / "fixture-restore-restore"
            override = json.loads((settings / "runtime.compose.json").read_text())
            self.assertEqual("false", override["services"]["backend"]["environment"]["FCM_ENABLED"])
            self.assertEqual("mailpit", override["services"]["backend"]["environment"]["SMTP_HOST"])
            serialized = repr(calls) + (settings / "runtime.compose.json").read_text() + (settings / "runtime.env").read_text()
            for key in ("MYSQL_PASSWORD", "MINIO_SECRET_KEY", "JWT_SECRET"):
                self.assertNotIn(source_config["services"]["backend"]["environment"][key], serialized)


if __name__ == "__main__":
    unittest.main()
