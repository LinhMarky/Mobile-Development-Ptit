"""Validate external SMTP/Firebase configuration without printing credentials."""

import argparse
from email.message import EmailMessage
from email.utils import parseaddr
import json
from pathlib import Path
import smtplib
import ssl
import subprocess
import sys

from compose_config import read_compose_json


class ConfigurationError(ValueError):
    """A static, safe-to-display configuration diagnosis, never containing a secret."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ConfigurationError(message)


def validate_smtp(environment: dict) -> None:
    host = environment.get("SMTP_HOST", "").strip()
    require(bool(host) and host.lower() not in ("mailpit", "localhost", "127.0.0.1", "::1"), "Configure an external SMTP host, not Mailpit/loopback")
    require(bool(environment.get("SMTP_USERNAME")) and bool(environment.get("SMTP_PASSWORD")), "SMTP username/password are required")
    require(1 <= int(environment.get("SMTP_PORT", "0")) <= 65535, "Invalid SMTP port")
    starttls = environment.get("SMTP_STARTTLS", "").lower() == "true"
    implicit = environment.get("SPRING_MAIL_PROPERTIES_MAIL_SMTP_SSL_ENABLE", "false").lower() == "true"
    require(starttls != implicit, "Enable exactly one SMTP mode: STARTTLS or implicit TLS")
    address = parseaddr(environment.get("MAIL_FROM", ""))[1]
    require("@" in address and not address.lower().endswith((".test", ".local", ".invalid", ".example")), "MAIL_FROM must be a real authorized sender address")
    require(environment.get("SPRING_MAIL_PROPERTIES_MAIL_SMTP_AUTH") == "true", "SMTP authentication must be enabled")
    require(environment.get("SPRING_MAIL_PROPERTIES_MAIL_SMTP_SSL_CHECKSERVERIDENTITY") == "true",
            "SMTP certificate hostname verification must be enabled")
    require(environment.get("SPRING_MAIL_PROPERTIES_MAIL_SMTP_STARTTLS_ENABLE") == str(starttls).lower(),
            "SMTP_STARTTLS and the effective JavaMail STARTTLS setting must match")
    require(environment.get("SPRING_MAIL_PROPERTIES_MAIL_SMTP_STARTTLS_REQUIRED") == str(starttls).lower(),
            "Require STARTTLS when using STARTTLS; disable it only with implicit TLS")


def validate_firebase(path: Path, project: str) -> None:
    require(path.is_absolute() and path.is_file(), "Firebase credential must be an existing absolute file path")
    credential = json.loads(path.read_text(encoding="utf-8"))
    require(credential.get("type") == "service_account", "Use a backend service-account JSON, not Android google-services.json")
    require(bool(project) and credential.get("project_id") == project, "Firebase project ID does not match the service account")
    require(bool(credential.get("client_email")) and bool(credential.get("private_key_id")), "Incomplete Firebase service account")
    require(credential.get("private_key", "").startswith("-----BEGIN PRIVATE KEY-----"), "Firebase private key is missing")


def check_smtp_network(environment: dict, recipient: str | None) -> None:
    context = ssl.create_default_context()
    implicit = environment.get("SPRING_MAIL_PROPERTIES_MAIL_SMTP_SSL_ENABLE", "false").lower() == "true"
    client_type = smtplib.SMTP_SSL if implicit else smtplib.SMTP
    options = {"context": context} if implicit else {}
    with client_type(environment["SMTP_HOST"], int(environment["SMTP_PORT"]), timeout=15, **options) as client:
        client.ehlo()
        if not implicit:
            client.starttls(context=context)
            client.ehlo()
        client.login(environment["SMTP_USERNAME"], environment["SMTP_PASSWORD"])
        if recipient:
            require("@" in parseaddr(recipient)[1], "Invalid test-email recipient")
            message = EmailMessage()
            message["From"] = environment["MAIL_FROM"]
            message["To"] = recipient
            message["Subject"] = "Roomly: kiểm tra SMTP VPS"
            message.set_content("Đây là email kiểm tra cấu hình SMTP. Luồng đăng ký/xác minh cần được kiểm tra riêng từ app hoặc API.")
            client.send_message(message)
    print("PASS SMTP: TLS certificate verified and authentication accepted")
    if recipient:
        print("SMTP accepted the test email; confirm actual inbox delivery separately.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env-file", type=Path, default=Path(__file__).resolve().parent / ".env")
    parser.add_argument("--smtp-env", type=Path, help="Optional private SMTP dotenv file, applied after the main env file")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--demo", action="store_true")
    mode.add_argument("--prod", action="store_true")
    parser.add_argument("--smtp", action="store_true")
    parser.add_argument("--smtp-only", action="store_true", help="Check the private SMTP file without any database/backend configuration")
    parser.add_argument("--firebase", action="store_true")
    parser.add_argument("--network", action="store_true", help="Authenticate to SMTP over TLS; sends no email by default")
    parser.add_argument("--send-test-email", help="Explicitly send one diagnostic email to this address")
    parser.add_argument("--container", action="store_true", help="Check Firebase file readability as the running backend user")
    args = parser.parse_args()
    if args.smtp_only:
        args.smtp = True
        require(not (args.firebase or args.demo or args.prod or args.container), "SMTP-only mode cannot include backend/Firebase profiles")
    require(args.smtp or args.firebase, "Choose --smtp and/or --firebase")
    require(not (args.prod and args.smtp), "Production already enforces SMTP STARTTLS")
    require(not (args.network or args.send_test_email) or args.smtp, "SMTP network checks require --smtp")
    require(not args.container or args.firebase, "Container credential checks require --firebase")
    require(not args.smtp_env or args.smtp_env.is_file(), "Private SMTP env file does not exist")
    directory = Path(__file__).resolve().parent
    if args.smtp_only:
        selected_file = args.smtp_env or args.env_file
        require(selected_file.is_file(), "Private SMTP env file does not exist")
        # This overlay alone describes only SMTP env values, without a runnable image.
        # Disable image consistency validation only for this read-only config extraction.
        compose = ["docker", "compose", "--env-file", str(selected_file.resolve()), "-f", str(directory / "compose.smtp.yaml")]
        config_options = ["config", "--format", "json", "--no-consistency"]
    else:
        compose = ["docker", "compose", "--env-file", str(args.env_file.resolve())]
        if args.smtp_env:
            compose += ["--env-file", str(args.smtp_env.resolve())]
        compose += ["-f", str(directory / "compose.yaml")]
        if args.demo:
            compose += ["-f", str(directory / "compose.demo.yaml")]
        elif args.prod:
            compose += ["-f", str(directory / "compose.prod.yaml")]
        if args.smtp:
            compose += ["-f", str(directory / "compose.smtp.yaml")]
        if args.firebase:
            compose += ["-f", str(directory.parent / "compose.firebase.yaml")]
        config_options = ["config", "--format", "json"]
    result = subprocess.run(compose + config_options, capture_output=True, text=True)
    require(result.returncode == 0, "Compose config failed; check missing env variables locally (secrets omitted)")
    # Compose escapes every literal $ as $$ in config output, including JSON.
    # Reverse this serialization step; container/SMTP values contain the original $.
    configuration = read_compose_json(result.stdout)["services"]["backend"]
    environment = configuration["environment"]
    if args.smtp:
        validate_smtp(environment)
        print("PASS SMTP configuration: real sender, auth and exactly one TLS mode")
        if args.network or args.send_test_email:
            check_smtp_network(environment, args.send_test_email)
    if args.firebase:
        mount = next(item for item in configuration["volumes"] if item["target"] == "/run/secrets/firebase-service-account.json")
        # Compose's normalized JSON omits false values, including create_host_path=false.
        require(mount.get("read_only") and not mount.get("bind", {}).get("create_host_path", False), "Firebase bind must be read-only and reject missing host files")
        validate_firebase(Path(mount["source"]), environment.get("FIREBASE_PROJECT_ID", ""))
        print("PASS Firebase configuration: project matches service account; existing read-only credential file")
        if args.container:
            result = subprocess.run(compose + ["exec", "-T", "backend", "test", "-r", mount["target"]], capture_output=True)
            require(result.returncode == 0, "Backend user cannot read the mounted Firebase credential")
            print("PASS Firebase mount readable by the running backend user")
    print("Configuration checks do not prove email inbox delivery or an FCM notification on a phone.")


if __name__ == "__main__":
    try:
        main()
    except ConfigurationError as error:
        print(f"FAIL configuration: {error}", file=sys.stderr)
        sys.exit(1)
    except ssl.SSLCertVerificationError:
        print("FAIL SMTP TLS: certificate or hostname verification failed; verification was not disabled.", file=sys.stderr)
        sys.exit(1)
    except smtplib.SMTPAuthenticationError as error:
        print(f"FAIL SMTP authentication (code {error.smtp_code}); check SMTP credentials/App Password locally.", file=sys.stderr)
        sys.exit(1)
    except (OSError, ValueError, KeyError, StopIteration, smtplib.SMTPException) as error:
        # Remote SMTP errors and malformed credential JSON can contain sensitive data.
        print(f"FAIL external service check ({type(error).__name__}); inspect configuration locally.", file=sys.stderr)
        sys.exit(1)
