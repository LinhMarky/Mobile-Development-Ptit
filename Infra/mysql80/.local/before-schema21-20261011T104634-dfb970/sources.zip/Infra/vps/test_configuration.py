"""Offline regression checks for proxy trust boundaries and external-service guards."""

from pathlib import Path
import json
import tempfile
import unittest

from check_services import validate_firebase, validate_smtp
from render_proxy import render, trusted_regex, validate_host
from compose_config import read_compose_json
from configure_smtp import dotenv_value


class ConfigurationTests(unittest.TestCase):
    def test_compose_json_dollar_escaping_is_decoded_once(self):
        original = {"password": "literal$money$$${unchanged}", "proxy_regex": "^(127\\.0\\.0\\.1)$"}
        serialized = json.dumps(original).replace("$", "$$")
        self.assertEqual(original, read_compose_json(serialized))
        for value in ("line\nbreak", "carriage\rreturn", "nul\x00byte"):
            with self.assertRaises(ValueError):
                dotenv_value(value)

    def test_host_injection_and_invalid_addresses_are_rejected(self):
        for host in ("https://api.example.com", "example.com;include", "example.com\n}", "999.1.2.3", "example.com:443", "::1"):
            with self.subTest(host=host), self.assertRaises(ValueError):
                validate_host(host)
        self.assertEqual("203.0.113.10", validate_host("203.0.113.10"))
        self.assertEqual("api.example.com", validate_host("API.EXAMPLE.COM"))

    def test_proxy_regex_trusts_only_exact_configured_addresses(self):
        import re
        expression = trusted_regex(["127.0.0.1", "172.19.0.1"])
        self.assertTrue(re.fullmatch(expression, "172.19.0.1"))
        for address in ("172.19.0.2", "172x19x0x1", "10.0.0.1"):
            self.assertIsNone(re.fullmatch(expression, address))
        for address in ("172.19.0.0/16", ".*", ""):
            with self.assertRaises(ValueError):
                trusted_regex([address])

    def test_proxy_keeps_paths_replaces_spoofed_headers_and_allows_upload_and_wss(self):
        bootstrap, tls = render("203.0.113.10", 8080)
        self.assertIn("location / { return 503; }", bootstrap)
        self.assertNotIn("proxy_pass", bootstrap)
        self.assertIn("client_max_body_size 60m", tls)
        self.assertIn("proxy_pass http://127.0.0.1:8080;", tls)
        self.assertNotIn("proxy_pass http://127.0.0.1:8080/;", tls)
        self.assertEqual(2, tls.count("proxy_set_header X-Forwarded-For $remote_addr;"))
        self.assertIn('proxy_set_header Forwarded "";', tls)
        self.assertIn('proxy_set_header Connection "upgrade";', tls)
        self.assertIn("proxy_read_timeout 3600s", tls)
        self.assertIn("location /actuator { return 404; }", tls)
        self.assertNotIn("$request\"", tls)

    def test_smtp_rejects_mailpit_missing_auth_and_wrong_tls_modes(self):
        configuration = {"SMTP_HOST": "smtp.example.com", "SMTP_PORT": "587", "SMTP_USERNAME": "user", "SMTP_PASSWORD": "fixture", "MAIL_FROM": "sender@example.com", "SMTP_STARTTLS": "true", "SPRING_MAIL_PROPERTIES_MAIL_SMTP_AUTH": "true", "SPRING_MAIL_PROPERTIES_MAIL_SMTP_SSL_ENABLE": "false", "SPRING_MAIL_PROPERTIES_MAIL_SMTP_SSL_CHECKSERVERIDENTITY": "true", "SPRING_MAIL_PROPERTIES_MAIL_SMTP_STARTTLS_ENABLE": "true", "SPRING_MAIL_PROPERTIES_MAIL_SMTP_STARTTLS_REQUIRED": "true"}
        validate_smtp(configuration)
        for change in ({"SMTP_HOST": "mailpit"}, {"SMTP_PASSWORD": ""}, {"SMTP_STARTTLS": "false"}, {"SPRING_MAIL_PROPERTIES_MAIL_SMTP_SSL_ENABLE": "true"}, {"MAIL_FROM": "noreply@homely.test"}, {"SPRING_MAIL_PROPERTIES_MAIL_SMTP_SSL_CHECKSERVERIDENTITY": "false"}, {"SPRING_MAIL_PROPERTIES_MAIL_SMTP_STARTTLS_REQUIRED": "false"}, {"SPRING_MAIL_PROPERTIES_MAIL_SMTP_STARTTLS_ENABLE": "false"}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                validate_smtp(configuration | change)
        validate_smtp(configuration | {"SMTP_PORT": "465", "SMTP_STARTTLS": "false", "SPRING_MAIL_PROPERTIES_MAIL_SMTP_SSL_ENABLE": "true", "SPRING_MAIL_PROPERTIES_MAIL_SMTP_STARTTLS_ENABLE": "false", "SPRING_MAIL_PROPERTIES_MAIL_SMTP_STARTTLS_REQUIRED": "false"})

    def test_firebase_rejects_android_json_missing_file_and_cross_project_credentials(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "credential.json"
            with self.assertRaises(ValueError):
                validate_firebase(path, "project-a")
            path.write_text(json.dumps({"project_info": {"project_id": "project-a"}}))
            with self.assertRaises(ValueError):
                validate_firebase(path, "project-a")
            path.write_text(json.dumps({"type": "service_account", "project_id": "project-a", "client_email": "fixture@example.com", "private_key_id": "fixture", "private_key": "-----BEGIN PRIVATE KEY-----\nfixture"}))
            validate_firebase(path, "project-a")
            with self.assertRaises(ValueError):
                validate_firebase(path, "project-b")


if __name__ == "__main__":
    unittest.main()
