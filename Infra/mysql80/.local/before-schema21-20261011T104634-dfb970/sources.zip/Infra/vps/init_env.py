"""Create a VPS env file once, without printing secrets or replacing an existing file."""

import argparse
import base64
import os
from pathlib import Path
import re
import secrets


def random_secret(size: int) -> str:
    return base64.b64encode(secrets.token_bytes(size)).decode("ascii")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tag", required=True, help="Explicit backend image tag, e.g. report-20261008")
    parser.add_argument("--demo", action="store_true", help="Initialize SMTP settings for compose.demo.yaml")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / ".env")
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}", args.tag):
        parser.error("Invalid image tag")
    if args.tag.lower() == "latest":
        parser.error("Use a versioned tag instead of latest")

    values = {
        "COMPOSE_PROJECT_NAME": "homely-vps",
        "BACKEND_IMAGE": "homely-backend",
        "BACKEND_TAG": args.tag,
        "API_PORT": "8080",
        "MYSQL_DATABASE": "homely",
        "MYSQL_PASSWORD": random_secret(32),
        "MYSQL_ROOT_PASSWORD": random_secret(32),
        "MINIO_ACCESS_KEY": "homely-vps",
        "MINIO_SECRET_KEY": random_secret(32),
        "JWT_SECRET": random_secret(64),
        "DEMO_PASSWORD": random_secret(24),
        "BACKEND_MEMORY_LIMIT": "1024m",
        "MYSQL_MEMORY_LIMIT": "1024m",
        "MINIO_MEMORY_LIMIT": "512m",
        "JAVA_TOOL_OPTIONS": "-Xms128m -Xmx640m -XX:ActiveProcessorCount=2",
        "LOG_MAX_SIZE": "10m",
        "LOG_MAX_FILES": "3",
        "SMTP_HOST": "mailpit" if args.demo else "",
        "SMTP_PORT": "1025" if args.demo else "587",
        "SMTP_USERNAME": "",
        "SMTP_PASSWORD": "",
        "MAIL_FROM": "noreply@homely.test" if args.demo else "",
        "MAILPIT_PORT": "8025",
        "SMTP_STARTTLS": "true",
        "SMTP_SSL": "false",
        "FIREBASE_PROJECT_ID": "",
        "FIREBASE_CREDENTIALS_FILE": "",
        "MYSQL_TLS_DIRECTORY": "",
        "MYSQL_TRUSTSTORE_FILE": "",
    }
    # O_EXCL prevents overwriting credentials used by existing persistent volumes.
    try:
        descriptor = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        parser.error("Env file already exists; it was not changed")
    with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
        stream.write("# Generated locally; do not commit or share this file.\n")
        stream.writelines(f"{key}={value}\n" for key, value in values.items())
    print(f"Created {args.output}. Secrets were not printed.")
    if not args.demo:
        print("Configure SMTP_HOST, SMTP credentials and MAIL_FROM locally before starting.")


if __name__ == "__main__":
    main()
