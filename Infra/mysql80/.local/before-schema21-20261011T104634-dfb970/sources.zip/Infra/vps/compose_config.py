"""Decode the resolved JSON emitted by `docker compose config --format json`."""

import json


def read_compose_json(output: str) -> dict:
    # Compose doubles every literal $ when serializing an interpolated config.
    # Decode exactly that layer, preserving values such as a real $$ password.
    # This rule applies to config output only, never to docker inspect output.
    return json.loads(output.replace("$$", "$"))
