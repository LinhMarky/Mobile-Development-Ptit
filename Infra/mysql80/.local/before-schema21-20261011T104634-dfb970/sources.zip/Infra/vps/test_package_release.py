"""Offline release packaging tests: all files are temporary and Docker is mocked."""

from contextlib import redirect_stderr, redirect_stdout
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import package_release as release


BACKEND = "homely-backend:vps-verified-20261008"
MINIO = "homely-minio-source:release-2025-04-22"


class FakeDocker:
    def __init__(self, *, missing=None, architecture="amd64", failure=None):
        self.calls = []
        self.missing = missing
        self.architecture = architecture
        self.failure = failure
        self.references = [BACKEND, MINIO, *(reference for _, reference in release.DATA_IMAGES)]
        self.ids = {reference: "sha256:" + str(index + 1) * 64 for index, reference in enumerate(self.references)}

    def __call__(self, command, **options):
        self.calls.append((command, options))
        action = command[2]
        if action == self.failure:
            return subprocess.CompletedProcess(command, 1, "fixture-private-password", "fixture-private-password")
        if action == "ls":
            output = "\n".join(json.dumps({"Repository": reference.rsplit(":", 1)[0],
                                           "Tag": reference.rsplit(":", 1)[1], "ID": self.ids[reference]})
                               for reference in self.references if reference != self.missing)
        elif action == "inspect":
            output = json.dumps({"id": self.ids[command[-1]], "os": "linux",
                                 "architecture": self.architecture, "variant": ""})
        elif action == "save":
            Path(command[4]).write_bytes(b"fixture image archive without host credentials")
            output = ""
        else:
            raise AssertionError(f"Unexpected Docker operation: {action}")
        return subprocess.CompletedProcess(command, 0, output, "")


class ReleasePackagingTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.workspace = Path(self.temporary.name) / "workspace"
        self.workspace.mkdir()
        for relative in (*release.RELEASE_FILES, *release.OPTIONAL_FILES):
            source = self.workspace / relative
            source.parent.mkdir(parents=True, exist_ok=True)
            source.write_text(f"public fixture: {relative}\n", encoding="utf-8")
        self.output = self.workspace / "backend/target/backend-verification/release"
        self.docker = FakeDocker()

    def package(self, **options):
        return release.create_release(self.workspace, self.output, BACKEND, MINIO,
                                      runner=self.docker, **options)

    def test_allowlist_excludes_secrets_private_state_backups_sources_and_frontends(self):
        excluded = (
            "Infra/vps/.env", "Infra/vps/.env.smtp", "Infra/vps/.env.example.backup",
            "Infra/vps/generated/proxy/proxy.env", "Infra/vps/runtime-results.json",
            "Infra/vps/private_helper.py", "Infra/vps/nginx/private-key.pem",
            "Infra/vps/__pycache__/cached.pyc", "Infra/vps/data/database.sql",
            "backend/target/app.jar", "backend/src/main/java/Application.java",
            "Infra/backups/objects.tar", "Infra/firebase-service-account.json",
            ".git/config", ".codex/private-state.json", ".agents/private.md",
            "Frontend-Mobile-App/source.ts", "Homely-android/google-services.json",
        )
        for relative in excluded:
            path = self.workspace / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("fixture-host-secret-never-read", encoding="utf-8")
        forbidden = {self.workspace / relative for relative in excluded}
        original_open = Path.open

        def guard_open(path, *args, **kwargs):
            self.assertNotIn(path, forbidden, "Packaging attempted to read an excluded private file")
            return original_open(path, *args, **kwargs)

        with patch.object(Path, "open", guard_open):
            manifest = self.package()
        actual = {path.relative_to(self.output).as_posix() for path in self.output.rglob("*") if path.is_file()}
        self.assertEqual(set(release.RELEASE_FILES) | set(release.OPTIONAL_FILES) | {"images.tar", "manifest.json"}, actual)
        self.assertTrue(actual.isdisjoint(excluded))
        self.assertNotIn("fixture-host-secret-never-read", json.dumps(manifest))
        self.assertTrue(manifest["scope"]["runtime_images_provided"])
        self.assertIn("cannot rebuild", manifest["scope"]["backend_context"])

    def test_manifest_hashes_sizes_platform_and_compose_image_settings_match_payload(self):
        manifest = self.package()
        self.assertEqual(manifest, json.loads((self.output / "manifest.json").read_text(encoding="utf-8")))
        self.assertEqual("linux/amd64", manifest["target_platform"])
        self.assertRegex(manifest["created_at_utc"], r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ$")
        self.assertEqual({"BACKEND_IMAGE": "homely-backend", "BACKEND_TAG": "vps-verified-20261008",
                          "MINIO_IMAGE": MINIO}, manifest["compose_image_settings"])
        for record in manifest["files"]:
            content = (self.output / record["path"]).read_bytes()
            self.assertEqual(len(content), record["size_bytes"])
            self.assertEqual(hashlib.sha256(content).hexdigest(), record["sha256"])
        self.assertEqual([BACKEND, MINIO], [item["reference"] for item in manifest["images"]])
        self.assertEqual([self.docker.ids[BACKEND], self.docker.ids[MINIO]], [item["id"] for item in manifest["images"]])

    def test_metadata_accepts_engine_without_variant_field(self):
        def engine_without_variant(command, **options):
            if command[2] == "inspect":
                self.assertNotIn(".Variant", command[4], "Older Docker engines reject this missing template field")
            result = self.docker(command, **options)
            if command[2] == "inspect":
                metadata = json.loads(result.stdout)
                metadata.pop("variant")
                return subprocess.CompletedProcess(command, 0, json.dumps(metadata), "")
            return result

        manifest = release.create_release(self.workspace, self.output, BACKEND, MINIO,
                                          runner=engine_without_variant)
        self.assertTrue(all(item["architecture"] == "amd64" and item["variant"] == "" for item in manifest["images"]))

    def test_existing_empty_or_nonempty_directory_is_never_overwritten_and_docker_is_not_called(self):
        self.output.mkdir(parents=True)
        for nonempty in (False, True):
            if nonempty:
                (self.output / "keep.txt").write_text("keep this", encoding="utf-8")
            with self.subTest(nonempty=nonempty), self.assertRaisesRegex(release.ReleaseError, "already exists"):
                self.package()
            self.assertEqual([], self.docker.calls)
            if nonempty:
                self.assertEqual("keep this", (self.output / "keep.txt").read_text())

    def test_existing_file_output_is_never_overwritten(self):
        self.output.parent.mkdir(parents=True)
        self.output.write_text("keep this", encoding="utf-8")
        with self.assertRaisesRegex(release.ReleaseError, "already exists"):
            self.package()
        self.assertEqual("keep this", self.output.read_text())
        self.assertEqual([], self.docker.calls)

    def test_protected_output_and_parent_traversal_are_rejected_before_docker(self):
        for protected in (".git", ".agents", ".codex", ".aws"):
            with self.subTest(protected=protected), self.assertRaisesRegex(release.ReleaseError, "protected"):
                release.create_release(self.workspace, self.workspace / protected / "release", BACKEND, MINIO,
                                       runner=self.docker)
        with self.assertRaisesRegex(release.ReleaseError, "'..'"):
            release.create_release(self.workspace, self.workspace / ".." / "release", BACKEND, MINIO,
                                   runner=self.docker)
        self.assertEqual([], self.docker.calls)

    def test_unsafe_allowlist_cannot_escape_workspace(self):
        with patch.object(release, "RELEASE_FILES", ("../outside.md",)):
            with self.assertRaisesRegex(release.ReleaseError, "unsafe path"):
                self.package()
        self.assertEqual([], self.docker.calls)

    def test_source_symlink_and_output_parent_junction_are_rejected(self):
        source = self.workspace / release.RELEASE_FILES[0]
        # Model both link types without needing Windows symlink privileges.
        with patch.object(Path, "is_symlink", autospec=True, side_effect=lambda path: path == source):
            with self.assertRaisesRegex(release.ReleaseError, "Symlinks"):
                self.package()
        with patch.object(Path, "is_junction", create=True, autospec=True,
                          side_effect=lambda path: path == self.output.parent):
            with self.assertRaisesRegex(release.ReleaseError, "junctions"):
                self.package()
        self.assertFalse(self.output.exists())
        self.assertEqual([], self.docker.calls)

    def test_missing_required_document_is_understandable_and_optional_dockerignore_can_be_absent(self):
        relative = "Docs - contract/IMPLEMENTATION_STATUS.md"
        (self.workspace / relative).unlink()
        with self.assertRaisesRegex(release.ReleaseError, "Required release file missing: Docs - contract/IMPLEMENTATION_STATUS"):
            self.package()
        self.assertEqual([], self.docker.calls)
        (self.workspace / relative).write_text("public fixture", encoding="utf-8")
        (self.workspace / release.OPTIONAL_FILES[0]).unlink()
        manifest = self.package()
        self.assertNotIn("backend/.dockerignore", {item["path"] for item in manifest["files"]})

    def test_invalid_or_unversioned_image_references_are_rejected_before_docker(self):
        invalid = ("homely-backend", "homely-backend:latest", "homely-backend:LATEST", "UPPER:v1",
                   "--output=x:v1", "repo@sha256:abc", "registry:5000/thing", "sha256:" + "a" * 64,
                   "repo: tag", "https://registry/repo:v1", "repo:$(private)", "../repo:v1")
        for reference in invalid:
            with self.subTest(reference=reference), self.assertRaises(release.ReleaseError):
                release.create_release(self.workspace, self.output, reference, MINIO, runner=self.docker)
        self.assertEqual(("registry.example:5000/team/backend", "v1.2"),
                         release.validate_image_ref("registry.example:5000/team/backend:v1.2"))
        self.assertEqual([], self.docker.calls)

    def test_missing_image_or_wrong_architecture_never_creates_output_or_saves(self):
        for docker in (FakeDocker(missing=MINIO), FakeDocker(architecture="arm64")):
            with self.subTest(docker=docker), self.assertRaises(release.ReleaseError):
                release.create_release(self.workspace, self.output, BACKEND, MINIO, runner=docker)
            self.assertFalse(self.output.exists())
            self.assertNotIn("save", [command[2] for command, _ in docker.calls])

    def test_optional_data_images_and_only_read_metadata_and_save_commands(self):
        manifest = self.package(include_data_images=True)
        self.assertTrue(manifest["scope"]["data_images_included"])
        self.assertEqual(self.docker.references, [image["reference"] for image in manifest["images"]])
        self.assertEqual(["ls", "inspect", "inspect", "inspect", "inspect", "save",
                          "ls", "inspect", "inspect", "inspect", "inspect"],
                         [command[2] for command, _ in self.docker.calls])
        command = next(command for command, _ in self.docker.calls if command[2] == "save")
        self.assertEqual(self.docker.references, command[5:])
        for command, options in self.docker.calls:
            self.assertEqual(["docker", "image"], command[:2])
            self.assertTrue(options["capture_output"])
            self.assertFalse(options["check"])
            if command[2] == "inspect":
                self.assertEqual(release.IMAGE_METADATA_FORMAT, command[4])
                self.assertNotIn("Config", command[4])
                self.assertNotIn("Env", command[4])

    def test_tag_changed_during_export_prevents_a_completed_manifest(self):
        original_runner = self.docker

        def changing_runner(command, **options):
            result = original_runner(command, **options)
            if command[2] == "save":
                original_runner.ids[BACKEND] = "sha256:" + "f" * 64
            return result

        with self.assertRaisesRegex(release.ReleaseError, "tags changed"):
            release.create_release(self.workspace, self.output, BACKEND, MINIO, runner=changing_runner)
        self.assertTrue((self.output / "images.tar").is_file())
        self.assertFalse((self.output / "manifest.json").exists())

    def test_docker_error_output_never_appears_in_cli_stdout_or_stderr(self):
        stdout, stderr = io.StringIO(), io.StringIO()
        docker = FakeDocker(failure="ls")
        with patch.object(release.subprocess, "run", docker), patch.object(release, "selected_sources", return_value=[]):
            with redirect_stdout(stdout), redirect_stderr(stderr), self.assertRaises(SystemExit) as error:
                release.main(["--output", str(self.output), "--backend-image", BACKEND, "--minio-image", MINIO])
        self.assertEqual(1, error.exception.code)
        self.assertIn("Cannot list local Docker images", stderr.getvalue())
        self.assertNotIn("fixture-private-password", stdout.getvalue() + stderr.getvalue())
        self.assertFalse(self.output.exists())


if __name__ == "__main__":
    unittest.main()
