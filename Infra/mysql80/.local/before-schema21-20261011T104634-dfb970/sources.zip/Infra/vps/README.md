# Bộ triển khai backend trên VPS

Contract **1.6.0**, giữ HTTP JSON `{statusCode,message,data}`. Bộ này có cấu hình backend/database/storage, Nginx HTTPS/WSS, SMTP và Firebase cho VPS. Backend chỉ bind `127.0.0.1`, MySQL/MinIO không publish port. Triển khai nhanh theo [hướng dẫn mục 3–4](../../Docs%20-%20contract/VPS_HTTPS_SMTP_FCM_08_10_2026.md); [file bàn giao FE](../../Docs%20-%20contract/FE_BACKEND_HANDOFF_08_10_2026.md) ghi rõ URL/tài khoản và quy tắc tích hợp.

## 1. Cấu trúc và giới hạn

| File | Vai trò |
| --- | --- |
| `compose.yaml` | VPS cơ sở: demo/mock tắt, SMTP ngoài, profile `vps` |
| `compose.demo.yaml` | Bật rõ môi trường báo cáo: tài khoản demo, simulate payment và Mailpit |
| `compose.prod.yaml` | Bật profile `prod`: MySQL TLS xác minh hostname, SMTP STARTTLS, demo/mock tắt |
| `.env.example`, `init_env.py` | Cấu hình mẫu và tạo secret ngẫu nhiên; không ghi đè .env đã có |
| `check_runtime.py` | Kiểm chứng chỉ đọc container, volume, giới hạn và HTTP contract |
| `test_persistence.py` | Tạo phòng/ảnh thử và recreate container trong demo, kiểm tra dữ liệu còn nguyên |
| `render_proxy.py`, `compose.proxy.yaml` | Nginx trên host, HTTPS trực tiếp bằng IP hoặc domain, WSS và IP proxy được tin cụ thể |
| `compose.smtp.yaml`, `check_services.py` | SMTP thật cho môi trường báo cáo; kiểm tra TLS/auth và credential Firebase |
| `check_firebase.py`, `requirements-firebase.txt` | OAuth và FCM HTTP V1 validate-only; kiểm tra API/quyền, không gửi tới điện thoại |
| `stack.py` | Dùng cùng lựa chọn demo/prod/proxy/SMTP/Firebase cho triển khai và kiểm tra |
| `check_public.py` | Kiểm tra HTTPS/Swagger/wrapper và tùy chọn WSS/STOMP từ ngoài VPS |
| `nginx/renew-nginx.sh` | Reload Nginx sau khi Certbot gia hạn thành công |
| `configure_smtp.py`, `compose_config.py` | Tạo file SMTP riêng bằng prompt ẩn và đọc đúng JSON Compose khi secret có dấu `$` |
| `test_email_flow.py` | Đăng ký/xác minh bằng email thật; kiểm tra danh tính, mã dùng lại và refresh sau logout; `check-session` kiểm tra lại tài khoản đã verified, giữ bằng chứng xác minh trước |
| `backup_restore.py`, `verify_restored_data.py` | Backup MySQL logical + MinIO đã dừng; restore sang project hoàn toàn mới; đối chiếu phòng/ảnh/tài khoản qua API trên stack thử |
| `package_release.py` | Xuất image linux/amd64 đã có và danh sách file triển khai cụ thể, manifest SHA-256; loại credential, source/cache và backup dữ liệu |

Profile `vps` dùng cấu hình cơ sở, chưa phải cấu hình production. Dùng `prod` khi đã đáp ứng mục 5. Không kết hợp overlay demo và prod.

Mỗi dịch vụ có restart `unless-stopped` và log JSON tối đa mặc định **10 MiB × 3 file/container**. Backend/MySQL mặc định mỗi dịch vụ **1 GiB**, MinIO **512 MiB**, Mailpit demo **128 MiB**. Heap backend **640 MiB**, còn phần bộ nhớ cho metaspace/direct buffer/thread. Đây là cấu hình khởi đầu cho stack nhỏ; cần tính thêm OS/Docker và đo tải thực tế. Build cũng dùng RAM, không nằm trong giới hạn runtime của dịch vụ.

Backend chạy non-root, root filesystem chỉ đọc, `/tmp` có tmpfs 128 MiB, không có Linux capabilities và không cho tăng quyền. MySQL/MinIO dùng named volumes theo Compose project. Đừng đổi tên project hoặc tạo lại .env nếu đang dùng dữ liệu cũ; mật khẩu trong .env phải khớp tài khoản đã lưu trong volume.

## 2. Kiểm chứng bản backend trước triển khai

Trên Windows, từ thư mục gốc repository:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Infra\Verify-Backend.ps1
```

Script tạo MySQL 8.4 trong project ngẫu nhiên, schema `homely_verify`, port loopback ngẫu nhiên và dữ liệu tmpfs. Chạy Maven verify gồm H2/MySQL, đóng gói JAR, ghi SHA-256 nguồn/JAR và kết quả mới; cuối cùng dọn riêng project vừa tạo. Không dùng database ứng dụng. Cần Docker đang chạy, JDK phù hợp và Maven Wrapper tải được dependency hoặc có cache.

Kết quả nằm tại `backend/target/backend-verification/result.json`, log tại `maven-verify.log`, danh sách SHA nguồn tại `source-sha256.txt`. Git revision đi kèm SHA nguồn vì workspace có thể chứa thay đổi chưa commit. Test pass không chứng minh đã triển khai VPS hoặc giao FCM tới thiết bị.

Bản kiểm chứng ngày 09/10 đạt **255 test**, H2 và MySQL 8.4.11. Image hiện tại `homely-backend:vps-verified-20261009-fcm` đã chạy local, giữ nguyên Gmail, Firebase và dữ liệu. Bundle `backend/target/backend-verification/pre-vps-release-20261009-fcm` chứa image này và cấu hình/tài liệu mới. Dùng lệnh load/khởi tạo trong [runbook VPS](../../Docs%20-%20contract/VPS_HTTPS_SMTP_FCM_08_10_2026.md) khi triển khai bundle; các ví dụ build bên dưới dành cho checkout đầy đủ source.

## 3. Khởi tạo môi trường một lần

Trên Ubuntu cần Docker Engine/Compose plugin và Python 3. Chạy tại `Infra/vps`:

```bash
python3 init_env.py --demo --tag report-20261008
docker compose --env-file .env -f compose.yaml -f compose.demo.yaml config --quiet
docker compose --env-file .env -f compose.yaml -f compose.demo.yaml build backend minio
docker compose --env-file .env -f compose.yaml -f compose.demo.yaml up -d --wait --wait-timeout 300
python3 check_runtime.py --demo
```

Windows thay `python3` bằng lệnh Python trên máy (`python` hoặc `py`). Dùng tag mới cho từng bản đã kiểm chứng; không dùng `latest`. File secret `.env` bị Git ignore, mode 600 khi tạo trên Linux; script không in secret và từ chối ghi đè.

Trên VPS RAM nhỏ, build trước rồi chuyển image sang VPS/registry. Ví dụ, sau build trên máy có đủ RAM:

```bash
docker image save -o homely-images-report-20261008.tar homely-backend:report-20261008 homely-minio-source:release-2025-04-22
```

Chép archive và code cấu hình cần dùng tới VPS, `docker image load -i homely-images-report-20261008.tar`, rồi chạy `up -d --no-build --wait --wait-timeout 300` với cùng các file Compose/.env. Image archive không chứa file .env/service account. Hai máy phải cùng kiến trúc image hoặc build cho kiến trúc đích.

Endpoint nội bộ: `http://127.0.0.1:8080/actuator/health`, Swagger tại `/swagger-ui/index.html`. Mailpit demo bind loopback 8025; muốn xem từ máy khác dùng SSH tunnel. Mobile dùng endpoint HTTPS công khai của proxy sau bước cấu hình proxy, không dùng `127.0.0.1` của VPS làm URL điện thoại.

### Kiểm tra dữ liệu qua recreate trên môi trường thử

Script sau tạo một phòng/ảnh bằng host demo, rồi recreate container của đúng project được xác nhận. Chạy trên môi trường thử có thể gián đoạn; phòng/ảnh được giữ lại để kiểm tra bằng chứng. Không chạy trên production hoặc môi trường đang phục vụ người dùng.

```bash
python3 test_persistence.py --confirm-project homely-vps --output persistence-results.json
python3 check_runtime.py --demo
```

Nếu đã đổi `COMPOSE_PROJECT_NAME`, truyền đúng tên project mới; script từ chối tên không khớp hoặc backend không ở chế độ demo/Mailpit. Có thể truyền `--env-file /path/to/demo.env` để chọn môi trường riêng. Script kiểm tra container ID đã đổi, image/volume giữ nguyên, đọc lại room và media attachment qua API, so sánh bytes ảnh với bản upload. Không xóa volume và không tạo lại mật khẩu.

## 4. SMTP ngoài và Firebase

Hướng dẫn tạo file SMTP riêng, kiểm tra TLS/auth và nghiệm thu thư thật tại [MAIL_REAL_CHECK_09_10_2026.md](../../Docs%20-%20contract/MAIL_REAL_CHECK_09_10_2026.md). `check_services.py --smtp-only --smtp-env .env.smtp --network` không cần cấu hình database và không gửi thư; thêm `--send-test-email <recipient>` khi đã chọn người nhận. Khi dùng file SMTP riêng, giữ `--smtp-env .env.smtp` trong các lệnh `stack.py ... config/up/check`.

Nếu dùng VPS cơ sở với SMTP ngoài, khởi tạo **không có `--demo`**, điền riêng `SMTP_HOST`, `SMTP_PORT`, `SMTP_USERNAME`, `SMTP_PASSWORD`, `MAIL_FROM` trong .env. Chạy `-f compose.yaml` và `python3 check_runtime.py` tương ứng. Mailpit chỉ giữ thư thử trong demo.

FCM mặc định tắt để không báo đã hoạt động khi chưa có Firebase. Khi đã có project và service account, dùng override chung:

```bash
export FIREBASE_PROJECT_ID=your-project-id
export FIREBASE_CREDENTIALS_FILE=/opt/homely-private/firebase-service-account.json
docker compose --env-file .env -f compose.yaml -f compose.demo.yaml -f ../compose.firebase.yaml config --quiet
docker compose --env-file .env -f compose.yaml -f compose.demo.yaml -f ../compose.firebase.yaml up -d --wait --wait-timeout 300
```

File credential phải tồn tại, backend user phải đọc được file mount; không chmod world-readable chỉ để qua lỗi quyền. Tên biến thực tế là `FIREBASE_CREDENTIALS_FILE`. Roomly cần cấu hình Firebase riêng cho `com.example.roomly`. Kiểm tra token và push trên thiết bị theo [FIREBASE_SETUP](../../Docs%20-%20contract/FIREBASE_SETUP.md).

Kiểm tra API thật bằng `check_firebase.py` cần Python venv và dependency trong `requirements-firebase.txt`; hướng dẫn cài tại file Firebase ở trên. Chế độ Compose chọn `.env`/`.env.smtp` và overlay Firebase; chế độ độc lập dùng `--credential-file` và `--project-id`. Công cụ luôn gửi `validate_only=true`, xác minh OAuth/API/quyền mà không giao thông báo; 21 test offline đã đạt. Kết quả chỉ chứa trạng thái an toàn, không lưu token/private key hoặc response body.

## 5. Điều kiện dùng production overlay

1. `MYSQL_TLS_DIRECTORY` là đường dẫn tuyệt đối có `ca.pem`, `server-cert.pem`, `server-key.pem`. Certificate server cần SAN **DNS:mysql** vì JDBC dùng hostname `mysql`; CA/key được giữ ngoài repository. MySQL trong container phải đọc được key/cert; xác định UID/GID theo image trước khi đặt quyền trên host.
2. `MYSQL_TRUSTSTORE_FILE` là file PKCS12 giữ các public root CA của JDK và bổ sung CA MySQL, mật khẩu `changeit`, backend user đọc được. Truststore không chứa private key. Không đặt thêm cùng các JVM truststore flags trong `JAVA_TOOL_OPTIONS`. JSSE dùng truststore được chỉ định thay cho cơ chế tìm `cacerts`; cần giữ cả các CA phục vụ kết nối ngoài như Firebase/SMTP. [Java 21 JSSE](https://docs.oracle.com/en/java/javase/21/security/java-secure-socket-extension-jsse-reference-guide.html).
3. SMTP thật có auth/STARTTLS; MAIL_FROM hợp lệ. Profile prod giữ `VERIFY_IDENTITY` và STARTTLS required.
4. Demo/seed/mock tắt; tài khoản/admin phải được tạo theo quy trình production phù hợp. Không bật seed để lách production guard.

Ví dụ tạo truststore bằng JDK đã chuẩn bị trên máy triển khai, giữ các public CA:

```bash
keytool -importkeystore -noprompt -srckeystore "$JAVA_HOME/lib/security/cacerts" -srcstorepass changeit -destkeystore /opt/homely-private/mysql-truststore.p12 -deststoretype PKCS12 -deststorepass changeit
keytool -importcert -noprompt -alias homely-mysql-ca -file /opt/homely-private/mysql-tls/ca.pem -keystore /opt/homely-private/mysql-truststore.p12 -storetype PKCS12 -storepass changeit
```

Chỉ chạy khi thư mục/file CA đã được chuẩn bị và đường dẫn đích là truststore mới; cập nhật CA công khai theo JDK dùng cho image. Không ghi đè truststore hoặc certificate đang được dùng mà chưa có kế hoạch cập nhật.

Kiểm tra cú pháp trước khi chạy:

```bash
docker compose --env-file .env -f compose.yaml -f compose.prod.yaml config --quiet
docker compose --env-file .env -f compose.yaml -f compose.prod.yaml up -d --no-build --wait --wait-timeout 300
python3 check_runtime.py --prod
```

`config --quiet` không kiểm chứng CA, quyền đọc file, SMTP hoặc chứng chỉ hostname. Phải chạy runtime checks và luồng nghiệp vụ trên môi trường production đã cấu hình trước khi tuyên bố production sẵn sàng. `prod` overlay không tự sinh chứng chỉ hoặc triển khai proxy HTTPS.

## 6. Vận hành và cập nhật

Dùng cùng .env, project và các file Compose đã chọn cho mọi lệnh. Ví dụ môi trường báo cáo:

```bash
docker compose --env-file .env -f compose.yaml -f compose.demo.yaml ps -a
docker compose --env-file .env -f compose.yaml -f compose.demo.yaml logs --since=15m --tail=100 backend mysql minio
docker stats --no-stream
```

Healthcheck xác định healthy/unhealthy; Docker restart policy chỉ xử lý tiến trình thoát và daemon khởi động lại theo chính sách. Container còn chạy nhưng unhealthy không tự restart. JVM ExitOnOutOfMemoryError giúp tiến trình thoát khi Java heap OOM; cần tìm nguyên nhân, không coi restart lặp là đã sửa lỗi.

Sau khi có bản mới, backup theo bước vận hành của dự án, đổi `BACKEND_TAG` sang tag đã kiểm chứng, build/load image tương ứng rồi:

```bash
docker compose --env-file .env -f compose.yaml -f compose.demo.yaml up -d --no-deps --no-build --wait --wait-timeout 180 backend
python3 check_runtime.py --demo
```

Chỉ dùng `--no-deps` khi MySQL/MinIO đã healthy. Giữ image cũ và secret cũ để quay lại code khi cần; rollback JAR không tự rollback migration. Named volumes tồn tại qua restart/recreate container; lệnh `down -v` xóa volume. Không dùng xóa volume làm cách sửa deploy.

Backup/restore MySQL + MinIO đã nghiệm thu thực tế local ngày 09/10: phòng, liên kết/bytes ảnh và trạng thái tài khoản verified giữ đúng; chặn restore vào stack đích đã có đạt. Lệnh và bằng chứng tại [BACKUP_RESTORE_09_10_2026.md](../../Docs%20-%20contract/BACKUP_RESTORE_09_10_2026.md). Công cụ không xóa volume và giữ nguyên stack nguồn; stack thử dùng Mailpit, tắt FCM và seed.

Bộ image/cấu hình chọn riêng từng file, không gộp secret hoặc dữ liệu, được chuẩn bị bằng `package_release.py`; xem [VPS_HTTPS_SMTP_FCM_08_10_2026.md](../../Docs%20-%20contract/VPS_HTTPS_SMTP_FCM_08_10_2026.md). Bundle chứa image chạy sẵn và không có đủ application source để build lại; VPS dùng `docker image load` và `--no-build`. Bộ công cụ Firebase/cấu hình/packaging/backup đạt tổng cộng **50 test offline**.

Nghiệm thu VPS/Firebase thật trên điện thoại vẫn cần thực hiện. Cấu hình cho mục 3–4 tại [hướng dẫn HTTPS/WSS](../../Docs%20-%20contract/VPS_HTTPS_SMTP_FCM_08_10_2026.md). Gmail thật đã nghiệm thu local theo [kết quả email](../../Docs%20-%20contract/MAIL_REAL_CHECK_09_10_2026.md); phải thử lại SMTP trên VPS. Kết quả local không chứng minh VPS đã hoạt động hoặc đã giao FCM thật.

**Cập nhật Firebase 09/10:** backend local bật FCM cho project `roomly-6d99d`, service account/Android config khớp, mount read-only/user đọc được và stack healthy. OAuth + HTTP V1 validate-only đạt **200 lúc 17:59:13 VN**, API/quyền đã kiểm chứng. Image mới giữ nguyên volume/Gmail/dữ liệu; đăng ký thiết bị sai platform hoặc installationId quá 36 ký tự bị từ chối 400. Chưa nghiệm thu push tới điện thoại. Lệnh giữ đúng Firebase + Gmail và bằng chứng tại [FIREBASE_SETUP.md](../../Docs%20-%20contract/FIREBASE_SETUP.md). Credential riêng phải chuyển và đặt đường dẫn Linux khi lên VPS.
