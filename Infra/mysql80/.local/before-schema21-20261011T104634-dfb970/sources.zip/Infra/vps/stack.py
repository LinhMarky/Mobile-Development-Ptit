"""Run the same explicit VPS Compose selection for deploy, checks and operations."""

import argparse
from pathlib import Path
import subprocess
import sys


def main() -> None:
    directory = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env-file", type=Path, default=directory / ".env")
    parser.add_argument("--smtp-env", type=Path, help="Optional private SMTP env file")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--demo", action="store_true", help="Report environment: seed/demo accounts and Mailpit")
    mode.add_argument("--prod", action="store_true", help="Strict production; requires database TLS and real SMTP")
    parser.add_argument("--proxy", action="store_true", help="Host Nginx and generated proxy.env")
    parser.add_argument("--proxy-env", type=Path, default=directory / "generated" / "proxy" / "proxy.env")
    parser.add_argument("--smtp", action="store_true", help="Real SMTP, including when demo accounts remain enabled")
    parser.add_argument("--firebase", action="store_true", help="Real Firebase credential override")
    parser.add_argument("action", choices=("config", "build", "up", "check", "ps", "logs", "stop"))
    args = parser.parse_args()
    if args.prod and args.smtp:
        parser.error("Production already requires STARTTLS; do not override it with the demo SMTP mode")
    if not args.env_file.is_file():
        parser.error("Env file missing; initialize it once and configure credentials locally")
    compose = ["docker", "compose", "--env-file", str(args.env_file.resolve())]
    if args.smtp_env:
        if not args.smtp_env.is_file():
            parser.error("Private SMTP env file does not exist")
        compose += ["--env-file", str(args.smtp_env.resolve())]
    if args.proxy:
        if not args.proxy_env.is_file():
            parser.error("proxy.env missing; run render_proxy.py for the actual VPS IP/network")
        compose += ["--env-file", str(args.proxy_env.resolve())]
    compose += ["-f", str(directory / "compose.yaml")]
    selected_mode = "--demo" if args.demo else "--prod" if args.prod else None
    if selected_mode:
        compose += ["-f", str(directory / ("compose.demo.yaml" if args.demo else "compose.prod.yaml"))]
    for selected, file in ((args.proxy, directory / "compose.proxy.yaml"),
                           (args.smtp, directory / "compose.smtp.yaml"),
                           (args.firebase, directory.parent / "compose.firebase.yaml")):
        if selected:
            compose += ["-f", str(file)]
    common = ["--env-file", str(args.env_file.resolve())]
    if args.smtp_env:
        common += ["--smtp-env", str(args.smtp_env.resolve())]
    if selected_mode:
        common.append(selected_mode)
    if args.action == "check":
        checker = [sys.executable, str(directory / "check_runtime.py"), *common]
        if args.proxy:
            checker += ["--proxy-env", str(args.proxy_env.resolve())]
        if args.smtp:
            checker.append("--smtp")
        if args.firebase:
            checker.append("--firebase")
        subprocess.run(checker, check=True)
        return
    if args.action == "up" and (args.smtp or args.firebase):
        preflight = [sys.executable, str(directory / "check_services.py"), "--env-file", str(args.env_file.resolve())]
        if args.smtp_env:
            preflight += ["--smtp-env", str(args.smtp_env.resolve())]
        if args.demo:
            preflight.append("--demo")
        elif args.prod:
            preflight.append("--prod")
        if args.smtp:
            preflight.append("--smtp")
        if args.firebase:
            preflight.append("--firebase")
        subprocess.run(preflight, check=True)
    commands = {"config": ["config", "--quiet"], "build": ["build", "backend", "minio"],
                "up": ["up", "-d", "--no-build", "--wait", "--wait-timeout", "300"],
                "ps": ["ps", "-a"], "logs": ["logs", "--since=15m", "--tail=100", "backend", "mysql", "minio"],
                "stop": ["stop"]}
    subprocess.run(compose + commands[args.action], check=True)


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError:
        sys.exit(1)
