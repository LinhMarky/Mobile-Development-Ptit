#!/bin/sh
# Certbot deploy hook: reload only after a successful syntax check.
set -eu
/usr/sbin/nginx -t
/bin/systemctl reload nginx
