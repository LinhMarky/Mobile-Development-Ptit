"""Back up this single-server stack; restore trusted backups into a NEW project.

The source application's private env files must be retained separately. MySQL
dumps and MinIO archives contain private application data. No credentials are
copied into the manifest or saved restore settings. This is an offline recovery
tool, not a parser or sandbox for SQL supplied by an untrusted party.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import hmac
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import subprocess
import sys
import tarfile
import time

from compose_config import read_compose_json


DIRECTORY = Path(__file__).resolve().parent
PROJECT = re.compile(r"[a-z0-9][a-z0-9_-]{0,62}\Z")
DATABASE = re.compile(r"[A-Za-z_][A-Za-z0-9_]{0,63}\Z")
SHA256 = re.compile(r"[0-9a-f]{64}\Z")
IMAGE_ID = re.compile(r"sha256:[0-9a-f]{64}\Z")
SAFE_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:/@-]*\Z")
CORE = ("mysql", "minio", "backend")
SELECTION = ("demo", "prod", "proxy", "smtp", "firebase")
CRITICAL = {
    "mysql": ("MYSQL_DATABASE", "MYSQL_USER", "MYSQL_PASSWORD", "MYSQL_ROOT_PASSWORD"),
    "minio": ("MINIO_ROOT_USER", "MINIO_ROOT_PASSWORD"),
    "backend": ("MYSQL_DB", "MYSQL_USER", "MYSQL_PASSWORD", "MINIO_ACCESS_KEY", "MINIO_SECRET_KEY", "JWT_SECRET"),
}
# Password expansion happens ONLY inside the selected container. The argument
# arrays contain static shell programs, never values read from private env files.
DUMP = ('MYSQL_PWD="$MYSQL_ROOT_PASSWORD" exec mysqldump --user=root '
        '--protocol=SOCKET --socket=/var/run/mysqld/mysqld.sock '
        '--single-transaction --routines --triggers --events --hex-blob '
        '--no-tablespaces --set-gtid-purged=OFF --column-statistics=0 '
        '--default-character-set=utf8mb4 "$MYSQL_DATABASE"')
IMPORT = ('MYSQL_PWD="$MYSQL_ROOT_PASSWORD" exec mysql --user=root '
          '--protocol=SOCKET --socket=/var/run/mysqld/mysqld.sock '
          '--default-character-set=utf8mb4 --database="$MYSQL_DATABASE"')
EMPTY = 'test -z "$(find /data -mindepth 1 -maxdepth 1 -print -quit)"'


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def docker(*arguments: str, stdin=None, stdout=None) -> str:
    result = subprocess.run(["docker", *arguments], stdin=stdin,
                            stdout=stdout if stdout is not None else subprocess.PIPE,
                            stderr=subprocess.PIPE, check=False)
    require(result.returncode == 0, "Docker operation failed; inspect Docker locally. Command output is withheld to protect secrets.")
    return result.stdout.decode("utf-8") if stdout is None else ""


def selection(args) -> dict:
    return {key: bool(getattr(args, key)) for key in SELECTION}


def compose_arguments(args) -> list[str]:
    require(not (args.prod and args.smtp), "Production already requires STARTTLS; omit --smtp.")
    command = ["compose", "--env-file", str(args.env_file.resolve())]
    for path in (args.env_file, args.smtp_env, args.proxy_env if args.proxy else None):
        if path is not None:
            require(path.is_file(), "A selected private env file is missing.")
    if args.smtp_env:
        command += ["--env-file", str(args.smtp_env.resolve())]
    if args.proxy:
        command += ["--env-file", str(args.proxy_env.resolve())]
    command += ["-f", str(DIRECTORY / "compose.yaml")]
    for selected, path in (
        (args.demo, DIRECTORY / "compose.demo.yaml"),
        (args.prod, DIRECTORY / "compose.prod.yaml"),
        (args.proxy, DIRECTORY / "compose.proxy.yaml"),
        (args.smtp, DIRECTORY / "compose.smtp.yaml"),
        (args.firebase, DIRECTORY.parent / "compose.firebase.yaml"),
    ):
        if selected:
            command += ["-f", str(path)]
    return command


def environment(container: dict) -> dict:
    return dict(item.split("=", 1) for item in container["Config"]["Env"] if "=" in item)


def critical_configuration(configuration: dict) -> dict:
    services = configuration["services"]
    result = {}
    for service, keys in CRITICAL.items():
        values = services[service]["environment"]
        require(all(isinstance(values.get(key), str) and values[key] for key in keys),
                "Required recovery credentials are absent from the selected configuration.")
        result[service] = {key: values[key] for key in keys}
    require(DATABASE.fullmatch(result["mysql"]["MYSQL_DATABASE"]) is not None, "Unsupported database name.")
    require(result["backend"]["MYSQL_DB"] == result["mysql"]["MYSQL_DATABASE"] and
            result["backend"]["MYSQL_USER"] == result["mysql"]["MYSQL_USER"] and
            result["backend"]["MYSQL_PASSWORD"] == result["mysql"]["MYSQL_PASSWORD"],
            "Backend and MySQL recovery settings differ.")
    require(result["backend"]["MINIO_ACCESS_KEY"] == result["minio"]["MINIO_ROOT_USER"] and
            result["backend"]["MINIO_SECRET_KEY"] == result["minio"]["MINIO_ROOT_PASSWORD"],
            "Backend and MinIO recovery credentials differ.")
    require(len(result["backend"]["JWT_SECRET"]) >= 32, "A strong original JWT secret is required for recovery.")
    return result


def fingerprint(configuration: dict, salt: str) -> str:
    encoded = json.dumps(critical_configuration(configuration), sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(bytes.fromhex(salt) + encoded).hexdigest()


def inspect_project(compose: list[str]) -> dict:
    identifiers = docker(*compose, "ps", "-a", "-q").split()
    require(bool(identifiers), "The selected source project has no containers.")
    result = {}
    for item in json.loads(docker("inspect", *identifiers)):
        service = item["Config"]["Labels"]["com.docker.compose.service"]
        require(service not in result, "Replicated services are unsupported by this single-server recovery tool.")
        result[service] = item
    return result


def volume_for(container: dict, destination: str) -> str:
    mounts = [item for item in container["Mounts"] if item["Destination"] == destination]
    require(len(mounts) == 1 and mounts[0]["Type"] == "volume", "Recovery requires the expected named data volume.")
    return mounts[0]["Name"]


def verify_source(configuration: dict, services: dict, project: str) -> dict:
    require(configuration["name"] == project and PROJECT.fullmatch(project) is not None,
            "Confirmation does not match the selected source Compose project.")
    critical_configuration(configuration)
    for name in CORE:
        require(name in services, "A required source service is missing.")
        container = services[name]
        labels = container["Config"]["Labels"]
        require(labels["com.docker.compose.project"] == project, "Source container project mismatch.")
        require(container["State"]["Status"] in ("running", "exited"), "Source services must be running or cleanly stopped.")
        actual = environment(container)
        expected = configuration["services"][name]["environment"]
        for key in CRITICAL[name]:
            require(actual.get(key) == expected.get(key), "The selected env files differ from the running source recovery credentials.")
        require(container["Config"]["Image"] == configuration["services"][name]["image"],
                "Source image does not match the selected Compose image.")
    for key in ("SPRING_PROFILES_ACTIVE", "DEMO_ENABLED", "DEMO_SEED", "FCM_ENABLED", "SMTP_HOST", "SMTP_PORT"):
        require(environment(services["backend"]).get(key) == configuration["services"]["backend"]["environment"].get(key),
                "The selected service mode differs from the source backend.")
    require(services["mysql"]["State"]["Status"] == "running" and
            services["mysql"]["State"].get("Health", {}).get("Status") == "healthy",
            "Source MySQL must already be running and healthy.")
    volumes = {}
    for name, destination in (("mysql", "/var/lib/mysql"), ("minio", "/data")):
        require(not any(services[name]["HostConfig"].get("PortBindings", {}).values()),
                "This recovery tool requires private MySQL and MinIO services without published ports.")
        volume = volume_for(services[name], destination)
        users = docker("ps", "-a", "--filter", "volume=" + volume, "--format", "{{.ID}}").split()
        require(len(users) == 1 and services[name]["Id"].startswith(users[0]),
                "A data volume is attached to another container; recovery is refused.")
        volumes[name] = {"name": volume, "destination": destination}
    require(volumes["mysql"]["name"] != volumes["minio"]["name"], "Source data volumes must be distinct.")
    return volumes


def private_directory(path: Path) -> None:
    # A new/exclusive directory leaves partial artifacts available for diagnosis.
    path.mkdir(mode=0o700, parents=False, exist_ok=False)
    if os.name != "nt":
        path.chmod(0o700)


def private_file(path: Path):
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    return os.fdopen(descriptor, "wb")


def write_json(path: Path, data: dict) -> None:
    with private_file(path) as stream:
        stream.write((json.dumps(data, indent=2) + "\n").encode())


def artifact(path: Path) -> dict:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return {"sha256": digest.hexdigest(), "size": path.stat().st_size}


def wait_healthy(identifier: str, seconds: int = 300) -> None:
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        state = json.loads(docker("inspect", identifier))[0]["State"]
        if state.get("Health", {}).get("Status") == "healthy":
            return
        require(state["Status"] in ("running", "restarting"), "A recovery service stopped before becoming healthy.")
        time.sleep(2)
    raise RuntimeError("A recovery service did not become healthy within the allowed time.")


def helper(image: str, volume: str, readonly: bool = False) -> list[str]:
    mount = "type=volume,source=" + volume + ",target=/data" + (",readonly" if readonly else "")
    return ["run", "--rm", "--pull", "never", "--network", "none", "--read-only", "--user", "0",
            "--cap-drop", "ALL", "--cap-add", "DAC_OVERRIDE", "--cap-add", "CHOWN", "--cap-add", "FOWNER",
            "--security-opt", "no-new-privileges", "--mount", mount, "--entrypoint", "sh", image]


def resume_source(services: dict, running: dict) -> None:
    failures = False
    for name in ("minio", "backend"):
        if running[name]:
            try:
                docker("start", services[name]["Id"])
                wait_healthy(services[name]["Id"])
            except (RuntimeError, OSError):
                # Still attempt the other original service if one restart fails.
                failures = True
    require(not failures, "Source restart failed. Restart the original backend/MinIO locally; backup files were retained.")


def backup(args, compose: list[str], configuration: dict) -> None:
    require(configuration["name"] == args.confirm_project, "Confirmation does not match the selected source Compose project.")
    services = inspect_project(compose)
    volumes = verify_source(configuration, services, args.confirm_project)
    output = args.output.resolve()
    private_directory(output)
    running = {name: services[name]["State"]["Status"] == "running" for name in ("backend", "minio")}
    try:
        # Stop application writers first; keep MySQL running for its logical dump.
        if running["backend"]:
            docker("stop", "--time", "60", services["backend"]["Id"])
        if running["minio"]:
            docker("stop", "--time", "30", services["minio"]["Id"])
        with private_file(output / "mysql.sql") as stream:
            docker("exec", services["mysql"]["Id"], "sh", "-c", DUMP, stdout=stream)
        with private_file(output / "minio.tar") as stream:
            docker(*helper(services["minio"]["Image"], volumes["minio"]["name"], True),
                   "-c", "exec tar -cpf - -C /data .", stdout=stream)
        database = configuration["services"]["mysql"]["environment"]["MYSQL_DATABASE"]
        validate_sql(output / "mysql.sql", database)
        validate_archive(output / "minio.tar")
        salt = secrets.token_hex(32)
        manifest = {
            "format_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
            "source_project": args.confirm_project, "database": database, "selection": selection(args),
            "fingerprint_salt": salt, "configuration_sha256": fingerprint(configuration, salt),
            "services": {name: {"image_ref": item["Config"]["Image"], "image_id": item["Image"], "container_id": item["Id"]}
                         for name, item in services.items() if name in (*CORE, "mailpit")},
            "volumes": volumes,
            "artifacts": {name: artifact(output / name) for name in ("mysql.sql", "minio.tar")},
        }
        validate_manifest(manifest)
        write_json(output / "manifest.json", manifest)
    finally:
        resume_source(services, running)
    print("PASS: logical MySQL and cold MinIO backup complete; original running services resumed.")
    print("Backup directory: " + str(output))


def validate_manifest(data: dict) -> None:
    expected = {"format_version", "created_utc", "source_project", "database", "selection", "fingerprint_salt",
                "configuration_sha256", "services", "volumes", "artifacts"}
    require(isinstance(data, dict) and set(data) == expected and data["format_version"] == 1, "Unsupported backup manifest schema.")
    require(isinstance(data["source_project"], str) and PROJECT.fullmatch(data["source_project"]) is not None, "Invalid source project in backup.")
    require(isinstance(data["database"], str) and DATABASE.fullmatch(data["database"]) is not None, "Invalid backup database name.")
    require(isinstance(data["created_utc"], str), "Invalid backup timestamp.")
    created = datetime.fromisoformat(data["created_utc"])
    require(created.utcoffset() is not None, "Backup timestamp must include its timezone.")
    for key in ("fingerprint_salt", "configuration_sha256"):
        require(isinstance(data[key], str) and SHA256.fullmatch(data[key]) is not None, "Invalid backup configuration fingerprint.")
    selected = data["selection"]
    require(isinstance(selected, dict) and set(selected) == set(SELECTION) and
            all(type(value) is bool for value in selected.values()) and not (selected["demo"] and selected["prod"]) and
            not (selected["prod"] and selected["smtp"]), "Invalid backup service selection.")
    services = data["services"]
    require(isinstance(services, dict) and set(CORE) <= set(services) <= {*CORE, "mailpit"}, "Invalid backup services.")
    for item in services.values():
        require(isinstance(item, dict) and set(item) == {"image_ref", "image_id", "container_id"}, "Invalid backup image metadata.")
        require(isinstance(item["image_id"], str) and IMAGE_ID.fullmatch(item["image_id"]) is not None and
                isinstance(item["image_ref"], str) and SAFE_NAME.fullmatch(item["image_ref"]) is not None and
                isinstance(item["container_id"], str) and SHA256.fullmatch(item["container_id"]) is not None,
                "Invalid backup image or container identifier.")
    require(isinstance(data["volumes"], dict) and set(data["volumes"]) == {"mysql", "minio"}, "Invalid backup volume metadata.")
    for name, destination in (("mysql", "/var/lib/mysql"), ("minio", "/data")):
        item = data["volumes"][name]
        require(isinstance(item, dict) and set(item) == {"name", "destination"} and item["destination"] == destination and
                isinstance(item["name"], str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", item["name"]) is not None,
                "Invalid backup volume name or destination.")
    require(data["volumes"]["mysql"]["name"] != data["volumes"]["minio"]["name"], "Backup data volumes must be distinct.")
    require(isinstance(data["artifacts"], dict) and set(data["artifacts"]) == {"mysql.sql", "minio.tar"}, "Invalid backup artifacts.")
    for item in data["artifacts"].values():
        require(isinstance(item, dict) and set(item) == {"sha256", "size"} and
                isinstance(item["sha256"], str) and SHA256.fullmatch(item["sha256"]) is not None and
                type(item["size"]) is int and item["size"] > 0, "Invalid artifact checksum or size.")


def validate_sql(path: Path, database: str) -> None:
    require(DATABASE.fullmatch(database) is not None, "Unsupported recovery schema name.")
    marker = False
    complete = False
    with path.open("rb") as stream:
        require(stream.readline().startswith(b"-- MySQL dump "), "Artifact is not a supported logical MySQL dump.")
        for line in stream:
            if line.startswith(b"-- Host:"):
                match = re.search(rb"\sDatabase:\s+([A-Za-z0-9_]+)\s*$", line)
                require(match is not None and match.group(1).decode() == database, "Dump schema differs from the selected database.")
                marker = True
            require(re.match(rb"\s*(?:USE\s|(?:CREATE|DROP|ALTER)\s+DATABASE\b)", line, re.IGNORECASE) is None,
                    "Database-switching dumps are unsupported; regenerate with this recovery tool.")
            if line.startswith(b"-- Dump completed on "):
                complete = True
    require(marker and complete, "Logical MySQL dump is incomplete or has no matching schema marker.")


def validate_archive(path: Path) -> None:
    size = path.stat().st_size
    require(size >= 1024 and size % 512 == 0, "MinIO archive is truncated or not a plain tar archive.")
    names = set()
    with tarfile.open(path, mode="r:") as archive:
        for member in archive:
            name = member.name
            parts = PurePosixPath(name).parts
            require(name and len(name) <= 4096 and not name.startswith("/") and "\\" not in name and ":" not in name and
                    ".." not in parts and not member.issparse() and (member.isfile() or member.isdir()),
                    "MinIO archive contains an unsafe path, link, or special file.")
            normalized = str(PurePosixPath(name))
            require(normalized not in names and not (normalized == "." and not member.isdir()), "MinIO archive has duplicate or invalid root entries.")
            names.add(normalized)
            require(member.offset_data + member.size <= size, "MinIO archive contains a truncated file.")
    require(bool(names), "MinIO archive contains no entries.")


def reject_duplicate_keys(pairs: list) -> dict:
    result = {}
    for key, value in pairs:
        require(key not in result, "Backup manifest has duplicate JSON fields.")
        result[key] = value
    return result


def load_backup(directory: Path) -> dict:
    require(directory.is_dir() and not directory.is_symlink(), "Backup must be a real local directory.")
    for name in ("manifest.json", "mysql.sql", "minio.tar"):
        require((directory / name).is_file() and not (directory / name).is_symlink(), "A required backup file is missing or is a symlink.")
    require((directory / "manifest.json").stat().st_size <= 1024 * 1024, "Backup manifest is unexpectedly large.")
    data = json.loads((directory / "manifest.json").read_text(encoding="utf-8"), object_pairs_hook=reject_duplicate_keys)
    validate_manifest(data)
    for name, expected in data["artifacts"].items():
        require(artifact(directory / name) == expected, "Backup artifact checksum or size mismatch; no target was modified.")
    validate_sql(directory / "mysql.sql", data["database"])
    validate_archive(directory / "minio.tar")
    return data


def require_new_target(project: str, manifest: dict) -> None:
    require(PROJECT.fullmatch(project) is not None and project != manifest["source_project"],
            "Restore requires an explicit valid target project DIFFERENT from the source.")
    require(not docker("ps", "-a", "--filter", "label=com.docker.compose.project=" + project, "--format", "{{.ID}}").strip(),
            "Target project already has containers; only a completely NEW project is accepted.")
    require(not docker("volume", "ls", "--filter", "label=com.docker.compose.project=" + project, "--format", "{{.Name}}").strip(),
            "Target project already has volumes; existing datasets are never overwritten.")
    names = set(docker("volume", "ls", "--format", "{{.Name}}").split())
    require(not {project + "_mysql_data", project + "_minio_data"} & names,
            "A target data volume already exists; restore cannot overwrite it.")
    require(not docker("network", "ls", "--filter", "label=com.docker.compose.project=" + project, "--format", "{{.Name}}").strip() and
            project + "_default" not in docker("network", "ls", "--format", "{{.Name}}").split(),
            "Target project already has a network; choose a completely NEW project.")
    require(not {project + "_mysql_data", project + "_minio_data"} & {item["name"] for item in manifest["volumes"].values()},
            "Target volume names overlap the source backup; restore is refused.")


def target_settings(args, manifest: dict, directory: Path) -> tuple[Path, Path]:
    override = {"services": {name: {"image": item["image_id"]} for name, item in manifest["services"].items()},
                "volumes": {name + "_data": {"name": args.confirm_target + "_" + name + "_data"} for name in ("mysql", "minio")},
                "networks": {"default": {"name": args.confirm_target + "_default"}}}
    if args.restore_test:
        require(args.demo and not args.prod and "mailpit" in manifest["services"], "Restore tests require an original demo/Mailpit selection.")
        override["services"]["backend"]["environment"] = {
            "FCM_ENABLED": "false", "DEMO_SEED": "false", "SMTP_HOST": "mailpit", "SMTP_PORT": "1025",
            "SMTP_USERNAME": "", "SMTP_PASSWORD": "", "SMTP_AUTH": "false", "SMTP_STARTTLS": "false",
            "SPRING_MAIL_PROPERTIES_MAIL_SMTP_AUTH": "false", "SPRING_MAIL_PROPERTIES_MAIL_SMTP_STARTTLS_ENABLE": "false",
            "SPRING_MAIL_PROPERTIES_MAIL_SMTP_STARTTLS_REQUIRED": "false", "SPRING_MAIL_PROPERTIES_MAIL_SMTP_SSL_ENABLE": "false",
            "MAIL_FROM": "noreply@homely.test",
        }
    private_directory(directory)
    settings, ports = directory / "runtime.compose.json", directory / "runtime.env"
    write_json(settings, override)
    with private_file(ports) as stream:
        stream.write(f"API_PORT={args.api_port}\nMAILPIT_PORT={args.mailpit_port}\n".encode())
    return settings, ports


def verify_target_configuration(configuration: dict, args, manifest: dict) -> None:
    require(configuration["name"] == args.confirm_target, "Resolved target project differs from confirmation.")
    require(hmac.compare_digest(fingerprint(configuration, manifest["fingerprint_salt"]), manifest["configuration_sha256"]),
            "Original private database/MinIO/JWT settings are required; recovery credentials differ.")
    for name in CORE:
        require(configuration["services"][name]["image"] == manifest["services"][name]["image_id"], "Target image is not pinned to the backup.")
    require(set(configuration.get("volumes", {})) == {"mysql_data", "minio_data"}, "Unexpected target volumes are unsupported.")
    for name in ("mysql", "minio"):
        volume = configuration["volumes"][name + "_data"]
        require(volume["name"] == args.confirm_target + "_" + name + "_data" and not volume.get("external"), "Target must use new private named volumes.")
    require(set(configuration.get("networks", {})) == {"default"} and
            configuration["networks"]["default"]["name"] == args.confirm_target + "_default" and
            not configuration["networks"]["default"].get("external"), "Target must use a new private project network.")
    for name, service in configuration["services"].items():
        for port in service.get("ports", []):
            require(port.get("host_ip") in ("127.0.0.1", "::1") and name not in ("mysql", "minio"), "Target data services must be private; API ports must be loopback-only.")
    api_bindings = configuration["services"]["backend"].get("ports", [])
    require(len(api_bindings) == 1 and api_bindings[0].get("target") == 8080 and
            str(api_bindings[0].get("published")) == str(args.api_port),
            "Resolved target API port differs from --api-port; check inherited shell variables.")
    if "mailpit" in configuration["services"]:
        bindings = configuration["services"]["mailpit"].get("ports", [])
        require(len(bindings) == 1 and bindings[0].get("target") == 8025 and
                str(bindings[0].get("published")) == str(args.mailpit_port),
                "Resolved target Mailpit port differs from --mailpit-port; check inherited shell variables.")
    if args.restore_test:
        env = configuration["services"]["backend"]["environment"]
        require(env.get("FCM_ENABLED") == "false" and env.get("SMTP_HOST") == "mailpit" and
                env.get("SMTP_PASSWORD") == "" and env.get("DEMO_SEED") == "false", "Restore-test notification isolation is missing.")


def restore(args, compose: list[str], source_configuration: dict) -> None:
    require(1 <= args.api_port <= 65535 and 1 <= args.mailpit_port <= 65535 and args.api_port != args.mailpit_port, "Choose two distinct valid loopback ports.")
    source = args.input.absolute()
    manifest = load_backup(source)
    require(selection(args) == manifest["selection"], "Select the same Compose mode/overrides used for this backup.")
    require(source_configuration["name"] == manifest["source_project"], "The selected original env belongs to a different source project.")
    require(hmac.compare_digest(fingerprint(source_configuration, manifest["fingerprint_salt"]), manifest["configuration_sha256"]),
            "Restore requires the retained original private env files; recovery credentials differ.")
    require(not args.restore_test or (args.demo and not args.prod and "mailpit" in manifest["services"]), "Restore tests require an original demo/Mailpit selection.")
    require_new_target(args.confirm_target, manifest)
    for item in manifest["services"].values():
        installed = json.loads(docker("image", "inspect", item["image_id"]))
        require(len(installed) == 1 and installed[0]["Id"] == item["image_id"], "A pinned backup image is unavailable locally; load it explicitly before recovery.")
    settings_directory = (args.settings_dir or source.parent / (args.confirm_target + "-restore")).resolve()
    settings, ports = target_settings(args, manifest, settings_directory)
    target = [*compose, "--project-name", args.confirm_target, "--env-file", str(ports), "-f", str(settings)]
    configuration = read_compose_json(docker(*target, "config", "--format", "json"))
    verify_target_configuration(configuration, args, manifest)
    # Repeat immediately before creating target resources. Docker cannot make
    # project-name reservation atomic; do not run concurrent recovery/deployment.
    require_new_target(args.confirm_target, manifest)
    try:
        docker(*target, "create", "--no-build", "--pull", "never", "mysql", "minio")
        services = inspect_project(target)
        for name, destination in (("mysql", "/var/lib/mysql"), ("minio", "/data")):
            require(name in services and services[name]["Config"]["Labels"]["com.docker.compose.project"] == args.confirm_target,
                    "New target container labels differ from confirmation.")
            require(volume_for(services[name], destination) == args.confirm_target + "_" + name + "_data" and
                    services[name]["State"]["Status"] == "created", "Target containers must be new, stopped and attached to new data volumes.")
            docker(*helper(manifest["services"]["minio"]["image_id"], args.confirm_target + "_" + name + "_data"), "-c", EMPTY)
        with (source / "minio.tar").open("rb") as stream:
            # -i must precede the image; tar extraction is into the NEW volume.
            command = helper(manifest["services"]["minio"]["image_id"], args.confirm_target + "_minio_data")
            command.insert(1, "-i")
            docker(*command, "-c", EMPTY + " && exec tar -xpf - -C /data", stdin=stream)
        docker(*target, "up", "-d", "--no-build", "--pull", "never", "--no-deps", "--wait", "--wait-timeout", "300", "mysql")
        with (source / "mysql.sql").open("rb") as stream:
            docker("exec", "-i", services["mysql"]["Id"], "sh", "-c", IMPORT, stdin=stream)
        docker(*target, "up", "-d", "--no-build", "--pull", "never", "--no-deps", "--wait", "--wait-timeout", "300", "mysql", "minio")
        for name in ("mysql", "minio"):
            wait_healthy(services[name]["Id"])
        # The backend has not existed until both datasets were restored.
        docker(*target, "up", "-d", "--no-build", "--pull", "never", "--wait", "--wait-timeout", "300")
        healthy = inspect_project(target)
        for name in CORE:
            wait_healthy(healthy[name]["Id"])
    except (Exception, KeyboardInterrupt):
        # Leave new volumes and partial artifacts for diagnosis, but prevent an
        # unhealthy partially recovered backend from accepting requests.
        try:
            docker(*target, "stop", "backend")
        except (RuntimeError, OSError):
            pass
        raise
    print("PASS: restored into new project " + args.confirm_target + "; MySQL, MinIO and backend are healthy.")
    print("API origin: http://127.0.0.1:" + str(args.api_port))
    print("Non-secret restore settings: " + str(settings_directory))
    print("Source volumes and backup artifacts were retained. Verify existing records and media through the API.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env-file", type=Path, default=DIRECTORY / ".env")
    parser.add_argument("--smtp-env", type=Path)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--demo", action="store_true")
    mode.add_argument("--prod", action="store_true")
    parser.add_argument("--proxy", action="store_true")
    parser.add_argument("--proxy-env", type=Path, default=DIRECTORY / "generated" / "proxy" / "proxy.env")
    parser.add_argument("--smtp", action="store_true")
    parser.add_argument("--firebase", action="store_true")
    actions = parser.add_subparsers(dest="action", required=True)
    save = actions.add_parser("backup", help="Briefly quiesce backend/MinIO and save a logical/cold backup")
    save.add_argument("--confirm-project", required=True)
    save.add_argument("--output", type=Path, required=True, help="NEW backup directory; parent directory must exist")
    recover = actions.add_parser("restore", help="Restore a trusted backup into a completely NEW project")
    recover.add_argument("--input", type=Path, required=True)
    recover.add_argument("--confirm-target", required=True, help="NEW project, different from the source")
    recover.add_argument("--api-port", type=int, required=True)
    recover.add_argument("--mailpit-port", type=int, default=18025)
    recover.add_argument("--settings-dir", type=Path, help="NEW directory for non-secret pinned-image/port overrides")
    recover.add_argument("--restore-test", action="store_true", help="Demo only: Mailpit, FCM disabled, no reseeding")
    args = parser.parse_args()
    compose = compose_arguments(args)
    configuration = read_compose_json(docker(*compose, "config", "--format", "json"))
    if args.action == "backup":
        backup(args, compose, configuration)
    else:
        restore(args, compose, configuration)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("FAIL: interrupted. Source restart was attempted; inspect local service status.", file=sys.stderr)
        sys.exit(1)
    except (RuntimeError, OSError, ValueError, KeyError, TypeError, tarfile.TarError):
        # Exception strings can contain secret JSON, SQL, or env values. All
        # operational errors use static RuntimeError messages; other exceptions
        # are reported without their data or a traceback.
        error = sys.exc_info()[1]
        message = str(error) if type(error) is RuntimeError else "Recovery failed; check local files/configuration. Sensitive details are withheld."
        print("FAIL: " + message, file=sys.stderr)
        sys.exit(1)
