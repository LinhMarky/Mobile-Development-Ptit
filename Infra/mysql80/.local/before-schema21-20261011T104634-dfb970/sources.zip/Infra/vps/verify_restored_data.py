"""Compare existing test room/media/account data across source and restored local stacks."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from urllib.parse import urlsplit
import uuid
from datetime import datetime, timezone

from compose_config import read_compose_json
from test_persistence import api


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def local_origin(value: str) -> str:
    address = urlsplit(value)
    require(address.scheme == "http" and address.hostname in ("127.0.0.1", "::1", "localhost")
            and address.path in ("", "/") and not address.query and not address.fragment
            and not address.username and not address.password, "Use a loopback HTTP origin for this isolated restore test")
    return value.rstrip("/")


def source_configuration(env_file: Path, smtp_env: Path | None) -> dict:
    directory = Path(__file__).resolve().parent
    require(env_file.is_file(), "Original private source env file is missing")
    command = ["docker", "compose", "--env-file", str(env_file.resolve())]
    if smtp_env:
        require(smtp_env.is_file(), "Private SMTP env file is missing")
        command += ["--env-file", str(smtp_env.resolve())]
    command += ["-f", str(directory / "compose.yaml"), "-f", str(directory / "compose.demo.yaml")]
    if smtp_env:
        command += ["-f", str(directory / "compose.smtp.yaml")]
    command += ["config", "--format", "json"]
    completed = subprocess.run(command, capture_output=True, text=True, check=False)
    require(completed.returncode == 0, "Source Compose config failed; private output omitted")
    return read_compose_json(completed.stdout)


def authenticate(origin: str, email: str, password: str) -> dict:
    return api(origin, "POST", "/auth/login", data={
        "email": email, "password": password, "installation_id": str(uuid.uuid4()),
        "device_name": "Backup restore acceptance",
    })


def logout(origin: str, session: dict) -> None:
    api(origin, "POST", "/auth/logout", token=session["access_token"],
        data={"refresh_token": session["refresh_token"]})
    api(origin, "POST", "/auth/refresh", data={"refresh_token": session["refresh_token"]}, expected_status=400)


def sample(origin: str, password: str, fixture: dict, email_state: dict | None) -> dict:
    session = authenticate(origin, "host@homely.test", password)
    try:
        token = session["access_token"]
        profile = api(origin, "GET", "/profile", token)
        require(profile["id"] == session["user"]["id"] and profile["email"] == "host@homely.test",
                "Host login/profile identity mismatch")
        room = api(origin, "GET", f"/rooms/{fixture['room_id']}", token)
        attachments = api(origin, "GET", f"/media/room/{fixture['room_id']}", token)
        require(any(media["id"] == fixture["media_id"] for media in attachments), "Expected media attachment is missing")
        image = api(origin, "GET", f"/media/{fixture['media_id']}/content", token, raw=True)
        digest = hashlib.sha256(image).hexdigest()
        require(digest == fixture["media_sha256"], "Media bytes do not match the earlier persistence fixture")
        result = {"host_id": profile["id"], "room_id": room["id"], "unit_code": room["unit_code"],
                  "media_id": fixture["media_id"], "media_sha256": digest, "media_attachment": True}
    finally:
        logout(origin, session)
    if email_state is not None:
        session = authenticate(origin, email_state["email"], email_state["password"])
        try:
            profile = api(origin, "GET", "/profile", session["access_token"])
            require(profile["id"] == email_state["user_id"] == session["user"]["id"]
                    and profile["email"] == email_state["email"] and profile["email_verified"] is True,
                    "Restored real-email account identity/verification flag is incorrect")
            result["verified_user_id"] = profile["id"]
            result["email_verified"] = True
        finally:
            logout(origin, session)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env-file", type=Path, required=True)
    parser.add_argument("--smtp-env", type=Path)
    parser.add_argument("--confirm-project", required=True)
    parser.add_argument("--source-origin", required=True)
    parser.add_argument("--restored-origin", required=True)
    parser.add_argument("--fixture", type=Path, required=True, help="Safe persistence result with room/media IDs and bytes checksum")
    parser.add_argument("--email-state-file", type=Path, help="Optional ignored private real-email test account state, never printed")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source, restored = local_origin(args.source_origin), local_origin(args.restored_origin)
    require(source != restored, "Restored origin must differ from source")
    require(not args.output.exists(), "Output already exists; no acceptance requests were made")
    configuration = source_configuration(args.env_file, args.smtp_env)
    require(configuration["name"] == args.confirm_project, "Source project confirmation mismatch")
    environment = configuration["services"]["backend"]["environment"]
    require(environment.get("DEMO_ENABLED") == "true" and environment.get("DEMO_SEED") == "true",
            "This acceptance check requires the explicitly selected demo source")
    fixture = json.loads(args.fixture.read_text(encoding="utf-8"))
    require(fixture.get("project") == args.confirm_project and fixture.get("pass") is True,
            "Persistence fixture belongs to another project or did not pass")
    email_state = json.loads(args.email_state_file.read_text(encoding="utf-8")) if args.email_state_file else None
    if email_state is not None:
        require(email_state.get("registered") is True and email_state.get("origin") == source,
                "Private email account state does not match the source")
    before = sample(source, environment["DEMO_PASSWORD"], fixture, email_state)
    after = sample(restored, environment["DEMO_PASSWORD"], fixture, email_state)
    require(before == after, "Source and restored room/media/account samples differ")
    proof = {"completed_utc": datetime.now(timezone.utc).isoformat(), "source_project": args.confirm_project,
             "source_origin": source, "restored_origin": restored, "source": before, "restored": after,
             "database_restored": True, "media_attachment_restored": True, "media_bytes_restored": True,
             "verified_account_restored": after.get("email_verified") is True if email_state else None, "pass": True}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as output:
        json.dump(proof, output, indent=2)
        output.write("\n")
    print("PASS restore acceptance: room identity, media attachment/bytes, account identity and logout/refresh checks")
    print(f"Safe evidence: {args.output}; passwords and tokens were omitted.")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError, StopIteration):
        print("FAIL restore acceptance: configuration/request/data mismatch; private data omitted.", file=sys.stderr)
        sys.exit(1)
