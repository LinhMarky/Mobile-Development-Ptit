package com.example.roomly;

import android.app.Application;

import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiClient;
import com.example.roomly.data.remote.ApiError;
import com.example.roomly.data.repository.AuthRepository;
import com.example.roomly.data.repository.SessionRepository;
import com.example.roomly.push.PushTokenRepository;

import org.json.JSONObject;

public final class RoomlyApplication extends Application {
    @Override public void onCreate() {
        super.onCreate();
        SessionRepository.getInstance().initialize(this);
        ApiClient.initialize(this);
        PushTokenRepository.initialize(this);
        if (SessionRepository.getInstance().getCurrentSession().isLoggedIn()) {
            AuthRepository.getInstance().refreshAccount(new ApiCallback() {
                @Override public void onSuccess(JSONObject envelope) { }
                @Override public void onError(ApiError error) { }
            });
        }
    }
}
