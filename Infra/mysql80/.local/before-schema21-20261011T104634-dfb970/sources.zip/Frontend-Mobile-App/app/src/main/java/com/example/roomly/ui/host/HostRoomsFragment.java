package com.example.roomly.ui.host;
import android.widget.LinearLayout;
import com.example.roomly.data.remote.Jsons;
import com.example.roomly.data.repository.HostRepository;
import com.example.roomly.ui.host.viewing.HostAppointmentsFragment;
import org.json.JSONArray;
import org.json.JSONObject;
public class HostRoomsFragment extends HostScreenFragment {
    private final HostRepository repository=new HostRepository();
    private int page;
    @Override protected String title() {
        return "Phòng của tôi";
    }
    @Override protected void render() {
        button("Thêm phòng",()->open(new HostAddRoomFragment()));
        button("Bài đăng của tôi",()->open(new HostListingsFragment()));
        button("Yêu cầu xem phòng",()->open(new HostAppointmentsFragment()));
        button("Tải lại",this::reload);
        error("Đang tải phòng…");
        repository.rooms(page,callback(envelope-> {
            JSONArray rows=Jsons.items(envelope);
            error(rows.length()==0?"Bạn chưa có phòng ở trang này.":"");
            for(int i=0;i<rows.length();i++) {
                JSONObject room=rows.optJSONObject(i);
                if(room==null)continue;
                JSONObject address=Jsons.object(room,"address");
                String id=room.optString("id");
                LinearLayout row=card("Phòng "+room.optString("unit_code")+"\n"+address.optString("line")+", "+address.optString("province_name")+"\n"+room.optString("area_m2")+" m² · "+room.optInt("max_occupants")+" người\n"+HostLabels.availability(room.optString("availability")));
                cardButton(row,"Xem phòng",()->open(HostRoomDetailFragment.newInstance(id)));
            }
            JSONObject paging=Jsons.data(envelope);
            text("Trang "+(page+1)+" / "+Math.max(1,paging.optInt("total_pages")));
            if(page>0)button("Trang trước",()-> {
                page--;
                reload();
            });
            if(page+1<paging.optInt("total_pages"))button("Trang tiếp",()-> {
                page++;
                reload();
            });
        }));
    }
}
