package com.example.roomly.data.model;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Display data with separate physical room and advert IDs. */
public class RoomCard {
    public enum RoomType { ROOM, APARTMENT, STUDIO }
    private final String title, price, address, amenities;
    private final int imageResId;
    private final RoomType roomType;
    private boolean saved, savePending;
    private long monthlyRent, roomId, listingId, hostId;
    private int areaSquareMeters, termsVersion;
    private BigDecimal rentAmount, depositAmount;
    private String description = "", availability = "", imageUrl = "";
    private List<Fee> fees = Collections.emptyList();

    // Old model consumers retain constructors; API screens create server-backed cards only.
    public RoomCard(String title, String price, String address, String amenities, int imageResId, boolean saved) {
        this(title, price, address, amenities, imageResId, saved, RoomType.ROOM);
    }
    public RoomCard(String title, String price, String address, String amenities, int imageResId,
                    boolean saved, RoomType roomType) {
        this.title = title; this.price = price; this.address = address; this.amenities = amenities;
        this.imageResId = imageResId; this.saved = saved; this.roomType = roomType;
    }
    public RoomCard(long roomId, long listingId, long hostId, String title, String address,
                    String amenities, RoomType roomType, BigDecimal rent, BigDecimal deposit,
                    BigDecimal area, String description, String availability, int termsVersion,
                    List<Fee> fees, boolean saved) {
        this(title, rent == null ? "Chưa có giá thuê" : formatMoney(rent) + "/tháng",
                address, amenities, 0, saved, roomType);
        this.roomId = roomId; this.listingId = listingId; this.hostId = hostId;
        rentAmount = rent; depositAmount = deposit;
        monthlyRent = rent == null ? 0 : rent.longValue();
        areaSquareMeters = area == null ? 0 : area.intValue();
        this.description = description; this.availability = availability; this.termsVersion = termsVersion;
        this.fees = Collections.unmodifiableList(new ArrayList<>(fees));
    }
    public static String formatMoney(BigDecimal amount) {
        return amount == null ? "Chưa cung cấp" : NumberFormat.getNumberInstance(new Locale("vi", "VN"))
                .format(amount) + " ₫";
    }
    public String getTitle() { return title; }
    public String getPrice() { return price; }
    public String getAddress() { return address; }
    public String getAmenities() { return amenities; }
    public int getImageResId() { return imageResId; }
    public RoomType getRoomType() { return roomType; }
    public boolean isSaved() { return saved; }
    public void setSaved(boolean saved) { this.saved = saved; }
    public boolean isSavePending() { return savePending; }
    public void setSavePending(boolean pending) { savePending = pending; }
    public long getMonthlyRent() { return monthlyRent; }
    public void setMonthlyRent(long rent) { monthlyRent = rent; }
    public int getAreaSquareMeters() { return areaSquareMeters; }
    public void setAreaSquareMeters(int area) { areaSquareMeters = area; }
    public long getRoomId() { return roomId; }
    public long getListingId() { return listingId; }
    public long getHostId() { return hostId; }
    public BigDecimal getRentAmount() { return rentAmount; }
    public BigDecimal getDepositAmount() { return depositAmount; }
    public String getDescription() { return description; }
    public String getAvailability() { return availability; }
    public int getTermsVersion() { return termsVersion; }
    public List<Fee> getFees() { return fees; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String url) { imageUrl = url == null ? "" : url; }
    public static final class Fee {
        public final String code, mode, unit, note;
        public final BigDecimal amount;
        public Fee(String code, String mode, BigDecimal amount, String unit, String note) {
            this.code = code; this.mode = mode; this.amount = amount; this.unit = unit; this.note = note;
        }
        public String display() {
            if ("INCLUDED".equals(mode)) return "Đã gồm trong tiền thuê";
            if ("NEGOTIABLE".equals(mode)) return "Thỏa thuận";
            return formatMoney(amount) + (unit.isEmpty() ? "" : "/" + unit);
        }
    }
}
