package com.example.roomly.ui.host;
import android.os.Bundle;
public class HostEditListingFragment extends ListingFormFragment {
    public static HostEditListingFragment newInstance(String listingId) {
        HostEditListingFragment fragment=new HostEditListingFragment();
        Bundle args=new Bundle();
        args.putString("listing_id",listingId);
        fragment.setArguments(args);
        return fragment;
    }
}
