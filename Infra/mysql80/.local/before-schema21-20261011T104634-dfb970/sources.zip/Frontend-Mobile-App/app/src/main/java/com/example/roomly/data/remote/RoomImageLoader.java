package com.example.roomly.data.remote;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import com.example.roomly.data.repository.SessionRepository;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

/** Ảnh gateway cùng origin; cache giới hạn, tách theo phiên và không giữ View đã hủy. */
public final class RoomImageLoader {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(16 * 1024) {
        @Override protected int sizeOf(String key, Bitmap bitmap) { return bitmap.getByteCount() / 1024; }
    };
    private RoomImageLoader() { }

    public static void clear() { CACHE.evictAll(); }

    public static void load(ImageView view, String path) {
        long generation = SessionRepository.getInstance().getGeneration();
        String key = generation + ":" + path;
        view.setTag(key);
        if (path == null || path.isEmpty()) return;
        Bitmap cached = CACHE.get(key);
        if (cached != null) { view.setImageBitmap(cached); return; }
        WeakReference<ImageView> target = new WeakReference<>(view);
        ApiClient api = ApiClient.getInstance();
        try {
            api.httpClient().newCall(api.authorizedRequest(path).build()).enqueue(new Callback() {
                @Override public void onFailure(Call call, IOException error) { }
                @Override public void onResponse(Call call, Response response) {
                    try (Response closeable = response) {
                        if (!response.isSuccessful() || response.body() == null) return;
                        byte[] bytes;
                        try (InputStream input = response.body().byteStream();
                             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                            byte[] buffer = new byte[8192];
                            int count;
                            while ((count = input.read(buffer)) != -1) {
                                if (output.size() + count > 10 * 1024 * 1024) return;
                                output.write(buffer, 0, count);
                            }
                            bytes = output.toByteArray();
                        }
                        BitmapFactory.Options options = new BitmapFactory.Options();
                        options.inJustDecodeBounds = true;
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
                        options.inSampleSize = 1;
                        while (Math.max(options.outWidth, options.outHeight) / options.inSampleSize > 1600) {
                            options.inSampleSize *= 2;
                        }
                        options.inJustDecodeBounds = false;
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
                        if (bitmap == null) return;
                        MAIN.post(() -> {
                            ImageView image = target.get();
                            if (generation != SessionRepository.getInstance().getGeneration()) return;
                            CACHE.put(key, bitmap);
                            if (image != null && key.equals(image.getTag())) image.setImageBitmap(bitmap);
                        });
                    } catch (IOException ignored) { }
                }
            });
        } catch (IllegalArgumentException ignored) { }
    }
}
