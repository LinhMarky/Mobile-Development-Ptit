package com.example.roomly.ui.messages;

import android.os.Handler;
import android.os.Looper;
import com.example.roomly.data.remote.ApiClient;
import com.example.roomly.data.repository.SessionRepository;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

/** Native STOMP 1.2: the JWT belongs only in the HTTP handshake. */
public final class ChatSocket extends WebSocketListener {
    public interface Listener {
        void onReady();
        void onMessage(JSONObject message, boolean acknowledgement);
        void onProblem(String message);
        void onDisconnected(boolean authenticationRequired);
    }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Listener listener;
    private final StompFrameDecoder decoder = new StompFrameDecoder();
    private WebSocket socket;
    private volatile boolean connected;
    private volatile boolean closed;

    public ChatSocket(Listener listener) { this.listener = listener; }

    public void connect() {
        String token = SessionRepository.getInstance().getAccessToken();
        if (token == null || token.isEmpty()) {
            main.post(() -> listener.onDisconnected(true));
            return;
        }
        closed = false;
        socket = ApiClient.getInstance().httpClient().newWebSocket(new Request.Builder()
                .url(ApiClient.getInstance().websocketUrl())
                .header("Authorization", "Bearer " + token).build(), this);
    }

    @Override public void onOpen(WebSocket ws, Response response) {
        if (closed) { ws.cancel(); return; }
        ws.send("CONNECT\naccept-version:1.2\nhost:roomly\nheart-beat:0,0\n\n\u0000");
    }

    @Override public void onMessage(WebSocket ws, ByteString bytes) {
        onMessage(ws, bytes.string(StandardCharsets.UTF_8));
    }

    @Override public synchronized void onMessage(WebSocket ws, String text) {
        if (closed) return;
        java.util.List<StompFrameDecoder.Frame> frames;
        try { frames = decoder.accept(text); }
        catch (IllegalArgumentException ignored) {
            ws.cancel(); problem("Không đọc được giao thức chat. Hãy kết nối lại để đồng bộ lịch sử.");
            disconnect(false); return;
        }
        for (StompFrameDecoder.Frame frame : frames) {
            String command = frame.command;
            if ("CONNECTED".equals(command)) {
                String[] queues = {"chat.messages", "chat.acks", "chat.errors"};
                for (int i = 0; i < queues.length; i++) {
                    ws.send("SUBSCRIBE\nid:" + i + "\ndestination:/user/queue/" + queues[i]
                            + "\nack:auto\n\n\u0000");
                }
                connected = true;
                main.post(() -> { if (!closed) listener.onReady(); });
                continue;
            }
            if (!"MESSAGE".equals(command) && !"ERROR".equals(command)) continue;
            try {
                JSONObject data = new JSONObject(frame.body);
                String destination = frame.headers.get("destination");
                boolean error = "ERROR".equals(command)
                        || (destination != null && destination.contains("chat.errors"));
                if (error) {
                    problem(data.optString("detail", "Không thể gửi tin. Kiểm tra lịch sử trước khi thử lại."));
                    if ("ERROR".equals(command)) {
                        ws.cancel(); disconnect(data.optInt("status") == 401);
                    }
                } else {
                    boolean ack = destination != null && destination.contains("chat.acks");
                    main.post(() -> { if (!closed) listener.onMessage(data, ack); });
                }
            } catch (Exception ignored) { problem("Không đọc được phản hồi chat. Hãy đồng bộ lại lịch sử."); }
        }
    }

    public boolean send(JSONObject body) {
        return !closed && connected && socket != null && socket.send(
                "SEND\ndestination:/app/chat.send\ncontent-type:application/json\n\n" + body + "\u0000");
    }

    public void close() {
        closed = true; connected = false;
        if (socket != null) { socket.close(1000, "Leaving conversation"); socket = null; }
    }

    private void problem(String message) {
        main.post(() -> { if (!closed) listener.onProblem(message); });
    }
    private void disconnect(boolean auth) {
        connected = false;
        main.post(() -> { if (!closed) listener.onDisconnected(auth); });
    }
    @Override public void onFailure(WebSocket ws, Throwable error, Response response) {
        disconnect(response != null && response.code() == 401);
    }
    @Override public void onClosing(WebSocket ws, int code, String reason) { ws.close(code, null); }
    @Override public void onClosed(WebSocket ws, int code, String reason) { disconnect(false); }
}
