package com.example.roomly.push;

import android.content.Intent;
import com.example.roomly.data.repository.SessionRepository;
import java.util.Arrays;

/** Notification extras are untrusted; the server still checks target ownership. */
public final class PushNotificationRouter {
    private PushNotificationRouter() { }
    public static final class Target {
        public final String type;
        public final String id;
        Target(String type, String id) { this.type = type; this.id = id; }
    }
    public static Target takeTarget(Intent intent) {
        if (intent == null) return null;
        String recipient = intent.getStringExtra("recipient_id");
        String type = intent.getStringExtra("ref_type");
        String id = intent.getStringExtra("ref_id");
        intent.removeExtra("recipient_id"); intent.removeExtra("ref_type"); intent.removeExtra("ref_id");
        String current = SessionRepository.getInstance().getCurrentSession().getUserId();
        if (current == null || !current.equals(recipient) || type == null || id == null
                || !Arrays.asList("conversation", "viewing", "booking", "listing", "room", "report").contains(type)) return null;
        try { if (Long.parseLong(id) <= 0) return null; }
        catch (NumberFormatException ignored) { return null; }
        return new Target(type, id);
    }
    public static String takeConversationId(Intent intent) {
        Target target = takeTarget(intent);
        return target != null && "conversation".equals(target.type) ? target.id : null;
    }
}
