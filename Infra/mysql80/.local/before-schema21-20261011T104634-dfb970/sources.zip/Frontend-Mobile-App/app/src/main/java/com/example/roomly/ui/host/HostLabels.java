package com.example.roomly.ui.host;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;
public final class HostLabels {
    private HostLabels() {
    }
    public static String listing(String status) {
        switch(status) {
            case "DRAFT":return "Bản nháp";
            case "PENDING_REVIEW":return "Chờ duyệt";
            case "PUBLISHED":return "Đang hiển thị";
            case "HIDDEN":return "Đã ẩn";
            case "REJECTED":return "Bị từ chối";
            case "EXPIRED":return "Hết hạn";
            default:return status;
        }
    }
    public static boolean editable(String status) {
        return "DRAFT".equals(status)||"HIDDEN".equals(status)||"REJECTED".equals(status)||"EXPIRED".equals(status);
    }
    public static String viewing(String status) {
        switch(status) {
            case "REQUESTED":return "Chờ chủ trọ xác nhận";
            case "CONFIRMED":return "Đã xác nhận";
            case "COMPLETED":return "Đã hoàn tất";
            case "CANCELLED_BY_TENANT":return "Người thuê đã hủy";
            case "CANCELLED_BY_HOST":return "Chủ trọ đã hủy";
            case "NO_SHOW":return "Không đến";
            default:return status;
        }
    }
    public static String availability(String status) {
        switch(status) {
            case "AVAILABLE":return "Còn phòng";
            case "HELD":return "Đã giữ chỗ";
            case "RENTED":return "Đã cho thuê";
            default:return status;
        }
    }
    public static String money(String amount) {
        try {
            return NumberFormat.getNumberInstance(new Locale("vi","VN")).format(new BigDecimal(amount))+" ₫";
        }catch(Exception e) {
            return "Chưa có giá";
        }
    }
}
