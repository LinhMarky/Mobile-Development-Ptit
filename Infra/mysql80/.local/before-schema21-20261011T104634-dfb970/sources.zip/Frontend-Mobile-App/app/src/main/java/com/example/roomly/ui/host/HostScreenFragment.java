package com.example.roomly.ui.host;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.example.roomly.R;
import com.example.roomly.data.model.SessionState;
import com.example.roomly.data.model.UserRole;
import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiError;
import com.example.roomly.data.repository.SessionRepository;
import com.example.roomly.ui.auth.LoginFragment;
import com.example.roomly.ui.auth.VerifyEmailFragment;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.textfield.TextInputEditText;
import org.json.JSONObject;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
/** Shared small-screen layout and lifecycle-safe API callbacks for host forms. */
public abstract class HostScreenFragment extends Fragment {
    protected LinearLayout content;
    protected TextView status;
    protected final Map<String, EditText> fields = new LinkedHashMap<>();
    private Bundle savedFields = new Bundle();
    private Bundle intents = new Bundle();
    private long renderedGeneration = -1;
    private int renderEpoch;
    private String formOwner;
    private String accessSignature;
    protected abstract String title();
    protected abstract void render();
    protected boolean hostOnly() {
        return true;
    }
    protected void clearPrivateState() {
    }
    @Override public void onCreate(@Nullable Bundle state) {
        super.onCreate(state);
        if (state != null) {
            savedFields = state.getBundle("form") == null ? new Bundle() : state.getBundle("form");
            intents = state.getBundle("intents") == null ? new Bundle() : state.getBundle("intents");
            formOwner = state.getString("form_owner");
        }
    }
    @Override public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle state) {
        ScrollView scroll = new ScrollView(requireContext());
        content = new LinearLayout(requireContext());
        content.setOrientation(LinearLayout.VERTICAL);
        int p = dp(20);
        content.setPadding(p, p, p, p);
        scroll.setFillViewport(true);
        scroll.addView(content);
        return scroll;
    }
    @Override public void onViewCreated(@NonNull View view, Bundle state) {
        super.onViewCreated(view, state);
        renderedGeneration = SessionRepository.getInstance().getGeneration();
        reload();
        SessionRepository.getInstance().getSessionState().observe(getViewLifecycleOwner(), session -> {
            long generation = SessionRepository.getInstance().getGeneration();
            if (generation != renderedGeneration || !signature(session).equals(accessSignature)) {
                renderedGeneration = generation;
                reload();
            }
        });
    }
    protected final void reload() {
        if (content == null) return;
        renderEpoch++;
        SessionState session = SessionRepository.getInstance().getCurrentSession();
        accessSignature = signature(session);
        String owner = session.getUserId();
        if (formOwner != null && !formOwner.equals(owner)) {
            savedFields.clear();
            fields.clear();
            intents.clear();
            clearPrivateState();
        }
        formOwner = owner;
        rememberFields();
        fields.clear();
        content.removeAllViews();
        TextView heading = text(title());
        heading.setTextSize(24);
        heading.setTypeface(null, 1);
        status = text("");
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        if (!session.isLoggedIn()) {
            status.setText("Đăng nhập để tiếp tục.");
            button("Đăng nhập", () -> open(new LoginFragment()));
            return;
        }
        if (hostOnly() && !session.hasRole(UserRole.HOST)) {
            status.setText("Tài khoản chưa có quyền chủ trọ.");
            return;
        }
        if (!session.isEmailVerified()) {
            status.setText("Xác minh email trước khi quản lý phòng hoặc đặt lịch.");
            button("Xác minh email", () -> open(VerifyEmailFragment.newInstance(session.getEmail())));
            return;
        }
        render();
    }
    protected TextView text(String value) {
        TextView view = new TextView(requireContext());
        view.setText(value);
        view.setTextSize(16);
        view.setPadding(0, dp(8), 0, dp(8));
        content.addView(view);
        return view;
    }
    protected Button button(String label, Runnable click) {
        MaterialButton button = new MaterialButton(requireContext());
        button.setText(label);
        button.setOnClickListener(v -> click.run());
        content.addView(button);
        return button;
    }
    protected EditText field(String key, String label, String initial, int type) {
        TextInputLayout wrapper = new TextInputLayout(requireContext());
        wrapper.setHint(label);
        TextInputEditText input = new TextInputEditText(requireContext());
        input.setInputType(type);
        input.setText(savedFields.containsKey(key) ? savedFields.getString(key) : initial);
        wrapper.addView(input);
        content.addView(wrapper);
        fields.put(key, input);
        return input;
    }
    protected EditText field(String key, String label, String initial) {
        return field(key, label, initial, InputType.TYPE_CLASS_TEXT);
    }
    protected String value(String key) {
        EditText field = fields.get(key);
        return field == null || field.getText() == null ? "" : field.getText().toString().trim();
    }
    protected LinearLayout card(String summary) {
        MaterialCardView card = new MaterialCardView(requireContext());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, dp(8));
        card.setLayoutParams(lp);
        LinearLayout body = new LinearLayout(requireContext());
        body.setOrientation(LinearLayout.VERTICAL);
        int p=dp(12);
        body.setPadding(p,p,p,p);
        TextView label = new TextView(requireContext());
        label.setText(summary);
        label.setTextSize(16);
        body.addView(label);
        card.addView(body);
        content.addView(card);
        return body;
    }
    protected Button cardButton(LinearLayout row, String label, Runnable click) {
        MaterialButton button = new MaterialButton(requireContext());
        button.setText(label);
        button.setOnClickListener(v -> click.run());
        row.addView(button);
        return button;
    }
    protected void open(Fragment screen) {
        if (isAdded() && !getParentFragmentManager().isStateSaved()) getParentFragmentManager().beginTransaction().replace(R.id.fragment_container, screen).addToBackStack(null).commit();
    }
    protected void back() {
        if (isAdded() && !getParentFragmentManager().isStateSaved()) getParentFragmentManager().popBackStack();
    }
    protected void error(String message) {
        if (status != null) status.setText(message);
    }
    protected void clearForm() {
        savedFields.clear();
        fields.clear();
    }
    protected String intentKey(String name, String fingerprint) {
        String old = intents.getString(name + ".payload");
        if (!fingerprint.equals(old)) {
            intents.putString(name + ".payload", fingerprint);
            intents.putString(name + ".key", UUID.randomUUID().toString());
        }
        return intents.getString(name + ".key");
    }
    protected void finishIntent(String name) {
        intents.remove(name + ".payload");
        intents.remove(name + ".key");
    }
    protected ApiCallback callback(Consumer<JSONObject> success) {
        return callback(null, success);
    }
    protected ApiCallback callback(@Nullable Button action, Consumer<JSONObject> success) {
        final View expected = content;
        final int expectedEpoch = renderEpoch;
        final long generation = SessionRepository.getInstance().getGeneration();
        if (action != null) action.setEnabled(false);
        return new ApiCallback() {
            private boolean active() {
                return content != null && content == expected && renderEpoch == expectedEpoch && isAdded() && generation == SessionRepository.getInstance().getGeneration();
            }
            @Override public void onSuccess(JSONObject envelope) {
                if (!active()) return;
                if (action != null) action.setEnabled(true);
                success.accept(envelope);
            }
            @Override public void onError(ApiError failure) {
                if (!active()) return;
                if (action != null) action.setEnabled(true);
                error(failure.getMessage() + (failure.getStatusCode() == 409 ? "\nDữ liệu đã thay đổi. Tải lại trước khi thao tác tiếp." : ""));
            }
        };
    }
    private void rememberFields() {
        for (Map.Entry<String,EditText> entry : fields.entrySet()) savedFields.putString(entry.getKey(), entry.getValue().getText() == null ? "" : entry.getValue().getText().toString());
    }
    @Override public void onSaveInstanceState(@NonNull Bundle out) {
        rememberFields();
        out.putBundle("form", savedFields);
        out.putBundle("intents", intents);
        out.putString("form_owner", formOwner);
        super.onSaveInstanceState(out);
    }
    @Override public void onDestroyView() {
        rememberFields();
        fields.clear();
        content = null;
        status = null;
        super.onDestroyView();
    }
    protected int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
    private static String signature(SessionState session) {
        return session.getUserId() + ":" + session.isEmailVerified() + ":" + session.getRoles();
    }
}
