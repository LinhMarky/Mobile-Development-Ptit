package com.example.roomly.data.model;

import org.junit.Test;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.*;

public class RoomCardTest {
    @Test public void preservesSeparateServerIdentifiersAndExactVndAmounts() {
        BigDecimal rent = new BigDecimal("200000000000000001");
        RoomCard room = new RoomCard(900L, 600L, 71L, "Title", "Address", "25.5 m²",
                RoomCard.RoomType.APARTMENT, rent, new BigDecimal("999999999999999999"),
                new BigDecimal("25.5"), "Description", "AVAILABLE", 3, new ArrayList<>(), false);
        assertEquals(900L, room.getRoomId());
        assertEquals(600L, room.getListingId());
        assertEquals(71L, room.getHostId());
        assertEquals(rent, room.getRentAmount());
        assertEquals("999999999999999999", room.getDepositAmount().toPlainString());
        assertTrue(room.getPrice().contains("200.000.000.000.000.001"));
    }
    @Test public void absentPriceAndFeeAreShownAsUnknownRatherThanFree() {
        assertEquals("Chưa cung cấp", RoomCard.formatMoney(null));
        assertEquals("Chưa cung cấp", new RoomCard.Fee("WATER", "FIXED", null, "", "").display());
        assertEquals("0 ₫/người", new RoomCard.Fee("WATER", "FIXED", BigDecimal.ZERO, "người", "").display());
    }
    @Test public void feeSnapshotCannotBeChangedByItsCaller() {
        List<RoomCard.Fee> source = new ArrayList<>();
        source.add(new RoomCard.Fee("WATER", "FIXED", BigDecimal.TEN, "m³", "Metered"));
        RoomCard room = new RoomCard(900L, 600L, 71L, "Title", "Address", "", RoomCard.RoomType.ROOM,
                BigDecimal.TEN, BigDecimal.ONE, BigDecimal.TEN, "", "AVAILABLE", 1, source, true);
        source.clear();
        assertEquals(1, room.getFees().size());
        try { room.getFees().clear(); fail("Fee snapshot must be immutable"); }
        catch (UnsupportedOperationException expected) { }
    }
}
