package com.example.roomly.ui.saved;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.roomly.R;
import com.example.roomly.data.model.RoomCard;
import com.example.roomly.data.model.UserRole;
import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiError;
import com.example.roomly.data.repository.CatalogRepository;
import com.example.roomly.data.repository.SessionAccess;
import com.example.roomly.data.repository.SessionRepository;
import com.example.roomly.databinding.FragmentSavedBinding;
import com.example.roomly.ui.auth.LoginFragment;
import com.example.roomly.ui.auth.VerifyEmailFragment;
import com.example.roomly.ui.detail.RoomDetailFragment;
import com.example.roomly.ui.explore.RoomAdapter;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Saved physical rooms from the authenticated wishlist API, including unavailable adverts. */
public class SavedFragment extends Fragment {
    private FragmentSavedBinding binding;
    private RoomAdapter adapter;
    private final List<RoomCard> rooms = new ArrayList<>();
    private int requestEpoch, nextPage;
    private boolean loading, hasMore;

    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater,
            @Nullable ViewGroup container, @Nullable Bundle state) {
        binding = FragmentSavedBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }
    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        binding.rvSavedRooms.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new RoomAdapter(new ArrayList<>());
        adapter.setOnRoomClickListener(this::openRoom);
        adapter.setOnSaveRequestListener(this::toggleSave);
        binding.rvSavedRooms.setAdapter(adapter);
        binding.btnSavedLogin.setOnClickListener(v -> open(new LoginFragment()));
        binding.btnSavedRetry.setOnClickListener(v -> loadPage(!rooms.isEmpty()));
        binding.btnSavedMore.setOnClickListener(v -> loadPage(true));
        SessionRepository.getInstance().getSessionState().observe(getViewLifecycleOwner(), session -> refresh());
    }
    @Override public void onResume() { super.onResume(); refresh(); }

    private void refresh() {
        if (binding == null || adapter == null) return;
        requestEpoch++;
        loading = false; hasMore = false; nextPage = 0;
        rooms.clear(); adapter.updateRooms(rooms);
        binding.layoutSavedEmpty.setVisibility(View.GONE);
        binding.tvSavedStatus.setVisibility(View.GONE);
        binding.btnSavedRetry.setVisibility(View.GONE);
        binding.btnSavedMore.setVisibility(View.GONE);
        SessionAccess.Result result = SessionAccess.requireRole(UserRole.TENANT, false);
        boolean allowed = result == SessionAccess.Result.ALLOWED;
        binding.rvSavedRooms.setVisibility(allowed ? View.VISIBLE : View.GONE);
        binding.layoutSavedAccess.setVisibility(allowed ? View.GONE : View.VISIBLE);
        if (!allowed) {
            boolean login = result == SessionAccess.Result.LOGIN_REQUIRED;
            binding.tvSavedAccessTitle.setText(login ? "Đăng nhập để xem phòng đã lưu" : "Danh sách dành cho người thuê");
            binding.tvSavedAccessDescription.setText(login ? "Lưu phòng bạn quan tâm để xem lại." : "Tài khoản cần có vai trò người thuê.");
            binding.btnSavedLogin.setVisibility(login ? View.VISIBLE : View.GONE);
            return;
        }
        loadPage(false);
    }
    private void loadPage(boolean append) {
        if (binding == null || loading || (append && !hasMore)) return;
        loading = true;
        final FragmentSavedBinding activeView = binding;
        final int epoch = ++requestEpoch;
        final long generation = SessionRepository.getInstance().getGeneration();
        binding.tvSavedStatus.setText("Đang tải phòng đã lưu...");
        binding.tvSavedStatus.setVisibility(View.VISIBLE);
        binding.btnSavedRetry.setVisibility(View.GONE);
        binding.btnSavedMore.setEnabled(false);
        CatalogRepository.getInstance().saved(append ? nextPage : 0, new CatalogRepository.PageCallback() {
            private boolean current() { return binding == activeView && epoch == requestEpoch
                    && generation == SessionRepository.getInstance().getGeneration(); }
            @Override public void onSuccess(List<RoomCard> pageRooms, int page, boolean more) {
                if (!current()) return;
                loading = false;
                if (!append) rooms.clear();
                rooms.addAll(pageRooms); nextPage = page + 1; hasMore = more;
                adapter.updateRooms(rooms);
                binding.tvSavedStatus.setVisibility(View.GONE);
                binding.layoutSavedEmpty.setVisibility(rooms.isEmpty() ? View.VISIBLE : View.GONE);
                binding.rvSavedRooms.setVisibility(rooms.isEmpty() ? View.GONE : View.VISIBLE);
                binding.btnSavedMore.setEnabled(true);
                binding.btnSavedMore.setVisibility(more ? View.VISIBLE : View.GONE);
            }
            @Override public void onError(ApiError error) {
                if (!current()) return;
                loading = false;
                binding.tvSavedStatus.setText(error.getMessage());
                binding.btnSavedRetry.setVisibility(View.VISIBLE);
                binding.btnSavedMore.setEnabled(true);
                binding.btnSavedMore.setVisibility(View.GONE);
            }
        });
    }
    private void toggleSave(RoomCard room) {
        if (binding == null || room.isSavePending()) return;
        SessionAccess.Result access = SessionAccess.requireRole(UserRole.TENANT, true);
        if (access != SessionAccess.Result.ALLOWED) {
            if (access == SessionAccess.Result.LOGIN_REQUIRED) open(new LoginFragment());
            else if (access == SessionAccess.Result.EMAIL_VERIFICATION_REQUIRED) open(VerifyEmailFragment.newInstance(
                    SessionRepository.getInstance().getCurrentSession().getEmail()));
            else Toast.makeText(requireContext(), "Tài khoản cần có vai trò người thuê.", Toast.LENGTH_LONG).show();
            return;
        }
        room.setSavePending(true); adapter.notifyRoomSaveChanged(room);
        final FragmentSavedBinding activeView = binding;
        CatalogRepository.getInstance().toggleSaved(room, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                room.setSavePending(false);
                if (binding != activeView) return;
                refresh();
            }
            @Override public void onError(ApiError error) {
                room.setSavePending(false);
                if (binding != activeView) return;
                adapter.notifyRoomSaveChanged(room);
                Toast.makeText(requireContext(), error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private void openRoom(RoomCard room) {
        if (room.getListingId() <= 0) {
            Toast.makeText(requireContext(), "Tin đã ẩn hoặc hết hạn. Bạn vẫn có thể bỏ lưu phòng.", Toast.LENGTH_LONG).show();
        } else open(RoomDetailFragment.newInstance(room));
    }
    private void open(Fragment next) {
        if (binding == null || getParentFragmentManager().isStateSaved()) return;
        getParentFragmentManager().beginTransaction().setReorderingAllowed(true)
                .replace(R.id.fragment_container, next).addToBackStack(null).commit();
    }
    @Override public void onDestroyView() {
        requestEpoch++;
        if (binding != null) binding.rvSavedRooms.setAdapter(null);
        adapter = null; binding = null;
        super.onDestroyView();
    }
}
