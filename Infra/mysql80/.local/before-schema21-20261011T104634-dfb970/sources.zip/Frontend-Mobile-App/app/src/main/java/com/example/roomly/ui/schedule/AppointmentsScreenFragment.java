package com.example.roomly.ui.schedule;
import android.widget.Button;
import android.widget.LinearLayout;
import androidx.appcompat.app.AlertDialog;
import com.example.roomly.data.remote.Jsons;
import com.example.roomly.data.model.ViewingRules;
import com.example.roomly.data.repository.ViewingRepository;
import com.example.roomly.ui.host.HostLabels;
import com.example.roomly.ui.host.HostScreenFragment;
import com.example.roomly.ui.host.viewing.HostViewingFragment;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
/** Host and tenant see their own server records and permitted state transitions. */
public abstract class AppointmentsScreenFragment extends HostScreenFragment {
    private final ViewingRepository repository=new ViewingRepository();
    private int page;
    protected abstract boolean isHost();
    @Override protected boolean hostOnly() {
        return isHost();
    }
    @Override protected String title() {
        return isHost()?"Yêu cầu xem phòng":"Lịch xem phòng của tôi";
    }
    @Override protected void render() {
        button("Tải lại",this::reload);
        error("Đang tải lịch hẹn…");
        repository.viewings(isHost(),page,callback(envelope-> {
            JSONArray rows=Jsons.items(envelope);
            error(rows.length()==0?"Chưa có lịch hẹn ở trang này.":"");
            for(int i=0;i<rows.length();i++) {
                JSONObject viewing=rows.optJSONObject(i);
                if(viewing==null)continue;
                long id=viewing.optLong("id");
                String state=viewing.optString("status");
                LinearLayout row=card("Lịch #"+id+" · Phòng #"+viewing.optLong("room_id")+"\n"+HostViewingFragment.format(viewing.optString("slot_start_at"))+" → "+HostViewingFragment.format(viewing.optString("slot_end_at"))+"\n"+HostLabels.viewing(state)+"\n"+viewing.optString("note",""));
                if(isHost()) {
                    android.widget.TextView tenant=new android.widget.TextView(requireContext());
                    tenant.setText("Người thuê #"+viewing.optLong("tenant_id"));
                    row.addView(tenant);
                    if("REQUESTED".equals(state))action(row,id,"confirm","Xác nhận lịch",state);
                    if("CONFIRMED".equals(state)&&hasStarted(viewing))action(row,id,"complete","Hoàn tất buổi xem",state);
                }
                if(("REQUESTED".equals(state)||"CONFIRMED".equals(state))&&(isHost()||canTenantCancel(viewing)))action(row,id,"cancel","Hủy lịch",state);
                else if(!isHost()&&("REQUESTED".equals(state)||"CONFIRMED".equals(state))) {
                    android.widget.TextView note=new android.widget.TextView(requireContext());
                    note.setText("Không thể hủy khi còn dưới 2 giờ trước lịch hẹn.");
                    row.addView(note);
                }
                String reason=viewing.optString("cancelled_reason","");
                if(!reason.isEmpty()&&!"null".equals(reason)) {
                    android.widget.TextView label=new android.widget.TextView(requireContext());
                    label.setText("Lý do hủy: "+reason);
                    row.addView(label);
                }
            }
            JSONObject paging=Jsons.data(envelope);
            text("Trang "+(page+1)+" / "+Math.max(1,paging.optInt("total_pages")));
            if(page>0)button("Trang trước",()-> {
                page--;
                reload();
            });
            if(page+1<paging.optInt("total_pages"))button("Trang tiếp",()-> {
                page++;
                reload();
            });
        }));
    }
    private void action(LinearLayout row,long id,String action,String label,String state) {
        final Button[] button=new Button[1];
        button[0]=cardButton(row,label,()->new AlertDialog.Builder(requireContext()).setMessage(label+" #"+id+"?").setNegativeButton("Để sau",null).setPositiveButton(label,(dialog,which)->repository.action(id,action,intentKey(action+id,id+":"+state),callback(button[0],envelope-> {
            finishIntent(action+id);
            reload();
        }))).show());
    }
    private boolean hasStarted(JSONObject viewing) {
        try {
            return ViewingRules.hostCanComplete(viewing.optString("status"),Instant.parse(viewing.optString("slot_start_at")),Instant.now());
        }catch(Exception invalid) {
            return false;
        }
    }
    private boolean canTenantCancel(JSONObject viewing) {
        try {
            return ViewingRules.tenantCanCancel(viewing.optString("status"),Instant.parse(viewing.optString("slot_start_at")),Instant.now());
        }catch(Exception invalid) {
            return false;
        }
    }
}
