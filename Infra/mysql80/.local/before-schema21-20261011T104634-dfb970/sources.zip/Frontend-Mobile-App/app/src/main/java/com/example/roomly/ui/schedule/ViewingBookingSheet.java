package com.example.roomly.ui.schedule;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import com.example.roomly.R;
import com.example.roomly.data.model.RoomCard;
import com.example.roomly.data.model.SessionState;
import com.example.roomly.data.model.ViewingRules;
import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiError;
import com.example.roomly.data.remote.Jsons;
import com.example.roomly.data.repository.SessionRepository;
import com.example.roomly.data.repository.ViewingRepository;
import com.example.roomly.ui.auth.LoginFragment;
import com.example.roomly.ui.auth.VerifyEmailFragment;
import com.example.roomly.ui.host.viewing.HostViewingFragment;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
/** Books a server-provided slot; the client never invents an available time. */
public class ViewingBookingSheet extends DialogFragment {
    private final ViewingRepository repository=new ViewingRepository();
    private TextView status;
    private RadioGroup choices;
    private EditText note;
    private long selectedSlot;
    private long generation;
    private String key;
    private String fingerprint;
    private boolean submitting;
    private String ownerId;
    public static void show(Fragment source, RoomCard room) {
        SessionState session=SessionRepository.getInstance().getCurrentSession();
        Fragment access=!session.isLoggedIn()?new LoginFragment():!session.isEmailVerified()?VerifyEmailFragment.newInstance(session.getEmail()):null;
        if(access!=null) {
            if(!source.getParentFragmentManager().isStateSaved())source.getParentFragmentManager().beginTransaction().replace(R.id.fragment_container,access).addToBackStack(null).commit();
            return;
        }
        if(String.valueOf(room.getHostId()).equals(session.getUserId())) {
            Toast.makeText(source.requireContext(),"Bạn không thể đặt lịch xem phòng của chính mình.",Toast.LENGTH_SHORT).show();
            return;
        }
        if(source.getParentFragmentManager().isStateSaved())return;
        if(source.getParentFragmentManager().findFragmentByTag("viewing_booking")!=null)return;
        ViewingBookingSheet sheet=new ViewingBookingSheet();
        Bundle args=new Bundle();
        args.putLong("room_id",room.getRoomId());
        args.putString("title",room.getTitle());
        sheet.setArguments(args);
        sheet.show(source.getParentFragmentManager(),"viewing_booking");
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        generation=SessionRepository.getInstance().getGeneration();
        ownerId=state==null?SessionRepository.getInstance().getCurrentSession().getUserId():state.getString("owner_id");
        if(state!=null) {
            key=state.getString("key");
            fingerprint=state.getString("fingerprint");
            selectedSlot=state.getLong("selected_slot");
        }
    }
    @NonNull @Override public Dialog onCreateDialog(Bundle state) {
        LinearLayout layout=new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        int padding=(int)(20*getResources().getDisplayMetrics().density);
        layout.setPadding(padding,padding,padding,padding);
        status=new TextView(requireContext());
        status.setText("Đang tải khung giờ…");
        layout.addView(status);
        choices=new RadioGroup(requireContext());
        layout.addView(choices);
        note=new EditText(requireContext());
        note.setHint("Lời nhắn cho chủ trọ (tối đa 1000 ký tự)");
        note.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        if(state!=null)note.setText(state.getString("note",""));
        layout.addView(note);
        android.widget.ScrollView scroll=new android.widget.ScrollView(requireContext());
        scroll.addView(layout);
        return new AlertDialog.Builder(requireContext()).setTitle("Hẹn xem: "+requireArguments().getString("title")).setView(scroll).setNegativeButton("Đóng",null).setPositiveButton("Gửi yêu cầu",null).create();
    }
    @Override public void onStart() {
        super.onStart();
        AlertDialog dialog=(AlertDialog)getDialog();
        if(dialog==null)return;
        SessionRepository.getInstance().getSessionState().observe(this,session-> {
            if(generation!=SessionRepository.getInstance().getGeneration()||ownerId==null||!ownerId.equals(session.getUserId()))dismissAllowingStateLoss();
        });
        if(ownerId==null||!ownerId.equals(SessionRepository.getInstance().getCurrentSession().getUserId()))return;
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view->book());
        loadSlots(dialog);
    }
    private boolean active(AlertDialog expected) {
        return isAdded()&&status!=null&&getDialog()==expected&&generation==SessionRepository.getInstance().getGeneration();
    }
    private void loadSlots(AlertDialog dialog) {
        repository.slots(requireArguments().getLong("room_id"),new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                if(!active(dialog))return;
                JSONArray slots=Jsons.items(envelope);
                choices.removeAllViews();
                int count=0;
                for(int i=0;i<slots.length();i++) {
                    JSONObject slot=slots.optJSONObject(i);
                    if(slot==null||!"OPEN".equals(slot.optString("status")))continue;
                    try {
                        if(!ViewingRules.bookable(slot.optString("status"),Instant.parse(slot.optString("start_at")),Instant.now()))continue;
                    }catch(Exception invalid) {
                        continue;
                    }
                    long id=slot.optLong("id");
                    RadioButton option=new RadioButton(requireContext());
                    option.setId(View.generateViewId());
                    option.setText(HostViewingFragment.format(slot.optString("start_at"))+" → "+HostViewingFragment.format(slot.optString("end_at")));
                    choices.addView(option);
                    count++;
                    if(selectedSlot==id) {
                        choices.check(option.getId());
                        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                    }
                    option.setOnClickListener(view-> {
                        selectedSlot=id;
                        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(!submitting);
                    });
                }
                status.setText(count==0?"Chưa có khung giờ có thể đặt. Chủ trọ cần mở lịch cách hiện tại ít nhất 24 giờ.":"Chọn một khung giờ. Lịch cần được chủ trọ xác nhận.");
            }
            @Override public void onError(ApiError error) {
                if(active(dialog))status.setText(error.getMessage());
            }
        });
    }
    private void book() {
        AlertDialog dialog=(AlertDialog)getDialog();
        if(dialog==null||!active(dialog)||submitting||selectedSlot<=0)return;
        SessionState session=SessionRepository.getInstance().getCurrentSession();
        if(!session.isLoggedIn()||!session.isEmailVerified()) {
            status.setText("Phiên đã thay đổi. Đăng nhập và xác minh email trước khi đặt lịch.");
            return;
        }
        String text=note.getText()==null?"":note.getText().toString().trim();
        if(text.length()>1000) {
            status.setText("Lời nhắn tối đa 1000 ký tự.");
            return;
        }
        String payload=selectedSlot+":"+text;
        if(!payload.equals(fingerprint)) {
            fingerprint=payload;
            key=UUID.randomUUID().toString();
        }
        submitting=true;
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setEnabled(false);
        setCancelable(false);
        status.setText("Đang gửi yêu cầu…");
        repository.book(selectedSlot,text,key,new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                if(!active(dialog))return;
                submitting=false;
                Toast.makeText(requireContext(),"Đã gửi yêu cầu. Chờ chủ trọ xác nhận.",Toast.LENGTH_LONG).show();
                if(!getParentFragmentManager().isStateSaved())getParentFragmentManager().beginTransaction().replace(R.id.fragment_container,new ScheduleFragment()).addToBackStack(null).commit();
                dismissAllowingStateLoss();
            }
            @Override public void onError(ApiError error) {
                if(!active(dialog))return;
                submitting=false;
                setCancelable(true);
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setEnabled(true);
                status.setText(error.getMessage());
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                if(error.getStatusCode()==409 && !"IDEMPOTENCY_IN_PROGRESS".equals(error.getCode())) {
                    selectedSlot=0;
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                    loadSlots(dialog);
                }
            }
        });
    }
    @Override public void onSaveInstanceState(@NonNull Bundle out) {
        out.putString("owner_id",ownerId);
        out.putString("key",key);
        out.putString("fingerprint",fingerprint);
        out.putLong("selected_slot",selectedSlot);
        out.putString("note",note==null||note.getText()==null?"":note.getText().toString());
        super.onSaveInstanceState(out);
    }
    @Override public void onDestroyView() {
        status=null;
        choices=null;
        note=null;
        super.onDestroyView();
    }
}
