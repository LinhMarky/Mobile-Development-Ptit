package com.example.roomly.data.model;

import org.junit.Test;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import static org.junit.Assert.*;

public class ViewingRulesTest {
    private final Instant now = Instant.parse("2026-10-10T00:00:00Z");

    @Test public void bookingIncludesExact24HourBoundary() {
        assertTrue(ViewingRules.bookable("OPEN", now.plus(24, ChronoUnit.HOURS), now));
        assertFalse(ViewingRules.bookable("OPEN", now.plus(24, ChronoUnit.HOURS).minusMillis(1), now));
    }

    @Test public void bookingRejectsClosedAndBookedSlots() {
        Instant future = now.plus(3, ChronoUnit.DAYS);
        assertFalse(ViewingRules.bookable("CANCELLED", future, now));
        assertFalse(ViewingRules.bookable("BOOKED", future, now));
    }

    @Test public void tenantCancellationIncludesExact2HourBoundary() {
        Instant starts = now.plus(2, ChronoUnit.HOURS);
        assertTrue(ViewingRules.tenantCanCancel("REQUESTED", starts, now));
        assertTrue(ViewingRules.tenantCanCancel("CONFIRMED", starts, now));
        assertFalse(ViewingRules.tenantCanCancel("CONFIRMED", starts.minusMillis(1), now));
    }

    @Test public void terminalViewingCannotBeCancelled() {
        Instant future = now.plus(3, ChronoUnit.DAYS);
        for (String state : new String[]{"COMPLETED", "CANCELLED_BY_HOST", "CANCELLED_BY_TENANT", "NO_SHOW"}) {
            assertFalse(ViewingRules.tenantCanCancel(state, future, now));
        }
    }

    @Test public void hostCompletionRequiresConfirmedAndStarted() {
        assertTrue(ViewingRules.hostCanComplete("CONFIRMED", now, now));
        assertTrue(ViewingRules.hostCanComplete("CONFIRMED", now.minusMillis(1), now));
        assertFalse(ViewingRules.hostCanComplete("CONFIRMED", now.plusMillis(1), now));
        assertFalse(ViewingRules.hostCanComplete("REQUESTED", now.minusMillis(1), now));
        assertFalse(ViewingRules.hostCanComplete("COMPLETED", now.minusMillis(1), now));
    }
}
