package com.example.roomly.data.repository;
import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiClient;
import com.example.roomly.data.remote.Jsons;
import org.json.JSONObject;
import org.json.JSONArray;
import com.example.roomly.data.remote.ApiError;
/** Host endpoints. No local records are treated as persisted server data. */
public final class HostRepository {
    private final ApiClient api = ApiClient.getInstance();
    public void rooms(int page, ApiCallback callback) {
        api.get("/rooms?page=" + page + "&size=20", true, callback);
    }
    public void room(String id, ApiCallback callback) {
        api.get("/rooms/" + id, true, callback);
    }
    public void saveRoom(String id, JSONObject body, String key, ApiCallback callback) {
        api.request(id == null ? "POST" : "PATCH", id == null ? "/rooms" : "/rooms/" + id,
        body, true, id == null ? key : null, callback);
    }
    public void listings(int page, ApiCallback callback) {
        api.get("/listings/my?page=" + page + "&size=20", true, callback);
    }
    /** Own drafts are intentionally resolved through /my, never the public detail route. */
    public void findListing(String id, ApiCallback callback) {
        findListing(id, 0, callback);
    }
    private void findListing(String id, int page, ApiCallback callback) {
        listings(page, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                JSONArray rows = Jsons.items(envelope);
                for (int i=0; i<rows.length(); i++) {
                    JSONObject listing = rows.optJSONObject(i);
                    if (listing != null && id.equals(listing.optString("id"))) {
                        callback.onSuccess(Jsons.body("data", listing));
                        return;
                    }
                }
                JSONObject paging = Jsons.data(envelope);
                if (page + 1 < paging.optInt("total_pages")) findListing(id, page+1, callback);
                else callback.onSuccess(Jsons.body("data", new JSONObject()));
            }
            @Override public void onError(ApiError error) {
                callback.onError(error);
            }
        });
    }
    public void saveListing(String id, String roomId, JSONObject body, String key, ApiCallback callback) {
        api.request(id == null ? "POST" : "PATCH",
        id == null ? "/listings/room/" + roomId : "/listings/" + id,
        body, true, id == null ? key : null, callback);
    }
    public void listingAction(String id, String action, String key, ApiCallback callback) {
        api.request("POST", "/listings/" + id + "/" + action, Jsons.body(), true, key, callback);
    }
    public void media(String roomId, ApiCallback callback) {
        api.get("/media/room/" + roomId, true, callback);
    }
    public void attach(String roomId, long mediaId, String key, ApiCallback callback) {
        org.json.JSONArray ids = new org.json.JSONArray();
        ids.put(mediaId);
        api.request("POST", "/media/attach/room/" + roomId,
        Jsons.body("media_ids", ids), true, key, callback);
    }
    public void deleteMedia(long mediaId, ApiCallback callback) {
        api.request("DELETE", "/media/" + mediaId, null, true, null, callback);
    }
}
