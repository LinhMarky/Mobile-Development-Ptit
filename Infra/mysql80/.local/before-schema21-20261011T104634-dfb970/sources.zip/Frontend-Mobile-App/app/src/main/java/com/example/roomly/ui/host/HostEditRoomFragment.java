package com.example.roomly.ui.host;
import android.os.Bundle;
public class HostEditRoomFragment extends RoomFormFragment {
    public static HostEditRoomFragment newInstance(String roomId) {
        HostEditRoomFragment fragment=new HostEditRoomFragment();
        Bundle args=new Bundle();
        args.putString("room_id",roomId);
        fragment.setArguments(args);
        return fragment;
    }
}
