package com.example.roomly.push;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiClient;
import com.example.roomly.data.remote.ApiError;
import com.example.roomly.data.remote.Jsons;
import com.example.roomly.data.repository.AuthRepository;
import com.example.roomly.data.repository.SessionRepository;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;
import java.util.Objects;

/** One registration at a time, bound to both the account and installation. */
public final class PushTokenRepository {
    private static final PushTokenRepository INSTANCE = new PushTokenRepository();
    public static PushTokenRepository getInstance() { return INSTANCE; }
    private final Handler main = new Handler(Looper.getMainLooper());
    private final MutableLiveData<String> status = new MutableLiveData<>("Đang chuẩn bị thông báo…");
    private Context context;
    private SharedPreferences preferences;
    private String token = "";
    private String observedUser;
    private String registeredUser;
    private String registeredToken;
    private long observedGeneration = -1;
    private boolean registering, fetching, paused;
    private int retryCount;
    private Runnable retryTask, logoutContinuation;

    public static void initialize(Context source) {
        INSTANCE.main.post(() -> {
            if (INSTANCE.context == null) {
                INSTANCE.context = source.getApplicationContext();
                INSTANCE.preferences = INSTANCE.context.getSharedPreferences("roomly_push", Context.MODE_PRIVATE);
                INSTANCE.token = INSTANCE.preferences.getString("token", "");
            }
            INSTANCE.onSessionChanged();
        });
    }
    public LiveData<String> getStatus() { return status; }

    public void onNewToken(String newToken) {
        main.post(() -> {
            if (context == null || newToken == null || newToken.isEmpty()) return;
            if (!newToken.equals(token)) {
                token = newToken;
                preferences.edit().putString("token", token).apply();
                retryCount = 0; registeredToken = null;
            }
            registerIfNeeded();
        });
    }
    public void onSessionChanged() {
        if (Looper.myLooper() != Looper.getMainLooper()) { main.post(this::onSessionChanged); return; }
        if (context == null) return;
        SessionRepository session = SessionRepository.getInstance();
        String user = session.getCurrentSession().getUserId();
        if (!Objects.equals(observedUser, user) || observedGeneration != session.getGeneration()) {
            observedUser = user; observedGeneration = session.getGeneration();
            registeredUser = null; registeredToken = null; retryCount = 0;
            if (retryTask != null) { main.removeCallbacks(retryTask); retryTask = null; }
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            if (manager != null) manager.cancelAll();
        }
        if (user == null) { status.setValue("Đăng nhập để nhận thông báo cá nhân."); return; }
        if (!firebaseAvailable()) { status.setValue("Chưa có cấu hình Firebase cho bản ứng dụng này."); return; }
        if (!token.isEmpty()) registerIfNeeded();
        fetchToken();
    }
    private boolean firebaseAvailable() {
        try { return !FirebaseApp.getApps(context).isEmpty(); }
        catch (IllegalStateException ignored) { return false; }
    }
    private void fetchToken() {
        if (fetching || paused || !firebaseAvailable()) return;
        fetching = true;
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            fetching = false;
            if (task.isSuccessful() && task.getResult() != null) onNewToken(task.getResult());
            else {
                if (SessionRepository.getInstance().getCurrentSession().isLoggedIn()) {
                    status.setValue("Chưa lấy được mã thiết bị. Sẽ thử lại khi có mạng."); scheduleRetry();
                }
            }
        });
    }
    private void registerIfNeeded() {
        SessionRepository session = SessionRepository.getInstance();
        String user = session.getCurrentSession().getUserId();
        if (context == null || paused || registering || user == null || token.isEmpty()) return;
        if (Objects.equals(registeredUser, user) && token.equals(registeredToken)) { renderRegistered(); return; }
        registering = true;
        String expectedToken = token; long generation = session.getGeneration();
        status.setValue("Đang đăng ký thông báo với máy chủ…");
        ApiClient.getInstance().request("PUT", "/profile/device-token",
                Jsons.body("token", token, "platform", "ANDROID", "deviceName", AuthRepository.deviceName(),
                        "installationId", session.getInstallationId()), true, null, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                registering = false;
                boolean current = generation == session.getGeneration()
                        && Objects.equals(user, session.getCurrentSession().getUserId());
                if (current && expectedToken.equals(token)) {
                    registeredUser = user; registeredToken = expectedToken; retryCount = 0;
                    renderRegistered();
                }
                completeLogoutOrContinue();
            }
            @Override public void onError(ApiError error) {
                registering = false;
                if (generation == session.getGeneration() && !paused) {
                    status.setValue("Chưa đăng ký được thông báo: " + error.getMessage());
                    scheduleRetry();
                }
                completeLogoutOrContinue();
            }
        });
    }
    private void completeLogoutOrContinue() {
        if (logoutContinuation != null) {
            Runnable action = logoutContinuation; logoutContinuation = null; action.run();
        } else if (!paused && (!Objects.equals(registeredUser, SessionRepository.getInstance().getCurrentSession().getUserId())
                || !Objects.equals(registeredToken, token))) {
            // Retry an account/token switch after the previous request has completed.
            if (retryTask == null) main.post(this::registerIfNeeded);
        }
    }
    private void renderRegistered() {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            status.setValue("Thiết bị đã đăng ký. Hãy cho phép thông báo trong cài đặt điện thoại.");
        } else if (!context.getSystemService(NotificationManager.class).areNotificationsEnabled()) {
            status.setValue("Thiết bị đã đăng ký nhưng thông báo đang bị tắt trong cài đặt.");
        } else status.setValue("Đã đăng ký thông báo. Chờ sự kiện thật từ máy chủ.");
    }
    private void scheduleRetry() {
        if (paused || !SessionRepository.getInstance().getCurrentSession().isLoggedIn()) return;
        if (retryTask != null) main.removeCallbacks(retryTask);
        long delay = Math.min(60_000, 2000L << Math.min(retryCount++, 5));
        retryTask = () -> { retryTask = null; registerIfNeeded(); fetchToken(); };
        main.postDelayed(retryTask, delay);
    }

    /** Logout must follow any token PUT already in flight, so it cannot re-enable the device afterwards. */
    public void beginLogout(Runnable continuation) {
        if (Looper.myLooper() != Looper.getMainLooper()) { main.post(() -> beginLogout(continuation)); return; }
        paused = true;
        if (retryTask != null) { main.removeCallbacks(retryTask); retryTask = null; }
        if (registering) logoutContinuation = continuation; else continuation.run();
    }
    public void endLogout(boolean success) {
        paused = false; logoutContinuation = null;
        if (success) { registeredUser = null; registeredToken = null; }
        onSessionChanged();
    }
}
