package com.example.roomly.data.repository;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import com.example.roomly.data.model.ChatMessage;
import com.example.roomly.data.model.Conversation;
import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiClient;
import com.example.roomly.data.remote.ApiError;
import com.example.roomly.data.remote.Jsons;
import com.example.roomly.ui.messages.ChatSocket;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

/** REST owns history. STOMP is an additional channel; receipts never mean saved. */
public final class ChatRepository {
    public interface Result<T> { void onSuccess(T value); void onError(String message); }
    public interface Listener {
        void onConversation(Conversation conversation);
        void onMessages(List<ChatMessage> messages, boolean hasOlder);
        void onStatus(String message, boolean canSend, String pendingContent);
        void onAcknowledged(String content);
    }

    private static final ChatRepository INSTANCE = new ChatRepository();
    public static ChatRepository getInstance() { return INSTANCE; }
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, Channel> channels = new HashMap<>();
    private final Map<Long, String> openKeys = new HashMap<>();
    private String owner;
    private long generation = -1;
    private Channel active;
    private SharedPreferences pendingStore;

    /** Keep operation UUIDs across process death; never persist a claim that a message was delivered. */
    public static void initialize(Context context) {
        INSTANCE.pendingStore = context.getApplicationContext().getSharedPreferences("roomly_chat_pending", Context.MODE_PRIVATE);
        INSTANCE.onSessionChanged();
    }

    public void onSessionChanged() {
        SessionRepository session = SessionRepository.getInstance();
        String next = session.getCurrentSession().getUserId();
        if (java.util.Objects.equals(owner, next) && generation == session.getGeneration()) return;
        if (active != null) active.stop();
        active = null; channels.clear(); openKeys.clear();
        owner = next; generation = session.getGeneration();
        restorePending();
    }

    private void restorePending() {
        if (pendingStore == null) return;
        if (owner == null || !owner.equals(pendingStore.getString("owner", ""))) {
            pendingStore.edit().clear().apply(); return;
        }
        try {
            JSONArray stored = new JSONArray(pendingStore.getString("operations", "[]"));
            for (int index = 0; index < Math.min(stored.length(), 50); index++) {
                JSONObject body = stored.optJSONObject(index);
                if (body == null || body.optLong("conversation_id") <= 0
                        || body.optString("content").trim().isEmpty() || body.optString("content").length() > 5000) continue;
                UUID.fromString(body.optString("client_message_id"));
                String id = String.valueOf(body.optLong("conversation_id"));
                channels.computeIfAbsent(id, Channel::new).pending = body;
            }
        } catch (Exception ignored) { pendingStore.edit().clear().apply(); }
    }
    private boolean savePending() {
        if (pendingStore == null || owner == null) return false;
        JSONArray operations = new JSONArray();
        for (Channel channel : channels.values()) if (channel.pending != null) operations.put(channel.pending);
        // Commit precedes SEND, otherwise process death could lose the UUID of an accepted message.
        return pendingStore.edit().putString("owner", owner).putString("operations", operations.toString()).commit();
    }

    public void openConversation(long roomId, ApiCallback callback) {
        onSessionChanged();
        String key = openKeys.computeIfAbsent(roomId, ignored -> UUID.randomUUID().toString());
        long expected = generation;
        ApiClient.getInstance().request("POST", "/conversations", Jsons.body("room_id", roomId),
                true, key, new ApiCallback() {
                    @Override public void onSuccess(JSONObject envelope) {
                        if (expected != SessionRepository.getInstance().getGeneration()) return;
                        openKeys.remove(roomId); callback.onSuccess(envelope);
                    }
                    @Override public void onError(ApiError error) {
                        if (expected != SessionRepository.getInstance().getGeneration()) return;
                        // Keep the key when network or PROCESSING makes the outcome uncertain.
                        if (error.getStatusCode() >= 400 && error.getStatusCode() < 500
                                && error.getStatusCode() != 409) openKeys.remove(roomId);
                        callback.onError(error);
                    }
                });
    }

    public void list(int page, Result<ConversationPage> callback) {
        onSessionChanged();
        String user = owner; long expected = generation;
        ApiClient.getInstance().get("/conversations?page=" + page + "&size=20", true, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                if (expected != SessionRepository.getInstance().getGeneration()) return;
                JSONArray items = Jsons.items(envelope);
                List<Conversation> conversations = new ArrayList<>();
                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.optJSONObject(i);
                    if (item != null && item.optLong("id") > 0) conversations.add(new Conversation(item, user));
                }
                JSONObject data = Jsons.data(envelope);
                callback.onSuccess(new ConversationPage(conversations,
                        (page + 1L) * 20 < data.optLong("total_elements", conversations.size())));
            }
            @Override public void onError(ApiError error) {
                if (expected == SessionRepository.getInstance().getGeneration()) callback.onError(error.getMessage());
            }
        });
    }

    public static final class ConversationPage {
        public final List<Conversation> items;
        public final boolean hasMore;
        ConversationPage(List<Conversation> items, boolean hasMore) { this.items = items; this.hasMore = hasMore; }
    }

    public void attach(String conversationId, Listener listener) {
        onSessionChanged();
        if (owner == null) { listener.onStatus("Đăng nhập để xem hội thoại.", false, null); return; }
        if (active != null) active.stop();
        Channel channel = channels.computeIfAbsent(conversationId, Channel::new);
        active = channel; channel.listener = listener; channel.epoch++;
        channel.publish(); channel.loadDetail();
        if (!channel.initialLoaded) channel.loadLatest();
        channel.connect();
    }

    public void detach(Listener listener) {
        if (active != null && active.listener == listener) { active.stop(); active = null; }
    }
    public void loadOlder(String id) { if (active != null && active.id.equals(id)) active.loadOlder(); }
    public void reconnect(String id) {
        if (active != null && active.id.equals(id)) {
            if (!active.initialLoaded) active.loadLatest();
            if (active.ready) active.syncAfter(); else active.connect();
        }
    }
    public void send(String id, String content) {
        if (active == null || !active.id.equals(id)) return;
        Channel channel = active;
        if (channel.pending != null) {
            channel.status("Đang kiểm tra tin chưa được xác nhận. Bản nháp mới được giữ nguyên.");
            reconnect(id); return;
        }
        if (!channel.ready || !channel.initialLoaded || channel.syncing) {
            channel.status("Chờ kết nối và đồng bộ lịch sử trước khi gửi."); return;
        }
        if (content.trim().isEmpty() || content.length() > 5000) return;
        channel.pending = Jsons.body("conversation_id", Long.parseLong(id), "content", content,
                "client_message_id", UUID.randomUUID().toString(), "content_type", "TEXT");
        channel.transmitPending();
    }

    private final class Channel {
        final String id;
        final String user = owner;
        final long accountGeneration = generation;
        final TreeMap<Long, ChatMessage> messages = new TreeMap<>();
        Listener listener;
        Conversation conversation;
        ChatSocket socket;
        boolean ready, initialLoaded, loading, syncing, hasOlder;
        Long olderCursor;
        long restWatermark;
        long markedRead;
        int epoch, retry;
        JSONObject pending;
        Runnable reconnectTask, pendingTimeout;
        String status = "Đang tải hội thoại…";

        Channel(String id) { this.id = id; }
        boolean valid(int expectedEpoch) {
            return active == this && listener != null && epoch == expectedEpoch
                    && accountGeneration == SessionRepository.getInstance().getGeneration()
                    && java.util.Objects.equals(user, SessionRepository.getInstance().getCurrentSession().getUserId());
        }
        void stop() {
            epoch++; listener = null; ready = false; loading = false; syncing = false;
            if (socket != null) socket.close(); socket = null;
            if (reconnectTask != null) main.removeCallbacks(reconnectTask);
            if (pendingTimeout != null) main.removeCallbacks(pendingTimeout);
        }
        void status(String text) { status = text; publish(); }
        void publish() {
            if (listener == null) return;
            if (conversation != null) listener.onConversation(conversation);
            listener.onMessages(new ArrayList<>(messages.values()), hasOlder && !loading);
            listener.onStatus(status, ready && initialLoaded && !syncing && pending == null,
                    pending == null ? null : pending.optString("content"));
        }
        void loadDetail() {
            int expected = epoch;
            ApiClient.getInstance().get("/conversations/" + id, true, new ApiCallback() {
                @Override public void onSuccess(JSONObject envelope) {
                    if (!valid(expected)) return;
                    conversation = new Conversation(Jsons.data(envelope), user); publish();
                }
                @Override public void onError(ApiError error) { if (valid(expected)) status(error.getMessage()); }
            });
        }
        void loadLatest() {
            if (loading) return;
            loading = true; int expected = epoch;
            ApiClient.getInstance().get("/conversations/" + id + "/messages?limit=50", true, new ApiCallback() {
                @Override public void onSuccess(JSONObject envelope) {
                    if (!valid(expected)) return;
                    loading = false; initialLoaded = true;
                    JSONObject data = Jsons.data(envelope);
                    JSONArray items = Jsons.items(envelope);
                    merge(items, true);
                    hasOlder = data.optBoolean("has_more");
                    olderCursor = data.isNull("next_cursor") ? null : data.optLong("next_cursor");
                    status = ready ? "Đã kết nối" : "Đang kết nối…";
                    publish();
                    if (ready) syncAfter();
                }
                @Override public void onError(ApiError error) {
                    if (!valid(expected)) return;
                    loading = false; status(error.getMessage() + " Bấm Kết nối lại để thử.");
                }
            });
        }
        void loadOlder() {
            if (loading || !hasOlder || olderCursor == null) return;
            loading = true; publish(); int expected = epoch;
            ApiClient.getInstance().get("/conversations/" + id + "/messages?limit=50&before_sequence="
                    + olderCursor, true, new ApiCallback() {
                @Override public void onSuccess(JSONObject envelope) {
                    if (!valid(expected)) return;
                    loading = false; JSONObject data = Jsons.data(envelope);
                    merge(Jsons.items(envelope), false);
                    hasOlder = data.optBoolean("has_more");
                    olderCursor = data.isNull("next_cursor") ? null : data.optLong("next_cursor");
                    publish();
                }
                @Override public void onError(ApiError error) {
                    if (valid(expected)) { loading = false; status(error.getMessage()); }
                }
            });
        }
        void connect() {
            if (socket != null) socket.close();
            if (reconnectTask != null) main.removeCallbacks(reconnectTask);
            ready = false; int expected = epoch; status("Đang kết nối…");
            socket = new ChatSocket(new ChatSocket.Listener() {
                @Override public void onReady() {
                    if (!valid(expected)) return;
                    ready = true; retry = 0;
                    if (initialLoaded) syncAfter(); else publish();
                }
                @Override public void onMessage(JSONObject json, boolean ack) {
                    if (!valid(expected) || json.optLong("conversation_id") != Long.parseLong(id)) return;
                    ChatMessage message = new ChatMessage(json, user);
                    mergeMessage(message);
                    if (ack) acknowledge(message);
                    publish();
                    // REST watermark is separate: a realtime event must not skip missing sequences.
                    syncAfter();
                }
                @Override public void onProblem(String message) {
                    if (!valid(expected)) return;
                    // The error has no guaranteed UUID correlation; retain the pending operation.
                    status(message + (pending == null ? "" : " Tin chưa xác nhận được giữ lại để đối chiếu."));
                }
                @Override public void onDisconnected(boolean auth) {
                    if (!valid(expected)) return;
                    ready = false;
                    status("Mất kết nối. Đang thử kết nối lại; tin chưa xác nhận vẫn được giữ.");
                    scheduleReconnect(auth);
                }
            });
            socket.connect();
        }
        void scheduleReconnect(boolean authenticationRequired) {
            if (reconnectTask != null) main.removeCallbacks(reconnectTask);
            int expected = epoch;
            long delay = Math.min(30_000, 1000L << Math.min(retry++, 5));
            reconnectTask = () -> {
                if (!valid(expected)) return;
                // This normal authenticated request refreshes an expired access token before a new handshake.
                ApiClient.getInstance().get("/profile", true, new ApiCallback() {
                    @Override public void onSuccess(JSONObject envelope) { if (valid(expected)) connect(); }
                    @Override public void onError(ApiError error) {
                        if (!valid(expected)) return;
                        status(error.getMessage()); scheduleReconnect(false);
                    }
                });
            };
            main.postDelayed(reconnectTask, delay);
        }
        void syncAfter() {
            if (!initialLoaded || syncing || !ready) return;
            syncing = true; publish(); syncPage(restWatermark);
        }
        void syncPage(long after) {
            int expected = epoch;
            ApiClient.getInstance().get("/conversations/" + id + "/messages?limit=50&after_sequence=" + after,
                    true, new ApiCallback() {
                @Override public void onSuccess(JSONObject envelope) {
                    if (!valid(expected)) return;
                    JSONArray items = Jsons.items(envelope);
                    merge(items, true);
                    boolean more = Jsons.data(envelope).optBoolean("has_more");
                    if (more && restWatermark > after) { syncPage(restWatermark); return; }
                    syncing = false; status = "Đã kết nối"; publish(); markRead();
                    if (pending != null) transmitPending();
                }
                @Override public void onError(ApiError error) {
                    if (!valid(expected)) return;
                    syncing = false; status(error.getMessage() + " Bấm Kết nối lại để đồng bộ.");
                }
            });
        }
        void merge(JSONArray items, boolean advanceRestWatermark) {
            for (int i = 0; i < items.length(); i++) {
                JSONObject json = items.optJSONObject(i);
                if (json == null) continue;
                ChatMessage message = new ChatMessage(json, user);
                mergeMessage(message); acknowledge(message);
                if (advanceRestWatermark) restWatermark = Math.max(restWatermark, message.getSequence());
            }
        }
        void mergeMessage(ChatMessage message) {
            if (message.getId() > 0 && message.getSequence() > 0
                    && message.getConversationId() == Long.parseLong(id)) messages.put(message.getSequence(), message);
        }
        void acknowledge(ChatMessage message) {
            if (pending == null || !message.isSentByMe()
                    || !pending.optString("client_message_id").equals(message.getClientMessageId())) return;
            String content = pending.optString("content"); pending = null;
            savePending();
            if (pendingTimeout != null) main.removeCallbacks(pendingTimeout);
            status = "Đã kết nối";
            if (listener != null) listener.onAcknowledged(content);
        }
        void transmitPending() {
            if (pending == null || !ready || socket == null) return;
            if (!savePending()) {
                status("Chưa lưu được mã gửi trên thiết bị. Tin chưa được gửi; hãy kiểm tra bộ nhớ rồi thử lại."); return;
            }
            if (!socket.send(pending)) {
                ready = false; status("Chưa gửi được tin. Đang kết nối lại…"); scheduleReconnect(false); return;
            }
            status("Đang chờ máy chủ xác nhận tin nhắn…");
            if (pendingTimeout != null) main.removeCallbacks(pendingTimeout);
            int expected = epoch;
            pendingTimeout = () -> {
                if (valid(expected) && pending != null) {
                    status("Tin chưa được xác nhận. Bấm Kết nối lại để kiểm tra và gửi lại cùng mã tin.");
                }
            };
            main.postDelayed(pendingTimeout, 12_000);
        }
        void markRead() {
            if (messages.isEmpty()) return;
            long last = messages.lastKey();
            if (last <= markedRead) return;
            int expected = epoch;
            ApiClient.getInstance().request("POST", "/conversations/" + id + "/read-marker",
                    Jsons.body("last_read_sequence", last), true, UUID.randomUUID().toString(), new ApiCallback() {
                @Override public void onSuccess(JSONObject envelope) {
                    if (valid(expected)) markedRead = Math.max(markedRead, last);
                }
                @Override public void onError(ApiError error) { /* Retry when the conversation is next synchronized. */ }
            });
        }
    }
}
