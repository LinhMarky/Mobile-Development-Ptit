package com.example.roomly.ui.host;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import com.example.roomly.data.remote.ApiClient;
import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiError;
import com.example.roomly.data.remote.Jsons;
import com.example.roomly.data.remote.RoomImageLoader;
import com.example.roomly.data.repository.HostRepository;
import com.example.roomly.ui.host.viewing.HostViewingFragment;
import org.json.JSONArray;
import org.json.JSONObject;
public class HostRoomDetailFragment extends HostScreenFragment {
    private final HostRepository repository=new HostRepository();
    private long pendingMediaId;
    private boolean uploading;
    private Button uploadButton;
    private final ActivityResultLauncher<String[]> picker=registerForActivityResult(new ActivityResultContracts.OpenDocument(),this::uploadPhoto);
    public static HostRoomDetailFragment newInstance(String id) {
        HostRoomDetailFragment fragment=new HostRoomDetailFragment();
        Bundle args=new Bundle();
        args.putString("room_id",id);
        fragment.setArguments(args);
        return fragment;
    }
    private String id() {
        return requireArguments().getString("room_id");
    }
    @Override protected String title() {
        return "Chi tiết phòng";
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        if(saved!=null)pendingMediaId=saved.getLong("pending_media_id");
    }
    @Override protected void render() {
        error("Đang tải phòng…");
        repository.room(id(),callback(envelope-> {
            JSONObject room=Jsons.data(envelope),address=Jsons.object(room,"address"),location=Jsons.object(room,"location");
            error("");
            text("Phòng "+room.optString("unit_code"));
            text(address.optString("line")+", "+address.optString("province_name"));
            text(room.optString("area_m2")+" m² · "+room.optInt("max_occupants")+" người tối đa\n"+HostLabels.availability(room.optString("availability")));
            text("Vị trí: "+location.optString("latitude")+", "+location.optString("longitude"));
            JSONArray amenities=Jsons.array(room,"amenities");
            StringBuilder names=new StringBuilder();
            for(int i=0;i<amenities.length();i++) {
                JSONObject item=amenities.optJSONObject(i);
                if(item!=null) {
                    if(names.length()>0)names.append(", ");
                    names.append(item.optString("name"));
                }
            }
            text("Tiện ích: "+(names.length()==0?"Chưa chọn":names));
            button("Sửa thông tin phòng",()->open(HostEditRoomFragment.newInstance(id())));
            button("Tạo bài đăng",()->open(HostCreateListingFragment.newInstance(id())));
            button("Bài đăng của tôi",()->open(new HostListingsFragment()));
            button("Khung giờ xem phòng",()->open(HostViewingFragment.newInstance(id())));
            uploadButton=button("Thêm ảnh (JPEG, PNG)",()->picker.launch(new String[] {
                "image/jpeg","image/png"
            }));
            uploadButton.setEnabled(!uploading);
            if(pendingMediaId>0)button("Gắn lại ảnh đã tải lên",this::attachPending);
            button("Ảnh đã tải lên chưa gắn",this::recoverReadyPhotos);
            button("Tải lại",this::reload);
            button("Quay lại",this::back);
            loadMedia();
        }));
    }
    private void loadMedia() {
        repository.media(id(),callback(envelope-> {
            JSONArray media=Jsons.items(envelope);
            text("Ảnh phòng ("+media.length()+")");
            for(int i=0;i<media.length();i++) {
                JSONObject row=media.optJSONObject(i);
                if(row==null)continue;
                long mediaId=row.optLong("id");
                LinearLayout card=card(row.optString("original_filename","Ảnh phòng"));
                ImageView image=new ImageView(requireContext());
                image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                card.addView(image,new LinearLayout.LayoutParams(-1,dp(180)));
                RoomImageLoader.load(image,ApiClient.getInstance().mediaUrl(mediaId));
                cardButton(card,"Xóa ảnh",()->new AlertDialog.Builder(requireContext()).setMessage("Xóa ảnh này khỏi phòng?").setNegativeButton("Giữ lại",null).setPositiveButton("Xóa",(dialog,which)->repository.deleteMedia(mediaId,callback(result->reload()))).show());
            }
        }));
    }
    private void uploadPhoto(Uri uri) {
        if(uri==null||content==null||uploading)return;
        try {
            requireContext().getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }catch(SecurityException ignored) {
            /* Current grant can still read this upload. */
        }
        uploading=true;
        error("Đang tải ảnh lên…");
        ApiCallback guarded=callback(uploadButton,envelope-> {
            pendingMediaId=Jsons.data(envelope).optLong("id");
            attachPending();
        });
        ApiClient.getInstance().upload(uri,"ROOM_PHOTO",new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                uploading=false;
                guarded.onSuccess(envelope);
            }
            @Override public void onError(ApiError error) {
                uploading=false;
                guarded.onError(error);
            }
        });
    }
    private void attachPending() {
        if(pendingMediaId<=0) {
            error("Chưa nhận được mã ảnh từ máy chủ.");
            return;
        }
        long mediaId=pendingMediaId;
        error("Đang gắn ảnh vào phòng…");
        repository.attach(id(),mediaId,intentKey("attach",id()+":"+mediaId),callback(uploadButton,envelope-> {
            pendingMediaId=0;
            finishIntent("attach");
            reload();
        }));
    }
    private void recoverReadyPhotos() {
        ApiClient.getInstance().get("/media/my?purpose=ROOM_PHOTO",true,callback(envelope-> {
            JSONArray rows=Jsons.items(envelope);
            if(rows.length()==0) {
                error("Không có ảnh đang chờ gắn.");
                return;
            }
            String[] names=new String[rows.length()];
            for(int i=0;i<rows.length();i++) {
                JSONObject row=rows.optJSONObject(i);
                names[i]=row==null?"Ảnh":row.optString("original_filename","Ảnh")+" (#"+row.optLong("id")+")";
            }
            new AlertDialog.Builder(requireContext()).setTitle("Gắn ảnh đã tải lên").setItems(names,(dialog,index)-> {
                JSONObject row=rows.optJSONObject(index);
                if(row!=null) {
                    pendingMediaId=row.optLong("id");
                    attachPending();
                }
            }).setNegativeButton("Đóng",null).show();
        }));
    }
    @Override protected void clearPrivateState() {
        pendingMediaId=0;
        uploading=false;
    }
    @Override public void onSaveInstanceState(Bundle out) {
        out.putLong("pending_media_id",pendingMediaId);
        super.onSaveInstanceState(out);
    }
    @Override public void onDestroyView() {
        uploadButton=null;
        super.onDestroyView();
    }
}
