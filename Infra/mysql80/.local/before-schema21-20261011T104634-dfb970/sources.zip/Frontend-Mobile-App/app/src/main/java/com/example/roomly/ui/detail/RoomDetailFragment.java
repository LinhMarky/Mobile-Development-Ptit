package com.example.roomly.ui.detail;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.example.roomly.R;
import com.example.roomly.data.model.RoomCard;
import com.example.roomly.data.model.UserRole;
import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiError;
import com.example.roomly.data.remote.Jsons;
import com.example.roomly.data.remote.RoomImageLoader;
import com.example.roomly.data.repository.CatalogRepository;
import com.example.roomly.data.repository.ChatRepository;
import com.example.roomly.data.repository.SessionAccess;
import com.example.roomly.data.repository.SessionRepository;
import com.example.roomly.databinding.FragmentRoomDetailBinding;
import com.example.roomly.ui.auth.LoginFragment;
import com.example.roomly.ui.auth.VerifyEmailFragment;
import com.example.roomly.ui.messages.ChatFragment;
import com.example.roomly.ui.schedule.ViewingBookingSheet;
import org.json.JSONObject;

/** Reloads a public advert by its server ID after navigation or process recreation. */
public class RoomDetailFragment extends Fragment {
    private static final String ARG_LISTING_ID = "listing_id";
    private FragmentRoomDetailBinding binding;
    private RoomCard room;
    private int requestEpoch;
    public static RoomDetailFragment newInstance(RoomCard room) { return newInstance(room.getListingId()); }
    public static RoomDetailFragment newInstance(long listingId) {
        RoomDetailFragment fragment = new RoomDetailFragment();
        Bundle args = new Bundle(); args.putLong(ARG_LISTING_ID, listingId); fragment.setArguments(args);
        return fragment;
    }
    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater,
            @Nullable ViewGroup container, @Nullable Bundle state) {
        binding = FragmentRoomDetailBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }
    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        binding.btnBack.setOnClickListener(v -> getParentFragmentManager().popBackStack());
        binding.btnDetailRetry.setOnClickListener(v -> loadDetail());
        binding.btnDetailSchedule.setOnClickListener(v -> {
            if (room != null && requireTenant()) ViewingBookingSheet.show(this, room);
        });
        binding.btnDetailMessage.setOnClickListener(v -> openConversation());
        clearDetails();
        loadDetail();
    }
    private void clearDetails() {
        binding.tvDetailTitle.setText("Đang tải thông tin phòng...");
        binding.tvDetailPrice.setText(""); binding.tvDetailAddress.setText("");
        binding.tvDetailAmenities.setText(""); binding.tvDetailDescription.setText("");
        binding.tvDetailElectricity.setText("Chưa cung cấp"); binding.tvDetailWater.setText("Chưa cung cấp");
        binding.tvDetailInternet.setText("Chưa cung cấp"); binding.tvDetailLandlordName.setText("");
        binding.tvDetailDeposit.setText("");
        binding.btnDetailSchedule.setEnabled(false); binding.btnDetailMessage.setEnabled(false);
        RoomImageLoader.load(binding.imgRoomDetail, "");
    }
    private void loadDetail() {
        if (binding == null) return;
        room = null; clearDetails();
        final FragmentRoomDetailBinding activeView = binding;
        final int epoch = ++requestEpoch;
        binding.btnDetailRetry.setVisibility(View.GONE);
        long id = getArguments() == null ? 0 : getArguments().getLong(ARG_LISTING_ID);
        if (id <= 0) { binding.tvDetailTitle.setText("Không tìm thấy tin đăng."); return; }
        CatalogRepository.getInstance().detail(id, new CatalogRepository.RoomCallback() {
            @Override public void onSuccess(RoomCard result) {
                if (binding != activeView || requestEpoch != epoch) return;
                room = result; display(result);
                CatalogRepository.getInstance().loadImage(result, url -> {
                    if (binding == activeView && room == result) RoomImageLoader.load(binding.imgRoomDetail, url);
                });
            }
            @Override public void onError(ApiError error) {
                if (binding != activeView || requestEpoch != epoch) return;
                binding.tvDetailTitle.setText(error.getStatusCode() == 404 ? "Tin đã ẩn hoặc hết hạn." : "Chưa tải được tin đăng.");
                binding.tvDetailDescription.setText(error.getMessage());
                binding.btnDetailRetry.setVisibility(View.VISIBLE);
            }
        });
    }
    private void display(RoomCard value) {
        binding.tvDetailTitle.setText(value.getTitle()); binding.tvDetailPrice.setText(value.getPrice());
        binding.tvDetailAddress.setText(value.getAddress()); binding.tvDetailAmenities.setText(value.getAmenities());
        binding.tvDetailDeposit.setText("Tiền đặt cọc: " + RoomCard.formatMoney(value.getDepositAmount()));
        binding.tvDetailLandlordName.setText(value.getHostId() > 0 ? "Chủ phòng #" + value.getHostId() : "Chưa có thông tin");
        StringBuilder description = new StringBuilder(value.getDescription().isEmpty() ? "Chủ phòng chưa cung cấp mô tả." : value.getDescription());
        if (!"AVAILABLE".equals(value.getAvailability())) description.append("\n\nPhòng hiện không còn trống để đặt lịch mới.");
        for (RoomCard.Fee fee : value.getFees()) {
            String code = fee.code.toUpperCase(java.util.Locale.ROOT);
            if (code.contains("ELECTRIC")) binding.tvDetailElectricity.setText(fee.display());
            else if (code.contains("WATER")) binding.tvDetailWater.setText(fee.display());
            else if (code.contains("INTERNET") || code.contains("WIFI")) binding.tvDetailInternet.setText(fee.display());
            else description.append("\n\n").append(fee.code).append(": ").append(fee.display());
            if (!fee.note.isEmpty()) description.append("\n").append(fee.code).append(": ").append(fee.note);
        }
        binding.tvDetailDescription.setText(description);
        binding.btnDetailMessage.setEnabled(true);
        binding.btnDetailSchedule.setEnabled("AVAILABLE".equals(value.getAvailability()));
    }
    private boolean requireTenant() {
        SessionAccess.Result access = SessionAccess.requireRole(UserRole.TENANT, true);
        if (access == SessionAccess.Result.ALLOWED) return true;
        if (access == SessionAccess.Result.LOGIN_REQUIRED) open(new LoginFragment());
        else if (access == SessionAccess.Result.EMAIL_VERIFICATION_REQUIRED) open(VerifyEmailFragment.newInstance(
                SessionRepository.getInstance().getCurrentSession().getEmail()));
        else Toast.makeText(requireContext(), "Tài khoản cần có vai trò người thuê.", Toast.LENGTH_LONG).show();
        return false;
    }
    private void openConversation() {
        if (binding == null || room == null || !binding.btnDetailMessage.isEnabled() || !requireTenant()) return;
        final FragmentRoomDetailBinding activeView = binding;
        final long generation = SessionRepository.getInstance().getGeneration();
        binding.btnDetailMessage.setEnabled(false);
        ChatRepository.getInstance().openConversation(room.getRoomId(), new ApiCallback() {
            private boolean current() { return binding == activeView && generation == SessionRepository.getInstance().getGeneration(); }
            @Override public void onSuccess(JSONObject envelope) {
                if (!current()) return;
                binding.btnDetailMessage.setEnabled(true);
                String id = Jsons.data(envelope).optString("id", "");
                if (!id.isEmpty()) open(ChatFragment.newInstance(id));
                else Toast.makeText(requireContext(), "Phản hồi hội thoại không hợp lệ.", Toast.LENGTH_LONG).show();
            }
            @Override public void onError(ApiError error) {
                if (!current()) return;
                binding.btnDetailMessage.setEnabled(true);
                Toast.makeText(requireContext(), error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private void open(Fragment next) {
        if (binding == null || getParentFragmentManager().isStateSaved()) return;
        getParentFragmentManager().beginTransaction().setReorderingAllowed(true)
                .replace(R.id.fragment_container, next).addToBackStack(null).commit();
    }
    @Override public void onDestroyView() { requestEpoch++; room = null; binding = null; super.onDestroyView(); }
}
