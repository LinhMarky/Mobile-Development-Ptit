package com.example.roomly.data.repository;

import android.net.Uri;
import android.text.TextUtils;
import com.example.roomly.data.model.RoomCard;
import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiClient;
import com.example.roomly.data.remote.ApiError;
import com.example.roomly.data.remote.Jsons;
import org.json.JSONArray;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Public catalog reads and session-scoped wishlist state. Callbacks run on the main thread. */
public final class CatalogRepository {
    private static final CatalogRepository INSTANCE = new CatalogRepository();
    public static CatalogRepository getInstance() { return INSTANCE; }
    private final ApiClient api = ApiClient.getInstance();
    private final Set<Long> savedIds = new HashSet<>();
    private final Map<Long, Boolean> savedChecks = new HashMap<>();
    private long savedGeneration = -1;
    private long savedRevision;
    public interface PageCallback {
        void onSuccess(List<RoomCard> rooms, int page, boolean hasMore);
        void onError(ApiError error);
    }
    public interface RoomCallback {
        void onSuccess(RoomCard room);
        void onError(ApiError error);
    }
    public interface ImageCallback { void onLoaded(String url); }
    private void scopeSavedState() {
        long current = SessionRepository.getInstance().getGeneration();
        if (savedGeneration != current) {
            savedGeneration = current; savedRevision++; savedIds.clear(); savedChecks.clear();
        }
    }
    public void search(String query, RoomCard.RoomType type, Long minPrice, Long maxPrice,
                       Long minArea, Long maxArea, int page, PageCallback callback) {
        Uri.Builder uri = new Uri.Builder().path("/listings")
                .appendQueryParameter("page", String.valueOf(page)).appendQueryParameter("size", "20")
                .appendQueryParameter("sort", "newest");
        if (query != null && !query.trim().isEmpty()) uri.appendQueryParameter("query", query.trim());
        if (type != null) uri.appendQueryParameter("room_type", type == RoomCard.RoomType.ROOM ? "SINGLE_ROOM"
                : type == RoomCard.RoomType.APARTMENT ? "MINI_APARTMENT" : "STUDIO");
        add(uri, "min_rent_vnd", minPrice); add(uri, "max_rent_vnd", maxPrice);
        add(uri, "min_area_m2", minArea); add(uri, "max_area_m2", maxArea);
        api.get(uri.build().toString(), false, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                scopeSavedState();
                List<RoomCard> rooms = new ArrayList<>();
                JSONArray items = Jsons.items(envelope);
                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.optJSONObject(i);
                    if (item != null) rooms.add(fromListing(item, savedIds.contains(item.optLong("room_id"))));
                }
                JSONObject data = Jsons.data(envelope);
                callback.onSuccess(rooms, data.optInt("current_page", page), page + 1 < data.optInt("total_pages", 0));
            }
            @Override public void onError(ApiError error) { callback.onError(error); }
        });
    }
    private static void add(Uri.Builder builder, String key, Long value) {
        if (value != null) builder.appendQueryParameter(key, value.toString());
    }
    public void detail(long listingId, RoomCallback callback) {
        api.get("/listings/" + listingId, false, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                scopeSavedState();
                JSONObject item = Jsons.data(envelope);
                callback.onSuccess(fromListing(item, savedIds.contains(item.optLong("room_id"))));
            }
            @Override public void onError(ApiError error) { callback.onError(error); }
        });
    }
    public void saved(int page, PageCallback callback) {
        scopeSavedState();
        final long generation = savedGeneration;
        final long revision = savedRevision;
        api.get("/wishlist?page=" + page + "&size=20", true, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                if (generation != SessionRepository.getInstance().getGeneration()) return;
                boolean cacheCurrent = revision == savedRevision;
                if (page == 0 && cacheCurrent) { savedIds.clear(); savedChecks.clear(); }
                List<RoomCard> rooms = new ArrayList<>();
                JSONArray items = Jsons.items(envelope);
                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.optJSONObject(i);
                    if (item == null) continue;
                    long roomId = item.optLong("room_id");
                    if (cacheCurrent) { savedIds.add(roomId); savedChecks.put(roomId, true); }
                    JSONObject listing = item.optJSONObject("listing");
                    if (listing != null) rooms.add(fromListing(listing, true));
                    else rooms.add(new RoomCard(roomId, 0, 0, item.optString("unit_code", "Phòng đã lưu"),
                            item.optString("address", ""), "Tin không còn hiển thị công khai", RoomCard.RoomType.ROOM,
                            null, null, null, "", "UNAVAILABLE", 0, new ArrayList<>(), true));
                }
                JSONObject data = Jsons.data(envelope);
                callback.onSuccess(rooms, data.optInt("current_page", page), page + 1 < data.optInt("total_pages", 0));
            }
            @Override public void onError(ApiError error) {
                if (generation == SessionRepository.getInstance().getGeneration()) callback.onError(error);
            }
        });
    }
    public void checkSaved(RoomCard room, Runnable changed) {
        scopeSavedState();
        if (!SessionRepository.getInstance().getCurrentSession().isLoggedIn()) { room.setSaved(false); changed.run(); return; }
        final long generation = savedGeneration;
        final long revision = savedRevision;
        Boolean known = savedChecks.get(room.getRoomId());
        if (known != null) { room.setSaved(known); changed.run(); return; }
        api.get("/wishlist/" + room.getRoomId() + "/check", true, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                if (generation != SessionRepository.getInstance().getGeneration() || revision != savedRevision) return;
                boolean saved = Jsons.data(envelope).optBoolean("saved");
                savedChecks.put(room.getRoomId(), saved);
                if (saved) savedIds.add(room.getRoomId()); else savedIds.remove(room.getRoomId());
                room.setSaved(saved); changed.run();
            }
            @Override public void onError(ApiError error) { /* Failed reads never fabricate saved state. */ }
        });
    }
    public void toggleSaved(RoomCard room, ApiCallback callback) {
        scopeSavedState();
        final long generation = savedGeneration;
        final boolean target = !room.isSaved();
        savedRevision++;
        api.request(target ? "POST" : "DELETE", "/wishlist/" + room.getRoomId(), null, true, null, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                if (generation != SessionRepository.getInstance().getGeneration()) return;
                savedRevision++;
                room.setSaved(target); savedChecks.put(room.getRoomId(), target);
                if (target) savedIds.add(room.getRoomId()); else savedIds.remove(room.getRoomId());
                callback.onSuccess(envelope);
            }
            @Override public void onError(ApiError error) {
                if (generation == SessionRepository.getInstance().getGeneration()) callback.onError(error);
            }
        });
    }
    public void loadImage(RoomCard room, ImageCallback callback) {
        if (!room.getImageUrl().isEmpty()) { callback.onLoaded(room.getImageUrl()); return; }
        if (room.getListingId() <= 0 || room.getRoomId() <= 0) { callback.onLoaded(""); return; }
        api.get("/media/room/" + room.getRoomId(), false, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                JSONArray items = Jsons.items(envelope);
                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.optJSONObject(i);
                    if (item != null && item.optString("content_type").startsWith("image/") && item.optLong("id") > 0) {
                        room.setImageUrl(api.mediaUrl(item.optLong("id"))); break;
                    }
                }
                callback.onLoaded(room.getImageUrl());
            }
            @Override public void onError(ApiError error) { callback.onLoaded(""); }
        });
    }
    public static RoomCard fromListing(JSONObject listing, boolean saved) {
        JSONObject room = Jsons.object(listing, "room");
        JSONObject address = Jsons.object(room, "address");
        String location = join(address.optString("line", ""), address.optString("ward_name", ""), address.optString("province_name", ""));
        BigDecimal area = decimal(room, "area_m2");
        List<String> amenities = new ArrayList<>();
        if (area != null) amenities.add(area.stripTrailingZeros().toPlainString() + " m²");
        JSONArray features = Jsons.array(room, "amenities");
        for (int i = 0; i < features.length(); i++) {
            JSONObject feature = features.optJSONObject(i);
            if (feature != null && !feature.optString("name").isEmpty()) amenities.add(feature.optString("name"));
        }
        RoomCard.RoomType type;
        try { type = "MINI_APARTMENT".equals(room.optString("room_type")) ? RoomCard.RoomType.APARTMENT
                : RoomCard.RoomType.valueOf(room.optString("room_type")); }
        catch (IllegalArgumentException ignored) { type = RoomCard.RoomType.ROOM; }
        List<RoomCard.Fee> fees = new ArrayList<>();
        JSONArray rows = Jsons.array(listing, "fees");
        for (int i = 0; i < rows.length(); i++) {
            JSONObject fee = rows.optJSONObject(i);
            if (fee != null) fees.add(new RoomCard.Fee(fee.optString("fee_code"), fee.optString("fee_mode"),
                    decimal(fee, "amount_vnd"), fee.optString("unit_name", ""), fee.optString("note", "")));
        }
        return new RoomCard(listing.optLong("room_id", room.optLong("id")), listing.optLong("id"), room.optLong("host_id"),
                listing.optString("title", ""), location, TextUtils.join(" • ", amenities), type,
                decimal(listing, "rent_vnd"), decimal(listing, "deposit_vnd"), area,
                listing.optString("description", ""), room.optString("availability", ""),
                listing.optInt("terms_version"), fees, saved);
    }
    private static BigDecimal decimal(JSONObject object, String key) {
        if (object.isNull(key)) return null;
        try { return new BigDecimal(object.optString(key)); } catch (NumberFormatException ignored) { return null; }
    }
    private static String join(String... values) {
        List<String> parts = new ArrayList<>();
        for (String value : values) if (!value.isEmpty()) parts.add(value);
        return TextUtils.join(", ", parts);
    }
}
