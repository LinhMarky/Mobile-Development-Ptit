package com.example.roomly.ui.host;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AlertDialog;
import com.example.roomly.data.remote.Jsons;
import com.example.roomly.data.repository.HostRepository;
import org.json.JSONObject;
public class HostListingDetailFragment extends HostScreenFragment {
    private final HostRepository repository=new HostRepository();
    public static HostListingDetailFragment newInstance(String id) {
        HostListingDetailFragment fragment=new HostListingDetailFragment();
        Bundle args=new Bundle();
        args.putString("listing_id",id);
        fragment.setArguments(args);
        return fragment;
    }
    private String id() {
        return requireArguments().getString("listing_id");
    }
    @Override protected String title() {
        return "Chi tiết bài đăng";
    }
    @Override protected void render() {
        error("Đang tải bài đăng…");
        repository.findListing(id(),callback(envelope-> {
            JSONObject listing=Jsons.data(envelope);
            if(!listing.has("id")) {
                error("Bài đăng không còn thuộc tài khoản này.");
                button("Quay lại",this::back);
                return;
            }
            error("");
            String status=listing.optString("status");
            text(listing.optString("title"));
            text(HostLabels.listing(status));
            text(HostLabels.money(listing.optString("rent_vnd"))+"/tháng");
            text("Tiền cọc: "+HostLabels.money(listing.optString("deposit_vnd")));
            text(listing.optString("description"));
            if(HostLabels.editable(status)) {
                button("Sửa bài đăng",()->open(HostEditListingFragment.newInstance(id())));
                final Button[] submit=new Button[1];
                submit[0]=button("Gửi duyệt",()->new AlertDialog.Builder(requireContext()).setMessage("Gửi bài đăng để quản trị viên duyệt? Bài sẽ hiển thị công khai sau khi được duyệt.").setNegativeButton("Để sau",null).setPositiveButton("Gửi duyệt",(dialog,which)->repository.listingAction(id(),"submit",intentKey("submit",id()+":"+listing.optInt("version")),callback(submit[0],result-> {
                    finishIntent("submit");
                    reload();
                }))).show());
            } else if("PUBLISHED".equals(status)) {
                final Button[] hide=new Button[1];
                hide[0]=button("Ẩn bài đăng",()->new AlertDialog.Builder(requireContext()).setMessage("Ẩn bài đăng khỏi danh sách tìm phòng?").setNegativeButton("Giữ lại",null).setPositiveButton("Ẩn",(dialog,which)->repository.listingAction(id(),"hide",intentKey("hide",id()+":"+listing.optInt("version")),callback(hide[0],result-> {
                    finishIntent("hide");
                    reload();
                }))).show());
            }
            if("PENDING_REVIEW".equals(status))text("Bài đang chờ quản trị viên duyệt.");
            button("Xem phòng",()->open(HostRoomDetailFragment.newInstance(listing.optString("room_id"))));
            button("Tải lại",this::reload);
            button("Quay lại",this::back);
        }));
    }
}
