package com.example.roomly.data.repository;

import android.os.Build;

import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiClient;
import com.example.roomly.data.remote.ApiError;
import com.example.roomly.data.remote.Jsons;

import org.json.JSONObject;

/** Nghiệp vụ xác thực; UI không tự tạo user, token hay trạng thái verified. */
public final class AuthRepository {
    private static final AuthRepository INSTANCE = new AuthRepository();
    private final SessionRepository session = SessionRepository.getInstance();
    private AuthRepository() { }
    public static AuthRepository getInstance() { return INSTANCE; }

    public void login(String email, String password, ApiCallback callback) {
        long generation = session.getGeneration();
        JSONObject body = Jsons.body("email", email, "password", password,
                "installation_id", session.getInstallationId(), "device_name", deviceName());
        ApiClient.getInstance().request("POST", "auth/login", body, false, null, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                try {
                    if (!session.acceptLogin(Jsons.data(envelope), generation)) {
                        callback.onError(new ApiError(401, "SESSION_CHANGED", "Phiên đăng nhập đã thay đổi."));
                        return;
                    }
                    callback.onSuccess(envelope);
                } catch (IllegalArgumentException | IllegalStateException error) {
                    callback.onError(new ApiError(0, "SESSION_STORE_ERROR", "Không lưu được phiên đăng nhập. Hãy thử lại."));
                }
            }
            @Override public void onError(ApiError error) { callback.onError(error); }
        });
    }

    public void register(String fullName, String email, String password, ApiCallback callback) {
        ApiClient.getInstance().request("POST", "auth/register",
                Jsons.body("fullName", fullName, "email", email, "password", password), false, null, callback);
    }

    public void refreshAccount(ApiCallback callback) {
        long generation = session.getGeneration();
        ApiClient.getInstance().get("auth/account", true, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                try {
                    session.updateAccount(Jsons.data(envelope), generation);
                    callback.onSuccess(envelope);
                } catch (IllegalArgumentException | IllegalStateException error) {
                    callback.onError(new ApiError(0, "SESSION_STORE_ERROR", "Không cập nhật được phiên trên thiết bị."));
                }
            }
            @Override public void onError(ApiError error) { callback.onError(error); }
        });
    }

    public void enableHost(ApiCallback callback) {
        ApiClient.getInstance().request("POST", "auth/enable-host", new JSONObject(), true, null, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) { refreshAccount(callback); }
            @Override public void onError(ApiError error) { callback.onError(error); }
        });
    }

    public void logout(ApiCallback callback) {
        long generation = session.getGeneration();
        String refresh = session.getRefreshToken();
        if (refresh.isEmpty()) {
            callback.onError(new ApiError(401, "LOGIN_REQUIRED", "Bạn cần đăng nhập."));
            return;
        }
        ApiClient.getInstance().request("POST", "auth/logout", Jsons.body("refresh_token", refresh),
                true, null, new ApiCallback() {
                    @Override public void onSuccess(JSONObject envelope) {
                        session.clearIfCurrent(generation);
                        callback.onSuccess(envelope);
                    }
                    @Override public void onError(ApiError error) { callback.onError(error); }
                });
    }

    public static String deviceName() {
        String name = Build.MANUFACTURER + " " + Build.MODEL;
        return name.length() > 100 ? name.substring(0, 100) : name;
    }
}
