package com.example.roomly.data.model;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

/** Client hints mirror viewing time limits; the server remains authoritative. */
public final class ViewingRules {
    private ViewingRules() { }

    public static boolean bookable(String status, Instant startsAt, Instant now) {
        return "OPEN".equals(status) && !startsAt.isBefore(now.plus(24, ChronoUnit.HOURS));
    }

    public static boolean active(String status) {
        return "REQUESTED".equals(status) || "CONFIRMED".equals(status);
    }

    public static boolean tenantCanCancel(String status, Instant startsAt, Instant now) {
        return active(status) && !startsAt.isBefore(now.plus(2, ChronoUnit.HOURS));
    }

    public static boolean hostCanComplete(String status, Instant startsAt, Instant now) {
        return "CONFIRMED".equals(status) && !startsAt.isAfter(now);
    }
}
