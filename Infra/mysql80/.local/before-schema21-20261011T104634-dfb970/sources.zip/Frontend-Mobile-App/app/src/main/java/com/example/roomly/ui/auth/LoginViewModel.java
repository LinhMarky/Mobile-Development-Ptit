package com.example.roomly.ui.auth;

import android.util.Patterns;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.roomly.data.repository.AuthRepository;
import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiError;
import org.json.JSONObject;

/**
 * Kiểm tra dữ liệu nhập và quản lý trạng thái màn hình đăng nhập.
 * Chưa gọi API hoặc tạo phiên đăng nhập.
 */
public class LoginViewModel extends ViewModel {
    private final MutableLiveData<Boolean> loginComplete = new MutableLiveData<>(false);
    public LiveData<Boolean> getLoginComplete() { return loginComplete; }
    public void consumeLoginComplete() { loginComplete.setValue(false); }

    // Chỉ ViewModel được cập nhật trạng thái.
    private final MutableLiveData<LoginUiState> uiState =
            new MutableLiveData<>(LoginUiState.initial());

    /**
     * Cho phép Fragment theo dõi trạng thái qua LiveData chỉ đọc.
     */
    public LiveData<LoginUiState> getUiState() {
        return uiState;
    }

    /**
     * Kiểm tra dữ liệu khi người dùng bấm Đăng nhập.
     * Không trim mật khẩu vì khoảng trắng có thể thuộc mật khẩu.
     */
    public void login(String emailInput, String passwordInput) {
        LoginUiState currentState = uiState.getValue();

        if (currentState != null && currentState.isLoading()) {
            return;
        }

        String email = emailInput == null
                ? ""
                : emailInput.trim();

        String password = passwordInput == null
                ? ""
                : passwordInput;

        String emailError = validateEmail(email);
        String passwordError = validatePassword(password);

        if (emailError != null || passwordError != null) {
            uiState.setValue(new LoginUiState(
                    false,
                    emailError,
                    passwordError,
                    null
            ));

            return;
        }

        uiState.setValue(new LoginUiState(true, null, null, null));
        AuthRepository.getInstance().login(email, password, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                uiState.setValue(LoginUiState.initial());
                loginComplete.setValue(true);
            }
            @Override public void onError(ApiError error) {
                uiState.setValue(new LoginUiState(false, error.getFieldError("email"),
                        error.getFieldError("password"), error.getMessage()));
            }
        });
    }

    /**
     * Kiểm tra email đã nhập và có định dạng hợp lệ.
     */
    private String validateEmail(String email) {
        if (email.isEmpty()) {
            return "Bạn hãy nhập email.";
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return "Email không đúng định dạng.";
        }

        return null;
    }

    /**
     * Kiểm tra mật khẩu đăng nhập không trống.
     * Quy tắc tối thiểu 12 ký tự sẽ áp dụng ở form tạo mật khẩu.
     */
    private String validatePassword(String password) {
        if (password.isEmpty()) {
            return "Bạn hãy nhập mật khẩu.";
        }

        return null;
    }
}
