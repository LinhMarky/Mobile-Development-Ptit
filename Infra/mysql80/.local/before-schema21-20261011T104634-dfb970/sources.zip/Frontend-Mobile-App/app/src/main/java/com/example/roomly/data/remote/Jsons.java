package com.example.roomly.data.remote;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class Jsons {
    private Jsons() { }

    public static JSONObject object(JSONObject source, String key) {
        JSONObject value = source == null ? null : source.optJSONObject(key);
        return value == null ? new JSONObject() : value;
    }

    public static JSONArray array(JSONObject source, String key) {
        JSONArray value = source == null ? null : source.optJSONArray(key);
        return value == null ? new JSONArray() : value;
    }

    public static JSONObject data(JSONObject envelope) { return object(envelope, "data"); }

    public static JSONArray items(JSONObject envelope) {
        Object data = envelope.opt("data");
        if (data instanceof JSONArray) return (JSONArray) data;
        return data instanceof JSONObject ? array((JSONObject) data, "data") : new JSONArray();
    }

    public static JSONObject body(Object... pairs) {
        if (pairs.length % 2 != 0) throw new IllegalArgumentException("JSON needs key/value pairs");
        JSONObject body = new JSONObject();
        try {
            for (int index = 0; index < pairs.length; index += 2) {
                body.put((String) pairs[index], pairs[index + 1] == null ? JSONObject.NULL : pairs[index + 1]);
            }
        } catch (JSONException error) {
            throw new IllegalArgumentException("Invalid JSON value", error);
        }
        return body;
    }
}
