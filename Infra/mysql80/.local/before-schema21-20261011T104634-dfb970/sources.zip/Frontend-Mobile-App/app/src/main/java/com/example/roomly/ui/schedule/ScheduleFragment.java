package com.example.roomly.ui.schedule;
public class ScheduleFragment extends AppointmentsScreenFragment {
    @Override protected boolean isHost() {
        return false;
    }
}
