package com.example.roomly.ui.messages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Decoder for the backend's UTF-8 JSON STOMP frames, including fragmented/combined WebSocket messages. */
public final class StompFrameDecoder {
    private static final int MAX_BUFFER_CHARS = 256 * 1024;
    private final StringBuilder buffer = new StringBuilder();
    public static final class Frame {
        public final String command;
        public final Map<String, String> headers;
        public final String body;
        Frame(String command, Map<String, String> headers, String body) {
            this.command = command; this.headers = headers; this.body = body;
        }
    }
    public List<Frame> accept(String text) {
        buffer.append(text);
        if (buffer.length() > MAX_BUFFER_CHARS) {
            buffer.setLength(0); throw new IllegalArgumentException("STOMP response exceeds buffer limit");
        }
        List<Frame> result = new ArrayList<>();
        int end;
        while ((end = buffer.indexOf("\u0000")) >= 0) {
            String wire = buffer.substring(0, end).replace("\r\n", "\n");
            buffer.delete(0, end + 1);
            while (wire.startsWith("\n")) wire = wire.substring(1);
            int line = wire.indexOf('\n');
            int split = wire.indexOf("\n\n");
            if (line < 0 || split < line) throw new IllegalArgumentException("Malformed STOMP frame");
            String command = wire.substring(0, line);
            Map<String, String> headers = new LinkedHashMap<>();
            String headerBlock = split == line ? "" : wire.substring(line + 1, split);
            for (String header : headerBlock.split("\n")) {
                if (header.isEmpty()) continue;
                int colon = header.indexOf(':');
                if (colon <= 0) throw new IllegalArgumentException("Malformed STOMP header");
                String key = unescape(header.substring(0, colon));
                String value = unescape(header.substring(colon + 1));
                // STOMP defines the first value when a header repeats.
                if (!headers.containsKey(key)) headers.put(key, value);
            }
            result.add(new Frame(command, headers, wire.substring(split + 2)));
        }
        if (buffer.toString().trim().isEmpty()) buffer.setLength(0);
        return result;
    }
    private static String unescape(String value) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char current = value.charAt(i);
            if (current != '\\') { result.append(current); continue; }
            if (++i >= value.length()) throw new IllegalArgumentException("Malformed STOMP escape");
            switch (value.charAt(i)) {
                case 'c': result.append(':'); break;
                case 'n': result.append('\n'); break;
                case 'r': result.append('\r'); break;
                case '\\': result.append('\\'); break;
                default: throw new IllegalArgumentException("Malformed STOMP escape");
            }
        }
        return result.toString();
    }
}
