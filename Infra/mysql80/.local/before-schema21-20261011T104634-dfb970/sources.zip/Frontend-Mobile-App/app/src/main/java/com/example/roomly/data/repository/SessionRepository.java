package com.example.roomly.data.repository;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.roomly.data.model.SessionState;
import com.example.roomly.data.model.UserRole;
import com.example.roomly.data.remote.Jsons;
import com.example.roomly.data.remote.SecureSessionStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.EnumSet;

/** Nguồn phiên duy nhất; bảo vệ refresh/logout/đổi tài khoản chạy đồng thời. */
public final class SessionRepository {
    private static final SessionRepository INSTANCE = new SessionRepository();
    private final MutableLiveData<SessionState> sessionState = new MutableLiveData<>(SessionState.guest());
    private final Handler main = new Handler(Looper.getMainLooper());
    private SecureSessionStore store;
    private JSONObject saved = new JSONObject();
    private SessionState current = SessionState.guest();
    private long generation;
    private String installationId = "";

    private SessionRepository() { }
    public static SessionRepository getInstance() { return INSTANCE; }

    public synchronized void initialize(Context context) {
        if (store != null) return;
        store = new SecureSessionStore(context.getApplicationContext());
        installationId = store.installationId();
        saved = store.read();
        if (!saved.optString("access_token").isEmpty() && !saved.optString("refresh_token").isEmpty()) {
            try { current = parseUser(Jsons.object(saved, "user")); }
            catch (IllegalArgumentException error) { saved = new JSONObject(); store.clear(); }
        }
        publish();
    }

    public LiveData<SessionState> getSessionState() { return sessionState; }
    public synchronized SessionState getCurrentSession() { return current; }
    public synchronized String getAccessToken() { return saved.optString("access_token", ""); }
    public synchronized String getRefreshToken() { return saved.optString("refresh_token", ""); }
    public synchronized String getInstallationId() { return installationId; }
    public synchronized long getGeneration() { return generation; }

    public synchronized boolean acceptLogin(JSONObject data, long expectedGeneration) {
        if (generation != expectedGeneration) return false;
        if (data.optString("access_token").isEmpty() || data.optString("refresh_token").isEmpty()) {
            throw new IllegalArgumentException("Phản hồi đăng nhập thiếu token.");
        }
        SessionState user = parseUser(Jsons.object(data, "user"));
        store.write(data);
        saved = data;
        current = user;
        generation++;
        publish();
        return true;
    }

    /** Refresh giữ generation, chỉ nhận đúng refresh token hiện hành. */
    public synchronized boolean acceptRefresh(JSONObject data, long expectedGeneration, String previousRefresh) {
        if (generation != expectedGeneration || !getRefreshToken().equals(previousRefresh)) return false;
        if (data.optString("access_token").isEmpty() || data.optString("refresh_token").isEmpty()) return false;
        SessionState user = parseUser(Jsons.object(data, "user"));
        if (!user.getUserId().equals(current.getUserId())) return false;
        store.write(data);
        saved = data;
        current = user;
        publish();
        return true;
    }

    public synchronized void updateAccount(JSONObject user, long expectedGeneration) {
        if (generation != expectedGeneration || !current.isLoggedIn()) return;
        SessionState next = parseUser(user);
        if (!next.getUserId().equals(current.getUserId())) return;
        JSONObject nextSaved = Jsons.body("access_token", getAccessToken(),
                "refresh_token", getRefreshToken(), "user", user);
        store.write(nextSaved);
        saved = nextSaved;
        current = next;
        publish();
    }

    /** Tương thích UI cũ; không cho debug helper tạo phiên không có token. */
    public synchronized void updateAuthenticatedSession(SessionState session) {
        if (getAccessToken().isEmpty()) throw new IllegalStateException("Cần đăng nhập backend trước.");
        if (session == null || !session.isLoggedIn()) throw new IllegalArgumentException("Phiên không hợp lệ.");
        current = session;
        publish();
    }

    public synchronized void clearLocalSession() {
        generation++;
        saved = new JSONObject();
        current = SessionState.guest();
        if (store != null) store.clear();
        publish();
    }

    public synchronized void clearIfCurrent(long expectedGeneration) {
        if (generation == expectedGeneration) clearLocalSession();
    }

    private void publish() {
        SessionState state = current;
        long version = generation;
        if (Looper.myLooper() == Looper.getMainLooper()) sessionState.setValue(state);
        else main.post(() -> {
            synchronized (SessionRepository.this) {
                if (version == generation) sessionState.setValue(current);
            }
        });
    }

    private static SessionState parseUser(JSONObject user) {
        EnumSet<UserRole> roles = EnumSet.noneOf(UserRole.class);
        JSONArray serverRoles = Jsons.array(user, "roles");
        for (int index = 0; index < serverRoles.length(); index++) {
            String role = serverRoles.optString(index).replace("ROLE_", "");
            try { roles.add(UserRole.valueOf(role)); } catch (IllegalArgumentException ignored) { }
        }
        if (user.optBoolean("host")) roles.add(UserRole.HOST);
        if (roles.isEmpty()) roles.add(UserRole.TENANT);
        return SessionState.authenticated(user.optString("id", ""), user.optString("fullName"),
                user.optString("email"), user.optBoolean("emailVerified"), roles);
    }
}
