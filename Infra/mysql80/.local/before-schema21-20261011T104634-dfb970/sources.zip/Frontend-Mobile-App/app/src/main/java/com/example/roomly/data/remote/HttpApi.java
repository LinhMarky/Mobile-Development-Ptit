package com.example.roomly.data.remote;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/** HTTP transport độc lập Android để kiểm thử wrapper, refresh và đổi tài khoản. */
public final class HttpApi {
    public interface Tokens {
        String accessToken();
        String refreshToken();
        long generation();
        boolean acceptRefresh(JSONObject data, long generation, String previousRefresh);
        void expire(long generation);
    }

    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private static final int MAX_JSON_BYTES = 4 * 1024 * 1024;
    private final HttpUrl base;
    private final Tokens tokens;
    private final Executor callbacks;
    private final OkHttpClient rawClient;
    private final OkHttpClient client;
    private final Object refreshLock = new Object();

    private static final class Scope {
        final long generation;
        Scope(long generation) { this.generation = generation; }
    }

    public HttpApi(String baseUrl, Tokens tokens, Executor callbacks) {
        base = HttpUrl.get(baseUrl);
        if (!base.encodedPath().equals("/api/v1/") || base.query() != null ||
                !base.username().isEmpty() || !base.password().isEmpty() || base.fragment() != null) {
            throw new IllegalArgumentException("API URL must end with /api/v1/");
        }
        this.tokens = tokens;
        this.callbacks = callbacks;
        rawClient = new OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS).writeTimeout(90, TimeUnit.SECONDS)
                .callTimeout(120, TimeUnit.SECONDS)
                .followRedirects(false).followSslRedirects(false).build();
        client = rawClient.newBuilder().authenticator((route, response) -> authenticate(response)).build();
    }

    /** Không cho URL media hoặc repository đưa token ra origin khác. */
    public String url(String path) {
        HttpUrl result = base.resolve(path);
        if (result == null || !result.scheme().equals(base.scheme()) || !result.host().equals(base.host()) ||
                result.port() != base.port() || !result.username().isEmpty() ||
                !result.password().isEmpty() || result.fragment() != null ||
                !result.encodedPath().startsWith("/api/v1/")) {
            throw new IllegalArgumentException("URL must belong to the configured backend API");
        }
        return result.toString();
    }

    public String websocketUrl() {
        String origin = base.newBuilder().encodedPath("/ws").query(null).build().toString();
        return origin.replaceFirst("^http", "ws");
    }

    public OkHttpClient httpClient() { return client; }

    public Request.Builder authorizedRequest(String path) {
        String token = tokens.accessToken();
        Request.Builder request = new Request.Builder().url(url(path));
        if (!token.isEmpty()) {
            request.header("Authorization", "Bearer " + token).tag(Scope.class, new Scope(tokens.generation()));
        }
        return request;
    }

    public void request(String method, String path, JSONObject body, boolean auth,
                        String idempotencyKey, ApiCallback callback) {
        boolean needsBody = method.equals("POST") || method.equals("PUT") || method.equals("PATCH");
        RequestBody payload = body != null || needsBody
                ? RequestBody.create(body == null ? "{}" : body.toString(), JSON) : null;
        send(method, path, payload, auth, idempotencyKey, callback);
    }

    public void send(String method, String path, RequestBody body, boolean auth,
                     String idempotencyKey, ApiCallback callback) {
        long generation = tokens.generation();
        if (auth && tokens.accessToken().isEmpty()) {
            callbacks.execute(() -> callback.onError(new ApiError(401, "LOGIN_REQUIRED", "Bạn cần đăng nhập.")));
            return;
        }
        Request.Builder builder;
        try {
            builder = auth ? authorizedRequest(path) : new Request.Builder().url(url(path));
            builder.header("Accept", "application/json").method(method, body);
            if (idempotencyKey != null) builder.header("Idempotency-Key", idempotencyKey);
        } catch (IllegalArgumentException error) {
            callbacks.execute(() -> callback.onError(new ApiError(0, "INVALID_REQUEST", "Đường dẫn yêu cầu không hợp lệ.")));
            return;
        }
        client.newCall(builder.build()).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException error) {
                deliver(auth, generation, callback, null,
                        new ApiError(0, "NETWORK_ERROR", "Không kết nối được backend. Kiểm tra mạng và thử lại."));
            }

            @Override public void onResponse(Call call, Response response) {
                try (Response closeable = response) {
                    JSONObject envelope = readEnvelope(response);
                    if (response.isSuccessful()) deliver(auth, generation, callback, envelope, null);
                    else deliver(auth, generation, callback, null, ApiError.fromResponse(response.code(), envelope));
                } catch (Exception error) {
                    deliver(auth, generation, callback, null, new ApiError(response.code(), "INVALID_RESPONSE",
                            "Backend trả dữ liệu không hợp lệ. Bạn hãy thử lại."));
                }
            }
        });
    }

    private void deliver(boolean auth, long generation, ApiCallback callback,
                         JSONObject envelope, ApiError error) {
        callbacks.execute(() -> {
            if (auth && tokens.generation() != generation) {
                callback.onError(new ApiError(401, "SESSION_CHANGED", "Phiên đăng nhập đã thay đổi."));
            } else if (error != null) callback.onError(error);
            else callback.onSuccess(envelope);
        });
    }

    /** Một refresh tại một thời điểm; retry giữ nguyên method/body/Idempotency-Key. */
    private Request authenticate(Response response) throws IOException {
        Scope scope = response.request().tag(Scope.class);
        if (scope == null || response.priorResponse() != null) return null;
        synchronized (refreshLock) {
            if (scope.generation != tokens.generation()) return null;
            String current = tokens.accessToken();
            if (current.isEmpty()) return null;
            if (!("Bearer " + current).equals(response.request().header("Authorization"))) {
                return response.request().newBuilder().header("Authorization", "Bearer " + current).build();
            }
            String previousRefresh = tokens.refreshToken();
            if (previousRefresh.isEmpty()) return null;
            Request refresh = new Request.Builder().url(url("auth/refresh"))
                    .post(RequestBody.create(Jsons.body("refresh_token", previousRefresh).toString(), JSON)).build();
            try (Response result = rawClient.newCall(refresh).execute()) {
                if (result.code() == 400 || result.code() == 401) {
                    tokens.expire(scope.generation);
                    return null;
                }
                // Timeout/5xx/mạng tạm thời không xóa phiên.
                if (!result.isSuccessful()) return null;
                JSONObject data = Jsons.data(readEnvelope(result));
                if (!tokens.acceptRefresh(data, scope.generation, previousRefresh)) return null;
                return response.request().newBuilder()
                        .header("Authorization", "Bearer " + tokens.accessToken()).build();
            } catch (IllegalArgumentException | IllegalStateException error) {
                return null;
            }
        }
    }

    static JSONObject readEnvelope(Response response) throws IOException {
        if (response.code() == 204 || response.body() == null) {
            return Jsons.body("statusCode", response.code(), "message", "", "data", null);
        }
        try (InputStream stream = response.body().byteStream();
             ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = stream.read(buffer)) != -1) {
                if (bytes.size() + count > MAX_JSON_BYTES) throw new IOException("Response too large");
                bytes.write(buffer, 0, count);
            }
            if (bytes.size() == 0) return Jsons.body("statusCode", response.code(), "message", "", "data", null);
            try { return new JSONObject(bytes.toString(StandardCharsets.UTF_8.name())); }
            catch (org.json.JSONException error) { throw new IOException("Invalid JSON"); }
        }
    }
}
