package com.example.roomly.ui.host.viewing;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.appcompat.app.AlertDialog;
import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiError;
import com.example.roomly.data.remote.Jsons;
import com.example.roomly.data.repository.ViewingRepository;
import com.example.roomly.ui.host.HostScreenFragment;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.Map;
public class HostViewingFragment extends HostScreenFragment {
    private static final DateTimeFormatter INPUT=DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm").withResolverStyle(ResolverStyle.STRICT);
    private final ViewingRepository repository=new ViewingRepository();
    private final Map<Long,JSONObject> createdSlots=new LinkedHashMap<>();
    private LinearLayout slotsContainer;
    public static HostViewingFragment newInstance(String roomId) {
        HostViewingFragment fragment=new HostViewingFragment();
        Bundle args=new Bundle();
        args.putString("room_id",roomId);
        fragment.setArguments(args);
        return fragment;
    }
    private long roomId() {
        return Long.parseLong(requireArguments().getString("room_id"));
    }
    @Override protected String title() {
        return "Khung giờ xem phòng";
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        if(saved!=null) {
            try {
                JSONArray rows=new JSONArray(saved.getString("created_slots","[]"));
                for(int i=0;i<rows.length();i++) {
                    JSONObject row=rows.getJSONObject(i);
                    createdSlots.put(row.getLong("id"),row);
                }
            }catch(Exception ignored) {
                createdSlots.clear();
            }
        }
    }
    @Override protected void render() {
        text("Chọn thời gian bắt đầu ít nhất 24 giờ sau hiện tại. Giờ địa phương: "+ZoneId.systemDefault().getId()+".");
        EditText start=field("start","Bắt đầu (năm-tháng-ngày giờ:phút)","");
        button("Chọn giờ bắt đầu",()->pickTime(start));
        EditText end=field("end","Kết thúc (năm-tháng-ngày giờ:phút)","");
        button("Chọn giờ kết thúc",()->pickTime(end));
        final Button[] create=new Button[1];
        create[0]=button("Tạo khung giờ",()->createSlot(create[0]));
        text("Danh sách bên dưới chỉ lấy các khung giờ đang mở cho phòng đã có bài đăng được duyệt. Khung giờ đã hủy không thể mở lại.");
        button("Tải lại khung giờ",this::reload);
        button("Yêu cầu xem phòng",()->open(new HostAppointmentsFragment()));
        button("Quay lại",this::back);
        slotsContainer=new LinearLayout(requireContext());
        slotsContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(slotsContainer);
        showSlots(createdSlots);
        ApiCallback guarded=callback(envelope-> {
            LinkedHashMap<Long,JSONObject> rows=new LinkedHashMap<>();
            JSONArray items=Jsons.items(envelope);
            for(int i=0;i<items.length();i++) {
                JSONObject row=items.optJSONObject(i);
                if(row!=null)rows.put(row.optLong("id"),row);
            }
            createdSlots.clear();
            createdSlots.putAll(rows);
            showSlots(rows);
            error(rows.isEmpty()?"Chưa có khung giờ đang mở.":"");
        });
        repository.slots(roomId(),new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                guarded.onSuccess(envelope);
            }
            @Override public void onError(ApiError error) {
                guarded.onError(error.getStatusCode()==404?new ApiError(404,"LISTING_NOT_PUBLIC","Phòng chưa có bài đăng công khai. Các khung giờ vừa tạo vẫn được lưu trên máy chủ; danh sách công khai sẽ có sau khi bài được duyệt."):error);
            }
        });
    }
    private void pickTime(EditText input) {
        LocalDateTime initial=LocalDateTime.now().plusDays(2);
        try {
            if(input.getText()!=null&&!input.getText().toString().trim().isEmpty())initial=LocalDateTime.parse(input.getText().toString(),INPUT);
        }catch(Exception ignored) {
            /* Show a future date picker if old input is invalid. */
        }
        LocalDateTime choice=initial;
        new DatePickerDialog(requireContext(),(view,year,month,day)->new TimePickerDialog(requireContext(),(clock,hour,minute)->input.setText(LocalDateTime.of(year,month+1,day,hour,minute).format(INPUT)),choice.getHour(),choice.getMinute(),true).show(),choice.getYear(),choice.getMonthValue()-1,choice.getDayOfMonth()).show();
    }
    private void createSlot(Button button) {
        try {
            Instant start=LocalDateTime.parse(value("start"),INPUT).atZone(ZoneId.systemDefault()).toInstant();
            Instant end=LocalDateTime.parse(value("end"),INPUT).atZone(ZoneId.systemDefault()).toInstant();
            if(start.isBefore(Instant.now().plus(24,ChronoUnit.HOURS)))throw new IllegalArgumentException("Giờ bắt đầu phải cách hiện tại ít nhất 24 giờ.");
            if(!end.isAfter(start))throw new IllegalArgumentException("Giờ kết thúc phải sau giờ bắt đầu.");
            repository.createSlot(roomId(),start,end,intentKey("slot",roomId()+":"+start+":"+end),callback(button,envelope-> {
                JSONObject created=Jsons.data(envelope);
                createdSlots.put(created.optLong("id"),created);
                finishIntent("slot");
                clearForm();
                reload();
            }));
        }catch(Exception invalid) {
            error(invalid instanceof java.time.format.DateTimeParseException?"Chọn thời gian hợp lệ theo năm-tháng-ngày giờ:phút.":invalid.getMessage());
        }
    }
    private void showSlots(Map<Long,JSONObject> rows) {
        if(slotsContainer==null)return;
        slotsContainer.removeAllViews();
        LinearLayout original=content;
        content=slotsContainer;
        for(JSONObject row:rows.values()) {
            long id=row.optLong("id");
            LinearLayout card=card("Khung giờ #"+id+"\n"+format(row.optString("start_at"))+" → "+format(row.optString("end_at")));
            final Button[] cancel=new Button[1];
            cancel[0]=cardButton(card,"Hủy khung giờ",()->new AlertDialog.Builder(requireContext()).setMessage("Hủy khung giờ này? Khung giờ đã hủy không thể mở lại.").setNegativeButton("Giữ lại",null).setPositiveButton("Hủy khung giờ",(dialog,which)->repository.cancelSlot(id,callback(cancel[0],envelope-> {
                createdSlots.remove(id);
                reload();
            }))).show());
        }
        content=original;
    }
    public static String format(String instant) {
        try {
            return Instant.parse(instant).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        }catch(Exception invalid) {
            return "Chưa có thời gian";
        }
    }
    @Override public void onSaveInstanceState(Bundle out) {
        JSONArray rows=new JSONArray();
        for(JSONObject row:createdSlots.values())rows.put(row);
        out.putString("created_slots",rows.toString());
        super.onSaveInstanceState(out);
    }
    @Override public void onDestroyView() {
        slotsContainer=null;
        super.onDestroyView();
    }
    @Override protected void clearPrivateState() {
        createdSlots.clear();
    }
}
