package com.example.roomly.ui.host;
/** Creates a server room; attach photos from its detail screen. */
public class HostAddRoomFragment extends RoomFormFragment {
}
