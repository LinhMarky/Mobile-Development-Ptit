package com.example.roomly.data.remote;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Token mã hóa bằng khóa Android Keystore; không lưu mật khẩu. */
public final class SecureSessionStore {
    private static final String KEY_ALIAS = "roomly.session.v1";
    private final SharedPreferences preferences;

    public SecureSessionStore(Context context) {
        preferences = context.getSharedPreferences("roomly_private_session", Context.MODE_PRIVATE);
    }

    public synchronized String installationId() {
        String id = preferences.getString("installation_id", null);
        if (id == null) {
            id = UUID.randomUUID().toString();
            preferences.edit().putString("installation_id", id).commit();
        }
        return id;
    }

    private SecretKey key() throws GeneralSecurityException, java.io.IOException {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        SecretKey existing = (SecretKey) store.getKey(KEY_ALIAS, null);
        if (existing != null) return existing;
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
        return generator.generateKey();
    }

    public synchronized JSONObject read() {
        String encoded = preferences.getString("session", null);
        if (encoded == null) return new JSONObject();
        try {
            JSONObject saved = new JSONObject(encoded);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128,
                    Base64.decode(saved.getString("iv"), Base64.NO_WRAP)));
            byte[] plain = cipher.doFinal(Base64.decode(saved.getString("ciphertext"), Base64.NO_WRAP));
            return new JSONObject(new String(plain, StandardCharsets.UTF_8));
        } catch (Exception error) {
            // Missing/invalidated key after reinstall or restore: require login.
            clear();
            return new JSONObject();
        }
    }

    public synchronized void write(JSONObject session) {
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key());
            byte[] encrypted = cipher.doFinal(session.toString().getBytes(StandardCharsets.UTF_8));
            JSONObject saved = Jsons.body("iv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP),
                    "ciphertext", Base64.encodeToString(encrypted, Base64.NO_WRAP));
            if (!preferences.edit().putString("session", saved.toString()).commit()) {
                throw new IllegalStateException("Không lưu được phiên đăng nhập trên thiết bị.");
            }
        } catch (GeneralSecurityException | java.io.IOException error) {
            throw new IllegalStateException("Không mở được kho lưu phiên an toàn.", error);
        }
    }

    public synchronized void clear() { preferences.edit().remove("session").commit(); }
}
