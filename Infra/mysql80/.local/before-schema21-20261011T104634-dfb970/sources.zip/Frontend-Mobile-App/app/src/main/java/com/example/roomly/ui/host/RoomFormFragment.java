package com.example.roomly.ui.host;
import android.os.Bundle;
import android.text.InputType;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import androidx.appcompat.app.AlertDialog;
import com.example.roomly.data.remote.ApiClient;
import com.example.roomly.data.remote.Jsons;
import com.example.roomly.data.repository.HostRepository;
import org.json.JSONArray;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;
/** The form maps only fields actually supported by the room contract. */
public abstract class RoomFormFragment extends HostScreenFragment {
    private final HostRepository repository = new HostRepository();
    private final String[] types = {
        "SINGLE_ROOM", "STUDIO", "MINI_APARTMENT"
    };
    private final Set<Long> amenities = new LinkedHashSet<>();
    private Spinner type;
    private int selectedType;
    private boolean restoredAmenities;
    private JSONObject current;
    protected String roomId() {
        return getArguments() == null ? null : getArguments().getString("room_id");
    }
    @Override protected String title() {
        return roomId() == null ? "Thêm phòng" : "Sửa phòng";
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        if (saved != null) {
            selectedType=saved.getInt("room_type_index");
            long[] ids=saved.getLongArray("amenities");
            if(ids!=null) {
                restoredAmenities=true;
                for(long id:ids)amenities.add(id);
            }
        }
    }
    @Override protected void render() {
        if (roomId() == null) {
            current=new JSONObject();
            buildForm();
        }
        else {
            error("Đang tải phòng…");
            repository.room(roomId(), callback(envelope -> {
                current=Jsons.data(envelope);
                error("");
                buildForm();
            }));
        }
    }
    private void buildForm() {
        JSONObject address=Jsons.object(current,"address"), location=Jsons.object(current,"location");
        if (!restoredAmenities) {
            amenities.clear();
            JSONArray existing=Jsons.array(current,"amenities");
            for(int i=0;i<existing.length();i++) {
                JSONObject item=existing.optJSONObject(i);
                if(item!=null)amenities.add(item.optLong("id"));
            }
        }
        if(roomId()==null) field("unit","Mã phòng (chữ in hoa, số, _ hoặc -)", "");
        else text("Mã phòng: "+current.optString("unit_code"));
        text("Loại phòng");
        type=new Spinner(requireContext());
        type.setAdapter(new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item,
        new String[] {
            "Phòng trọ", "Studio", "Căn hộ mini"
        }));
        String existingType=current.optString("room_type");
        if(!existingType.isEmpty() && selectedType==0) for(int i=0;i<types.length;i++)if(types[i].equals(existingType))selectedType=i;
        type.setSelection(selectedType);
        content.addView(type);
        int decimal=InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL;
        int signed=decimal|InputType.TYPE_NUMBER_FLAG_SIGNED;
        field("area","Diện tích (m²), từ 2 đến 1000", current.optString("area_m2",""),decimal);
        field("occupants","Số người tối đa (1–10)", current.has("max_occupants")?current.optString("max_occupants"):"",InputType.TYPE_CLASS_NUMBER);
        field("line","Địa chỉ cụ thể",address.optString("line",""));
        field("province_code","Mã tỉnh/thành phố",address.optString("province_code",""));
        field("province_name","Tên tỉnh/thành phố",address.optString("province_name",""));
        field("ward_code","Mã phường/xã (không bắt buộc)",address.optString("ward_code",""));
        field("ward_name","Tên phường/xã (đi cùng mã)",address.optString("ward_name",""));
        text("Dùng tọa độ chính xác của phòng trên bản đồ.");
        field("latitude","Vĩ độ (−90 đến 90)",location.optString("latitude",""),signed);
        field("longitude","Kinh độ (−180 đến 180)",location.optString("longitude",""),signed);
        Button amenityButton=button("Chọn tiện ích ("+amenities.size()+")",()->selectAmenities());
        amenityButton.setContentDescription("Chọn tiện ích phòng");
        final Button[] save=new Button[1];
        save[0]=button("Lưu phòng",()->save(save[0]));
        if(roomId()!=null)button("Tải lại dữ liệu mới nhất",()-> {
            clearForm();
            restoredAmenities=false;
            reload();
        });
        button("Quay lại",this::back);
    }
    private void selectAmenities() {
        ApiClient.getInstance().get("/amenities",false,callback(envelope-> {
            JSONArray rows=Jsons.items(envelope);
            ArrayList<Long> ids=new ArrayList<>();
            ArrayList<String> labels=new ArrayList<>();
            for(int i=0;i<rows.length();i++) {
                JSONObject row=rows.optJSONObject(i);
                if(row!=null) {
                    ids.add(row.optLong("id"));
                    labels.add(row.optString("name"));
                }
            }
            boolean[] checked=new boolean[ids.size()];
            Set<Long> selection=new LinkedHashSet<>(amenities);
            for(int i=0;i<ids.size();i++)checked[i]=selection.contains(ids.get(i));
            new AlertDialog.Builder(requireContext()).setTitle("Tiện ích phòng")
            .setMultiChoiceItems(labels.toArray(new String[0]),checked,(dialog,index,isChecked)-> {
                if(isChecked)selection.add(ids.get(index));
                else selection.remove(ids.get(index));
            })
            .setNegativeButton("Đóng",null).setPositiveButton("Chọn",(dialog,which)-> {
                if(selection.size()>30) {
                    error("Tối đa 30 tiện ích.");
                    return;
                }
                amenities.clear();
                amenities.addAll(selection);
                restoredAmenities=true;
                error("Đã chọn "+amenities.size()+" tiện ích.");
            }).show();
        }));
    }
    private void save(Button button) {
        try {
            String unit=value("unit");
            if(roomId()==null&&!unit.matches("[A-Z0-9_-]{1,30}"))throw new IllegalArgumentException("Mã phòng phải có 1–30 ký tự in hoa, số, _ hoặc -.");
            BigDecimal area=new BigDecimal(value("area").replace(',','.'));
            int occupants=Integer.parseInt(value("occupants"));
            if(area.compareTo(new BigDecimal("2"))<0||area.compareTo(new BigDecimal("1000"))>0||occupants<1||occupants>10)throw new IllegalArgumentException("Kiểm tra diện tích và số người tối đa.");
            if(value("line").length()<5||value("line").length()>300||value("province_code").isEmpty()||value("province_code").length()>20||value("province_name").isEmpty()||value("province_name").length()>100)throw new IllegalArgumentException("Nhập địa chỉ 5–300 ký tự và mã/tên tỉnh hợp lệ.");
            if(value("ward_code").isEmpty()!=value("ward_name").isEmpty())throw new IllegalArgumentException("Nhập cả mã và tên phường/xã, hoặc để trống cả hai.");
            double latitude=Double.parseDouble(value("latitude")), longitude=Double.parseDouble(value("longitude"));
            if(!Double.isFinite(latitude)||!Double.isFinite(longitude)||latitude<-90||latitude>90||longitude<-180||longitude>180)throw new IllegalArgumentException("Tọa độ không hợp lệ.");
            JSONArray ids=new JSONArray();
            for(Long id:amenities)ids.put(id);
            JSONObject address=Jsons.body("line",value("line"),"province_code",value("province_code"),"province_name",value("province_name"));
            if(!value("ward_code").isEmpty()) {
                address.put("ward_code",value("ward_code"));
                address.put("ward_name",value("ward_name"));
            }
            JSONObject body=Jsons.body("room_type",types[type.getSelectedItemPosition()],"area_m2",area.toPlainString(),
            "max_occupants",occupants,"address",address,"location",Jsons.body("latitude",latitude,"longitude",longitude),"amenity_ids",ids);
            if(roomId()==null)body.put("unit_code",unit);
            else body.put("expected_version",current.getInt("version"));
            String key=intentKey("room",body.toString());
            repository.saveRoom(roomId(),body,key,callback(button,envelope-> {
                finishIntent("room");
                clearForm();
                if(roomId()==null) {
                    String id=Jsons.data(envelope).optString("id");
                    open(HostRoomDetailFragment.newInstance(id));
                }else back();
            }));
        } catch (Exception invalid) {
            error(invalid instanceof NumberFormatException ? "Nhập đúng các trường số và tọa độ." : invalid.getMessage());
        }
    }
    @Override public void onSaveInstanceState(android.os.Bundle out) {
        if(type!=null)selectedType=type.getSelectedItemPosition();
        out.putInt("room_type_index",selectedType);
        long[] ids=new long[amenities.size()];
        int i=0;
        for(long id:amenities)ids[i++]=id;
        out.putLongArray("amenities",ids);
        super.onSaveInstanceState(out);
    }
    @Override protected void clearPrivateState() {
        amenities.clear();
        restoredAmenities=false;
        selectedType=0;
        current=null;
    }
}
