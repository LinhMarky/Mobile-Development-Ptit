package com.example.roomly.data.remote;

import org.json.JSONObject;

/** Không giữ request, token hay response body trong lỗi UI. */
public final class ApiError {
    private final int statusCode;
    private final String code;
    private final String message;
    private final JSONObject fields;

    public ApiError(int statusCode, String code, String message) {
        this(statusCode, code, message, new JSONObject());
    }

    private ApiError(int statusCode, String code, String message, JSONObject fields) {
        this.statusCode = statusCode;
        this.code = code;
        this.message = message;
        this.fields = fields;
    }

    public static ApiError fromResponse(int status, JSONObject envelope) {
        JSONObject data = Jsons.data(envelope);
        String message = data.optString("detail", envelope.optString("message", "Yêu cầu không thành công."));
        if (message.isEmpty()) message = "Yêu cầu không thành công (HTTP " + status + ").";
        return new ApiError(status, data.optString("code", "HTTP_ERROR"), message,
                Jsons.object(data, "field_errors"));
    }

    public int getStatusCode() { return statusCode; }
    public String getCode() { return code; }
    public String getMessage() { return message; }
    public String getFieldError(String key) {
        String value = fields.optString(key, "");
        return value.isEmpty() ? null : value;
    }
}
