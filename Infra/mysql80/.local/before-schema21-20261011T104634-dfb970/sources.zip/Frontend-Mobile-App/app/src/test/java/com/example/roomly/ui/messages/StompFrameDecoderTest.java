package com.example.roomly.ui.messages;

import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public class StompFrameDecoderTest {
    @Test public void reconstructsAFrameSplitBetweenWebSocketMessages() {
        StompFrameDecoder decoder = new StompFrameDecoder();
        assertTrue(decoder.accept("CONNE").isEmpty());
        assertTrue(decoder.accept("CTED\nversion:1.2\n\n").isEmpty());
        assertEquals("CONNECTED", decoder.accept("\u0000").get(0).command);
    }
    @Test public void retainsBothMessagesWhenEventAndAckShareOnePacket() {
        List<StompFrameDecoder.Frame> frames = new StompFrameDecoder().accept(
                "MESSAGE\ndestination:/user/queue/chat.messages\n\n{\"id\":9}\u0000"
                        + "MESSAGE\ndestination:/user/queue/chat.acks\n\n{\"id\":9}\u0000");
        assertEquals(2, frames.size());
        assertEquals("/user/queue/chat.messages", frames.get(0).headers.get("destination"));
        assertEquals("/user/queue/chat.acks", frames.get(1).headers.get("destination"));
    }
    @Test public void acceptsCrLfAndHeartbeatWithoutChangingUnicodeContent() {
        StompFrameDecoder decoder = new StompFrameDecoder();
        assertTrue(decoder.accept("\n\n").isEmpty());
        assertEquals("{\"content\":\"Phòng đẹp 🏠\"}", decoder.accept(
                "\r\nMESSAGE\r\ndestination:/user/queue/chat.messages\r\n\r\n"
                        + "{\"content\":\"Phòng đẹp 🏠\"}\u0000").get(0).body);
    }
    @Test public void escapedJsonNullIsPartOfContent() {
        String body = "{\"content\":\"text\\u0000inside\"}";
        assertEquals(body, new StompFrameDecoder().accept("MESSAGE\n\n" + body + "\u0000").get(0).body);
    }
    @Test public void decodesHeaderEscapesWithoutTreatingEscapedColonAsSeparator() {
        StompFrameDecoder.Frame frame = new StompFrameDecoder().accept(
                "MESSAGE\nkey\\cname:line\\nnext\\rslash\\\\\n\n{}\u0000").get(0);
        assertEquals("line\nnext\rslash\\", frame.headers.get("key:name"));
    }
    @Test public void firstRepeatedHeaderWins() {
        assertEquals("first", new StompFrameDecoder().accept(
                "MESSAGE\nid:first\nid:second\n\n{}\u0000").get(0).headers.get("id"));
    }
    @Test public void bufferLimitRejectsOversizeAndAllowsTheNextFrame() {
        StompFrameDecoder decoder = new StompFrameDecoder();
        char[] huge = new char[256 * 1024 + 1]; java.util.Arrays.fill(huge, 'x');
        try { decoder.accept(new String(huge)); fail("Must reject unbounded frame"); }
        catch (IllegalArgumentException expected) { }
        assertEquals("CONNECTED", decoder.accept("CONNECTED\n\n\u0000").get(0).command);
    }
    @Test(expected = IllegalArgumentException.class) public void invalidHeaderEscapeIsRejected() {
        new StompFrameDecoder().accept("MESSAGE\nid:bad\\tvalue\n\n{}\u0000");
    }
}
