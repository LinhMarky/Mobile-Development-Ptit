package com.example.roomly.ui.host;
import android.os.Bundle;
public class HostCreateListingFragment extends ListingFormFragment {
    public static HostCreateListingFragment newInstance(String roomId) {
        HostCreateListingFragment fragment=new HostCreateListingFragment();
        Bundle args=new Bundle();
        args.putString("room_id",roomId);
        fragment.setArguments(args);
        return fragment;
    }
}
