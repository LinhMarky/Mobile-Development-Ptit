package com.example.roomly.data.repository;
import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiClient;
import com.example.roomly.data.remote.Jsons;
import java.time.Instant;
public final class ViewingRepository {
    private final ApiClient api = ApiClient.getInstance();
    public void slots(long roomId, ApiCallback callback) {
        api.get("/viewing-slots/" + roomId, false, callback);
    }
    public void createSlot(long roomId, Instant start, Instant end, String key, ApiCallback callback) {
        api.request("POST", "/viewing-slots", Jsons.body("room_id", roomId,
        "start_at", start.toString(), "end_at", end.toString()), true, key, callback);
    }
    public void cancelSlot(long id, ApiCallback callback) {
        api.request("DELETE", "/viewing-slots/" + id, null, true, null, callback);
    }
    public void viewings(boolean host, int page, ApiCallback callback) {
        api.get("/viewings/" + (host ? "host" : "my") + "?page=" + page + "&size=20", true, callback);
    }
    public void book(long slotId, String note, String key, ApiCallback callback) {
        api.request("POST", "/viewings", Jsons.body("viewing_slot_id", slotId, "note", note), true, key, callback);
    }
    public void action(long id, String action, String key, ApiCallback callback) {
        api.request("POST", "/viewings/" + id + "/" + action, Jsons.body(), true, key, callback);
    }
}
