package com.example.roomly.ui.messages;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.roomly.R;
import com.example.roomly.data.model.ChatMessage;
import com.example.roomly.data.model.Conversation;
import com.example.roomly.data.repository.ChatRepository;
import com.example.roomly.data.repository.SessionRepository;
import com.example.roomly.databinding.FragmentChatBinding;
import com.example.roomly.ui.auth.VerifyEmailFragment;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Shows server history and keeps drafts until the server confirms persistence. */
public final class ChatFragment extends Fragment implements ChatRepository.Listener {
    private FragmentChatBinding binding;
    private ChatMessageAdapter adapter;
    private String conversationId;
    private String draft = "";
    private String visibleUser;
    private boolean attached;
    private boolean loadingOlder;
    private long lastSequence;
    private int oldCount;

    public static ChatFragment newInstance(String id) {
        ChatFragment fragment = new ChatFragment();
        Bundle args = new Bundle(); args.putString("conversation_id", id); fragment.setArguments(args);
        return fragment;
    }
    @Override public void onCreate(@Nullable Bundle state) {
        super.onCreate(state);
        conversationId = getArguments() == null ? null : getArguments().getString("conversation_id");
        visibleUser = SessionRepository.getInstance().getCurrentSession().getUserId();
        if (state != null && Objects.equals(state.getString("draft_owner"), visibleUser)) draft = state.getString("draft", "");
    }
    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater,
            @Nullable ViewGroup container, @Nullable Bundle state) {
        binding = FragmentChatBinding.inflate(inflater, container, false); return binding.getRoot();
    }
    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        adapter = new ChatMessageAdapter(new ArrayList<>());
        LinearLayoutManager manager = new LinearLayoutManager(requireContext()); manager.setStackFromEnd(true);
        binding.rvChatMessages.setLayoutManager(manager); binding.rvChatMessages.setAdapter(adapter);
        binding.edtChatMessage.setText(draft);
        binding.btnChatBack.setOnClickListener(v -> getParentFragmentManager().popBackStack());
        binding.btnSendMessage.setOnClickListener(v -> send());
        binding.btnChatReconnect.setOnClickListener(v -> ChatRepository.getInstance().reconnect(conversationId));
        binding.btnChatOlder.setOnClickListener(v -> {
            loadingOlder = true; ChatRepository.getInstance().loadOlder(conversationId);
        });
        binding.edtChatMessage.setOnEditorActionListener((v, action, event) -> {
            if (action != EditorInfo.IME_ACTION_SEND) return false;
            send(); return true;
        });
        View root = binding.getRoot();
        int bottom = root.getPaddingBottom();
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            int extra = Math.max(0, insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
                    - insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom);
            v.setPadding(v.getPaddingLeft(), v.getPaddingTop(), v.getPaddingRight(), bottom + extra); return insets;
        });
        SessionRepository.getInstance().getSessionState().observe(getViewLifecycleOwner(), session -> {
            if (!Objects.equals(visibleUser, session.getUserId())) {
                visibleUser = session.getUserId(); draft = ""; binding.edtChatMessage.setText("");
                adapter.updateMessages(new ArrayList<>()); lastSequence = 0;
                ChatRepository.getInstance().detach(this); attached = false;
            }
            if (!session.isLoggedIn()) {
                binding.tvChatStatus.setText("Đăng nhập để xem hội thoại."); binding.btnSendMessage.setEnabled(false);
            } else if (isResumed()) attach();
        });
    }
    @Override public void onResume() { super.onResume(); attach(); }
    @Override public void onPause() {
        if (binding != null) draft = binding.edtChatMessage.getText().toString();
        ChatRepository.getInstance().detach(this); attached = false;
        super.onPause();
    }
    private void attach() {
        if (binding == null || attached || !SessionRepository.getInstance().getCurrentSession().isLoggedIn()) return;
        try { if (Long.parseLong(conversationId) <= 0) throw new NumberFormatException(); }
        catch (Exception ignored) {
            binding.tvChatStatus.setText("Mã hội thoại không hợp lệ."); binding.btnSendMessage.setEnabled(false); return;
        }
        attached = true; ChatRepository.getInstance().attach(conversationId, this);
    }
    private void send() {
        if (binding == null || !binding.btnSendMessage.isEnabled()) return;
        if (!SessionRepository.getInstance().getCurrentSession().isEmailVerified()) {
            getParentFragmentManager().beginTransaction().replace(R.id.fragment_container,
                    VerifyEmailFragment.newInstance(SessionRepository.getInstance().getCurrentSession().getEmail()))
                    .addToBackStack(null).commit(); return;
        }
        String content = binding.edtChatMessage.getText().toString().trim();
        if (!content.isEmpty()) ChatRepository.getInstance().send(conversationId, content);
    }
    @Override public void onConversation(Conversation conversation) {
        if (binding == null) return;
        binding.tvChatContactName.setText(conversation.getContactName());
        binding.tvChatRoomTitle.setText(conversation.getRoomTitle());
    }
    @Override public void onMessages(List<ChatMessage> messages, boolean hasOlder) {
        if (binding == null) return;
        LinearLayoutManager manager = (LinearLayoutManager) binding.rvChatMessages.getLayoutManager();
        int first = manager == null ? 0 : manager.findFirstVisibleItemPosition();
        View firstView = manager == null ? null : manager.findViewByPosition(first);
        int offset = firstView == null ? 0 : firstView.getTop();
        adapter.updateMessages(messages);
        binding.tvChatEmpty.setText("Chưa có tin nhắn. Hãy gửi lời chào.");
        binding.tvChatEmpty.setVisibility(messages.isEmpty() ? View.VISIBLE : View.GONE);
        binding.btnChatOlder.setVisibility(hasOlder ? View.VISIBLE : View.GONE);
        long latest = messages.isEmpty() ? 0 : messages.get(messages.size() - 1).getSequence();
        if (loadingOlder && messages.size() > oldCount && latest == lastSequence) {
            if (manager != null) manager.scrollToPositionWithOffset(Math.max(0, first) + messages.size() - oldCount, offset);
            loadingOlder = false;
        } else if (latest > lastSequence) binding.rvChatMessages.scrollToPosition(messages.size() - 1);
        oldCount = messages.size(); lastSequence = latest;
    }
    @Override public void onStatus(String message, boolean canSend, String pendingContent) {
        if (binding == null) return;
        binding.tvChatStatus.setText(message);
        binding.btnSendMessage.setEnabled(canSend);
        if (pendingContent != null && binding.edtChatMessage.getText().toString().isEmpty()) binding.edtChatMessage.setText(pendingContent);
    }
    @Override public void onAcknowledged(String content) {
        if (binding == null) return;
        if (binding.edtChatMessage.getText().toString().trim().equals(content.trim())) {
            draft = ""; binding.edtChatMessage.setText("");
        }
    }
    @Override public void onSaveInstanceState(@NonNull Bundle out) {
        if (binding != null) draft = binding.edtChatMessage.getText().toString();
        out.putString("draft", draft); out.putString("draft_owner", visibleUser); super.onSaveInstanceState(out);
    }
    @Override public void onDestroyView() {
        ChatRepository.getInstance().detach(this); attached = false;
        if (binding != null) {
            ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), null);
            binding.rvChatMessages.setAdapter(null);
        }
        binding = null; adapter = null; oldCount = 0; lastSequence = 0;
        super.onDestroyView();
    }
}
