package com.example.roomly.data.model;

import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** The backend does not expose another member's name or photo in this DTO. */
public final class Conversation {
    private final String id;
    private final String contactName;
    private final String roomTitle;
    private final String preview;
    private final long activityMillis;
    private final long unreadCount;
    private final List<ChatMessage> messages = new ArrayList<>();

    public Conversation(JSONObject json, String currentUserId) {
        id = String.valueOf(json.optLong("id"));
        boolean isTenant = String.valueOf(json.optLong("tenant_id")).equals(currentUserId);
        long contactId = json.optLong(isTenant ? "host_id" : "tenant_id");
        contactName = (isTenant ? "Chủ phòng #" : "Người thuê #") + contactId;
        roomTitle = json.optString("room_title", "");
        preview = json.optString("last_message_preview", "");
        String time = json.isNull("last_message_at")
                ? json.optString("created_at", "") : json.optString("last_message_at", "");
        activityMillis = ChatMessage.parseTime(time);
        unreadCount = json.optLong("unread_count");
    }

    /** Retained for source compatibility with unused demo fixtures. */
    public Conversation(String id, String contactName, String roomTitle, int ignoredImage, long createdAt) {
        this.id = id; this.contactName = contactName; this.roomTitle = roomTitle;
        this.preview = ""; this.activityMillis = createdAt; this.unreadCount = 0;
    }
    public String getId() { return id; }
    public String getContactName() { return contactName; }
    public String getRoomTitle() { return roomTitle; }
    public int getRoomImageResId() { return com.example.roomly.R.drawable.ic_chat; }
    public long getUnreadCount() { return unreadCount; }
    public List<ChatMessage> getMessages() { return new ArrayList<>(messages); }
    public void addMessage(ChatMessage message) { messages.add(message); }
    public String getLastMessagePreview() {
        if (!messages.isEmpty()) return messages.get(messages.size() - 1).getContent();
        return preview.isEmpty() ? "Chưa có tin nhắn" : preview;
    }
    public long getLastActivityMillis() {
        return messages.isEmpty() ? activityMillis : messages.get(messages.size() - 1).getSentAtMillis();
    }
}
