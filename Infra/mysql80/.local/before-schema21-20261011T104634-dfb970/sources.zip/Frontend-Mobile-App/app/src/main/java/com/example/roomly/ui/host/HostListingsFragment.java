package com.example.roomly.ui.host;
import android.widget.LinearLayout;
import com.example.roomly.data.remote.Jsons;
import com.example.roomly.data.repository.HostRepository;
import org.json.JSONArray;
import org.json.JSONObject;
public class HostListingsFragment extends HostScreenFragment {
    private final HostRepository repository=new HostRepository();
    private int page;
    @Override protected String title() {
        return "Bài đăng của tôi";
    }
    @Override protected void render() {
        button("Tạo bài đăng từ phòng của tôi",()->open(new HostRoomsFragment()));
        button("Tải lại",this::reload);
        error("Đang tải bài đăng…");
        repository.listings(page,callback(envelope-> {
            JSONArray rows=Jsons.items(envelope);
            error(rows.length()==0?"Bạn chưa có bài đăng ở trang này.":"");
            for(int i=0;i<rows.length();i++) {
                JSONObject listing=rows.optJSONObject(i);
                if(listing==null)continue;
                String id=listing.optString("id");
                JSONObject room=Jsons.object(listing,"room");
                LinearLayout row=card(listing.optString("title")+"\nPhòng "+room.optString("unit_code")+"\n"+HostLabels.money(listing.optString("rent_vnd"))+"/tháng\n"+HostLabels.listing(listing.optString("status")));
                cardButton(row,"Xem bài đăng",()->open(HostListingDetailFragment.newInstance(id)));
            }
            JSONObject paging=Jsons.data(envelope);
            text("Trang "+(page+1)+" / "+Math.max(1,paging.optInt("total_pages")));
            if(page>0)button("Trang trước",()-> {
                page--;
                reload();
            });
            if(page+1<paging.optInt("total_pages"))button("Trang tiếp",()-> {
                page++;
                reload();
            });
        }));
    }
}
