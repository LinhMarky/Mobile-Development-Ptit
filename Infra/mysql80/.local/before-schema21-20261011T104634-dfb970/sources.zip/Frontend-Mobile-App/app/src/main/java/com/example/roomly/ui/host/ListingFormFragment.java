package com.example.roomly.ui.host;
import android.text.InputType;
import android.widget.Button;
import com.example.roomly.data.remote.Jsons;
import com.example.roomly.data.repository.HostRepository;
import org.json.JSONObject;
import java.math.BigDecimal;
public abstract class ListingFormFragment extends HostScreenFragment {
    private final HostRepository repository=new HostRepository();
    private JSONObject current=new JSONObject();
    protected String listingId() {
        return getArguments()==null?null:getArguments().getString("listing_id");
    }
    protected String roomId() {
        return getArguments()==null?null:getArguments().getString("room_id");
    }
    @Override protected String title() {
        return listingId()==null?"Tạo bài đăng":"Sửa bài đăng";
    }
    @Override protected void render() {
        error("Đang tải dữ liệu…");
        if(listingId()!=null)repository.findListing(listingId(),callback(envelope-> {
            current=Jsons.data(envelope);
            if(!current.has("id")) {
                error("Không tìm thấy bài đăng thuộc tài khoản này.");
                return;
            }
            if(!HostLabels.editable(current.optString("status"))) {
                error("Bài đăng ở trạng thái này không thể sửa.");
                button("Tải lại",this::reload);
                return;
            }
            buildForm();
        }));
        else repository.room(roomId(),callback(envelope-> {
            text("Phòng "+Jsons.data(envelope).optString("unit_code"));
            buildForm();
        }));
    }
    private void buildForm() {
        error("");
        field("title","Tiêu đề (tối đa 150 ký tự)",current.optString("title",""));
        field("description","Mô tả phòng",current.optString("description",""),InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        field("rent","Giá thuê mỗi tháng (đồng)",current.isNull("rent_vnd")?"":current.optString("rent_vnd",""),InputType.TYPE_CLASS_NUMBER);
        field("deposit","Tiền cọc (đồng), nhập 0 nếu không thu",current.isNull("deposit_vnd")?"":current.optString("deposit_vnd",""),InputType.TYPE_CLASS_NUMBER);
        text("Lưu bản nháp trước. Bạn có thể gửi duyệt tại màn hình chi tiết bài đăng.");
        final Button[] save=new Button[1];
        save[0]=button("Lưu bản nháp",()->save(save[0]));
        if(listingId()!=null)button("Tải lại dữ liệu mới nhất",()-> {
            clearForm();
            reload();
        });
        button("Quay lại",this::back);
    }
    private void save(Button button) {
        try {
            if(value("title").isEmpty()||value("title").length()>150)throw new IllegalArgumentException("Nhập tiêu đề từ 1 đến 150 ký tự.");
            if(value("description").length()>5000)throw new IllegalArgumentException("Mô tả tối đa 5000 ký tự.");
            if(!value("rent").matches("[0-9]{1,18}")||!value("deposit").matches("[0-9]{1,18}"))throw new IllegalArgumentException("Nhập giá thuê và cọc bằng số nguyên đồng, tối đa 18 chữ số.");
            BigDecimal rent=new BigDecimal(value("rent")),deposit=new BigDecimal(value("deposit"));
            if(rent.signum()<=0)throw new IllegalArgumentException("Giá thuê phải lớn hơn 0.");
            JSONObject body=Jsons.body("title",value("title"),"description",value("description"),"rent_vnd",rent.toPlainString(),"deposit_vnd",deposit.toPlainString());
            if(listingId()!=null)body.put("expected_version",current.getInt("version"));
            repository.saveListing(listingId(),roomId(),body,intentKey("listing",body.toString()),callback(button,envelope-> {
                finishIntent("listing");
                clearForm();
                if(listingId()!=null)back();
                else open(HostListingDetailFragment.newInstance(Jsons.data(envelope).optString("id")));
            }));
        }catch(Exception invalid) {
            error(invalid.getMessage());
        }
    }
}
