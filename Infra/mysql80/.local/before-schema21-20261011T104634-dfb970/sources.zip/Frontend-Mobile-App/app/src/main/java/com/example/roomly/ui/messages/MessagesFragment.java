package com.example.roomly.ui.messages;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.roomly.R;
import com.example.roomly.data.model.Conversation;
import com.example.roomly.data.repository.ChatRepository;
import com.example.roomly.data.repository.SessionRepository;
import com.example.roomly.databinding.FragmentMessagesBinding;
import com.example.roomly.ui.auth.LoginFragment;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

/** Paginated conversations from the current account, with explicit retry states. */
public final class MessagesFragment extends Fragment {
    private FragmentMessagesBinding binding;
    private ConversationAdapter adapter;
    private final Map<String, Conversation> items = new LinkedHashMap<>();
    private int page;
    private int requestVersion;
    private boolean loading;
    private boolean more;

    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater,
            @Nullable ViewGroup container, @Nullable Bundle state) {
        binding = FragmentMessagesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }
    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        adapter = new ConversationAdapter(new ArrayList<>());
        adapter.setOnConversationClickListener(this::openConversation);
        binding.rvConversations.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvConversations.setAdapter(adapter);
        binding.btnMessagesLogin.setOnClickListener(v -> open(new LoginFragment()));
        binding.btnRefreshMessages.setOnClickListener(v -> load(true));
        binding.btnMoreConversations.setOnClickListener(v -> load(false));
        SessionRepository.getInstance().getSessionState().observe(getViewLifecycleOwner(), session -> {
            requestVersion++; loading = false; items.clear(); adapter.updateConversations(new ArrayList<>());
            render();
            if (session.isLoggedIn()) load(true);
        });
    }
    @Override public void onResume() {
        super.onResume();
        if (binding != null && !loading && SessionRepository.getInstance().getCurrentSession().isLoggedIn()) load(true);
    }
    private void load(boolean reset) {
        if (binding == null || loading || !SessionRepository.getInstance().getCurrentSession().isLoggedIn()) return;
        if (!reset && !more) return;
        loading = true; int version = ++requestVersion;
        int targetPage = reset ? 0 : page + 1;
        binding.tvMessagesStatus.setText("Đang tải hội thoại…"); render();
        ChatRepository.getInstance().list(targetPage, new ChatRepository.Result<ChatRepository.ConversationPage>() {
            @Override public void onSuccess(ChatRepository.ConversationPage result) {
                if (binding == null || version != requestVersion) return;
                loading = false; page = targetPage; more = result.hasMore;
                if (reset) items.clear();
                for (Conversation conversation : result.items) items.put(conversation.getId(), conversation);
                adapter.updateConversations(new ArrayList<>(items.values()));
                binding.tvMessagesStatus.setText(items.isEmpty() ? "Chưa có hội thoại." : ""); render();
            }
            @Override public void onError(String message) {
                if (binding == null || version != requestVersion) return;
                loading = false; binding.tvMessagesStatus.setText(message + " Bấm Làm mới để thử lại."); render();
            }
        });
    }
    private void render() {
        if (binding == null) return;
        boolean loggedIn = SessionRepository.getInstance().getCurrentSession().isLoggedIn();
        binding.layoutMessagesGuest.setVisibility(loggedIn ? View.GONE : View.VISIBLE);
        binding.layoutMessagesEmpty.setVisibility(loggedIn && !loading && items.isEmpty() ? View.VISIBLE : View.GONE);
        binding.rvConversations.setVisibility(loggedIn && !items.isEmpty() ? View.VISIBLE : View.GONE);
        binding.btnRefreshMessages.setVisibility(loggedIn ? View.VISIBLE : View.GONE);
        binding.btnRefreshMessages.setEnabled(!loading);
        binding.btnMoreConversations.setVisibility(loggedIn && more ? View.VISIBLE : View.GONE);
        binding.btnMoreConversations.setEnabled(!loading);
        if (!loggedIn) binding.tvMessagesStatus.setText("");
    }
    private void openConversation(Conversation conversation) {
        if (SessionRepository.getInstance().getCurrentSession().isLoggedIn()) open(ChatFragment.newInstance(conversation.getId()));
        else open(new LoginFragment());
    }
    private void open(Fragment fragment) {
        if (!isAdded()) return;
        getParentFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).addToBackStack(null).commit();
    }
    @Override public void onDestroyView() {
        requestVersion++; loading = false;
        if (binding != null) binding.rvConversations.setAdapter(null);
        binding = null; adapter = null;
        super.onDestroyView();
    }
}