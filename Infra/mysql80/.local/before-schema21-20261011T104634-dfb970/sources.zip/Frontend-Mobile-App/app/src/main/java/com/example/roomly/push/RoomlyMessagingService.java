package com.example.roomly.push;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.core.app.NotificationCompat;
import com.example.roomly.MainActivity;
import com.example.roomly.data.repository.SessionRepository;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

/** Data-only FCM; never display another account's queued notification. */
public final class RoomlyMessagingService extends FirebaseMessagingService {
    public static final String CHANNEL_ID = "roomly_updates";
    @Override public void onNewToken(String token) {
        PushTokenRepository.initialize(this);
        PushTokenRepository.getInstance().onNewToken(token);
    }
    @Override public void onMessageReceived(RemoteMessage message) {
        Map<String, String> data = new java.util.HashMap<>(message.getData());
        new Handler(Looper.getMainLooper()).post(() -> display(data));
    }
    private void display(Map<String, String> data) {
        String user = SessionRepository.getInstance().getCurrentSession().getUserId();
        if (user == null || !user.equals(data.get("recipient_id"))) return;
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager == null || !manager.areNotificationsEnabled()) return;
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(new NotificationChannel(CHANNEL_ID,
                    "Tin nhắn và cập nhật giao dịch", NotificationManager.IMPORTANCE_DEFAULT));
        }
        String notificationId = data.get("notification_id");
        if (notificationId == null || notificationId.isEmpty()) return;
        int id = notificationId.hashCode();
        Intent intent = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("recipient_id", user).putExtra("ref_type", data.get("ref_type"))
                .putExtra("ref_id", data.get("ref_id"));
        PendingIntent pending = PendingIntent.getActivity(this, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String title = data.get("title"), body = data.get("body");
        manager.notify(id, new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title == null || title.isEmpty() ? "Roomly" : title)
                .setContentText(body == null ? "Có cập nhật mới." : body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setContentIntent(pending).setAutoCancel(true).build());
    }
}
