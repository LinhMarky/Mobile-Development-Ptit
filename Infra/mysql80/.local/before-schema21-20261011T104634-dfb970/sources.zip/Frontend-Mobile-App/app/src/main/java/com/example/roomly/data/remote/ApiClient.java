package com.example.roomly.data.remote;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import com.example.roomly.BuildConfig;
import com.example.roomly.data.repository.SessionRepository;

import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.Executors;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okio.BufferedSink;

/** Android facade: HTTP dùng chung, main-thread callbacks và upload từ ContentResolver. */
public final class ApiClient {
    private static ApiClient instance;
    private final Context context;
    private final HttpApi http;

    private ApiClient(Context context) {
        this.context = context.getApplicationContext();
        SessionRepository session = SessionRepository.getInstance();
        Handler main = new Handler(Looper.getMainLooper());
        http = new HttpApi(BuildConfig.API_URL, new HttpApi.Tokens() {
            public String accessToken() { return session.getAccessToken(); }
            public String refreshToken() { return session.getRefreshToken(); }
            public long generation() { return session.getGeneration(); }
            public boolean acceptRefresh(JSONObject data, long generation, String previous) {
                return session.acceptRefresh(data, generation, previous);
            }
            public void expire(long generation) { session.clearIfCurrent(generation); }
        }, main::post);
    }

    public static synchronized void initialize(Context context) {
        if (instance == null) instance = new ApiClient(context);
    }

    public static synchronized ApiClient getInstance() {
        if (instance == null) throw new IllegalStateException("Application not initialized");
        return instance;
    }

    public String url(String path) { return http.url(path); }
    public String mediaUrl(long id) { return url("media/" + id + "/content"); }
    public String websocketUrl() { return http.websocketUrl(); }
    public OkHttpClient httpClient() { return http.httpClient(); }
    public Request.Builder authorizedRequest(String path) { return http.authorizedRequest(path); }

    public void get(String path, boolean auth, ApiCallback callback) {
        request("GET", path, null, auth, null, callback);
    }

    public void request(String method, String path, JSONObject body, boolean auth,
                        String idempotencyKey, ApiCallback callback) {
        http.request(method, path, body, auth, idempotencyKey, callback);
    }

    public void upload(Uri uri, String purpose, ApiCallback callback) {
        String mime = context.getContentResolver().getType(uri);
        if (mime == null || (!mime.equals("image/jpeg") && !mime.equals("image/png"))) {
            new Handler(Looper.getMainLooper()).post(() -> callback.onError(
                    new ApiError(400, "INVALID_IMAGE", "Chọn ảnh JPEG hoặc PNG.")));
            return;
        }
        RequestBody image = new RequestBody() {
            @Override public MediaType contentType() { return MediaType.get(mime); }
            @Override public void writeTo(BufferedSink sink) throws IOException {
                try (InputStream stream = context.getContentResolver().openInputStream(uri)) {
                    if (stream == null) throw new IOException("Cannot read image");
                    byte[] buffer = new byte[8192];
                    long total = 0;
                    int count;
                    while ((count = stream.read(buffer)) != -1) {
                        total += count;
                        if (total > 10 * 1024 * 1024) throw new IOException("Image exceeds upload limit");
                        sink.write(buffer, 0, count);
                    }
                } catch (SecurityException error) {
                    throw new IOException("Image permission expired");
                }
            }
        };
        String name = mime.equals("image/png") ? "room.png" : "room.jpg";
        RequestBody body = new MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("file", name, image).build();
        http.send("POST", "media/upload?purpose=" + Uri.encode(purpose), body, true, null, callback);
    }
}
