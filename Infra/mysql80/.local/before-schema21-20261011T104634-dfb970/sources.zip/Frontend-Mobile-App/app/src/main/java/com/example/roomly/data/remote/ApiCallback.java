package com.example.roomly.data.remote;

import org.json.JSONObject;

/** Callback chạy trên main thread, response giữ global wrapper. */
public interface ApiCallback {
    void onSuccess(JSONObject envelope);
    void onError(ApiError error);
}
