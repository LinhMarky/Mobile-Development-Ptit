package com.example.roomly.ui.profile;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.example.roomly.R;
import com.example.roomly.data.model.AppMode;
import com.example.roomly.data.model.SessionState;
import com.example.roomly.data.model.UserRole;
import com.example.roomly.data.remote.ApiCallback;
import com.example.roomly.data.remote.ApiClient;
import com.example.roomly.data.remote.ApiError;
import com.example.roomly.data.remote.Jsons;
import com.example.roomly.data.repository.AuthRepository;
import com.example.roomly.data.repository.SessionRepository;
import com.example.roomly.databinding.BottomSheetEditProfileBinding;
import com.example.roomly.databinding.FragmentProfileBinding;
import com.example.roomly.push.PushTokenRepository;
import com.example.roomly.ui.auth.LoginFragment;
import com.example.roomly.ui.auth.VerifyEmailFragment;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import org.json.JSONObject;

/** Profile actions are accepted only after the backend confirms them. */
public final class ProfileFragment extends Fragment {
    private FragmentProfileBinding binding;
    private ProfileViewModel viewModel;
    private BottomSheetDialog editDialog;
    private SessionState current = SessionState.guest();
    private String phone = "";
    private String phoneOwner;
    private boolean busy;
    private int viewVersion;

    @Override public void onCreate(@Nullable Bundle state) {
        super.onCreate(state); viewModel = new ViewModelProvider(this).get(ProfileViewModel.class);
    }
    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater,
            @Nullable ViewGroup container, @Nullable Bundle state) {
        binding = FragmentProfileBinding.inflate(inflater, container, false); return binding.getRoot();
    }
    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        binding.btnOpenLogin.setOnClickListener(v -> open(new LoginFragment()));
        binding.btnProfileVerifyEmail.setOnClickListener(v -> verifyEmail());
        binding.btnEditProfile.setOnClickListener(v -> editProfile());
        binding.btnModeTenant.setOnClickListener(v -> viewModel.selectMode(AppMode.TENANT));
        binding.btnModeHost.setOnClickListener(v -> viewModel.selectMode(AppMode.HOST));
        binding.btnEnableHost.setOnClickListener(v -> enableHost());
        binding.btnProfileLogout.setOnClickListener(v -> confirmLogout());
        binding.btnNotificationSettings.setOnClickListener(v -> startActivity(
                new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, requireContext().getPackageName())));
        viewModel.getSessionState().observe(getViewLifecycleOwner(), session -> {
            current = session;
            if (!java.util.Objects.equals(phoneOwner, current.getUserId())) { phone = ""; phoneOwner = current.getUserId(); }
            render();
        });
        viewModel.getMode().observe(getViewLifecycleOwner(), mode -> render());
        PushTokenRepository.getInstance().getStatus().observe(getViewLifecycleOwner(), status -> {
            if (binding != null) binding.tvPushStatus.setText(status);
        });
    }
    @Override public void onResume() {
        super.onResume(); loadProfile(); PushTokenRepository.getInstance().onSessionChanged();
    }
    private boolean valid(int version, long generation) {
        return binding != null && version == viewVersion && generation == SessionRepository.getInstance().getGeneration();
    }
    private void loadProfile() {
        if (binding == null || !SessionRepository.getInstance().getCurrentSession().isLoggedIn()) return;
        int version = viewVersion; long generation = SessionRepository.getInstance().getGeneration();
        ApiClient.getInstance().get("/profile", true, new ApiCallback() {
            @Override public void onSuccess(JSONObject envelope) {
                if (!valid(version, generation)) return;
                JSONObject profile = Jsons.data(envelope);
                phone = profile.isNull("phone") ? "" : profile.optString("phone", ""); render();
            }
            @Override public void onError(ApiError error) { if (valid(version, generation)) toast(error.getMessage()); }
        });
    }
    private void render() {
        if (binding == null) return;
        boolean loggedIn = current.isLoggedIn();
        binding.layoutProfileGuest.setVisibility(loggedIn ? View.GONE : View.VISIBLE);
        binding.layoutProfileAccount.setVisibility(loggedIn ? View.VISIBLE : View.GONE);
        binding.tvProfileName.setText(current.getFullName()); binding.tvProfileEmail.setText(current.getEmail());
        binding.tvProfilePhone.setText(phone); binding.tvProfilePhone.setVisibility(phone.isEmpty() ? View.GONE : View.VISIBLE);
        binding.tvProfileVerification.setText(current.isEmailVerified() ? "Email đã được xác minh" : "Email chưa được xác minh");
        binding.btnProfileVerifyEmail.setVisibility(loggedIn && !current.isEmailVerified() ? View.VISIBLE : View.GONE);
        binding.btnEditProfile.setEnabled(loggedIn && !busy);
        binding.btnProfileLogout.setEnabled(loggedIn && !busy);
        binding.btnEnableHost.setVisibility(loggedIn && !current.hasRole(UserRole.HOST) ? View.VISIBLE : View.GONE);
        binding.btnEnableHost.setEnabled(!busy);
        boolean tenant = current.hasRole(UserRole.TENANT), host = current.hasRole(UserRole.HOST);
        binding.layoutProfileMode.setVisibility(tenant || host ? View.VISIBLE : View.GONE);
        binding.btnModeTenant.setVisibility(tenant ? View.VISIBLE : View.GONE);
        binding.btnModeHost.setVisibility(host ? View.VISIBLE : View.GONE);
        AppMode mode = viewModel.getCurrentMode();
        modeButton(binding.btnModeTenant, mode == AppMode.TENANT);
        modeButton(binding.btnModeHost, mode == AppMode.HOST);
        binding.tvProfileCurrentMode.setText(mode == AppMode.HOST ? "Đang sử dụng chế độ Chủ trọ" : "Đang sử dụng chế độ Người thuê");
    }
    private void modeButton(MaterialButton button, boolean selected) {
        button.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(requireContext(),
                selected ? R.color.roomly_primary : R.color.roomly_surface)));
        button.setTextColor(ContextCompat.getColor(requireContext(), selected ? R.color.roomly_surface : R.color.roomly_primary));
        button.setSelected(selected);
    }
    private boolean verified() {
        current = SessionRepository.getInstance().getCurrentSession();
        if (!current.isLoggedIn()) { open(new LoginFragment()); return false; }
        if (!current.isEmailVerified()) { verifyEmail(); return false; }
        return true;
    }
    private void verifyEmail() {
        current = SessionRepository.getInstance().getCurrentSession();
        open(current.isLoggedIn() ? VerifyEmailFragment.newInstance(current.getEmail()) : new LoginFragment());
    }
    private void enableHost() {
        if (busy || !verified()) return;
        new MaterialAlertDialogBuilder(requireContext()).setTitle("Đăng ký làm chủ phòng")
                .setMessage("Tài khoản sẽ có thêm quyền đăng và quản lý phòng.")
                .setNegativeButton("Để sau", null).setPositiveButton("Đăng ký", (dialog, which) -> {
                    if (binding == null) return;
                    busy = true; render(); int version = viewVersion; long generation = SessionRepository.getInstance().getGeneration();
                    AuthRepository.getInstance().enableHost(new ApiCallback() {
                        @Override public void onSuccess(JSONObject envelope) {
                            if (!valid(version, generation)) return;
                            busy = false; viewModel.selectMode(AppMode.HOST); render(); toast("Đã bật quyền chủ phòng.");
                        }
                        @Override public void onError(ApiError error) {
                            if (!valid(version, generation)) return;
                            busy = false; render(); toast(error.getMessage());
                        }
                    });
                }).show();
    }
    private void confirmLogout() {
        if (busy) return;
        new MaterialAlertDialogBuilder(requireContext()).setTitle("Đăng xuất?")
                .setMessage("Phiên hiện tại và đăng ký thông báo của thiết bị sẽ được tắt trên máy chủ.")
                .setNegativeButton("Hủy", null).setPositiveButton("Đăng xuất", (dialog, which) -> {
                    if (binding == null) return;
                    busy = true; render(); int version = viewVersion;
                    AuthRepository.getInstance().logout(new ApiCallback() {
                        @Override public void onSuccess(JSONObject envelope) {
                            if (binding == null || version != viewVersion) return;
                            busy = false; phone = ""; current = SessionRepository.getInstance().getCurrentSession(); render();
                            toast("Đã đăng xuất.");
                        }
                        @Override public void onError(ApiError error) {
                            if (binding == null || version != viewVersion) return;
                            busy = false; render(); toast(error.getMessage() + " Bạn vẫn đang đăng nhập; hãy thử lại.");
                        }
                    });
                }).show();
    }
    private void editProfile() {
        if (busy || !verified() || editDialog != null) return;
        BottomSheetEditProfileBinding form = BottomSheetEditProfileBinding.inflate(getLayoutInflater());
        BottomSheetDialog dialog = new BottomSheetDialog(requireContext()); editDialog = dialog;
        dialog.setContentView(form.getRoot());
        form.edtProfileName.setText(current.getFullName()); form.edtProfileEmail.setText(current.getEmail());
        form.edtProfilePhone.setText(phone);
        dialog.setOnDismissListener(ignored -> { if (editDialog == dialog) editDialog = null; });
        form.btnSaveProfile.setOnClickListener(v -> {
            String name = form.edtProfileName.getText().toString().trim();
            String newPhone = form.edtProfilePhone.getText().toString().trim();
            form.layoutProfileName.setError(null); form.layoutProfilePhone.setError(null);
            if (name.length() < 2 || name.length() > 100) { form.layoutProfileName.setError("Họ tên cần từ 2 đến 100 ký tự."); return; }
            if (newPhone.length() > 15) { form.layoutProfilePhone.setError("Số điện thoại tối đa 15 ký tự."); return; }
            form.btnSaveProfile.setEnabled(false); form.btnSaveProfile.setText("Đang lưu…");
            int version = viewVersion; long generation = SessionRepository.getInstance().getGeneration();
            ApiClient.getInstance().request("PATCH", "/profile", Jsons.body("fullName", name, "phone", newPhone), true, null,
                    new ApiCallback() {
                @Override public void onSuccess(JSONObject envelope) {
                    if (!valid(version, generation) || editDialog != dialog) return;
                    phone = newPhone;
                    AuthRepository.getInstance().refreshAccount(new ApiCallback() {
                        @Override public void onSuccess(JSONObject refreshed) {
                            if (!valid(version, generation)) return;
                            dialog.dismiss(); render(); toast("Đã cập nhật thông tin.");
                        }
                        @Override public void onError(ApiError error) {
                            if (!valid(version, generation)) return;
                            dialog.dismiss(); render(); toast("Thông tin đã được lưu. Chưa tải lại được hồ sơ: " + error.getMessage());
                        }
                    });
                }
                @Override public void onError(ApiError error) {
                    if (!valid(version, generation) || editDialog != dialog) return;
                    form.btnSaveProfile.setEnabled(true); form.btnSaveProfile.setText("Lưu thay đổi");
                    form.layoutProfileName.setError(error.getFieldError("fullName"));
                    form.layoutProfilePhone.setError(error.getFieldError("phone")); toast(error.getMessage());
                }
            });
        });
        dialog.show();
    }
    private void open(Fragment fragment) {
        if (binding != null) getParentFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment)
                .addToBackStack(null).commit();
    }
    private void toast(String text) { if (isAdded()) Toast.makeText(requireContext(), text, Toast.LENGTH_LONG).show(); }
    @Override public void onDestroyView() {
        viewVersion++; busy = false;
        if (editDialog != null) { editDialog.dismiss(); editDialog = null; }
        binding = null; super.onDestroyView();
    }
}