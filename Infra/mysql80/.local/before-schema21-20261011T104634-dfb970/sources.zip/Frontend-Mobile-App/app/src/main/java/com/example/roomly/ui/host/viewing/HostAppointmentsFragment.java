package com.example.roomly.ui.host.viewing;
import com.example.roomly.ui.schedule.AppointmentsScreenFragment;
public class HostAppointmentsFragment extends AppointmentsScreenFragment {
    @Override protected boolean isHost() {
        return true;
    }
}
