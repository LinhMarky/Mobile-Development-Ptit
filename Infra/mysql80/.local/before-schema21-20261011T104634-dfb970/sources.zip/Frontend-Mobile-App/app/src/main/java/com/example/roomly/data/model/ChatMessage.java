package com.example.roomly.data.model;

import org.json.JSONObject;
import java.time.Instant;

/** A message displayed as sent only after it exists on the server. */
public final class ChatMessage {
    private final long id;
    private final long conversationId;
    private final long sequence;
    private final String clientMessageId;
    private final String content;
    private final long sentAtMillis;
    private final boolean sentByMe;

    public ChatMessage(JSONObject json, String currentUserId) {
        id = json.optLong("id");
        conversationId = json.optLong("conversation_id");
        sequence = json.optLong("sequence");
        clientMessageId = json.optString("client_message_id", "");
        content = json.optString("content", "");
        sentAtMillis = parseTime(json.optString("created_at", ""));
        sentByMe = String.valueOf(json.optLong("sender_id")).equals(currentUserId);
    }

    /** Compatibility for unused demo fixtures; production screens use server DTOs. */
    public ChatMessage(String content, long sentAtMillis, boolean sentByMe) {
        this.id = 0; this.conversationId = 0; this.sequence = 0;
        this.clientMessageId = ""; this.content = content;
        this.sentAtMillis = sentAtMillis; this.sentByMe = sentByMe;
    }

    public static long parseTime(String value) {
        try { return Instant.parse(value).toEpochMilli(); }
        catch (RuntimeException ignored) { return 0; }
    }
    public long getId() { return id; }
    public long getConversationId() { return conversationId; }
    public long getSequence() { return sequence; }
    public String getClientMessageId() { return clientMessageId; }
    public String getContent() { return content; }
    public long getSentAtMillis() { return sentAtMillis; }
    public boolean isSentByMe() { return sentByMe; }
}
