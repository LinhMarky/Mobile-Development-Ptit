# Chat & WebSocket

Cập nhật ngày 09/10/2026 theo contract v1.6. Chạy backend bằng Java 17+ và Maven; Flyway quản lý schema, các bảng chat được tạo từ `V11__chat_tables.sql`. REST dùng global HTTP JSON wrapper `{statusCode,message,data}`; DTO/page nằm trong `data`, lỗi có ProblemDTO trong `data`. STOMP dùng MessageDTO/ProblemDTO trực tiếp. Đặc tả REST tại [openapi.yaml](openapi.yaml), hiện trạng và bằng chứng tại [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md).

## REST

Mọi request dùng `Authorization: Bearer <access_token>`. POST phải có `Idempotency-Key` không trắng, tối đa 128 ký tự. Cùng khóa/cùng body trả snapshot response lần đầu; quyền và trạng thái tài khoản được kiểm tra lại trước replay. Đổi body là thao tác khác cần khóa mới, nhưng nếu kết quả thao tác cũ chưa rõ thì phải đối chiếu trạng thái trước, không đổi khóa để bỏ qua lỗi PROCESSING.

| Method | Path | Request → kết quả trong `data` |
| --- | --- | --- |
| POST | `/api/v1/conversations` | `{"room_id": 12}` → 201 với conversation đã tạo hoặc đã tồn tại |
| GET | `/api/v1/conversations?page=0&size=20` | Danh sách của tài khoản hiện tại, size tối đa 50 |
| GET | `/api/v1/conversations/{id}` | Chi tiết, `last_read_sequence`, `unread_count` |
| GET | `/api/v1/conversations/{id}/messages?limit=20` | Cửa sổ tin mới nhất, kết quả theo sequence tăng dần |
| POST | `/api/v1/conversations/{id}/read-marker` | `{"last_read_sequence": 8}` → marker không giảm, không vượt sequence mới nhất |

Lịch sử nhận MessagePageDTO bên trong envelope: `response.data` là `{data: [...], next_cursor: number|null, has_more: boolean}`; danh sách tin ở `response.data.data`. `limit` 1..50, mặc định 20, kết quả luôn theo sequence tăng dần. Tải tin cũ bằng `before_sequence=next_cursor`; đồng bộ tin mới bằng `after_sequence=<sequence cuối đã nhận>`. Hai cursor loại trừ biên và không được truyền cùng lúc. `has_more` theo hướng đang đọc; `next_cursor` chỉ dùng cho cửa sổ mới nhất/tin cũ và luôn null khi đọc `after_sequence`. Chưa hỗ trợ `around_sequence`.

Tạo/mở yêu cầu ACTIVE và email verified; tạo hội thoại mới cần listing PUBLISHED chưa hết hạn. Chủ phòng không được tự mở hội thoại với mình. Conversation đã tồn tại vẫn giữ title snapshot và lịch sử khi listing bị ẩn/archive. Chỉ hai thành viên đọc được dữ liệu; tài khoản inactive bị chặn. `unread_count` không tính tin do chính mình gửi. Read marker không giảm và không vượt sequence mới nhất.

## STOMP dành cho Android native

1. Mở WebSocket `/ws` với HTTP header `Authorization: Bearer <access_token>`. Dùng `wss://` ở môi trường triển khai. Không đưa token vào query string; không dùng refresh token. Không có SockJS.
2. Gửi STOMP CONNECT bình thường; không gửi thêm header `login`, `passcode`, `user`, `simpUser`, `Authorization` trong STOMP frame. Danh tính lấy từ handshake.
3. Subscribe `/user/queue/chat.messages`, `/user/queue/chat.acks`, `/user/queue/chat.errors`. Không thay `/user` bằng ID/email; không subscribe trực tiếp `/queue` hay `/topic`.
4. SEND `/app/chat.send`, `content-type:application/json`, ví dụ:

```json
{"conversation_id":10,"content":"Phòng còn trống không?","client_message_id":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa","content_type":"TEXT"}
```

Tin gửi yêu cầu thành viên ACTIVE + email verified; content không trắng và tối đa 5000 ký tự. Phase 7 chỉ nhận TEXT; IMAGE/SYSTEM là enum dự trữ và bị từ chối.

ACK tại `/user/queue/chat.acks` là MessageDTO đã lưu, có `id`, `conversation_id`, `sender_id`, `client_message_id`, `content`, `content_type`, `sequence`, `created_at`. Tin mới cũng được gửi tới `/user/queue/chat.messages` của cả hai bên **sau khi transaction commit**. ACK chỉ gửi về phiên đã thực hiện SEND.

Giữ nguyên UUID và body khi retry. UUID chuẩn hóa chữ thường; retry cùng tin trả lại MessageDTO cũ, không tạo tin mới hay phát lại event. Dùng UUID cũ cho body/người gửi khác nhận lỗi 409. Deduplicate ở UI bằng `id` hoặc `(conversation_id, sequence)`, vì người gửi có thể nhận cả ACK lẫn event.

Lỗi xử lý payload/nghiệp vụ nhận ProblemDTO qua `/user/queue/chat.errors`. Vi phạm giao thức/quyền destination có thể trả STOMP ERROR rồi đóng kết nối. Lỗi chưa có correlation bắt buộc tới UUID: đừng đánh dấu tùy ý một tin đang chờ là thất bại; retry UUID đó hoặc đối chiếu history. Token hết hạn/tài khoản bị khóa bị chặn ở cả inbound và trước khi nhận MESSAGE qua kết nối đang mở.

## Kết nối lại và vận hành

Lưu sequence cuối cho từng hội thoại. Sau reconnect và subscribe, gọi REST `after_sequence` lặp tới `has_more=false`, kết hợp tin realtime bằng dedup; sau đó retry các UUID chưa có ACK. Không coi STOMP receipt là xác nhận lưu database.

- Simple broker và rate limit trong process: bản hiện tại chạy một backend instance. Mở rộng nhiều instance cần broker/limiter dùng chung.
- Realtime là best effort; database lưu lịch sử bền vững, REST phục hồi tin bỏ lỡ. Không có durable queue cho frame STOMP, không cam kết delivery exactly-once qua mạng.
- Tin chat đã có producer tạo inbox cho người nhận và delivery trong MySQL outbox; FCM worker có retry/preference/invalid-token handling. Đây là kênh thông báo riêng, không thay thế history/resync. Không dùng Kafka.
- `homely.chat.rest-requests-per-minute=120`: giới hạn HTTP theo tài khoản, lỗi 429 có `Retry-After: 60`.
- `homely.chat.messages-per-minute=60`: giới hạn SEND theo tài khoản, chung cho các socket.
- `homely.chat.allowed-origins`: danh sách origin HTTP(S) phân cách dấu phẩy nếu cần; không nhận wildcard. Client native không gửi Origin vẫn kết nối được.
- Giới hạn frame 32 KiB, buffer gửi 256 KiB, thời gian gửi 10 giây.

## Tích hợp và nghiệm thu

Project Firebase thật `roomly-6d99d` đã cấu hình backend local bật FCM/healthy; OAuth/API V1 validate-only được Google chấp nhận HTTP 200 ngày 09/10. Delivery tới điện thoại chưa kiểm chứng, Roomly FE chưa ghép API/FCM hoàn tất. Xem [FIREBASE_SETUP.md](FIREBASE_SETUP.md). Chỉ đánh dấu chat/push trên app hoàn tất sau thử hai tài khoản, foreground/background, logout/chuyển tài khoản và mạng mất/kết nối lại.

Khi nghiệm thu, cần hội thoại trên 100 tin, tải tin cũ, reconnect/resync và ACK chậm không tạo tin trùng. Các test tự động và bằng chứng backend hiện hành nằm tại [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md); kết quả backend không thay thế thử thiết bị. Integration test phải dùng schema MySQL riêng, không dùng database ứng dụng.
