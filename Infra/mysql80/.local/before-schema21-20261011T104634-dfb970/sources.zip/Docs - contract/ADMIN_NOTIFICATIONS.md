# Admin và thông báo trong ứng dụng

Cập nhật ngày 09/10/2026 theo controller/service và contract v1.6. API dùng base `/api/v1`, access JWT ở header `Authorization: Bearer ...`. HTTP JSON có global wrapper `{statusCode,message,data}`; DTO/page nằm trong `data`, lỗi có ProblemDTO trong `data` và giữ HTTP status thật. STOMP dùng DTO trực tiếp. Xem [hiện trạng và backlog](IMPLEMENTATION_STATUS.md).

Mọi POST dưới `/admin` và `/notifications` cần `Idempotency-Key` không trắng, tối đa 128 ký tự. Retry cùng key và request trả snapshot cũ sau khi kiểm tra lại tài khoản/quyền. Payload hoặc query khác là thao tác khác; khi kết quả lần trước chưa rõ, đối chiếu trạng thái trước khi tạo thao tác mới, không đổi key để chạy lại mù quáng.

## Admin

Các POST trong bảng trả HTTP 200 với envelope có `data: null` khi thành công. `id` phải dương. Tham số lý do/ghi chú nằm ở query string và phải được URL-encode; đây là định dạng hiện có của controller.

| GET path | Kết quả trong `data` |
| --- | --- |
| `/admin/listings?page=0&size=20` | PageResponse các listing PENDING_REVIEW |
| `/admin/cases?page=0&size=20` | PageResponse các case OPEN/IN_REVIEW, ưu tiên created_at tăng dần |

| POST path | Tham số bắt buộc | Hành vi |
| --- | --- | --- |
| `/admin/listings/{id}/approve` | — | PENDING_REVIEW → PUBLISHED; đặt published_at, expires_at sau đúng 30 ngày và snapshot terms_version |
| `/admin/listings/{id}/reject` | `reason`, không trắng, tối đa 500 ký tự | Chỉ từ PENDING_REVIEW; lưu lý do trong audit, gửi thông báo cho host |
| `/admin/listings/{id}/suspend` | `reason`, tối đa 500 | PUBLISHED/HIDDEN → SUSPENDED; host không tự submit lại tin bị tạm ngưng |
| `/admin/users/{id}/suspend` | `reason`, tối đa 500 | Khóa tài khoản ACTIVE, đồng bộ status/cờ suspended và thu hồi các refresh session; không được tự khóa mình |
| `/admin/users/{id}/unsuspend` | — | Mở khóa tài khoản SUSPENDED hoặc cờ legacy; không hồi sinh tài khoản DELETED hay session đã thu hồi |
| `/admin/cases/{id}/resolve` | `decision`, `note` không trắng, tối đa 2000; `tenant_refund_vnd` khi SPLIT | OPEN/IN_REVIEW → RESOLVED; xử lý sandbox theo decision, ghi người xử lý/thời điểm và thông báo hai bên |
| `/admin/reports/{id}/resolve` | `note`, không trắng, tối đa 1000 | PENDING/REVIEWING → RESOLVED, thông báo người báo cáo |
| `/admin/reviews/{id}/hide` | `reason`, tối đa 500 | Ẩn review đang hiển thị và lưu audit |

Decision và settlement hiện được thực hiện trong cùng transaction:

| Decision | Hành vi sandbox |
| --- | --- |
| `REFUND_TENANT` | Hoàn toàn bộ payment đã phân bổ cho booking |
| `FORFEIT_DEPOSIT` | Hoàn 0, ghi nhận host giữ toàn bộ tiền cọc |
| `SPLIT` | Bắt buộc query `tenant_refund_vnd` là số nguyên VND, lớn hơn 0 và nhỏ hơn số tiền payment; ghi phần tenant được hoàn và host giữ |
| `NO_ACTION` | Chỉ ghi kết luận; không settlement hoặc thay trạng thái booking/phòng |

Ba quyết định có settlement yêu cầu booking CONFIRMED và payment đã phân bổ SUCCEEDED. Refund dương được ghi SUCCEEDED theo cơ chế mô phỏng; booking chuyển CANCELLED và phòng AVAILABLE. Đây là sổ ghi nhận sandbox, chưa chuyển khoản thật. Trường hợp NO_ACTION rồi job quá hạn chạy lại cần được chốt trong [khoảng trống nghiệp vụ](CONTRACT_GAPS.md).

Chưa có endpoint khôi phục listing SUSPENDED. Admin có resolve report nhưng chưa có GET hàng đợi/detail report; các khoảng trống này vẫn nằm trong backlog.

Mỗi thao tác thay đổi trạng thái hợp lệ ghi audit trong cùng transaction; lỗi hoặc rollback không để lại audit/thông báo thành công. Gọi lại một chuyển trạng thái đã hoàn tất bằng key mới trả 409. Optimistic locking ngăn hai lần duyệt cùng commit. Reason/note được lưu trong audit JSON, không ghi nguyên nội dung vào log ứng dụng.

JWT lấy danh sách role được cấp trong database, gồm `ROLE_ADMIN` khi có; không tự thêm quyền TENANT. Admin đã bị gỡ role không thể dùng response cache cũ để vượt kiểm tra quyền. Cả status SUSPENDED và cờ suspended legacy đều chặn đăng nhập, refresh, request HTTP có JWT và chat theo guard hiện có. Mở khóa không phục hồi refresh session cũ; cơ chế access JWT hiện tại vẫn dựa vào TTL và trạng thái tài khoản, chưa có danh sách thu hồi access token riêng.

## Hộp thông báo

Các kết quả trong bảng nằm trong `data` của global wrapper. HTTP lỗi dùng `application/json` envelope, `data` là ProblemDTO; không đổi lỗi 4xx/5xx thành HTTP 200.

| Method | Path | Kết quả trong `data` |
| --- | --- | --- |
| GET | `/notifications?page=0&size=20` | PageResponse; size 1..50; sắp xếp created_at DESC, id DESC; không áp dụng sort tùy ý |
| GET | `/notifications/unread-count` | `{"unread_count": 2}` |
| POST | `/notifications/{id}/read` | NotificationDTO thuộc người gọi; không thuộc quyền sở hữu trả 404 |
| POST | `/notifications/read-all` | `{"updated": 2}`; số bản ghi đổi từ chưa đọc sang đã đọc |
| POST | `/notifications/mark-all-read` | Alias cũ, nên chuyển client sang `/read-all` |

NotificationDTO gồm `id`, `type`, `title`, `body`, `ref_type`, `ref_id`, `is_read`, `created_at`. Client nên xử lý được type mới. Inbox và các delivery trong MySQL outbox được ghi cùng transaction nghiệp vụ; rollback không để lại thông báo thành công. Các luồng admin, booking, payment, viewing và chat đã có producer; không dùng Kafka.

## FCM và giới hạn nghiệm thu

Worker có claim/lease, gửi qua Firebase Admin SDK ngoài transaction, backoff/retry, kiểm tra preference và loại token không còn hợp lệ. Payload data-only có sáu trường chuỗi: `notification_id`, `recipient_id`, `title`, `body`, `ref_type`, `ref_id`. Không nhầm payload push với NotificationDTO trong inbox: push không có trường `type`.

Project thật `roomly-6d99d` và credential đã được cấu hình; backend local bật FCM, healthy và mount credential read-only. Lúc 17:59:13 ngày 09/10/2026 (giờ Việt Nam), OAuth và FCM API V1 đã kiểm tra thật thành công: HTTP 200 với `validate_only:true`. Request này không gửi notification, nên chưa có bằng chứng giao push tới thiết bị. Roomly là app chính, phần ghép API/FCM của FE chưa được nghiệm thu hoàn tất. Làm theo [FIREBASE_SETUP.md](FIREBASE_SETUP.md); API chấp nhận request không thay thế thử foreground/background, logout/đổi tài khoản và mở đúng đối tượng.

Push và realtime là tín hiệu cập nhật, inbox/API là nguồn trạng thái để đối chiếu. Client phải kiểm tra người nhận, deduplicate theo notification ID và tải lại đối tượng theo quyền hiện tại. Kết quả kiểm thử, bằng chứng runtime và các việc còn lại được tập trung tại [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md).
