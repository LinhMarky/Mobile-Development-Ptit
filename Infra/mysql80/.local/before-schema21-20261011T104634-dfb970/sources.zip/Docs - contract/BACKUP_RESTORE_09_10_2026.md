# Backup và phục hồi MySQL + MinIO

Ngày 09/10/2026, giờ Việt Nam. Công cụ: `Infra/vps/backup_restore.py`. Phạm vi là stack Compose trên một server, với MySQL/MinIO dùng named volumes riêng và không publish port dữ liệu. Bản backup chứa dữ liệu riêng của ứng dụng; giữ ngoài Git và chuyển qua SSH khi cần.

## 1. Nguyên tắc và kết quả kiểm tra

Công cụ dừng backend trước, sau đó dừng MinIO để ngăn ứng dụng ghi dữ liệu trong lúc sao lưu. MySQL vẫn chạy để xuất SQL bằng `mysqldump --single-transaction`. MinIO được lưu bằng tar khi đã dừng. Sau cùng công cụ khởi động lại những dịch vụ vốn đang chạy, kể cả khi bước sao lưu thất bại. Chỉ thực hiện một lần backup/restore tại một thời điểm và không chạy cập nhật schema hoặc tác vụ ghi trực tiếp vào database/storage trong khoảng này.

Backup có ba file:

| File | Nội dung |
| --- | --- |
| `mysql.sql` | Schema và dữ liệu ứng dụng; không phải bản sao thô của volume MySQL đang chạy |
| `minio.tar` | Nội dung volume MinIO, gồm object và metadata |
| `manifest.json` | Project, image ID, checksum/kích thước và fingerprint của cấu hình phục hồi; không chứa mật khẩu |

Không có `.env`, SMTP credential hoặc Firebase private key trong manifest. Giữ riêng **file env gốc**: phục hồi cần đúng database/MinIO/JWT secret. Công cụ từ chối env đã đổi credential. Với máy đích khác, sửa riêng đường dẫn TLS/Firebase, port hoặc cấu hình mạng cho phù hợp; không sinh lại credential dữ liệu cũ.

**Kiểm tra offline: 9 test đạt.** Đã kiểm tra từ chối checksum sai, SQL đổi schema hoặc chưa hoàn tất, tar traversal/symlink/device, JSON sai cấu trúc, env không khớp và project đích đã tồn tại. Có kiểm tra khởi động lại nguồn khi dump thất bại và chỉ tạo backend sau khi phục hồi cả hai bộ dữ liệu.

**Backup và restore thực tế: PASS.** Backup tại `backend/target/backend-verification/backup-20261009`, tạo lúc **09:32:49 ngày 09/10/2026 UTC+7**, nguồn `homely-vps-check-20261008`. SQL 76.681 bytes, MinIO tar 96.768 bytes. Image backend giữ `homely-backend:vps-verified-20261008`. Đích `homely-restore-check-20261009` healthy sau phục hồi vào hai volume mới.

**Đối chiếu dữ liệu lúc 11:23:40 UTC+7: PASS.** Phòng ID 6 và mã phòng giữ nguyên; media ID 2 vẫn gắn đúng phòng, SHA-256 bytes ảnh `6b1048f8a6d40bac0b2954c18fefa40c4ea7a96120fc2e54b7317c0e43c2bbec` khớp nguồn. Tài khoản ID 5 giữ `email_verified=true`; danh tính login/profile đúng ở cả hai stack, logout và refresh bị từ chối sau logout đạt. Bằng chứng không chứa credential: `backend/target/backend-verification/restore-results-20261009.json`.

**Chặn restore đè: PASS.** Thử lại đúng project đích đang có bị từ chối trước khi sửa dữ liệu; cả bốn container ID giữ nguyên. Đây là kết quả thực tế bổ sung cho 9 test offline. Kết quả không đại diện cho PITR, khôi phục khi mất cả máy hoặc runtime trên VPS.

Sau nghiệm thu, stack nguồn vẫn healthy và HTTP contract 1.6.0 đạt (82 paths, wrapper success/error và guest/401). Stack phục hồi thử đã được `stop` để tiết kiệm RAM, giữ container và cả hai volume. Các kết quả PASS ở trên mô tả thời điểm kiểm thử, không có nghĩa stack đích còn chạy sau khi kết thúc.

## 2. Sao lưu stack thử hiện tại trên Windows

Từ `D:\BACKEND\Mobile`, chọn **thư mục output mới**, thư mục cha phải tồn tại. Ví dụ dưới đây là lần mới; bản `backup-20261009` đã có sẽ không bị ghi đè:

```powershell
python -B .\Infra\vps\backup_restore.py --env-file .\backend\target\backend-verification\vps-lab.env --smtp-env .\Infra\vps\.env.smtp --demo --smtp --firebase backup --confirm-project homely-vps-check-20261008 --output .\backend\target\backend-verification\backup-20261009-next
python .\Infra\vps\stack.py --env-file .\backend\target\backend-verification\vps-lab.env --smtp-env .\Infra\vps\.env.smtp --demo --smtp --firebase check
```

Backend sẽ gián đoạn ngắn trong khi backup. Không dùng lệnh xuất SQL qua chuyển hướng text của Windows PowerShell: công cụ ghi trực tiếp bytes từ Docker vào file để giữ đúng encoding. Không in SQL hoặc env ra console/chat.

Giữ đúng lựa chọn overlay của stack nguồn. Khi nguồn dùng Firebase/proxy, thêm `--firebase`/`--proxy` và `--proxy-env` tương ứng **trước** từ `backup`. Production dùng `--prod`, không kết hợp `--demo` hoặc `--smtp` vì production đã bắt buộc SMTP mã hóa.

## 3. Phục hồi sang một project mới để thử

Lệnh sau dành cho lần nghiệm thu riêng, dùng port loopback 18090 và 18026. Trước khi chạy, hai port phải trống. Đích phải là project hoàn toàn mới, khác nguồn, chưa có container/volume/network. Nếu tên ví dụ đã được dùng, chọn tên đích mới và output bằng chứng mới.

```powershell
python -B .\Infra\vps\backup_restore.py --env-file .\backend\target\backend-verification\vps-lab.env --smtp-env .\Infra\vps\.env.smtp --demo --smtp restore --input .\backend\target\backend-verification\backup-20261009 --confirm-target homely-restore-check-20261009 --api-port 18090 --mailpit-port 18026 --restore-test
```

`--restore-test` giữ dữ liệu đã phục hồi, tắt seed và FCM, chuyển SMTP của stack đích sang Mailpit. Stack nguồn tiếp tục giữ cấu hình SMTP Gmail. Các image được pin bằng ID từ manifest, phải có sẵn trên máy; công cụ không tự pull hoặc build. Chỉ phục hồi backup do mình quản lý và tin cậy; checksum phát hiện file thay đổi, không chứng minh backup không chứa SQL độc hại.

Sau khi restore, kiểm tra **dữ liệu**, ngoài trạng thái healthy:

```powershell
python -B .\Infra\vps\verify_restored_data.py --env-file .\backend\target\backend-verification\vps-lab.env --smtp-env .\Infra\vps\.env.smtp --confirm-project homely-vps-check-20261008 --source-origin http://127.0.0.1:18089 --restored-origin http://127.0.0.1:18090 --fixture .\backend\target\backend-verification\persistence-results.json --email-state-file .\backend\target\backend-verification\real-email-20261009\private-state.json --output .\backend\target\backend-verification\restore-results-20261009.json
```

Helper dành riêng cho dữ liệu thử hiện có: phòng ID 6, media ID 2 và tài khoản thật đã xác minh ID 5. Nó đối chiếu identity phòng, liên kết media, SHA-256 bytes ảnh và verified=true giữa hai stack; đồng thời thử logout và từ chối refresh sau logout. Password/token được đọc trong bộ nhớ và không ghi vào kết quả. Chạy lại cần `--output` mới.

## 4. Vận hành stack đã phục hồi

Công cụ lưu hai file **không chứa secret** tại `backend/target/backend-verification/homely-restore-check-20261009-restore`:

- `runtime.env`: port của stack đích.
- `runtime.compose.json`: image ID, tên volume/network mới và các override cách ly dịch vụ ngoài.

Mọi lệnh vận hành stack đích phải giữ các override này và đúng `--project-name`. Ví dụ xem trạng thái hoặc dừng stack thử sau nghiệm thu:

```powershell
docker compose --env-file .\backend\target\backend-verification\vps-lab.env --env-file .\Infra\vps\.env.smtp -f .\Infra\vps\compose.yaml -f .\Infra\vps\compose.demo.yaml -f .\Infra\vps\compose.smtp.yaml --project-name homely-restore-check-20261009 --env-file .\backend\target\backend-verification\homely-restore-check-20261009-restore\runtime.env -f .\backend\target\backend-verification\homely-restore-check-20261009-restore\runtime.compose.json ps -a
docker compose --env-file .\backend\target\backend-verification\vps-lab.env --env-file .\Infra\vps\.env.smtp -f .\Infra\vps\compose.yaml -f .\Infra\vps\compose.demo.yaml -f .\Infra\vps\compose.smtp.yaml --project-name homely-restore-check-20261009 --env-file .\backend\target\backend-verification\homely-restore-check-20261009-restore\runtime.env -f .\backend\target\backend-verification\homely-restore-check-20261009-restore\runtime.compose.json stop
```

`stop` giữ volume; không dùng `down -v` để sửa lỗi. Nếu restore thất bại, công cụ giữ artifact/volume đích để điều tra và cố dừng backend đích. Không tự động xóa hoặc khôi phục đè lên dữ liệu nguồn. Sau khi xác định nguyên nhân, thử lại bằng **project mới**.

## 5. Khi triển khai hoặc khôi phục trên VPS

VPS mới có thể bắt đầu bằng seed demo mới theo [VPS_HTTPS_SMTP_FCM_08_10_2026.md](VPS_HTTPS_SMTP_FCM_08_10_2026.md). Nếu cần giữ dữ liệu laptop, phải chuyển riêng backup cùng env nguồn qua SSH; không dùng `init_env.py` sinh secret mới cho dữ liệu đó. Phục hồi vào project mới bằng quy trình trên, kiểm tra dữ liệu trước khi đổi endpoint/proxy.

Đối với phục hồi dùng thật, bỏ `--restore-test` chỉ khi đã chốt SMTP/Firebase/mạng đích và sẵn sàng cho worker tiếp tục xử lý dữ liệu khôi phục. Outbox và job cũng là dữ liệu được backup: xem xét các tác vụ pending trước khi mở dịch vụ gửi thật. Phục hồi database không tự vô hiệu hóa các access token còn hạn trong snapshot; cần kế hoạch thu hồi phiên nếu nguyên nhân khôi phục liên quan sự cố bảo mật.

Giữ bản sao ở một nơi khác máy đang chạy, kiểm soát quyền đọc và định kỳ thử restore. Đây là công cụ backup toàn bộ và restore sang project mới; chưa có lịch tự động, PITR hoặc chuyển endpoint tự động. Tài liệu tham chiếu: [MySQL mysqldump](https://dev.mysql.com/doc/refman/8.4/en/mysqldump.html), [Docker volumes](https://docs.docker.com/engine/storage/volumes/).


**Cập nhật cấu hình nguồn 09/10:** nguồn hiện đã bật Firebase, nên ví dụ backup mới/check ở trên giữ `--firebase`. Backup `backup-20261009` được tạo trước đó với lựa chọn `firebase=false`; lệnh restore lịch sử giữ đúng lựa chọn cũ và `--restore-test` tắt gửi dịch vụ thật. Không tự sửa manifest của backup để khớp cấu hình mới.
