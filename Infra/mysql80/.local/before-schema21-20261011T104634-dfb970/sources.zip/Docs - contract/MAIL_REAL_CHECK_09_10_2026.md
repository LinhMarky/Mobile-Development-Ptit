# Kiểm tra SMTP thật trước khi đưa backend lên VPS

Ngày 09/10/2026, giờ Việt Nam. **Cập nhật khoảng 01:52 UTC+7:** Gmail thật đã xác thực và gửi thư thử thành công; người nhận xác nhận thư vào **Inbox bình thường**. Backend local đã hoàn tất đăng ký → gửi mã qua Gmail → xác minh → profile verified=true → login/logout; mã đã dùng và refresh token sau logout đều bị từ chối. Không lấy Mailpit hoặc fixture làm bằng chứng email Internet đã hoạt động.

## 0. Kết quả SMTP thật trong lượt kiểm tra

- Tài khoản SMTP/sender đúng sau khi chủ dự án sửa: **linhcoder2006@gmail.com**. Người nhận thử: **linhfunny2@gmail.com**. Không ghi App Password trong tài liệu.
- `smtp.gmail.com:587`, STARTTLS, xác minh certificate/hostname và auth: **PASS**.
- Thư “Roomly: kiểm tra SMTP VPS”: SMTP đã chấp nhận; chủ dự án xác nhận đến **Inbox**, sửa lại thông tin Spam ban đầu.
- Stack thử **homely-vps-check-20261008** đã khởi động lại với `.env.smtp`; MySQL/MinIO/backend/Mailpit healthy, wrapper/OpenAPI 1.6.0 đạt. Backend dùng Gmail thật; Mailpit chỉ còn là container thử, không phải SMTP của backend.
- `POST /api/v1/auth/register` từ backend thật trả **201**, tài khoản thử ID **5**, email_verified=false; JavaMail đã gửi thư “Homely — Xác minh email”. Login/profile/logout **PASS**. Kết quả an toàn: `backend/target/backend-verification/real-email-20261009/results.json`.
- Xác minh bằng mã người nhận cung cấp: **PASS lúc 01:50:26 UTC+7**; mã đầu tiên trả 200, dùng lại trả 400, profile email_verified=true. Không ghi mã trong tài liệu hoặc kết quả.
- Kiểm tra bổ sung lúc **01:52:22 UTC+7**: ID/email của login và profile khớp tài khoản thử đã đăng ký; logout thành công, dùng refresh token sau logout trả 400. Kết quả giữ nguyên thời điểm xác minh trước đó, không ghi lần kiểm tra session thành một lần xác minh mã mới.
- Thông tin private nằm tại `Infra/vps/.env.smtp` và private state trong `backend/target`; Git ignore đã kiểm tra. App Password từng xuất hiện trong chat nên cần thay sau kiểm thử và chạy lại auth với khóa mới.

## 1. Thông tin còn cần cho VPS và FCM

SMTP và người nhận thử đã được cung cấp, cấu hình và nghiệm thu local. Không cần xin lại mã xác minh đã dùng.

- VPS: public IP, hệ điều hành, RAM và phương thức truy cập SSH; credential được giữ riêng, không gửi password/private key vào chat.
- Firebase: project `roomly-6d99d`, Android JSON/service account đã có; OAuth + API V1 validate-only HTTP 200 đạt lúc 17:59:13 VN. Còn APK/token và nghiệm thu thiết bị theo [FIREBASE_SETUP.md](FIREBASE_SETUP.md).
- Khi thay App Password đã xuất hiện trong chat, cập nhật riêng `.env.smtp`, chạy lại auth và recreate đúng backend với cùng `--smtp-env`; không ghi secret trong tài liệu/image.

## 2. Các thay đổi và bằng chứng đã có

1. VPS base/prod và SMTP overlay chỉ gửi qua TLS, kiểm tra hostname certificate rõ ràng. STARTTLS được yêu cầu khi dùng STARTTLS; không bật đồng thời STARTTLS và implicit TLS.
2. Checker so sánh cả cấu hình hiệu lực của JavaMail; chặn trường hợp biến SMTP và JavaMail không khớp. Runtime checker so sánh SMTP host/port/user/password/sender/mode với container, nhưng không in giá trị secret.
3. Chẩn đoán lỗi cấu hình, lỗi certificate và lỗi xác thực được hiển thị bằng thông tin an toàn; SMTP authentication failure chỉ ghi mã lỗi, không ghi phản hồi có thể chứa thông tin nhạy cảm.
4. Thêm `configure_smtp.py`: nhập password ẩn trong terminal, tạo `.env.smtp` một lần, không ghi đè, không gửi email; file bị Git ignore và có mode 600 khi tạo trên Linux.
5. Sửa giải mã kết quả `docker compose config`: Compose nhân đôi `$` khi serialize, kể cả JSON. Helper chung giải mã đúng một lớp, không áp dụng lên `docker inspect`. Đã thử mật khẩu fixture có quote, backslash, dấu `$`, cú pháp `${...}` và backslash cuối; giá trị không bị đổi và không in ra stdout.

Nguồn kỹ thuật: [Docker Compose config implementation](https://github.com/docker/compose/blob/main/cmd/compose/config.go), [JavaMail SMTP properties](https://eclipse-ee4j.github.io/angus-mail/docs/api/org.eclipse.angus.mail/org/eclipse/angus/mail/smtp/package-summary.html).

**Kiểm chứng cấu hình trước khi cung cấp credential:** 6 kiểm tra offline PASS; 7 trường hợp Compose/preflight PASS; standalone SMTP env/escaping PASS. Các bài kiểm tra cấu hình này dùng fixture; phép thử Gmail thật được ghi riêng trong mục 0. Backend application/JAR không thay đổi trong lượt này; 249 test trước đó vẫn là kết quả ngày 08/10 của cùng code backend, không ghi thành một lần chạy mới.

Đã đối chiếu logic email: đăng ký và tạo token nằm trong cùng transaction; lỗi SMTP trả 503 `EMAIL_UNAVAILABLE`, rollback đăng ký và cho retry cùng email; resend thất bại giữ token cũ; token hết hạn/sai purpose/dùng lại bị chặn. Có test hiện hữu cho các trường hợp này. Hệ thống gửi mã xác minh 24 giờ qua email, không gửi link web reset password. Nội dung email backend hiện mang tên Homely; Roomly là app chính dùng backend đó.

## 3. Tạo cấu hình Gmail riêng trên máy

Google yêu cầu bật **2-Step Verification** để tạo App Password; một số tài khoản trường/công ty, Advanced Protection hoặc cấu hình chỉ security key có thể không có lựa chọn này. Không bật “less secure apps”. [Google App Passwords](https://support.google.com/accounts/answer/185833).

1. Bật 2-Step Verification trên tài khoản gửi.
2. Tạo App Password tại [trang Google](https://myaccount.google.com/apppasswords).
3. Tại gốc repository chạy, thay hai địa chỉ mẫu bằng địa chỉ thật:

```powershell
python .\Infra\vps\configure_smtp.py --gmail --username your-sender@gmail.com --recipient your-recipient@gmail.com
```

Nhập App Password ở prompt ẩn trong terminal. Công cụ bỏ khoảng trắng phân nhóm của Gmail và không in lại password. File tạo tại `Infra/vps/.env.smtp`; chỉ gửi **đường dẫn** file cho người kiểm tra. Không chạy `Get-Content`/`cat` hoặc `docker compose config` không có `--quiet` để chụp/gửi cấu hình.

Gmail dùng `smtp.gmail.com`, STARTTLS port 587; implicit TLS dùng port 465 khi chọn chế độ tương ứng. [Gmail SMTP chính thức](https://developers.google.com/workspace/gmail/imap/imap-smtp).

Nếu dùng SMTP khác:

```powershell
python .\Infra\vps\configure_smtp.py --host smtp.your-provider.example --port 587 --tls starttls --username your-smtp-username --sender authorized-sender@your-domain.example --recipient your-recipient@gmail.com
```

Hostname/email `.example` ở trên chỉ minh họa, phải thay bằng thông tin thật. Với port 465 chọn `--tls ssl`. Nếu file đã tồn tại, công cụ không thay; sửa riêng file tại máy khi cần xoay credential.

## 4. Kiểm tra thật theo từng bước

Đọc cấu hình SMTP riêng không cần MySQL/JWT/backend đang chạy:

```powershell
python .\Infra\vps\check_services.py --smtp-only --smtp-env .\Infra\vps\.env.smtp
python .\Infra\vps\check_services.py --smtp-only --smtp-env .\Infra\vps\.env.smtp --network
```

Network check thực hiện DNS/TCP/TLS/EHLO/auth, **không gửi thư**. Sau khi đã chọn rõ địa chỉ nhận và yêu cầu gửi email thử:

```powershell
python .\Infra\vps\check_services.py --smtp-only --smtp-env .\Infra\vps\.env.smtp --send-test-email your-recipient@gmail.com
```

SMTP chấp nhận DATA chưa chứng minh thư vào inbox. Người nhận cần xác nhận thư đến, subject, tiếng Việt không lỗi và spam folder. Checker không đọc toàn bộ hộp thư.

Đưa cấu hình riêng vào stack báo cáo bằng cùng tham số cho mọi thao tác, tại `Infra/vps`:

```bash
python3 stack.py --demo --proxy --smtp --smtp-env .env.smtp config
python3 stack.py --demo --proxy --smtp --smtp-env .env.smtp up
python3 stack.py --demo --proxy --smtp --smtp-env .env.smtp check
```

`.env` chính vẫn giữ password DB/MinIO/JWT; `.env.smtp` chỉ ghi đè SMTP. Khi chép tới VPS, chép file SMTP riêng qua SSH/SCP và giữ quyền đọc riêng, không gộp vào image/code archive công khai.

Các lệnh trên là mẫu VPS khi proxy đã cấu hình. Stack local hiện tại còn bật Firebase: giữ thêm `--firebase` và đúng `--env-file` như [FIREBASE_SETUP.md](FIREBASE_SETUP.md); không dùng mẫu thiếu overlay để recreate stack đang có.

Sau khi backend đã dùng SMTP thật, kiểm tra API/app: đăng ký bằng email nhận thật → nhận mã → `POST /api/v1/auth/verify-email` → kiểm tra `email_verified=true` → đăng nhập → mã cũ dùng lại trả 400. Kiểm tra resend và xử lý lỗi SMTP trên môi trường thử. Không dùng tài khoản seed `.test` để kết luận email thật đã gửi.

Lượt local hiện tại đã chạy thành công lệnh sau với mã của thư “Homely — Xác minh email” trong file riêng; không lưu App Password vào file mã. Lệnh minh họa lần xác minh đã thực hiện, **không chạy lại `verify` với mã đã dùng**:

```powershell
python .\Infra\vps\test_email_flow.py verify --origin http://127.0.0.1:18089 --state-file .\backend\target\backend-verification\real-email-20261009\private-state.json --token-file .\backend\target\backend-verification\real-email-20261009\verification-code.txt
```

Lệnh đọc mã/password thử từ file riêng, không in chúng. Nó kiểm tra xác minh thành công, dùng lại mã trả 400, đúng danh tính tài khoản, profile verified=true, login/logout và refresh sau logout trả 400; kết quả an toàn ở `results.json` cùng thư mục. Không chạy lại bước `begin` với cùng email đã đăng ký. Những file dưới `backend/target` là dữ liệu thử riêng, không đưa vào bộ code/image gửi cho FE.

Có thể kiểm tra lại danh tính và session mà không gửi thư hoặc dùng lại mã:

```powershell
python .\Infra\vps\test_email_flow.py check-session --origin http://127.0.0.1:18089 --state-file .\backend\target\backend-verification\real-email-20261009\private-state.json
```

`check-session` chỉ chạy khi report trước đã chứng minh xác minh và từ chối mã dùng lại cho cùng origin/user ID; giữ nguyên `verification_timestamp_utc`. Lượt xác minh 01:50 đã chứng minh mã/profile; kiểm tra danh tính và refresh sau logout bổ sung 01:52 bằng lệnh này đều PASS.

## 5. Điều kiện hoàn tất

| Kết quả | Trạng thái hiện tại |
| --- | --- |
| TLS/auth/mode/secret-file/preflight đã chuẩn bị và kiểm thử fixture | PASS local |
| Xác thực SMTP thật bằng credential của chủ dự án | PASS Gmail STARTTLS |
| Thư thử được người nhận xác nhận trong inbox | PASS, chủ dự án xác nhận Inbox |
| Đăng ký/xác minh bằng email thật qua backend | PASS local: xác minh, đúng tài khoản, verified=true, mã dùng lại 400, login/logout và refresh sau logout 400 |
| SMTP còn hoạt động khi chạy trên VPS | Chờ máy đích; kết quả laptop không thay thế phép thử VPS |
| FCM API thật / điện thoại | OAuth/API V1 validate-only 200 đạt; chờ tích hợp/token/thiết bị FE |

Không thể bảo đảm mọi điều kiện mạng/provider của VPS từ laptop. Sau deploy phải chạy lại network/email checks ở máy đích, vì outbound SMTP có thể khác môi trường phát triển.

**Kiểm tra trước bàn giao FE, 09/10:** đã chạy lại SMTP TLS/certificate/auth thành công, không gửi thêm email. Image backend mới `homely-backend:vps-verified-20261009-fcm` giữ nguyên Gmail sender `linhcoder2006@gmail.com`; account đã xác minh vẫn đúng. Kết quả image/dữ liệu tại `backend/target/backend-verification/fcm-backend-handoff-results-20261009.json`. Thư Inbox và mã xác minh vẫn là bằng chứng của lần gửi thật trước đó, không ghi thành một lần gửi mới.
