# Kế hoạch kiểm thử và điều kiện nghiệm thu

Cập nhật 10/10/2026, contract **v1.6.0**. Đây là kịch bản cần kiểm thử, không phải danh sách đã PASS. Kết quả từng lần chạy và giới hạn tại [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md); API/DTO/rule tại [PROJECT_CONTRACT.md](PROJECT_CONTRACT.md), [openapi.yaml](openapi.yaml). Test tự động và thao tác QA phải dùng schema/project thử riêng.

**Schema V19:** Kiểm tra đủ 14 base tables và không có view thay bảng; FK không nhận ID thuộc loại khác trong cùng bảng; trường bắt buộc vẫn được DB kiểm tra. Bulk delete/retention token không xóa role, preferences hoặc lifecycle lock. Database V18 có user phải bị từ chối nâng cấp trước tạo/bỏ bảng ứng dụng, user và 37 bảng cũ vẫn còn. Kiểm tra API/OpenAPI trước/sau không đổi; số bảng ít hơn không tự chứng minh đủ chức năng. Runner native tách biệt tại [Infra/mysql80/README.md](../Infra/mysql80/README.md); thiết kế tại [SCHEMA_14_TABLES.md](SCHEMA_14_TABLES.md).

**Schema V20:** Nâng cấp database V19 có đủ các loại entity, Unicode/JSON/binary, chu kỳ booking–payment và AUTO_INCREMENT cao hơn MAX(id). Đối chiếu property/ID/version/liên kết của 24 loại entity và chín bảng còn lại; cuối migration vẫn 14 bảng, tổng cột 283. Kiểm tra hai refresh cùng installation và cùng hash ở hai mục đích token khác nhau vẫn hợp lệ; hash trùng trong cùng loại bị chặn. Native helper phải từ chối thiếu backup, checksum/build không khớp hoặc ứng dụng vẫn ghi. Đối chiếu HTTP/OpenAPI trước/sau; không tự đổi enum/state transition để gộp cột.

## 1. Backend: giao dịch và concurrency

| Kịch bản | Kết quả cần xác nhận |
| --- | --- |
| Hai tenant tạo booking trên cùng phòng AVAILABLE | Có thể có nhiều PENDING của các tenant khác nhau; không giữ phòng ngay khi tạo. Cùng tenant không tạo thêm booking đang hoạt động cho cùng phòng |
| Hai host request duyệt hai PENDING của cùng phòng | Chỉ một booking được APPROVED và room HELD; request thua nhận 409 ROOM_NOT_AVAILABLE; không tạo hai hold |
| Webhook lặp cùng event ID/payload | Replay không phân bổ tiền, chuyển trạng thái hoặc tạo notification lần hai; cùng ID đổi payload trả 409 WEBHOOK_EVENT_REUSED |
| Event ID mới cho payment đã SUCCEEDED | Ghi nhận duplicate; không tạo refund/booking/notification mới chỉ vì event ID khác |
| Payment success đua job hết hạn | Kiểm tra deadline/trạng thái dưới lock. Success muộn không hồi sinh booking EXPIRED/CANCELLED; xử lý refund sandbox đúng một lần |
| Payment attempt hết hạn nhưng booking còn hạn giữ | Không tự giải phóng hold hợp lệ; payment mới không vượt hạn booking |
| Idempotency replay/concurrent/conflict | Cùng key/payload trả snapshot sau kiểm tra quyền; khác payload 409; mutation không chạy lần hai; PROCESSING không bị xóa để retry mù |
| Sửa listing/fees/media khi room HELD | Bị chặn theo contract; snapshot booking không thay đổi |
| Room/catalog/viewing thay đổi đồng thời | Thứ tự lock nhất quán; trạng thái cuối hợp lệ, không bán/giữ phòng hai lần |
| Inbox/outbox với rollback nghiệp vụ | Rollback không để lại thông báo thành công; worker gửi ngoài transaction và claim/retry đúng |

Các suite H2 không thay thế MySQL. Khi chạy `./mvnw.cmd verify` từ `backend`, thiết lập các biến `HOMELY_TEST_MYSQL_*` cho database thử như hướng dẫn [Infra/Verify-Backend.ps1](../Infra/Verify-Backend.ps1); không dùng database ứng dụng. Chỉ ghi MySQL PASS nếu các suite thật đã chạy, không bị skip.

## 2. API và global wrapper

- JSON success/error có `{statusCode,message,data}`, `statusCode` khớp HTTP; DTO snake_case, tiền là string nguyên VND. Page 0-based, size 1..50, list nằm trong `response.data.data`.
- 200 không DTO có `data:null`; 204/205/304 không body; media là bytes, OpenAPI không bị bọc; STOMP là DTO trực tiếp. Xem [GLOBAL_RESPONSE_WRAPPER.md](GLOBAL_RESPONSE_WRAPPER.md).
- Endpoint cần auth: thiếu/hết hạn token 401, sai role hoặc chưa verified khi bắt buộc 403. ID không tồn tại/không thuộc quyền và chuyển trạng thái sai theo từng endpoint, không lộ dữ liệu người khác.
- JSON/validation sai trả 400, có `data.code`/`field_errors` phù hợp; không mặc định mọi lỗi ngày tháng là 422. Kiểm tra riêng 405/406/415 và header đúng.
- POST thuộc idempotency filter: thiếu/trắng/quá 128 ký tự key trả 409 IDEMPOTENCY_KEY_REQUIRED; đổi payload cùng key 409 IDEMPOTENCY_KEY_REUSED; đang PROCESSING 409 IDEMPOTENCY_CONFLICT. Auth/multipart có quy tắc riêng trong contract.
- Lỗi HTTP dùng envelope `application/json`, không ghi raw secret/nội dung nhạy cảm vào log; 429 giữ Retry-After, 413 không làm parse JSON sai ở FE.
- AUTH10: `platform` chỉ nhận `ANDROID`, bỏ trường dùng mặc định; `null`, chuỗi trắng, `IOS` hoặc `android` trả 400. `installation_id` phải không trắng, tối đa 36 ký tự; chuỗi 37 ký tự bị từ chối. UUID ổn định là khuyến nghị phía FE, không phải regex bắt buộc tại endpoint này.

## 3. Auth, account deletion và retention

- JWT secret thiếu/sai/ngắn bị từ chối; token phải khớp ID kể cả email được dùng lại. Kiểm tra HTTP/service/STOMP và trạng thái tài khoản hiện tại trong DB.
- Login/refresh rotation dùng installation ổn định; request refresh đồng thời không tạo hai session hợp lệ ngoài quy tắc. Logout hiện hành thu hồi đúng session/device; thiếu refresh token có ngữ nghĩa logout tất cả thiết bị. Access JWT còn theo TTL nếu account active.
- Rate limit theo IP + identity; bỏ XFF thô từ client. Proxy chỉ tin IP cụ thể, kiểm tra limiter không gộp toàn bộ user qua proxy hoặc nhận XFF giả.
- SMTP lỗi đăng ký trả 503 EMAIL_UNAVAILABLE, rollback user/token và retry cùng email được; resend lỗi giữ token trước đó. Mã hết hạn/sai purpose/dùng lại bị từ chối.
- Xóa tài khoản có blocker booking/refund/report bị chặn; pending chặn mutation nhưng cho status/logout. Job kiểm tra lại dưới lock, lỗi rollback và FAILED retry được; giữ lịch sử tài chính, thu hồi session/device và anonymize đúng phạm vi.
- Retention chỉ xóa hết hạn/terminal theo batch; giữ PROCESSING và lịch sử giao dịch. Cả H2/MySQL, kiểm tra metrics ADMIN lấy quyền từ DB.
- Profile prod từ chối demo/seed/mock và SMTP không mã hóa. Không dùng kết quả demo để kết luận prod đã chạy.

## 4. Luồng E2E trên APK Roomly

### E2E-01: Tin phòng → cọc sandbox → bàn giao → review

1. Host login thật, tạo room, upload/attach ảnh và submit listing; admin duyệt PUBLISHED.
2. Tenant trên thiết bị khác tìm/đọc cùng ID và ảnh thật, tạo booking PENDING; host approve → room HELD.
3. Tenant dùng payment sandbox hợp lệ → booking CONFIRMED; không thu tiền thật.
4. Đến điều kiện bàn giao, hai bên xác nhận đúng quyền → COMPLETED, room RENTED; tenant viết review theo contract.
5. Inbox/trạng thái/notification của hai bên khớp API, refresh hoặc mở lại app không chuyển sang dữ liệu mẫu.

### E2E-02: Hết hạn và thanh toán muộn

Kiểm tra PENDING sau 24 giờ và APPROVED sau 48 giờ bằng clock/fixture có kiểm soát; phòng được nhả theo trạng thái. Webhook success sau hạn tạo refund sandbox đúng quy tắc, không phục hồi booking. Không sửa clock/dữ liệu môi trường đang demo để giả bằng chứng.

### E2E-03: Case và settlement sandbox

Booking CONFIRMED có payment SUCCEEDED đã được phân bổ; mở case hợp lệ. Admin thử `REFUND_TENANT`, `FORFEIT_DEPOSIT`, `SPLIT` (query `tenant_refund_vnd` nguyên, >0 và <payment amount) trên fixture riêng: lưu phân bổ, CANCELLED và room AVAILABLE cùng transaction. `NO_ACTION` chỉ kết luận, không settlement. Kiểm tra rollback/replay/ownership và khả năng case quá hạn mở lại theo [CONTRACT_GAPS.md](CONTRACT_GAPS.md). Không có decision `CANCEL_BOOKING`, không báo chuyển khoản thật.

### E2E-04: Chat, viewing và reconnect

Hai user thật chat TEXT qua STOMP; retry cùng UUID không trùng, read marker không giảm; reconnect/REST resync before/after cursor và phân trang hơn 50 tin. Slot xem dùng ID thật, host tạo trước ít nhất 24 giờ; tạo/xác nhận/hủy lịch đúng quyền và trạng thái. [CHAT.md](CHAT.md).

### E2E-05: Session và thông báo

Preflight backend ngày 09/10/2026 lúc 17:59:13 (giờ Việt Nam) đã xác thực OAuth và nhận HTTP 200 từ FCM API V1 với `validate_only:true`; bằng chứng `backend/target/backend-verification/fcm-network-20261009/fcm-api-results-20261009.json`. Đây là kiểm tra không gửi notification, chưa phải PASS cho kịch bản điện thoại dưới đây.

Đăng ký bằng email thật, xác minh và login; process restart khôi phục đúng phiên. Refresh invalid dọn session/socket/cache; mất mạng/503 tạm thời cho retry. Logout/đổi user không hiển thị dữ liệu hoặc push của user trước. Thử foreground/background, permission, preference, token đổi và retry đăng ký theo [FIREBASE_SETUP.md](FIREBASE_SETUP.md).

## 5. Media, quyền truy cập và P1 recovery

- Upload trả media READY, attach đúng host/room/purpose; GET `/api/v1/media/{id}/content` proxy bytes, không phải cam kết signed URL 5 phút. Bucket private, người ngoài không đọc media của listing ẩn, có no-store/nosniff.
- Report phải kiểm tra target tồn tại/visibility/membership; admin có queue/detail thật trước khi coi luồng xử lý hoàn chỉnh.
- Chèn lỗi ở ranh giới storage/DB để kiểm tra upload compensation, delete retry/rollback; đối soát idempotency kẹt sau crash. Các P1 này chưa được đóng bởi suite đã chạy trước đó.
- WebP: RIFF + WEBP, dimension/parser; kiểu/kích thước giả và vượt hạn bị từ chối. Rà truy vấn N+1 và batch job bằng dữ liệu có ý nghĩa, không suy từ dataset demo nhỏ.

## 6. VPS và nghiệm thu vận hành

Kiểm tra health, restart/RAM/log limits, non-root/read-only, data services private; recreate giữ ID/ảnh/verified user. Backup MySQL + MinIO rồi phục hồi project mới, từ chối ghi đè; giữ secret nguồn và đối chiếu checksum/bytes. [Backup–restore](BACKUP_RESTORE_09_10_2026.md).

Trên VPS thật: HTTPS CA tin cậy, WSS với JWT handshake, email thật từ máy đích, sự kiện backend tới hai điện thoại trên mạng ngoài. Proxy fixture/laptop PASS chưa đủ. [Runbook VPS](VPS_HTTPS_SMTP_FCM_08_10_2026.md), [SMTP](MAIL_REAL_CHECK_09_10_2026.md).

Mỗi luồng ghi ngày/giờ, bản code/image/APK, môi trường, ID đối tượng, expected/actual và PASS/FAIL/chưa chạy. Bỏ credential/token khỏi bằng chứng; ghi lỗi còn mở và chủ xử lý. Không lấy build/lint Homely hoặc ảnh UI Roomly làm kết quả E2E app chính.
