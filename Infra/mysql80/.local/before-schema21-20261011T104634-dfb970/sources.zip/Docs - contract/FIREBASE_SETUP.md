# Firebase/FCM cho Roomly và backend chung

Cập nhật 09/10/2026. Project thật **`roomly-6d99d`**, Android JSON đúng **`com.example.roomly`** và service account backend đã có. **FCM đã xác thực OAuth và chấp nhận yêu cầu API V1 validate-only với HTTP 200 lúc 17:59:13 VN; backend local bật FCM/healthy.** Không cần bật lại API của project này. Push tới điện thoại chờ APK/token thật; người phụ trách Roomly triển khai các bước Android bên dưới.

## 1. Cấu hình hiện tại và bằng chứng

| Hạng mục | Kết quả local lúc 17:21:24 UTC+7, 09/10 |
| --- | --- |
| Android | `Frontend-Mobile-App/app/google-services.json` tồn tại, đúng package và cùng project với backend; Git ignore |
| Backend | `FCM_ENABLED=true`, `FIREBASE_PROJECT_ID=roomly-6d99d`; health UP, API 1.6.0 |
| Credential | Service-account thật ngoài repository; mount read-only `/run/secrets/firebase-service-account.json`; user non-root đọc được |
| Cấu hình riêng | Hai biến Firebase đã lưu trong `backend/target/backend-verification/vps-lab.env`, Git ignore; Gmail riêng ở `Infra/vps/.env.smtp` |
| Dữ liệu/dịch vụ | Gmail, bốn image, hai data volume và MySQL/MinIO/Mailpit giữ nguyên; phòng 6, ảnh 2/attachment/bytes đúng, user 5 vẫn verified; logout/refresh bị từ chối đạt |
| API V1/quyền gửi, 17:59:13 VN | OAuth thành công, Google FCM trả HTTP 200 cho `validate_only=true`; không giao thông báo |
| Backend mới, 18:03:52 VN | Image `homely-backend:vps-verified-20261009-fcm`; Gmail/Firebase và data volumes giữ đúng. Sai platform/installation quá dài trả 400, không gửi token giả tới FCM |
| Chưa kiểm chứng | APK/token và push trên thiết bị, `phone_delivery_verified=false`; runtime VPS |

Bằng chứng cấu hình ban đầu: `backend/target/backend-verification/firebase-runtime-results-20261009.json`; quyền gửi thật: `backend/target/backend-verification/fcm-network-20261009/fcm-api-results-20261009.json`; backend mới/dữ liệu: `backend/target/backend-verification/fcm-backend-handoff-results-20261009.json`. Service account đang được tham chiếu từ file Downloads chủ dự án cung cấp; giữ file tại đường dẫn cấu hình hoặc cập nhật env và recreate đúng overlay nếu di chuyển. Không đưa file này vào APK, Git hoặc image; không in private key/raw token trong bằng chứng.

### Kiểm tra hoặc bật API V1

Project hiện tại đã qua kiểm tra API thật; các bước Console sau dùng khi chẩn đoán hoặc cấu hình project khác.

Mở [Firebase Cloud Messaging API cho roomly-6d99d](https://console.cloud.google.com/apis/library/fcm.googleapis.com?project=roomly-6d99d). Kiểm tra đúng project; nếu hiện **Enable / Activer** thì bật. Nếu có **Manage / Gérer** và **Disable**, API đã bật. Sau đó kiểm tra Firebase → Project settings → Cloud Messaging → API V1. Không cần tạo lại project/private key chỉ để bật API. [Google Cloud: bật dịch vụ](https://docs.cloud.google.com/service-usage/docs/enable-disable).

### Khi cần lấy lại file cấu hình

Trong Firebase Project settings → General, chọn Android app `com.example.roomly`, tải `google-services.json` và đưa vào module `Frontend-Mobile-App/app`. Service accounts → Firebase Admin SDK là nơi tạo credential backend khi thực sự cần cấp mới; lưu ngoài repository. Nếu thử `Homely-android`, đăng ký app riêng `com.example.homely` và dùng JSON tương ứng. Google Analytics không bắt buộc cho luồng này. [Android setup](https://firebase.google.com/docs/android/setup), [Firebase Admin setup](https://firebase.google.com/docs/admin/setup).

## 2. Lệnh local giữ Gmail và Firebase thật

Chạy từ gốc `D:/BACKEND/Mobile`, không tạo lại secret hoặc đổi project của stack đang có dữ liệu. Hai biến Firebase đã lưu trong env riêng; kiểm tra shell không còn override cũ khi chạy lại.

```powershell
python -B ./Infra/vps/check_services.py --env-file ./backend/target/backend-verification/vps-lab.env --smtp-env ./Infra/vps/.env.smtp --demo --smtp --firebase --container
python -B ./Infra/vps/stack.py --env-file ./backend/target/backend-verification/vps-lab.env --smtp-env ./Infra/vps/.env.smtp --demo --smtp --firebase check
```

Áp dụng cấu hình lại khi cần:

```powershell
python -B ./Infra/vps/stack.py --env-file ./backend/target/backend-verification/vps-lab.env --smtp-env ./Infra/vps/.env.smtp --demo --smtp --firebase up
```

Giữ `--smtp-env`, `--smtp`, `--firebase` trong mọi thao tác với stack này; không thêm `--proxy` khi chưa cấu hình proxy. `config` của helper chỉ kiểm tra, không in secret. Khi FCM bật, worker xử lý delivery đủ điều kiện; dùng tài khoản/thiết bị thử của nhóm. Giữ bản sao env/bằng chứng ngoài build output trước khi Maven clean.

Tên biến nguồn file Docker là **`FIREBASE_CREDENTIALS_FILE`**. Overlay tự đặt `GOOGLE_APPLICATION_CREDENTIALS=/run/secrets/firebase-service-account.json` trong container; không dùng đường dẫn Windows bên trong container hoặc tên cũ `FIREBASE_SERVICE_ACCOUNT_FILE`. Mount thiếu file/nhầm project bị chặn; thiếu cấu hình khi FCM bật làm startup lỗi. Kiểm tra cấu hình/mount bằng `check_services.py` không kiểm chứng quyền gửi; `check_firebase.py` ở mục sau kiểm tra OAuth/API/quyền bằng validate-only.

Trên VPS, chép credential riêng qua SSH, đặt đường dẫn Linux như `/opt/homely-private/firebase-service-account.json` và quyền đọc của UID/GID backend thực tế. Quy trình image/HTTPS/quyền file tại [runbook VPS](VPS_HTTPS_SMTP_FCM_08_10_2026.md); VPS là bước cuối.

### Kiểm tra quyền gửi mà không cần token điện thoại

`Infra/vps/check_firebase.py` xác thực bằng Google Auth rồi gọi API V1 với `validate_only=true`, topic thử cố định và payload data-only giống backend. Không tạo inbox/delivery, không đăng ký thiết bị và không gửi notification. Không có tùy chọn chuyển sang gửi thật. HTTP 200 chứng minh credential/API/quyền gửi được chấp nhận, chưa chứng minh điện thoại nhận. [FCM API: validate_only](https://firebase.google.com/docs/reference/fcm/rest/v1/projects.messages/send).

Công cụ mạng dùng dependency riêng trong [requirements-firebase.txt](../Infra/vps/requirements-firebase.txt); các công cụ Compose/SMTP khác vẫn chạy bằng thư viện chuẩn. Ví dụ trên Ubuntu VPS, từ `Infra/vps`, dùng Python CPython thông thường và môi trường riêng:

```bash
python3 -m venv /opt/homely-private/firebase-check-venv
/opt/homely-private/firebase-check-venv/bin/python -m pip install -r requirements-firebase.txt
/opt/homely-private/firebase-check-venv/bin/python -B check_firebase.py --env-file .env --smtp-env .env.smtp --demo --output /opt/homely-private/fcm-api-results.json
```

Nếu thiếu module venv, cài `python3-venv`. Output phải là file mới; công cụ không ghi đè. Chế độ standalone dùng `--credential-file <absolute-path> --project-id roomly-6d99d`, không ghép thêm cờ Compose. Lượt thực tế đã dùng Python 3.13 container riêng với Google Auth 2.61.0; key/scripts mount read-only, không copy vào image. Python MSYS trên máy hiện tại không build được dependency cryptography nên không dùng môi trường đó cho phép thử mạng.

Lỗi được rút gọn thành `SERVICE_DISABLED`, `PERMISSION_DENIED`, lỗi OAuth/mạng…; không lưu raw response, access token hoặc private key. 21 test offline bao phủ chế độ chỉ validate, TLS/timeout, nhầm project/endpoint, lỗi và chống ghi đè.

## 3. Kiến trúc và hành vi

- Booking, chat, admin và lịch xem tạo inbox + `push_deliveries` trong cùng transaction MySQL. Rollback không để lại thông báo đẩy.
- Worker lấy tối đa 50 delivery/lượt, gửi ngoài transaction, khóa claim để tránh hai worker nhận cùng việc; lease 180 giây để khôi phục sau crash.
- Lỗi tạm thời được thử lại với thời gian chờ tăng dần; tối đa 8 lần, delivery quá 24 giờ bị kết thúc. Token `UNREGISTERED` bị vô hiệu hóa. Không ghi token/credential vào log.
- Worker tôn trọng `chat_push`/`transaction_push`; inbox vẫn còn nếu tắt push. `recommendation_push` là trường tương thích cũ, hiện không có producer gợi ý phòng.
- Payload data-only có `notification_id`, `recipient_id`, `title`, `body`, `ref_type`, `ref_id`. Android kiểm tra người nhận với tài khoản đang đăng nhập trước khi hiển thị. Không đưa nội dung chat vào thông báo ngoài màn hình khóa.
- Đăng xuất vô hiệu hóa thiết bị thuộc session ở server; Android xóa session cục bộ cả khi mất mạng. Thông báo cũ gửi đến tài khoản khác bị client bỏ qua. Chuyển tài khoản trên cùng installation thay quyền sở hữu token.
- Giao nhận là **at-least-once**: crash sau gửi nhưng trước lưu SENT có thể gửi lại. Android dùng cùng notification ID để thay thông báo cũ. Push chỉ báo thay đổi; màn hình luôn đọc trạng thái thật từ API.
- Chưa có Kafka trong luồng này. MySQL outbox đủ cho phạm vi triển khai một backend của đồ án.

Metrics `homely.push.backlog`, `homely.push.failed`, `homely.push.attempts` qua `/actuator/metrics` dành cho ADMIN, ghi sau transaction finish. Test tự động dùng gateway giả; không chứng minh Firebase đã giao tới điện thoại.

## 4. Việc FE: ghép API thật và thêm FCM cho Roomly

Các bước trong phần này là thay đổi FE **cần triển khai**, chưa được thêm vào code trong lượt viết hướng dẫn. Roomly hiện chưa có HTTP client, auth/session bền vững, Google Services/FCM hay messaging service.

### 4.1 Hoàn thiện auth trước khi đăng ký token

- Login bằng API thật, đọc `{statusCode,message,data}` và lưu backend `user.id`, access token, refresh token an toàn. Refresh phải cập nhật token mới.
- Tạo một installation UUID ổn định cho mỗi lần cài đặt; dùng cùng UUID khi login và đăng ký device token. Giữ UUID khi logout/đổi tài khoản; tránh restore identity/session của một installation sang thiết bị khác.
- Khôi phục danh tính thật sau process restart. `LoginViewModel` hiện chỉ validate form; `SessionRepository` hiện giữ state trong bộ nhớ, chưa đáp ứng bước này.

Contract chuẩn tại [PROJECT_CONTRACT.md](PROJECT_CONTRACT.md), bảng LoginRequest/DeviceTokenRequest; quy tắc wrapper tại [bàn giao FE](FE_BACKEND_HANDOFF_08_10_2026.md).

### 4.2 Google Services và Firebase Messaging

Trong `Frontend-Mobile-App/build.gradle.kts`, giữ Android plugin hiện có và thêm:

```kotlin
id("com.google.gms.google-services") version "4.5.0" apply false
```

Trong khối `plugins` của `Frontend-Mobile-App/app/build.gradle.kts`, thêm:

```kotlin
id("com.google.gms.google-services")
```

Trong khối `dependencies` của module app, thêm:

```kotlin
implementation(platform("com.google.firebase:firebase-bom:35.0.0"))
implementation("com.google.firebase:firebase-messaging")
```

Các phiên bản trên theo tài liệu Firebase được kiểm tra ngày 09/10. Sync/build để kiểm chứng với Gradle của Roomly; hướng dẫn này chưa xác nhận APK mới đã build. [Firebase Android setup](https://firebase.google.com/docs/android/setup), [FCM Android](https://firebase.google.com/docs/cloud-messaging/android/get-started).

### 4.3 Permission, service và hiển thị

Trong `Frontend-Mobile-App/app/src/main/AndroidManifest.xml`, thêm hai permission dưới `<manifest>`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

Xin quyền runtime trên Android 13+, tạo notification channel trên Android 8+. Sau khi tạo lớp Java service, khai báo service dưới `<application>`:

```xml
<service android:name=".push.RoomlyMessagingService" android:exported="false">
    <intent-filter>
        <action android:name="com.google.firebase.MESSAGING_EVENT" />
    </intent-filter>
</service>
```

Các file gợi ý để tách trách nhiệm: `push/RoomlyMessagingService.java` nhận message/token, `push/PushTokenRepository.java` đăng ký/retry theo session, `push/PushNotificationRouter.java` điều hướng. Đây là tên lớp mới đề xuất, hiện chưa có trong Roomly. [FCM receive messages](https://firebase.google.com/docs/cloud-messaging/android/receive-messages).

Sau login/khôi phục phiên, lấy token hiện tại bằng `FirebaseMessaging.getInstance().getToken()` và đăng ký cho user thật đang đăng nhập. `onNewToken` lưu token mới; khi đang guest thì chỉ giữ token để đăng ký sau login, khi đã khôi phục phiên thật thì lên lịch đăng ký cho chủ phiên đó. Retry lỗi mạng có backoff; hủy công việc của tài khoản cũ khi logout/chuyển user. Không cần in raw token để chứng minh đăng ký thành công.

Ví dụ body theo contract, gửi cùng `Authorization: Bearer <access_token>`:

`platform` chỉ nhận `ANDROID` (bỏ trường thì dùng mặc định này); `installation_id` không trắng, tối đa 36 ký tự. FE dùng UUID ổn định của lần cài; backend chưa áp regex UUID. Input sai trả 400 `VALIDATION_FAILED` trong global wrapper. Không gửi token của tài khoản cũ sau khi đổi session.

```http
PUT /api/v1/profile/device-token
Content-Type: application/json
Authorization: Bearer <access_token>
```

```json
{
  "token": "<FCM token lấy riêng từ thiết bị>",
  "platform": "ANDROID",
  "device_name": "Roomly Android",
  "installation_id": "<UUID của installation đã login>"
}
```

Thành công: HTTP 200, wrapper `data.status="registered"`. Khi logout, gọi `POST /api/v1/auth/logout` với `Authorization: Bearer <access_token>`, `Content-Type: application/json` và body `{"refresh_token":"<refresh token hiện hành>"}` để server vô hiệu hóa session/device đó. Body thiếu refresh token có ngữ nghĩa logout tất cả thiết bị. Xóa token riêng qua `DELETE /api/v1/profile/device-token/{installationId}` trả 204 không có body.

### 4.4 Xử lý đúng payload backend

Backend gửi data-only gồm `notification_id`, `recipient_id`, `title`, `body`, `ref_type`, `ref_id`, tất cả là string; không có field `type`. Vì vậy app phải tạo notification từ dữ liệu nhận được.

Kiểm tra `recipient_id` bằng backend user ID đang đăng nhập trước khi hiển thị và kiểm tra lại lúc người dùng bấm mở. Dùng `notification_id` cùng recipient để thay thông báo trùng; đọc lại tài nguyên qua API khi mở chi tiết. Ref chưa hỗ trợ mở inbox, không mở màn hình sai đối tượng.

Inbox lấy qua `/api/v1/notifications`; list nằm trong `response.data.data`. Logout/đổi user phải dọn session, socket, công việc đăng ký token và thông báo thuộc user cũ. Tùy chọn push dùng API notification-preferences với `expected_version`; xem contract và [FIREBASE_SETUP.md](FIREBASE_SETUP.md).

## 5. Nối điện thoại với backend local khi chưa có VPS

Stack thử hiện có publish backend vào loopback máy tính port **18089**. Origin `127.0.0.1` trên điện thoại là điện thoại; cần cấu hình kết nối debug dưới đây.

### Điện thoại cắm USB

Bật Developer options/USB debugging, chấp nhận máy tính, rồi chạy ADB từ Android SDK platform-tools. Thiết bị cần Google Play services để dùng FCM theo cấu hình Android này.

```powershell
adb devices
adb -s 'SERIAL-THIET-BI-A' reverse tcp:18089 tcp:18089
adb -s 'SERIAL-THIET-BI-B' reverse tcp:18089 tcp:18089
```

Thay serial bằng giá trị thật, chạy cho từng thiết bị được nối. Hai APK debug dùng API `http://127.0.0.1:18089/api/v1/`, WebSocket `ws://127.0.0.1:18089/ws`. USB reverse có thể cần thiết lập lại sau khi rút dây/khởi động lại. [ADB man page](https://android.googlesource.com/platform/packages/modules/adb/+/refs/heads/main/docs/user/adb.1.md).

### Android Emulator

Dùng Google Play image; API debug `http://10.0.2.2:18089/api/v1/`, WebSocket `ws://10.0.2.2:18089/ws`. Địa chỉ `10.0.2.2` truy cập loopback của máy phát triển. [Android Emulator networking](https://developer.android.com/studio/run/emulator-networking).

Cả máy tính và thiết bị vẫn cần Internet cho FCM; ADB chỉ nối API local.

### Cho phép HTTP local trong bản debug

FE đặt cấu hình trong source set **`app/src/debug`**. Ví dụ `app/src/debug/AndroidManifest.xml`:

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application android:networkSecurityConfig="@xml/network_security_config" />
</manifest>
```

Và `app/src/debug/res/xml/network_security_config.xml`:

```xml
<network-security-config>
    <base-config cleartextTrafficPermitted="false" />
    <domain-config cleartextTrafficPermitted="true">
        <domain includeSubdomains="false">127.0.0.1</domain>
        <domain includeSubdomains="false">10.0.2.2</domain>
    </domain-config>
</network-security-config>
```

Release dùng origin HTTPS của VPS sau khi cấp chứng chỉ. URL phải được cấu hình cho build tương ứng; phần debug trên chưa được thêm vào app hoặc kiểm thử thiết bị. [Android network security configuration](https://developer.android.com/privacy-and-security/security-config).

## 6. Nghiệm thu bằng sự kiện thật từ backend

| Bước | Thao tác | Kết quả cần quan sát |
| --- | --- | --- |
| 1 | Cài APK Roomly đã tích hợp; cấp quyền; login tenant A và host B | Hai tài khoản/installation riêng, token đăng ký HTTP 200 |
| 2 | Tạo booking hoặc lịch xem hợp lệ, hoặc gửi chat giữa hai tài khoản | Inbox + delivery được tạo, đúng người nhận thấy push |
| 3 | Bấm push | Mở đúng đối tượng, đọc trạng thái thật qua API |
| 4 | Thử foreground và background thông thường | Handler/notification đúng; không chứa dữ liệu user khác |
| 5 | Logout A, login tài khoản khác trên cùng thiết bị | Push cho A không hiển thị khi user khác đang dùng app |
| 6 | Tắt quyền hoặc preference chat | Quyền/preference được tôn trọng, inbox vẫn theo trạng thái server |
| 7 | Mất mạng rồi khôi phục khi đăng ký token | Đăng ký được retry; không chuyển token sang tài khoản cũ |
| 8 | Đóng/mở tiến trình app, đổi token/cài lại | Khôi phục phiên phù hợp, token/installation được cập nhật |

Đầu tiên nghiệm thu một luồng chat hoặc lịch xem từ đầu tới cuối; sau đó mở rộng các dòng còn lại. Test gửi từ Firebase Console chỉ kiểm tra một phần đường nhận, không thay thế sự kiện backend data-only. Trạng thái delivery SENT chỉ chứng minh Google đã chấp nhận gửi, vẫn cần quan sát thiết bị. Ghi ID đối tượng/notification, thời gian và kết quả; bỏ raw token/credential khỏi bằng chứng.

## 7. Chẩn đoán

| Dấu hiệu | Kiểm tra đầu tiên |
| --- | --- |
| Không có Android client đúng package khi build | JSON của `com.example.roomly`, đúng module `app` |
| Backend không đọc được credential/startup lỗi | File thực, project ID và quyền mount/non-root; không in khóa |
| Điện thoại không gọi được API local | Health/port 18089, ADB reverse hoặc 10.0.2.2, HTTP debug |
| Có delivery nhưng không thấy thông báo | API V1/quyền gửi, Internet, permission/channel, handler data-only và user ID hiện tại |
| Push trùng/sai tài khoản | Dedup notification ID + recipient; session/installation/token ownership và logout |

SENT chỉ chứng minh gateway chấp nhận gửi; cần quan sát thiết bị. Force-stop qua Android Settings khác background thông thường, mở lại app trước khi thử tiếp. Việc còn lại của cả dự án tại [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md).
