# Global HTTP response wrapper — Contract v1.6

HTTP envelope được áp dụng từ v1.5 và giữ nguyên trong contract v1.6. Tài liệu này tập trung vào giao thức và cách parse; hiện trạng/bằng chứng kiểm chứng được gộp tại [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md). Nguồn giao thức hiện tại là [PROJECT_CONTRACT.md](PROJECT_CONTRACT.md) §1.3/§7/§8 và [openapi.yaml](openapi.yaml).

## Giao thức

Mọi HTTP JSON của controller ứng dụng có đúng ba trường `statusCode`, `message`, `data`. `statusCode` giữ camelCase theo tên envelope đã chốt, là integer trùng HTTP status thật. DTO trong `data` vẫn dùng snake_case và tiền VND vẫn là chuỗi số nguyên. Success message là reason phrase của HTTP status; error message lấy từ ProblemDTO.detail.

HTTP 201:

```json
{"statusCode":201,"message":"Created","data":{"id":7,"title":"Phòng A"}}
```

HTTP 200 với phân trang:

```json
{"statusCode":200,"message":"OK","data":{"data":[],"total_elements":0,"total_pages":0,"current_page":0,"page_size":20}}
```

HTTP 401:

```json
{
  "statusCode": 401,
  "message": "Authentication is required",
  "data": {
    "type": "urn:problem:authentication-required",
    "title": "Unauthorized",
    "status": 401,
    "detail": "Authentication is required",
    "instance": "/api/v1/profile",
    "code": "AUTHENTICATION_REQUIRED",
    "field_errors": [],
    "trace_id": "aef4c490-28ec-47ee-8523-9dc4d8c39089",
    "timestamp": "2026-10-04T14:25:00Z"
  }
}
```

HTTP lỗi vẫn là 4xx/5xx, Content-Type `application/json`, Cache-Control `no-store`; không đổi thành 200. ProblemDTO giữ code, field_errors, trace_id và timestamp trong data. Đây là Problem Details bên trong envelope, không gắn nhãn `application/problem+json` cho document root đã bọc.

HTTP 200 không có DTO trả `{"statusCode":200,"message":"OK","data":null}`. HTTP 204/205/304 không body; media/content trả byte stream nguyên gốc. Swagger/OpenAPI, Actuator và STOMP có giao thức riêng: STOMP vẫn trả MessageDTO/ProblemDTO trực tiếp, không thêm envelope HTTP.

## Triển khai

- `FormatRestResponse` bọc response một lần tại controller thuộc package ứng dụng; hỗ trợ DTO, array, page, null và StringHttpMessageConverter. Payload đã là RestResponse được giữ nguyên. Converter cho binary/resource/stream không bị bọc.
- `ApiProblems` giữ nơi tạo ProblemDTO chung. Filter security/account/idempotency/chat và lỗi HTTP handshake ghi envelope trực tiếp; lỗi MVC/servlet fallback được advice bọc. HTTP status, Allow, WWW-Authenticate và Retry-After được giữ.
- Idempotency lưu response sau khi serialize envelope; replay snapshot mới giữ nguyên bytes. Snapshot JSON hoặc success rỗng trước v1.5 được bọc khi replay, không lặp lại mutation hoặc xóa claim.
- Client tham khảo `Homely-android` dùng `ApiEnvelope` để gỡ data tại ApiClient cho request thường, login/refresh và upload multipart. UI nhận DTO/page; array được chuyển thành object data ở nội bộ cho màn hình danh sách. Lỗi đọc data.detail, có fallback cho lỗi proxy không phải JSON. Envelope thiếu field hoặc statusCode không khớp HTTP bị từ chối. Roomly cần triển khai parser tương ứng; các lớp của client tham khảo không tự có trong Roomly.
- OpenAPI hiện tại mô tả success envelope, RestResponseProblemDTO và RestResponseVoid, giữ schema media binary và extension STOMP. Việc bọc HTTP không đổi database/state machine hoặc thêm migration.

## Kiểm chứng và tích hợp client

Kết quả backend, runtime contract và giới hạn Android nằm tại [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md). Không dùng các lượt test client Homely cũ để kết luận Roomly đã ghép API. Roomly cần parser envelope cho success/error, page/array, login/refresh/upload và xử lý riêng no-content/binary/STOMP theo [bàn giao FE](FE_BACKEND_HANDOFF_08_10_2026.md).

Firebase đã cấu hình backend local; OAuth và API V1 đã trả HTTP 200 với `validate_only:true` ngày 09/10/2026. Kiểm tra này không gửi notification; giao push tới thiết bị chưa nghiệm thu, xem [FIREBASE_SETUP.md](FIREBASE_SETUP.md). Thanh toán/hoàn tiền vẫn là sandbox. Client cũ nhận DTO trực tiếp cần nâng cấp parser để tương thích envelope hiện tại.
