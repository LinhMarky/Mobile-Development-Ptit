# Bàn giao backend cho FE Roomly

Cập nhật 09/10/2026, 18:03 VN. **Mail và quyền gửi FCM backend đã kiểm chứng thật; image mới đã chạy local.** Chưa có VPS/IP, URL HTTPS dưới đây là mẫu. App chính: `Frontend-Mobile-App`, application ID **`com.example.roomly`**. 255 test backend đạt; lỗi đăng ký thiết bị được kiểm tra qua HTTP trên image đang chạy.

## 1. Kết nối

Sau khi deploy, lấy URL thực tế từ `Infra/vps/generated/proxy/fe-connection.env`:

| Mục | Mẫu |
| --- | --- |
| Origin | `https://<VPS-IP>` |
| Retrofit base URL | `https://<VPS-IP>/api/v1/` — có `/` cuối |
| WebSocket | `wss://<VPS-IP>/ws` — nằm ở origin, không dưới `/api/v1` |
| Swagger | `https://<VPS-IP>/swagger-ui/index.html` |
| OpenAPI runtime | `https://<VPS-IP>/v3/api-docs` |
| Health | `https://<VPS-IP>/actuator/health` |

Chứng chỉ phải được Android tin cậy. Không hardcode localhost/`mysql`/`minio`; không dùng `TrustAll`, bỏ hostname verification hoặc đổi sang HTTP để lách lỗi SSL. Cấu hình URL ở build config; dùng cùng endpoint trên tất cả điện thoại.

FE có thể bắt đầu bằng stack local **`http://127.0.0.1:18089`**, không phải chờ VPS: điện thoại dùng USB `adb reverse`, emulator dùng `10.0.2.2`. API base thêm `/api/v1/`, socket thêm `/ws`. Thiết lập HTTP chỉ cho debug tại [FIREBASE_SETUP.md](FIREBASE_SETUP.md); localhost của máy khác không truy cập backend này trực tiếp. Image đang chạy: `homely-backend:vps-verified-20261009-fcm`.

## 2. Contract cần giữ khi ghép API

Nguồn chính: [PROJECT_CONTRACT.md](PROJECT_CONTRACT.md), [OpenAPI](openapi.yaml), [FE_SPEC.md](FE_SPEC.md), [CHAT.md](CHAT.md). Runtime API version **1.6.0**.

- HTTP JSON dùng **`{statusCode,message,data}`**, bao gồm lỗi. Lỗi nghiệp vụ nằm trong `data.code`, `data.detail`, `data.field_errors`, `data.trace_id`; status HTTP vẫn có ý nghĩa. Bytes ảnh/file, Swagger và STOMP frame là các loại payload riêng.
- Phân trang: wrapper `data` là page; mảng phần tử nằm trong **`data.data`**. Lấy total/cursor theo DTO, không cast mọi response thành List.
- Auth dùng **access token** trong `Authorization: Bearer ...`; refresh qua `/auth/refresh` bằng refresh token. Native app giữ token theo contract; không dựa vào cookie trình duyệt. Không log token/password.
- Giá/cọc VND được truyền dưới dạng **chuỗi**; parse chính xác, không dùng float. ID room/listing/slot/booking lấy từ API, không dùng ID của dữ liệu demo.
- Mutation cần `Idempotency-Key` theo OpenAPI. Retry cùng thao tác giữ nguyên key/body; thao tác mới tạo key mới. Chat giữ `client_message_id` và deduplicate theo ID/sequence.
- URL media `/api/v1/media/{id}/content` resolve từ **origin**, không ghép thêm `/api/v1` lần hai. Media riêng cần Authorization khi hiển thị theo quyền server.
- Loading/error/retry phải phản ánh kết quả API. Logout/đổi user xóa socket, session và cache đúng phạm vi; lỗi mạng tạm thời không tự coi là refresh token bị thu hồi.

## 3. Auth và chat

Tài khoản báo cáo dùng email **`tenant@homely.test`**, **`host@homely.test`**, **`admin@homely.test`** khi đã bật demo seed. Mật khẩu ngẫu nhiên do backend quản lý trong `.env` được gửi riêng; không ghi trong tài liệu này. Tài khoản seed là dữ liệu thử, không gửi email thật tới miền `.test`.

Ví dụ body login cho app native:

```json
{"email":"tenant@homely.test","password":"<mật-khẩu-nhận-riêng>","installation_id":"<UUID-cố-định-của-installation>","device_name":"Roomly Android"}
```

WebSocket native gửi Authorization trong **HTTP handshake**. Không đưa token vào query; không gửi lại Authorization/login/passcode/user trong STOMP CONNECT. Subscribe `/user/queue/chat.messages`, `/user/queue/chat.acks`, `/user/queue/chat.errors`; gửi tới `/app/chat.send`. Không có SockJS. Luồng reconnect/history/UUID theo [CHAT.md](CHAT.md).

## 4. Firebase

**Cập nhật 09/10:** project thật **`roomly-6d99d`**. Android JSON đúng **`com.example.roomly`**, khớp service account backend. OAuth + API V1 đã được Google chấp nhận HTTP 200 ở chế độ validate-only; backend healthy, credential read-only. FE cần thêm SDK/plugin/service/quyền thông báo và token thật để nghiệm thu delivery. Service account chỉ dùng phía server. `PUT /api/v1/profile/device-token`: token 1..4096, device_name 1..100, platform `ANDROID`, installation_id không trắng/tối đa 36 ký tự (dùng UUID ổn định). Input sai trả 400 `VALIDATION_FAILED`; trường lỗi Java có thể là `installationId`. Cập nhật token đổi mới và xử lý đổi tài khoản/installation.

Payload data-only dùng `notification_id`, `recipient_id`, `title`, `body`, `ref_type`, `ref_id`. Chỉ hiển thị cho tài khoản đang đăng nhập đúng recipient; bấm mở màn hình đã tích hợp và đọc lại dữ liệu API. API validate-only PASS chưa chứng minh giao push. Cách ghép và nghiệm thu tại [FIREBASE_SETUP.md](FIREBASE_SETUP.md).

## 5. Các kết quả FE cần trả lại

1. APK login tenant/host thật, đọc danh sách/chi tiết tin thật; dữ liệu server thay đổi thì refresh thấy thay đổi.
2. Host tạo/gửi duyệt tin và ảnh; admin duyệt; tenant ở máy khác thấy cùng ID và ảnh theo quyền.
3. Hai tài khoản chat qua WSS; mở lại app/reconnect lấy history đúng, không tạo tin trùng.
4. Đăng ký bằng email thật, nhận/xác minh và login nếu đã bật SMTP thật.
5. Sự kiện booking/chat/lịch xem tới Roomly bằng FCM thật; foreground/background/logout/đổi user đúng.

Không báo đã ghép xong dựa trên màn hình repository demo. Mỗi luồng kèm endpoint, ID/trạng thái quan sát và kết quả, bỏ token/password khỏi bằng chứng. Backend và FE có thể làm song song; chỉ cần chốt endpoint sau khi VPS đã PASS.
