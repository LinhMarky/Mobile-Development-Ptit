package com.homely.rental.catalog.service;

import com.homely.rental.auth.entity.User;
import com.homely.rental.auth.security.UserResolver;
import com.homely.rental.catalog.dto.response.ListingDTO;
import com.homely.rental.catalog.entity.*;
import com.homely.rental.catalog.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import java.time.Instant;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class WishlistServiceTest {
    @Mock WishlistRepository wishlist;
    @Mock RoomRepository rooms;
    @Mock ListingRepository listings;
    @Mock ListingService listingService;
    @Mock UserResolver resolver;
    WishlistService service;
    Room room;
    Listing listing;
    User user;
    final PageRequest page = PageRequest.of(0, 20);

    @BeforeEach void setup() throws Exception {
        service = new WishlistService(wishlist, rooms, resolver, listings, listingService);
        user = new User(); user.setId(71L);
        room = new Room(); room.setId(900L); room.setUnitCode("A01");
        Address address = new Address(); address.setLine("Campus"); room.setAddress(address);
        listing = new Listing(); listing.setId(600L); listing.setRoom(room);
        listing.setStatus(ListingStatus.PUBLISHED); listing.setExpiresAt(Instant.now().plusSeconds(600));
        when(resolver.requireCurrent()).thenReturn(user);
    }
    private void oneSavedRoom() {
        WishlistItem item = new WishlistItem(); item.setId(5L); item.setUser(user); item.setRoom(room);
        when(wishlist.findByUserId(71L, page)).thenReturn(new PageImpl<>(List.of(item), page, 1));
        when(listings.findByRoomIdIn(List.of(900L))).thenReturn(List.of(listing));
    }
    @Test void publicAdvertAddsSeparateListingIdWithoutChangingSavedRoomIdentity() throws Exception {
        oneSavedRoom();
        ListingDTO summary = ListingDTO.builder().id(600L).roomId(900L).title("Actual title").build();
        when(listingService.toDTO(listing)).thenReturn(summary);
        var result = service.getSavedRooms(page);
        assertThat(result.getData()).hasSize(1);
        assertThat(result.getData().get(0)).containsEntry("id", 5L).containsEntry("room_id", 900L)
                .containsEntry("unit_code", "A01").containsEntry("address", "Campus")
                .containsEntry("listing_id", 600L).containsEntry("listing", summary).containsKey("saved_at");
        verify(wishlist).findByUserId(71L, page);
    }
    @ParameterizedTest @EnumSource(value = ListingStatus.class, names = "PUBLISHED", mode = EnumSource.Mode.EXCLUDE)
    void privateAdvertNeverAppearsInSavedRoomResponse(ListingStatus status) throws Exception {
        oneSavedRoom(); listing.setStatus(status);
        var item = service.getSavedRooms(page).getData().get(0);
        assertThat(item).containsEntry("room_id", 900L).containsEntry("listing_id", null).containsEntry("listing", null);
        verifyNoInteractions(listingService);
    }
    @Test void expiredAdvertIsHiddenEvenBeforeExpirationJobRuns() throws Exception {
        oneSavedRoom(); listing.setExpiresAt(Instant.now().minusSeconds(1));
        assertThat(service.getSavedRooms(page).getData().get(0)).containsEntry("listing", null);
        verifyNoInteractions(listingService);
    }
    @Test void legacyPublishedAdvertWithoutExpiryRemainsVisibleLikePublicDetail() throws Exception {
        oneSavedRoom(); listing.setExpiresAt(null);
        when(listingService.toDTO(listing)).thenReturn(ListingDTO.builder().id(600L).build());
        assertThat(service.getSavedRooms(page).getData().get(0)).containsEntry("listing_id", 600L);
    }
    @Test void emptyWishlistDoesNotQueryUnrelatedListings() throws Exception {
        when(wishlist.findByUserId(71L, page)).thenReturn(new PageImpl<>(List.of(), page, 0));
        assertThat(service.getSavedRooms(page).getData()).isEmpty();
        verifyNoInteractions(listings, listingService);
    }
}
