-- V20: simplify the 14-table schema without changing APIs or business properties.
-- Copy and verify all meaningful values, IDs, versions and identity counters before swapping.
-- V1-V19 are immutable. Back up and stop application writers before upgrading.

CREATE TABLE `account_records_v20` (
    `id` BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `record_type` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    `version` int NOT NULL DEFAULT '0',
    `user_id` bigint NULL,
    `device_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `expires_at` datetime(3) NULL,
    `installation_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `token_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `chat_push` tinyint(1) NULL DEFAULT '1',
    `deletion_completed_at` datetime(3) NULL,
    `deletion_failure_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `deletion_reason` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '',
    `deletion_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING',
    `deletion_user_id` bigint NULL,
    `device_active` tinyint(1) NULL DEFAULT '1',
    `device_user_id` bigint NULL,
    `fcm_token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `lifecycle_user_id` bigint NULL,
    `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'ANDROID',
    `preference_user_id` bigint NULL,
    `recommendation_push` tinyint(1) NULL DEFAULT '1',
    `revoked` tinyint(1) NULL DEFAULT '0',
    `role_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `token_purpose` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `transaction_email` tinyint(1) NULL DEFAULT '1',
    `transaction_push` tinyint(1) NULL DEFAULT '1',
    `used` tinyint(1) NULL DEFAULT '0',
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `active_fcm_token_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci GENERATED ALWAYS AS (if((`record_type` = _ascii'DEVICE_TOKEN'),if(`device_active`,sha2(`fcm_token`,256),NULL),NULL)) STORED,
    `active_installation_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci GENERATED ALWAYS AS (if((`record_type` = _ascii'DEVICE_TOKEN'),if(`device_active`,`installation_id`,NULL),NULL)) STORED,
    KEY `ix_account_user_id` (`user_id`),
    KEY `ix_account_kind_deletion_status` (`record_type`,`deletion_status`),
    KEY `ix_account_kind_expires_at` (`record_type`,`expires_at`),
    KEY `ix_account_kind_user_id` (`record_type`,`user_id`),
    KEY `ix_account_kind_device_user_id_device_active` (`record_type`,`device_user_id`,`device_active`),
    UNIQUE KEY `uk_account_kind_role_name` (`record_type`,`role_name`),
    UNIQUE KEY `uk_account_kind_active_fcm_token_hash` (`record_type`,`active_fcm_token_hash`),
    UNIQUE KEY `uk_account_kind_device_user_id_installation_id` (`record_type`,`device_user_id`,`installation_id`),
    UNIQUE KEY `uk_account_kind_preference_user_id` (`record_type`,`preference_user_id`),
    UNIQUE KEY `uk_account_kind_deletion_user_id` (`record_type`,`deletion_user_id`),
    UNIQUE KEY `uk_account_kind_lifecycle_user_id` (`record_type`,`lifecycle_user_id`),
    UNIQUE KEY `uk_account_kind_token_hash` (`record_type`,`token_hash`),
    UNIQUE KEY `uk_account_kind_active_installation_id` (`record_type`,`active_installation_id`),
    UNIQUE KEY `uk_account_id_kind` (`id`,`record_type`),
    CONSTRAINT `ck_account_kind` CHECK ((`record_type` in (_ascii'ROLE',_ascii'REFRESH_TOKEN',_ascii'ONE_TIME_TOKEN',_ascii'DEVICE_TOKEN',_ascii'PREFERENCES',_ascii'DELETION_REQUEST',_ascii'LIFECYCLE_LOCK'))),
    CONSTRAINT `ck_account_deletion_required` CHECK (((`record_type` <> _ascii'DELETION_REQUEST') or ((`deletion_user_id` is not null) and (`deletion_reason` is not null) and (`deletion_status` is not null)))),
    CONSTRAINT `ck_account_device_required` CHECK (((`record_type` <> _ascii'DEVICE_TOKEN') or ((`device_user_id` is not null) and (`fcm_token` is not null) and (`platform` is not null) and (`device_name` is not null) and (`installation_id` is not null) and (`device_active` is not null)))),
    CONSTRAINT `ck_account_lifecycle_required` CHECK (((`record_type` <> _ascii'LIFECYCLE_LOCK') or (`lifecycle_user_id` is not null))),
    CONSTRAINT `ck_account_preference_required` CHECK (((`record_type` <> _ascii'PREFERENCES') or ((`preference_user_id` is not null) and (`transaction_push` is not null) and (`transaction_email` is not null) and (`chat_push` is not null) and (`recommendation_push` is not null)))),
    CONSTRAINT `ck_account_refresh_required` CHECK (((`record_type` <> _ascii'REFRESH_TOKEN') or ((`token_hash` is not null) and (`user_id` is not null) and (`installation_id` is not null) and (`device_name` is not null) and (`expires_at` is not null) and (`revoked` is not null)))),
    CONSTRAINT `ck_account_role_required` CHECK (((`record_type` <> _ascii'ROLE') or (`role_name` is not null))),
    CONSTRAINT `ck_account_verify_required` CHECK (((`record_type` <> _ascii'ONE_TIME_TOKEN') or ((`token_hash` is not null) and (`user_id` is not null) and (`token_purpose` is not null) and (`used` is not null) and (`expires_at` is not null))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Accounts: roles, sessions, verification, devices, preferences, deletion and lifecycle locks.';

INSERT INTO `account_records_v20` (`id`,`record_type`,`version`,`user_id`,`device_name`,`expires_at`,`installation_id`,`token_hash`,`chat_push`,`deletion_completed_at`,`deletion_failure_code`,`deletion_reason`,`deletion_status`,`deletion_user_id`,`device_active`,`device_user_id`,`fcm_token`,`lifecycle_user_id`,`platform`,`preference_user_id`,`recommendation_push`,`revoked`,`role_name`,`token_purpose`,`transaction_email`,`transaction_push`,`used`,`created_at`,`updated_at`)
SELECT
    s.`id` AS `id`,
    s.`record_type` AS `record_type`,
    s.`version` AS `version`,
    CASE s.record_type WHEN 'REFRESH_TOKEN' THEN s.`refresh_user_id` WHEN 'ONE_TIME_TOKEN' THEN s.`verify_user_id` ELSE NULL END AS `user_id`,
    CASE s.record_type WHEN 'REFRESH_TOKEN' THEN s.`refresh_device_name` WHEN 'DEVICE_TOKEN' THEN s.`device_device_name` ELSE NULL END AS `device_name`,
    CASE s.record_type WHEN 'REFRESH_TOKEN' THEN s.`refresh_expires_at` WHEN 'ONE_TIME_TOKEN' THEN s.`verify_expires_at` ELSE NULL END AS `expires_at`,
    CASE s.record_type WHEN 'REFRESH_TOKEN' THEN s.`refresh_installation_id` WHEN 'DEVICE_TOKEN' THEN s.`device_installation_id` ELSE NULL END AS `installation_id`,
    CASE s.record_type WHEN 'REFRESH_TOKEN' THEN s.`refresh_token_hash` WHEN 'ONE_TIME_TOKEN' THEN s.`verify_token_hash` ELSE NULL END AS `token_hash`,
    s.`preference_chat_push` AS `chat_push`,
    s.`deletion_completed_at` AS `deletion_completed_at`,
    s.`deletion_failure_code` AS `deletion_failure_code`,
    s.`deletion_reason` AS `deletion_reason`,
    s.`deletion_status` AS `deletion_status`,
    s.`deletion_user_id` AS `deletion_user_id`,
    s.`device_active` AS `device_active`,
    s.`device_user_id` AS `device_user_id`,
    s.`device_token` AS `fcm_token`,
    s.`lifecycle_user_id` AS `lifecycle_user_id`,
    s.`device_platform` AS `platform`,
    s.`preference_user_id` AS `preference_user_id`,
    s.`preference_recommendation_push` AS `recommendation_push`,
    s.`refresh_revoked` AS `revoked`,
    s.`role_name` AS `role_name`,
    s.`verify_purpose` AS `token_purpose`,
    s.`preference_transaction_email` AS `transaction_email`,
    s.`preference_transaction_push` AS `transaction_push`,
    s.`verify_used` AS `used`,
    CASE s.record_type WHEN 'REFRESH_TOKEN' THEN s.`refresh_created_at` WHEN 'ONE_TIME_TOKEN' THEN s.`verify_created_at` WHEN 'DEVICE_TOKEN' THEN s.`device_created_at` WHEN 'PREFERENCES' THEN s.`preference_created_at` WHEN 'DELETION_REQUEST' THEN s.`deletion_created_at` ELSE NULL END AS `created_at`,
    CASE s.record_type WHEN 'DEVICE_TOKEN' THEN s.`device_updated_at` WHEN 'PREFERENCES' THEN s.`preference_updated_at` WHEN 'DELETION_REQUEST' THEN s.`deletion_updated_at` ELSE NULL END AS `updated_at`
FROM `account_records` s;

SET @schema20_identity = (SELECT AUTO_INCREMENT FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='account_records');
SET @schema20_ddl = CONCAT('ALTER TABLE account_records_v20 AUTO_INCREMENT=', COALESCE(@schema20_identity,1));
PREPARE schema20_statement FROM @schema20_ddl;
EXECUTE schema20_statement;
DEALLOCATE PREPARE schema20_statement;

CREATE TABLE `catalog_items_v20` (
    `id` BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `record_type` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    `user_id` bigint NULL,
    `room_id` bigint NULL,
    `listing_id` bigint NULL,
    `amount_vnd` decimal(18,0) NULL,
    `category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `fee_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `fee_mode` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'FIXED',
    `icon` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `note` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `sort_order` int NULL DEFAULT '0',
    `unit_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    KEY `ix_catalog_listing_id` (`listing_id`),
    KEY `ix_catalog_room_id` (`room_id`),
    KEY `ix_catalog_kind_listing_id` (`record_type`,`listing_id`),
    KEY `ix_catalog_kind_room_id` (`record_type`,`room_id`),
    UNIQUE KEY `uk_catalog_kind_name` (`record_type`,`name`),
    UNIQUE KEY `uk_catalog_kind_user_id_room_id` (`record_type`,`user_id`,`room_id`),
    UNIQUE KEY `uk_catalog_id_kind` (`id`,`record_type`),
    CONSTRAINT `ck_catalog_amenity_required` CHECK (((`record_type` <> _ascii'AMENITY') or (`name` is not null))),
    CONSTRAINT `ck_catalog_kind` CHECK ((`record_type` in (_ascii'AMENITY',_ascii'LISTING_FEE',_ascii'WISHLIST_ITEM'))),
    CONSTRAINT `ck_catalog_fee_required` CHECK (((`record_type` <> _ascii'LISTING_FEE') or ((`listing_id` is not null) and (`fee_code` is not null) and (`fee_mode` is not null) and (`amount_vnd` is not null) and (`sort_order` is not null)))),
    CONSTRAINT `ck_catalog_wishlist_required` CHECK (((`record_type` <> _ascii'WISHLIST_ITEM') or ((`user_id` is not null) and (`room_id` is not null))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Catalog: amenities, listing fees and saved rooms; record_type selects the entity.';

INSERT INTO `catalog_items_v20` (`id`,`record_type`,`user_id`,`room_id`,`listing_id`,`amount_vnd`,`category`,`fee_code`,`fee_mode`,`icon`,`name`,`note`,`sort_order`,`unit_name`,`created_at`)
SELECT
    s.`id` AS `id`,
    s.`record_type` AS `record_type`,
    s.`wishlist_user_id` AS `user_id`,
    s.`wishlist_room_id` AS `room_id`,
    s.`fee_listing_id` AS `listing_id`,
    s.`fee_amount_vnd` AS `amount_vnd`,
    s.`amenity_category` AS `category`,
    s.`fee_fee_code` AS `fee_code`,
    s.`fee_fee_mode` AS `fee_mode`,
    s.`amenity_icon` AS `icon`,
    s.`amenity_name` AS `name`,
    s.`fee_note` AS `note`,
    s.`fee_sort_order` AS `sort_order`,
    s.`fee_unit_name` AS `unit_name`,
    s.`wishlist_created_at` AS `created_at`
FROM `catalog_items` s;

SET @schema20_identity = (SELECT AUTO_INCREMENT FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='catalog_items');
SET @schema20_ddl = CONCAT('ALTER TABLE catalog_items_v20 AUTO_INCREMENT=', COALESCE(@schema20_identity,1));
PREPARE schema20_statement FROM @schema20_ddl;
EXECUTE schema20_statement;
DEALLOCATE PREPARE schema20_statement;

CREATE TABLE `rental_records_v20` (
    `id` BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `record_type` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    `version` int NOT NULL DEFAULT '0',
    `actor_id` bigint NULL,
    `room_id` bigint NULL,
    `host_id` bigint NULL,
    `tenant_id` bigint NULL,
    `booking_id` bigint NULL,
    `listing_id` bigint NULL,
    `amount_vnd` decimal(18,0) NULL,
    `note` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `actor_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `allocated_payment_id` bigint NULL,
    `attempt_count` int NULL DEFAULT '0',
    `booking_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING',
    `cancelled_at` datetime(3) NULL,
    `cancelled_reason` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `case_decision` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `case_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'OPEN',
    `case_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `currency` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'VND',
    `deposit_vnd` decimal(18,0) NULL DEFAULT '0',
    `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `desired_move_in` date NULL,
    `end_at` datetime(3) NULL,
    `event_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `event_provider` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `expires_at` datetime(3) NULL,
    `failure_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `from_status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `handover_due_at` datetime(3) NULL,
    `history_reason` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `hold_expires_at` datetime(3) NULL,
    `host_handover_confirmed_at` datetime(3) NULL,
    `host_retained_vnd` decimal(18,0) NULL,
    `is_test` tinyint(1) NULL DEFAULT '1',
    `last_error_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `last_reason` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `next_attempt_at` datetime(3) NULL,
    `occupant_count` int NULL DEFAULT '1',
    `opened_by` bigint NULL,
    `outcome` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `payer_id` bigint NULL,
    `payload_hash` binary(32) NULL,
    `payment_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING',
    `processed_at` datetime(3) NULL,
    `provider` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'MOCK_SANDBOX',
    `provider_payment_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `provider_refund_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `refund_payment_id` bigint NULL,
    `refund_reason` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `refund_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING',
    `rent_vnd` decimal(18,0) NULL,
    `request_expires_at` datetime(3) NULL,
    `resolution_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `resolved_at` datetime(3) NULL,
    `resolved_by` bigint NULL,
    `slot_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'OPEN',
    `snapshot_schema_version` int NULL DEFAULT '1',
    `start_at` datetime(3) NULL,
    `succeeded_at` datetime(3) NULL,
    `tenant_handover_confirmed_at` datetime(3) NULL,
    `tenant_refund_vnd` decimal(18,0) NULL,
    `tenant_terms_accepted_at` datetime(3) NULL,
    `terms_snapshot` json NULL,
    `to_status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `trace_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `viewing_slot_id` bigint NULL,
    `viewing_status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'REQUESTED',
    `webhook_payment_id` bigint NULL,
    `completed_at` datetime(3) NULL,
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `active_room_id` bigint GENERATED ALWAYS AS (if((`record_type` = _ascii'BOOKING'),(case when (`booking_status` in (_utf8mb4'APPROVED',_utf8mb4'CONFIRMED')) then `room_id` else NULL end),NULL)) STORED,
    `allocated_payment_id_kind` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'PAYMENT',
    `booking_id_kind` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'BOOKING',
    `open_case_booking_id` bigint GENERATED ALWAYS AS (if((`record_type` = _ascii'BOOKING_CASE'),(case when (`case_status` in (_utf8mb4'OPEN',_utf8mb4'IN_REVIEW')) then `booking_id` else NULL end),NULL)) STORED,
    `open_room_id` bigint GENERATED ALWAYS AS (if((`record_type` = _ascii'BOOKING'),(case when (`booking_status` in (_utf8mb4'PENDING',_utf8mb4'APPROVED',_utf8mb4'CONFIRMED')) then `room_id` else NULL end),NULL)) STORED,
    `pending_booking_id` bigint GENERATED ALWAYS AS (if((`record_type` = _ascii'PAYMENT'),(case when (`payment_status` = _utf8mb4'PENDING') then `booking_id` else NULL end),NULL)) STORED,
    `refund_payment_id_kind` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'PAYMENT',
    `viewing_slot_id_kind` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'VIEWING_SLOT',
    `webhook_payment_id_kind` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'PAYMENT',
    KEY `ix_rental_allocated_payment_id_allocated_payment_id_kind` (`allocated_payment_id`,`allocated_payment_id_kind`),
    KEY `ix_rental_host_id` (`host_id`),
    KEY `ix_rental_listing_id` (`listing_id`),
    KEY `ix_rental_room_id` (`room_id`),
    KEY `ix_rental_booking_id_booking_id_kind` (`booking_id`,`booking_id_kind`),
    KEY `ix_rental_opened_by` (`opened_by`),
    KEY `ix_rental_resolved_by` (`resolved_by`),
    KEY `ix_rental_actor_id` (`actor_id`),
    KEY `ix_rental_payer_id` (`payer_id`),
    KEY `ix_rental_refund_payment_id_refund_payment_id_kind` (`refund_payment_id`,`refund_payment_id_kind`),
    KEY `ix_rental_tenant_id` (`tenant_id`),
    KEY `ix_rental_viewing_slot_id_viewing_slot_id_kind` (`viewing_slot_id`,`viewing_slot_id_kind`),
    KEY `ix_rental_webhook_payment_id_webhook_payment_id_kind` (`webhook_payment_id`,`webhook_payment_id_kind`),
    KEY `ix_rental_kind_opened_by` (`record_type`,`opened_by`),
    KEY `ix_rental_kind_resolved_by` (`record_type`,`resolved_by`),
    KEY `ix_rental_kind_booking_id_case_status` (`record_type`,`booking_id`,`case_status`),
    KEY `ix_rental_kind_actor_id` (`record_type`,`actor_id`),
    KEY `ix_rental_kind_booking_id_created_at` (`record_type`,`booking_id`,`created_at`),
    KEY `ix_rental_kind_host_id_slot_status` (`record_type`,`host_id`,`slot_status`),
    KEY `ix_rental_kind_room_id_slot_status_start_at` (`record_type`,`room_id`,`slot_status`,`start_at`),
    KEY `ix_rental_kind_viewing_slot_id` (`record_type`,`viewing_slot_id`),
    KEY `ix_rental_kind_listing_id` (`record_type`,`listing_id`),
    KEY `ix_rental_kind_host_id_viewing_status` (`record_type`,`host_id`,`viewing_status`),
    KEY `ix_rental_kind_room_id_viewing_status` (`record_type`,`room_id`,`viewing_status`),
    KEY `ix_rental_kind_tenant_id_viewing_status` (`record_type`,`tenant_id`,`viewing_status`),
    KEY `ix_rental_kind_payer_id` (`record_type`,`payer_id`),
    KEY `ix_rental_kind_payment_status_expires_at` (`record_type`,`payment_status`,`expires_at`),
    KEY `ix_rental_kind_refund_status_next_attempt_at` (`record_type`,`refund_status`,`next_attempt_at`),
    KEY `ix_rental_kind_webhook_payment_id` (`record_type`,`webhook_payment_id`),
    KEY `ix_rental_kind_booking_status_handover_due_at` (`record_type`,`booking_status`,`handover_due_at`),
    KEY `ix_rental_kind_booking_status_hold_expires_at` (`record_type`,`booking_status`,`hold_expires_at`),
    KEY `ix_rental_kind_booking_status_request_expires_at` (`record_type`,`booking_status`,`request_expires_at`),
    KEY `ix_rental_kind_host_id_booking_status_created_at_id` (`record_type`,`host_id`,`booking_status`,`created_at`,`id`),
    KEY `ix_rental_kind_tenant_id_booking_status_created_at_id` (`record_type`,`tenant_id`,`booking_status`,`created_at`,`id`),
    UNIQUE KEY `uk_rental_kind_allocated_payment_id` (`record_type`,`allocated_payment_id`),
    UNIQUE KEY `uk_rental_kind_tenant_id_open_room_id` (`record_type`,`tenant_id`,`open_room_id`),
    UNIQUE KEY `uk_rental_kind_open_case_booking_id` (`record_type`,`open_case_booking_id`),
    UNIQUE KEY `uk_rental_kind_provider_payment_id` (`record_type`,`provider_payment_id`),
    UNIQUE KEY `uk_rental_kind_pending_booking_id` (`record_type`,`pending_booking_id`),
    UNIQUE KEY `uk_rental_kind_refund_payment_id` (`record_type`,`refund_payment_id`),
    UNIQUE KEY `uk_rental_kind_provider_refund_id` (`record_type`,`provider_refund_id`),
    UNIQUE KEY `uk_rental_kind_event_provider_event_id` (`record_type`,`event_provider`,`event_id`),
    UNIQUE KEY `uk_rental_kind_active_room_id` (`record_type`,`active_room_id`),
    UNIQUE KEY `uk_rental_id_kind` (`id`,`record_type`),
    CONSTRAINT `ck_rental_booking_allocated_payment_kind` CHECK ((`allocated_payment_id_kind` = _ascii'PAYMENT')),
    CONSTRAINT `ck_rental_booking_required` CHECK (((`record_type` <> _ascii'BOOKING') or ((`tenant_id` is not null) and (`host_id` is not null) and (`room_id` is not null) and (`listing_id` is not null) and (`booking_status` is not null) and (`occupant_count` is not null) and (`rent_vnd` is not null) and (`deposit_vnd` is not null) and (`terms_snapshot` is not null) and (`snapshot_schema_version` is not null) and (`request_expires_at` is not null)))),
    CONSTRAINT `ck_rental_case_booking_kind` CHECK ((`booking_id_kind` = _ascii'BOOKING')),
    CONSTRAINT `ck_rental_case_required` CHECK (((`record_type` <> _ascii'BOOKING_CASE') or ((`booking_id` is not null) and (`case_type` is not null) and (`description` is not null) and (`case_status` is not null)))),
    CONSTRAINT `ck_rental_history_required` CHECK (((`record_type` <> _ascii'BOOKING_HISTORY') or ((`booking_id` is not null) and (`to_status` is not null) and (`actor_type` is not null) and (`trace_id` is not null)))),
    CONSTRAINT `ck_rental_payment_required` CHECK (((`record_type` <> _ascii'PAYMENT') or ((`booking_id` is not null) and (`payer_id` is not null) and (`provider` is not null) and (`amount_vnd` is not null) and (`currency` is not null) and (`payment_status` is not null) and (`expires_at` is not null) and (`is_test` is not null)))),
    CONSTRAINT `ck_rental_refund_payment_kind` CHECK ((`refund_payment_id_kind` = _ascii'PAYMENT')),
    CONSTRAINT `ck_rental_refund_required` CHECK (((`record_type` <> _ascii'REFUND') or ((`refund_payment_id` is not null) and (`amount_vnd` is not null) and (`refund_status` is not null) and (`attempt_count` is not null)))),
    CONSTRAINT `ck_rental_kind` CHECK ((`record_type` in (_ascii'BOOKING',_ascii'BOOKING_CASE',_ascii'BOOKING_HISTORY',_ascii'VIEWING_SLOT',_ascii'VIEWING',_ascii'PAYMENT',_ascii'REFUND',_ascii'WEBHOOK_RECEIPT'))),
    CONSTRAINT `ck_rental_slot_required` CHECK (((`record_type` <> _ascii'VIEWING_SLOT') or ((`room_id` is not null) and (`host_id` is not null) and (`start_at` is not null) and (`end_at` is not null) and (`slot_status` is not null)))),
    CONSTRAINT `ck_rental_viewing_required` CHECK (((`record_type` <> _ascii'VIEWING') or ((`viewing_slot_id` is not null) and (`tenant_id` is not null) and (`room_id` is not null) and (`host_id` is not null) and (`viewing_status` is not null)))),
    CONSTRAINT `ck_rental_viewing_viewing_slot_kind` CHECK ((`viewing_slot_id_kind` = _ascii'VIEWING_SLOT')),
    CONSTRAINT `ck_rental_webhook_payment_kind` CHECK ((`webhook_payment_id_kind` = _ascii'PAYMENT')),
    CONSTRAINT `ck_rental_webhook_required` CHECK (((`record_type` <> _ascii'WEBHOOK_RECEIPT') or ((`event_provider` is not null) and (`event_id` is not null) and (`payload_hash` is not null) and (`processed_at` is not null))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Rentals: bookings, cases, history, viewings, sandbox payments, refunds and webhook receipts.';

INSERT INTO `rental_records_v20` (`id`,`record_type`,`version`,`actor_id`,`room_id`,`host_id`,`tenant_id`,`booking_id`,`listing_id`,`amount_vnd`,`note`,`actor_type`,`allocated_payment_id`,`attempt_count`,`booking_status`,`cancelled_at`,`cancelled_reason`,`case_decision`,`case_status`,`case_type`,`currency`,`deposit_vnd`,`description`,`desired_move_in`,`end_at`,`event_id`,`event_provider`,`expires_at`,`failure_code`,`from_status`,`handover_due_at`,`history_reason`,`hold_expires_at`,`host_handover_confirmed_at`,`host_retained_vnd`,`is_test`,`last_error_code`,`last_reason`,`next_attempt_at`,`occupant_count`,`opened_by`,`outcome`,`payer_id`,`payload_hash`,`payment_status`,`processed_at`,`provider`,`provider_payment_id`,`provider_refund_id`,`refund_payment_id`,`refund_reason`,`refund_status`,`rent_vnd`,`request_expires_at`,`resolution_note`,`resolved_at`,`resolved_by`,`slot_status`,`snapshot_schema_version`,`start_at`,`succeeded_at`,`tenant_handover_confirmed_at`,`tenant_refund_vnd`,`tenant_terms_accepted_at`,`terms_snapshot`,`to_status`,`trace_id`,`viewing_slot_id`,`viewing_status`,`webhook_payment_id`,`completed_at`,`created_at`,`updated_at`,`allocated_payment_id_kind`,`booking_id_kind`,`refund_payment_id_kind`,`viewing_slot_id_kind`,`webhook_payment_id_kind`)
SELECT
    s.`id` AS `id`,
    s.`record_type` AS `record_type`,
    s.`version` AS `version`,
    s.`history_actor_id` AS `actor_id`,
    CASE s.record_type WHEN 'BOOKING' THEN s.`booking_room_id` WHEN 'VIEWING_SLOT' THEN s.`slot_room_id` WHEN 'VIEWING' THEN s.`viewing_room_id` ELSE NULL END AS `room_id`,
    CASE s.record_type WHEN 'BOOKING' THEN s.`booking_host_id` WHEN 'VIEWING_SLOT' THEN s.`slot_host_id` WHEN 'VIEWING' THEN s.`viewing_host_id` ELSE NULL END AS `host_id`,
    CASE s.record_type WHEN 'BOOKING' THEN s.`booking_tenant_id` WHEN 'VIEWING' THEN s.`viewing_tenant_id` ELSE NULL END AS `tenant_id`,
    CASE s.record_type WHEN 'BOOKING_CASE' THEN s.`case_booking_id` WHEN 'BOOKING_HISTORY' THEN s.`history_booking_id` WHEN 'PAYMENT' THEN s.`payment_booking_id` ELSE NULL END AS `booking_id`,
    s.`booking_listing_id` AS `listing_id`,
    CASE s.record_type WHEN 'PAYMENT' THEN s.`payment_amount_vnd` WHEN 'REFUND' THEN s.`refund_amount_vnd` ELSE NULL END AS `amount_vnd`,
    CASE s.record_type WHEN 'BOOKING' THEN s.`booking_note` WHEN 'VIEWING' THEN s.`viewing_note` ELSE NULL END AS `note`,
    s.`history_actor_type` AS `actor_type`,
    s.`booking_allocated_payment_id` AS `allocated_payment_id`,
    s.`refund_attempt_count` AS `attempt_count`,
    s.`booking_status` AS `booking_status`,
    s.`booking_cancelled_at` AS `cancelled_at`,
    s.`viewing_cancelled_reason` AS `cancelled_reason`,
    s.`case_decision` AS `case_decision`,
    s.`case_status` AS `case_status`,
    s.`case_type` AS `case_type`,
    s.`payment_currency` AS `currency`,
    s.`booking_deposit_vnd` AS `deposit_vnd`,
    s.`case_description` AS `description`,
    s.`booking_desired_move_in` AS `desired_move_in`,
    s.`slot_end_at` AS `end_at`,
    s.`webhook_event_id` AS `event_id`,
    s.`webhook_provider` AS `event_provider`,
    s.`payment_expires_at` AS `expires_at`,
    s.`payment_failure_code` AS `failure_code`,
    s.`history_from_status` AS `from_status`,
    s.`booking_handover_due_at` AS `handover_due_at`,
    s.`history_reason` AS `history_reason`,
    s.`booking_hold_expires_at` AS `hold_expires_at`,
    s.`booking_host_handover_confirmed_at` AS `host_handover_confirmed_at`,
    s.`case_host_retained_vnd` AS `host_retained_vnd`,
    s.`payment_is_test` AS `is_test`,
    s.`refund_last_error_code` AS `last_error_code`,
    s.`booking_last_reason` AS `last_reason`,
    s.`refund_next_attempt_at` AS `next_attempt_at`,
    s.`booking_occupant_count` AS `occupant_count`,
    s.`case_opened_by` AS `opened_by`,
    s.`webhook_outcome` AS `outcome`,
    s.`payment_payer_id` AS `payer_id`,
    s.`webhook_payload_hash` AS `payload_hash`,
    s.`payment_status` AS `payment_status`,
    s.`webhook_processed_at` AS `processed_at`,
    s.`payment_provider` AS `provider`,
    s.`payment_provider_payment_id` AS `provider_payment_id`,
    s.`refund_provider_refund_id` AS `provider_refund_id`,
    s.`refund_payment_id` AS `refund_payment_id`,
    s.`refund_reason` AS `refund_reason`,
    s.`refund_status` AS `refund_status`,
    s.`booking_rent_vnd` AS `rent_vnd`,
    s.`booking_request_expires_at` AS `request_expires_at`,
    s.`case_resolution_note` AS `resolution_note`,
    s.`case_resolved_at` AS `resolved_at`,
    s.`case_resolved_by` AS `resolved_by`,
    s.`slot_status` AS `slot_status`,
    s.`booking_snapshot_schema_version` AS `snapshot_schema_version`,
    s.`slot_start_at` AS `start_at`,
    s.`payment_succeeded_at` AS `succeeded_at`,
    s.`booking_tenant_handover_confirmed_at` AS `tenant_handover_confirmed_at`,
    s.`case_tenant_refund_vnd` AS `tenant_refund_vnd`,
    s.`booking_tenant_terms_accepted_at` AS `tenant_terms_accepted_at`,
    s.`booking_terms_snapshot` AS `terms_snapshot`,
    s.`history_to_status` AS `to_status`,
    s.`history_trace_id` AS `trace_id`,
    s.`viewing_viewing_slot_id` AS `viewing_slot_id`,
    s.`viewing_status` AS `viewing_status`,
    s.`webhook_payment_id` AS `webhook_payment_id`,
    CASE s.record_type WHEN 'BOOKING' THEN s.`booking_completed_at` WHEN 'VIEWING' THEN s.`viewing_completed_at` WHEN 'REFUND' THEN s.`refund_completed_at` ELSE NULL END AS `completed_at`,
    CASE s.record_type WHEN 'BOOKING' THEN s.`booking_created_at` WHEN 'BOOKING_CASE' THEN s.`case_created_at` WHEN 'BOOKING_HISTORY' THEN s.`history_created_at` WHEN 'VIEWING_SLOT' THEN s.`slot_created_at` WHEN 'VIEWING' THEN s.`viewing_created_at` WHEN 'PAYMENT' THEN s.`payment_created_at` WHEN 'REFUND' THEN s.`refund_created_at` WHEN 'WEBHOOK_RECEIPT' THEN s.`webhook_created_at` ELSE NULL END AS `created_at`,
    CASE s.record_type WHEN 'BOOKING' THEN s.`booking_updated_at` WHEN 'BOOKING_CASE' THEN s.`case_updated_at` WHEN 'VIEWING_SLOT' THEN s.`slot_updated_at` WHEN 'VIEWING' THEN s.`viewing_updated_at` WHEN 'PAYMENT' THEN s.`payment_updated_at` WHEN 'REFUND' THEN s.`refund_updated_at` ELSE NULL END AS `updated_at`,
    s.`booking_allocated_payment_id_kind` AS `allocated_payment_id_kind`,
    'BOOKING' AS `booking_id_kind`,
    s.`refund_payment_id_kind` AS `refund_payment_id_kind`,
    s.`viewing_viewing_slot_id_kind` AS `viewing_slot_id_kind`,
    s.`webhook_payment_id_kind` AS `webhook_payment_id_kind`
FROM `rental_records` s;

SET @schema20_identity = (SELECT AUTO_INCREMENT FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='rental_records');
SET @schema20_ddl = CONCAT('ALTER TABLE rental_records_v20 AUTO_INCREMENT=', COALESCE(@schema20_identity,1));
PREPARE schema20_statement FROM @schema20_ddl;
EXECUTE schema20_statement;
DEALLOCATE PREPARE schema20_statement;

CREATE TABLE `activity_records_v20` (
    `id` BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `record_type` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    `version` int NOT NULL DEFAULT '0',
    `user_id` bigint NULL,
    `actor_id` bigint NULL,
    `room_id` bigint NULL,
    `booking_id` bigint NULL,
    `target_id` bigint NULL,
    `target_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `action` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `actor_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `attempts` int NULL DEFAULT '0',
    `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `delivery_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING',
    `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `detail` json NULL,
    `device_id` bigint NULL,
    `expires_at` datetime(3) NULL,
    `hide_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `idempotency_key` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `is_read` tinyint(1) NULL DEFAULT '0',
    `last_error` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `next_attempt_at` datetime(3) NULL,
    `notification_id` bigint NULL,
    `notification_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `rating` int NULL,
    `reason_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `ref_id` bigint NULL,
    `ref_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `report_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING',
    `request_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `request_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PROCESSING',
    `resolution_note` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `resolved_at` datetime(3) NULL,
    `resolved_by` bigint NULL,
    `response_body` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `response_content_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `response_location` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `response_status_code` int NULL,
    `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `trace_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
    `visible` tinyint(1) NULL DEFAULT '1',
    `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `device_id_kind` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'DEVICE_TOKEN',
    `notification_id_kind` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'NOTIFICATION',
    KEY `ix_activity_actor_id` (`actor_id`),
    KEY `ix_activity_device_id_device_id_kind` (`device_id`,`device_id_kind`),
    KEY `ix_activity_notification_id_notification_id_kind` (`notification_id`,`notification_id_kind`),
    KEY `ix_activity_user_id` (`user_id`),
    KEY `ix_activity_resolved_by` (`resolved_by`),
    KEY `ix_activity_room_id` (`room_id`),
    KEY `ix_activity_kind_user_id_is_read_created_at` (`record_type`,`user_id`,`is_read`,`created_at`),
    KEY `ix_activity_kind_expires_at` (`record_type`,`expires_at`),
    KEY `ix_activity_kind_room_id_visible_created_at` (`record_type`,`room_id`,`visible`,`created_at`),
    KEY `ix_activity_kind_resolved_by` (`record_type`,`resolved_by`),
    KEY `ix_activity_kind_report_status` (`record_type`,`report_status`),
    KEY `ix_activity_kind_device_id` (`record_type`,`device_id`),
    KEY `ix_activity_kind_delivery_status_created_at_id` (`record_type`,`delivery_status`,`created_at`,`id`),
    KEY `ix_activity_kind_delivery_status_next_attempt_at` (`record_type`,`delivery_status`,`next_attempt_at`),
    KEY `ix_activity_kind_actor_id_created_at` (`record_type`,`actor_id`,`created_at`),
    KEY `ix_activity_kind_target_type_target_id_created_at` (`record_type`,`target_type`,`target_id`,`created_at`),
    KEY `ix_activity_kind_request_status_expires_at_id` (`record_type`,`request_status`,`expires_at`,`id`),
    UNIQUE KEY `uk_activity_kind_booking_id` (`record_type`,`booking_id`),
    UNIQUE KEY `uk_activity_kind_notification_id_device_id` (`record_type`,`notification_id`,`device_id`),
    UNIQUE KEY `uk_activity_kind_idempotency_key` (`record_type`,`idempotency_key`),
    UNIQUE KEY `uk_activity_id_kind` (`id`,`record_type`),
    CONSTRAINT `ck_activity_kind` CHECK ((`record_type` in (_ascii'NOTIFICATION',_ascii'PUSH_DELIVERY',_ascii'AUDIT_LOG',_ascii'IDEMPOTENCY',_ascii'REVIEW',_ascii'REPORT'))),
    CONSTRAINT `ck_activity_audit_required` CHECK (((`record_type` <> _ascii'AUDIT_LOG') or ((`actor_type` is not null) and (`action` is not null) and (`target_type` is not null) and (`target_id` is not null)))),
    CONSTRAINT `ck_activity_delivery_device_kind` CHECK ((`device_id_kind` = _ascii'DEVICE_TOKEN')),
    CONSTRAINT `ck_activity_delivery_notification_kind` CHECK ((`notification_id_kind` = _ascii'NOTIFICATION')),
    CONSTRAINT `ck_activity_delivery_required` CHECK (((`record_type` <> _ascii'PUSH_DELIVERY') or ((`notification_id` is not null) and (`device_id` is not null) and (`delivery_status` is not null) and (`attempts` is not null) and (`next_attempt_at` is not null) and (`created_at` is not null)))),
    CONSTRAINT `ck_activity_notification_required` CHECK (((`record_type` <> _ascii'NOTIFICATION') or ((`user_id` is not null) and (`notification_type` is not null) and (`title` is not null) and (`is_read` is not null)))),
    CONSTRAINT `ck_activity_report_required` CHECK (((`record_type` <> _ascii'REPORT') or ((`actor_id` is not null) and (`target_type` is not null) and (`target_id` is not null) and (`reason_code` is not null) and (`report_status` is not null)))),
    CONSTRAINT `ck_activity_request_required` CHECK (((`record_type` <> _ascii'IDEMPOTENCY') or ((`idempotency_key` is not null) and (`request_status` is not null) and (`expires_at` is not null)))),
    CONSTRAINT `ck_activity_review_required` CHECK (((`record_type` <> _ascii'REVIEW') or ((`booking_id` is not null) and (`actor_id` is not null) and (`room_id` is not null) and (`rating` is not null) and (`visible` is not null))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Activity: inbox, push delivery, audit, request replay, reviews and reports.';

INSERT INTO `activity_records_v20` (`id`,`record_type`,`version`,`user_id`,`actor_id`,`room_id`,`booking_id`,`target_id`,`target_type`,`action`,`actor_type`,`attempts`,`body`,`comment`,`delivery_status`,`description`,`detail`,`device_id`,`expires_at`,`hide_reason`,`idempotency_key`,`ip_address`,`is_read`,`last_error`,`next_attempt_at`,`notification_id`,`notification_type`,`rating`,`reason_code`,`ref_id`,`ref_type`,`report_status`,`request_hash`,`request_status`,`resolution_note`,`resolved_at`,`resolved_by`,`response_body`,`response_content_type`,`response_location`,`response_status_code`,`title`,`trace_id`,`visible`,`created_at`,`updated_at`,`device_id_kind`,`notification_id_kind`)
SELECT
    s.`id` AS `id`,
    s.`record_type` AS `record_type`,
    s.`version` AS `version`,
    s.`notification_user_id` AS `user_id`,
    CASE s.record_type WHEN 'AUDIT_LOG' THEN s.`audit_actor_id` WHEN 'REVIEW' THEN s.`review_reviewer_id` WHEN 'REPORT' THEN s.`report_reporter_id` ELSE NULL END AS `actor_id`,
    s.`review_room_id` AS `room_id`,
    s.`review_booking_id` AS `booking_id`,
    CASE s.record_type WHEN 'AUDIT_LOG' THEN s.`audit_target_id` WHEN 'REPORT' THEN s.`report_target_id` ELSE NULL END AS `target_id`,
    CASE s.record_type WHEN 'AUDIT_LOG' THEN s.`audit_target_type` WHEN 'REPORT' THEN s.`report_target_type` ELSE NULL END AS `target_type`,
    s.`audit_action` AS `action`,
    s.`audit_actor_type` AS `actor_type`,
    s.`delivery_attempts` AS `attempts`,
    s.`notification_body` AS `body`,
    s.`review_comment` AS `comment`,
    s.`delivery_status` AS `delivery_status`,
    s.`report_description` AS `description`,
    s.`audit_detail` AS `detail`,
    s.`delivery_device_id` AS `device_id`,
    s.`request_expires_at` AS `expires_at`,
    s.`review_hide_reason` AS `hide_reason`,
    s.`request_idempotency_key` AS `idempotency_key`,
    s.`audit_ip_address` AS `ip_address`,
    s.`notification_is_read` AS `is_read`,
    s.`delivery_last_error` AS `last_error`,
    s.`delivery_next_attempt_at` AS `next_attempt_at`,
    s.`delivery_notification_id` AS `notification_id`,
    s.`notification_type` AS `notification_type`,
    s.`review_rating` AS `rating`,
    s.`report_reason_code` AS `reason_code`,
    s.`notification_ref_id` AS `ref_id`,
    s.`notification_ref_type` AS `ref_type`,
    s.`report_status` AS `report_status`,
    s.`request_request_hash` AS `request_hash`,
    s.`request_status` AS `request_status`,
    s.`report_resolution_note` AS `resolution_note`,
    s.`report_resolved_at` AS `resolved_at`,
    s.`report_resolved_by` AS `resolved_by`,
    s.`request_response_body` AS `response_body`,
    s.`request_response_content_type` AS `response_content_type`,
    s.`request_response_location` AS `response_location`,
    s.`request_response_status_code` AS `response_status_code`,
    s.`notification_title` AS `title`,
    s.`audit_trace_id` AS `trace_id`,
    s.`review_visible` AS `visible`,
    CASE s.record_type WHEN 'NOTIFICATION' THEN s.`notification_created_at` WHEN 'PUSH_DELIVERY' THEN s.`delivery_created_at` WHEN 'AUDIT_LOG' THEN s.`audit_created_at` WHEN 'IDEMPOTENCY' THEN s.`request_created_at` WHEN 'REVIEW' THEN s.`review_created_at` WHEN 'REPORT' THEN s.`report_created_at` ELSE NULL END AS `created_at`,
    CASE s.record_type WHEN 'REVIEW' THEN s.`review_updated_at` WHEN 'REPORT' THEN s.`report_updated_at` ELSE NULL END AS `updated_at`,
    s.`delivery_device_id_kind` AS `device_id_kind`,
    s.`delivery_notification_id_kind` AS `notification_id_kind`
FROM `activity_records` s;

SET @schema20_identity = (SELECT AUTO_INCREMENT FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='activity_records');
SET @schema20_ddl = CONCAT('ALTER TABLE activity_records_v20 AUTO_INCREMENT=', COALESCE(@schema20_identity,1));
PREPARE schema20_statement FROM @schema20_ddl;
EXECUTE schema20_statement;
DEALLOCATE PREPARE schema20_statement;

-- Fail before replacing any original table if any meaningful value differs.
CREATE TEMPORARY TABLE schema20_copy_guard (ok INT PRIMARY KEY);
INSERT INTO schema20_copy_guard VALUES (1);
INSERT INTO schema20_copy_guard SELECT 1 WHERE (SELECT COUNT(*) FROM `account_records`) <> (SELECT COUNT(*) FROM `account_records_v20`) OR EXISTS (SELECT 1 FROM `account_records` s LEFT JOIN `account_records_v20` n ON n.id=s.id WHERE n.id IS NULL OR
    NOT (n.`id` <=> s.`id`) OR
    NOT (n.`record_type` <=> s.`record_type`) OR
    NOT (n.`version` <=> s.`version`) OR
    NOT (n.`user_id` <=> CASE s.record_type WHEN 'REFRESH_TOKEN' THEN s.`refresh_user_id` WHEN 'ONE_TIME_TOKEN' THEN s.`verify_user_id` ELSE NULL END) OR
    NOT (n.`device_name` <=> CASE s.record_type WHEN 'REFRESH_TOKEN' THEN s.`refresh_device_name` WHEN 'DEVICE_TOKEN' THEN s.`device_device_name` ELSE NULL END) OR
    NOT (n.`expires_at` <=> CASE s.record_type WHEN 'REFRESH_TOKEN' THEN s.`refresh_expires_at` WHEN 'ONE_TIME_TOKEN' THEN s.`verify_expires_at` ELSE NULL END) OR
    NOT (n.`installation_id` <=> CASE s.record_type WHEN 'REFRESH_TOKEN' THEN s.`refresh_installation_id` WHEN 'DEVICE_TOKEN' THEN s.`device_installation_id` ELSE NULL END) OR
    NOT (n.`token_hash` <=> CASE s.record_type WHEN 'REFRESH_TOKEN' THEN s.`refresh_token_hash` WHEN 'ONE_TIME_TOKEN' THEN s.`verify_token_hash` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PREFERENCES' THEN n.`chat_push` ELSE NULL END <=> CASE WHEN s.record_type='PREFERENCES' THEN s.`preference_chat_push` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='DELETION_REQUEST' THEN n.`deletion_completed_at` ELSE NULL END <=> CASE WHEN s.record_type='DELETION_REQUEST' THEN s.`deletion_completed_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='DELETION_REQUEST' THEN n.`deletion_failure_code` ELSE NULL END <=> CASE WHEN s.record_type='DELETION_REQUEST' THEN s.`deletion_failure_code` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='DELETION_REQUEST' THEN n.`deletion_reason` ELSE NULL END <=> CASE WHEN s.record_type='DELETION_REQUEST' THEN s.`deletion_reason` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='DELETION_REQUEST' THEN n.`deletion_status` ELSE NULL END <=> CASE WHEN s.record_type='DELETION_REQUEST' THEN s.`deletion_status` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='DELETION_REQUEST' THEN n.`deletion_user_id` ELSE NULL END <=> CASE WHEN s.record_type='DELETION_REQUEST' THEN s.`deletion_user_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='DEVICE_TOKEN' THEN n.`device_active` ELSE NULL END <=> CASE WHEN s.record_type='DEVICE_TOKEN' THEN s.`device_active` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='DEVICE_TOKEN' THEN n.`device_user_id` ELSE NULL END <=> CASE WHEN s.record_type='DEVICE_TOKEN' THEN s.`device_user_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='DEVICE_TOKEN' THEN n.`fcm_token` ELSE NULL END <=> CASE WHEN s.record_type='DEVICE_TOKEN' THEN s.`device_token` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='LIFECYCLE_LOCK' THEN n.`lifecycle_user_id` ELSE NULL END <=> CASE WHEN s.record_type='LIFECYCLE_LOCK' THEN s.`lifecycle_user_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='DEVICE_TOKEN' THEN n.`platform` ELSE NULL END <=> CASE WHEN s.record_type='DEVICE_TOKEN' THEN s.`device_platform` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PREFERENCES' THEN n.`preference_user_id` ELSE NULL END <=> CASE WHEN s.record_type='PREFERENCES' THEN s.`preference_user_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PREFERENCES' THEN n.`recommendation_push` ELSE NULL END <=> CASE WHEN s.record_type='PREFERENCES' THEN s.`preference_recommendation_push` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REFRESH_TOKEN' THEN n.`revoked` ELSE NULL END <=> CASE WHEN s.record_type='REFRESH_TOKEN' THEN s.`refresh_revoked` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='ROLE' THEN n.`role_name` ELSE NULL END <=> CASE WHEN s.record_type='ROLE' THEN s.`role_name` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='ONE_TIME_TOKEN' THEN n.`token_purpose` ELSE NULL END <=> CASE WHEN s.record_type='ONE_TIME_TOKEN' THEN s.`verify_purpose` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PREFERENCES' THEN n.`transaction_email` ELSE NULL END <=> CASE WHEN s.record_type='PREFERENCES' THEN s.`preference_transaction_email` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PREFERENCES' THEN n.`transaction_push` ELSE NULL END <=> CASE WHEN s.record_type='PREFERENCES' THEN s.`preference_transaction_push` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='ONE_TIME_TOKEN' THEN n.`used` ELSE NULL END <=> CASE WHEN s.record_type='ONE_TIME_TOKEN' THEN s.`verify_used` ELSE NULL END) OR
    NOT (n.`created_at` <=> CASE s.record_type WHEN 'REFRESH_TOKEN' THEN s.`refresh_created_at` WHEN 'ONE_TIME_TOKEN' THEN s.`verify_created_at` WHEN 'DEVICE_TOKEN' THEN s.`device_created_at` WHEN 'PREFERENCES' THEN s.`preference_created_at` WHEN 'DELETION_REQUEST' THEN s.`deletion_created_at` ELSE NULL END) OR
    NOT (n.`updated_at` <=> CASE s.record_type WHEN 'DEVICE_TOKEN' THEN s.`device_updated_at` WHEN 'PREFERENCES' THEN s.`preference_updated_at` WHEN 'DELETION_REQUEST' THEN s.`deletion_updated_at` ELSE NULL END));
INSERT INTO schema20_copy_guard SELECT 1 WHERE (SELECT COUNT(*) FROM `catalog_items`) <> (SELECT COUNT(*) FROM `catalog_items_v20`) OR EXISTS (SELECT 1 FROM `catalog_items` s LEFT JOIN `catalog_items_v20` n ON n.id=s.id WHERE n.id IS NULL OR
    NOT (n.`id` <=> s.`id`) OR
    NOT (n.`record_type` <=> s.`record_type`) OR
    NOT (CASE WHEN n.record_type='WISHLIST_ITEM' THEN n.`user_id` ELSE NULL END <=> CASE WHEN s.record_type='WISHLIST_ITEM' THEN s.`wishlist_user_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='WISHLIST_ITEM' THEN n.`room_id` ELSE NULL END <=> CASE WHEN s.record_type='WISHLIST_ITEM' THEN s.`wishlist_room_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='LISTING_FEE' THEN n.`listing_id` ELSE NULL END <=> CASE WHEN s.record_type='LISTING_FEE' THEN s.`fee_listing_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='LISTING_FEE' THEN n.`amount_vnd` ELSE NULL END <=> CASE WHEN s.record_type='LISTING_FEE' THEN s.`fee_amount_vnd` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='AMENITY' THEN n.`category` ELSE NULL END <=> CASE WHEN s.record_type='AMENITY' THEN s.`amenity_category` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='LISTING_FEE' THEN n.`fee_code` ELSE NULL END <=> CASE WHEN s.record_type='LISTING_FEE' THEN s.`fee_fee_code` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='LISTING_FEE' THEN n.`fee_mode` ELSE NULL END <=> CASE WHEN s.record_type='LISTING_FEE' THEN s.`fee_fee_mode` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='AMENITY' THEN n.`icon` ELSE NULL END <=> CASE WHEN s.record_type='AMENITY' THEN s.`amenity_icon` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='AMENITY' THEN n.`name` ELSE NULL END <=> CASE WHEN s.record_type='AMENITY' THEN s.`amenity_name` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='LISTING_FEE' THEN n.`note` ELSE NULL END <=> CASE WHEN s.record_type='LISTING_FEE' THEN s.`fee_note` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='LISTING_FEE' THEN n.`sort_order` ELSE NULL END <=> CASE WHEN s.record_type='LISTING_FEE' THEN s.`fee_sort_order` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='LISTING_FEE' THEN n.`unit_name` ELSE NULL END <=> CASE WHEN s.record_type='LISTING_FEE' THEN s.`fee_unit_name` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='WISHLIST_ITEM' THEN n.`created_at` ELSE NULL END <=> CASE WHEN s.record_type='WISHLIST_ITEM' THEN s.`wishlist_created_at` ELSE NULL END));
INSERT INTO schema20_copy_guard SELECT 1 WHERE (SELECT COUNT(*) FROM `rental_records`) <> (SELECT COUNT(*) FROM `rental_records_v20`) OR EXISTS (SELECT 1 FROM `rental_records` s LEFT JOIN `rental_records_v20` n ON n.id=s.id WHERE n.id IS NULL OR
    NOT (n.`id` <=> s.`id`) OR
    NOT (n.`record_type` <=> s.`record_type`) OR
    NOT (n.`version` <=> s.`version`) OR
    NOT (CASE WHEN n.record_type='BOOKING_HISTORY' THEN n.`actor_id` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_HISTORY' THEN s.`history_actor_id` ELSE NULL END) OR
    NOT (n.`room_id` <=> CASE s.record_type WHEN 'BOOKING' THEN s.`booking_room_id` WHEN 'VIEWING_SLOT' THEN s.`slot_room_id` WHEN 'VIEWING' THEN s.`viewing_room_id` ELSE NULL END) OR
    NOT (n.`host_id` <=> CASE s.record_type WHEN 'BOOKING' THEN s.`booking_host_id` WHEN 'VIEWING_SLOT' THEN s.`slot_host_id` WHEN 'VIEWING' THEN s.`viewing_host_id` ELSE NULL END) OR
    NOT (n.`tenant_id` <=> CASE s.record_type WHEN 'BOOKING' THEN s.`booking_tenant_id` WHEN 'VIEWING' THEN s.`viewing_tenant_id` ELSE NULL END) OR
    NOT (n.`booking_id` <=> CASE s.record_type WHEN 'BOOKING_CASE' THEN s.`case_booking_id` WHEN 'BOOKING_HISTORY' THEN s.`history_booking_id` WHEN 'PAYMENT' THEN s.`payment_booking_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`listing_id` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_listing_id` ELSE NULL END) OR
    NOT (n.`amount_vnd` <=> CASE s.record_type WHEN 'PAYMENT' THEN s.`payment_amount_vnd` WHEN 'REFUND' THEN s.`refund_amount_vnd` ELSE NULL END) OR
    NOT (n.`note` <=> CASE s.record_type WHEN 'BOOKING' THEN s.`booking_note` WHEN 'VIEWING' THEN s.`viewing_note` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_HISTORY' THEN n.`actor_type` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_HISTORY' THEN s.`history_actor_type` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`allocated_payment_id` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_allocated_payment_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REFUND' THEN n.`attempt_count` ELSE NULL END <=> CASE WHEN s.record_type='REFUND' THEN s.`refund_attempt_count` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`booking_status` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_status` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`cancelled_at` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_cancelled_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='VIEWING' THEN n.`cancelled_reason` ELSE NULL END <=> CASE WHEN s.record_type='VIEWING' THEN s.`viewing_cancelled_reason` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_CASE' THEN n.`case_decision` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_CASE' THEN s.`case_decision` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_CASE' THEN n.`case_status` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_CASE' THEN s.`case_status` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_CASE' THEN n.`case_type` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_CASE' THEN s.`case_type` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PAYMENT' THEN n.`currency` ELSE NULL END <=> CASE WHEN s.record_type='PAYMENT' THEN s.`payment_currency` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`deposit_vnd` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_deposit_vnd` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_CASE' THEN n.`description` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_CASE' THEN s.`case_description` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`desired_move_in` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_desired_move_in` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='VIEWING_SLOT' THEN n.`end_at` ELSE NULL END <=> CASE WHEN s.record_type='VIEWING_SLOT' THEN s.`slot_end_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='WEBHOOK_RECEIPT' THEN n.`event_id` ELSE NULL END <=> CASE WHEN s.record_type='WEBHOOK_RECEIPT' THEN s.`webhook_event_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='WEBHOOK_RECEIPT' THEN n.`event_provider` ELSE NULL END <=> CASE WHEN s.record_type='WEBHOOK_RECEIPT' THEN s.`webhook_provider` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PAYMENT' THEN n.`expires_at` ELSE NULL END <=> CASE WHEN s.record_type='PAYMENT' THEN s.`payment_expires_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PAYMENT' THEN n.`failure_code` ELSE NULL END <=> CASE WHEN s.record_type='PAYMENT' THEN s.`payment_failure_code` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_HISTORY' THEN n.`from_status` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_HISTORY' THEN s.`history_from_status` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`handover_due_at` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_handover_due_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_HISTORY' THEN n.`history_reason` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_HISTORY' THEN s.`history_reason` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`hold_expires_at` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_hold_expires_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`host_handover_confirmed_at` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_host_handover_confirmed_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_CASE' THEN n.`host_retained_vnd` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_CASE' THEN s.`case_host_retained_vnd` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PAYMENT' THEN n.`is_test` ELSE NULL END <=> CASE WHEN s.record_type='PAYMENT' THEN s.`payment_is_test` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REFUND' THEN n.`last_error_code` ELSE NULL END <=> CASE WHEN s.record_type='REFUND' THEN s.`refund_last_error_code` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`last_reason` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_last_reason` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REFUND' THEN n.`next_attempt_at` ELSE NULL END <=> CASE WHEN s.record_type='REFUND' THEN s.`refund_next_attempt_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`occupant_count` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_occupant_count` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_CASE' THEN n.`opened_by` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_CASE' THEN s.`case_opened_by` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='WEBHOOK_RECEIPT' THEN n.`outcome` ELSE NULL END <=> CASE WHEN s.record_type='WEBHOOK_RECEIPT' THEN s.`webhook_outcome` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PAYMENT' THEN n.`payer_id` ELSE NULL END <=> CASE WHEN s.record_type='PAYMENT' THEN s.`payment_payer_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='WEBHOOK_RECEIPT' THEN n.`payload_hash` ELSE NULL END <=> CASE WHEN s.record_type='WEBHOOK_RECEIPT' THEN s.`webhook_payload_hash` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PAYMENT' THEN n.`payment_status` ELSE NULL END <=> CASE WHEN s.record_type='PAYMENT' THEN s.`payment_status` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='WEBHOOK_RECEIPT' THEN n.`processed_at` ELSE NULL END <=> CASE WHEN s.record_type='WEBHOOK_RECEIPT' THEN s.`webhook_processed_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PAYMENT' THEN n.`provider` ELSE NULL END <=> CASE WHEN s.record_type='PAYMENT' THEN s.`payment_provider` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PAYMENT' THEN n.`provider_payment_id` ELSE NULL END <=> CASE WHEN s.record_type='PAYMENT' THEN s.`payment_provider_payment_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REFUND' THEN n.`provider_refund_id` ELSE NULL END <=> CASE WHEN s.record_type='REFUND' THEN s.`refund_provider_refund_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REFUND' THEN n.`refund_payment_id` ELSE NULL END <=> CASE WHEN s.record_type='REFUND' THEN s.`refund_payment_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REFUND' THEN n.`refund_reason` ELSE NULL END <=> CASE WHEN s.record_type='REFUND' THEN s.`refund_reason` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REFUND' THEN n.`refund_status` ELSE NULL END <=> CASE WHEN s.record_type='REFUND' THEN s.`refund_status` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`rent_vnd` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_rent_vnd` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`request_expires_at` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_request_expires_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_CASE' THEN n.`resolution_note` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_CASE' THEN s.`case_resolution_note` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_CASE' THEN n.`resolved_at` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_CASE' THEN s.`case_resolved_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_CASE' THEN n.`resolved_by` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_CASE' THEN s.`case_resolved_by` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='VIEWING_SLOT' THEN n.`slot_status` ELSE NULL END <=> CASE WHEN s.record_type='VIEWING_SLOT' THEN s.`slot_status` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`snapshot_schema_version` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_snapshot_schema_version` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='VIEWING_SLOT' THEN n.`start_at` ELSE NULL END <=> CASE WHEN s.record_type='VIEWING_SLOT' THEN s.`slot_start_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PAYMENT' THEN n.`succeeded_at` ELSE NULL END <=> CASE WHEN s.record_type='PAYMENT' THEN s.`payment_succeeded_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`tenant_handover_confirmed_at` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_tenant_handover_confirmed_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_CASE' THEN n.`tenant_refund_vnd` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_CASE' THEN s.`case_tenant_refund_vnd` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`tenant_terms_accepted_at` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_tenant_terms_accepted_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`terms_snapshot` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_terms_snapshot` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_HISTORY' THEN n.`to_status` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_HISTORY' THEN s.`history_to_status` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING_HISTORY' THEN n.`trace_id` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING_HISTORY' THEN s.`history_trace_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='VIEWING' THEN n.`viewing_slot_id` ELSE NULL END <=> CASE WHEN s.record_type='VIEWING' THEN s.`viewing_viewing_slot_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='VIEWING' THEN n.`viewing_status` ELSE NULL END <=> CASE WHEN s.record_type='VIEWING' THEN s.`viewing_status` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='WEBHOOK_RECEIPT' THEN n.`webhook_payment_id` ELSE NULL END <=> CASE WHEN s.record_type='WEBHOOK_RECEIPT' THEN s.`webhook_payment_id` ELSE NULL END) OR
    NOT (n.`completed_at` <=> CASE s.record_type WHEN 'BOOKING' THEN s.`booking_completed_at` WHEN 'VIEWING' THEN s.`viewing_completed_at` WHEN 'REFUND' THEN s.`refund_completed_at` ELSE NULL END) OR
    NOT (n.`created_at` <=> CASE s.record_type WHEN 'BOOKING' THEN s.`booking_created_at` WHEN 'BOOKING_CASE' THEN s.`case_created_at` WHEN 'BOOKING_HISTORY' THEN s.`history_created_at` WHEN 'VIEWING_SLOT' THEN s.`slot_created_at` WHEN 'VIEWING' THEN s.`viewing_created_at` WHEN 'PAYMENT' THEN s.`payment_created_at` WHEN 'REFUND' THEN s.`refund_created_at` WHEN 'WEBHOOK_RECEIPT' THEN s.`webhook_created_at` ELSE NULL END) OR
    NOT (n.`updated_at` <=> CASE s.record_type WHEN 'BOOKING' THEN s.`booking_updated_at` WHEN 'BOOKING_CASE' THEN s.`case_updated_at` WHEN 'VIEWING_SLOT' THEN s.`slot_updated_at` WHEN 'VIEWING' THEN s.`viewing_updated_at` WHEN 'PAYMENT' THEN s.`payment_updated_at` WHEN 'REFUND' THEN s.`refund_updated_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='BOOKING' THEN n.`allocated_payment_id_kind` ELSE NULL END <=> CASE WHEN s.record_type='BOOKING' THEN s.`booking_allocated_payment_id_kind` ELSE NULL END) OR
    NOT (n.`booking_id_kind` <=> 'BOOKING') OR
    NOT (CASE WHEN n.record_type='REFUND' THEN n.`refund_payment_id_kind` ELSE NULL END <=> CASE WHEN s.record_type='REFUND' THEN s.`refund_payment_id_kind` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='VIEWING' THEN n.`viewing_slot_id_kind` ELSE NULL END <=> CASE WHEN s.record_type='VIEWING' THEN s.`viewing_viewing_slot_id_kind` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='WEBHOOK_RECEIPT' THEN n.`webhook_payment_id_kind` ELSE NULL END <=> CASE WHEN s.record_type='WEBHOOK_RECEIPT' THEN s.`webhook_payment_id_kind` ELSE NULL END));
INSERT INTO schema20_copy_guard SELECT 1 WHERE (SELECT COUNT(*) FROM `activity_records`) <> (SELECT COUNT(*) FROM `activity_records_v20`) OR EXISTS (SELECT 1 FROM `activity_records` s LEFT JOIN `activity_records_v20` n ON n.id=s.id WHERE n.id IS NULL OR
    NOT (n.`id` <=> s.`id`) OR
    NOT (n.`record_type` <=> s.`record_type`) OR
    NOT (n.`version` <=> s.`version`) OR
    NOT (CASE WHEN n.record_type='NOTIFICATION' THEN n.`user_id` ELSE NULL END <=> CASE WHEN s.record_type='NOTIFICATION' THEN s.`notification_user_id` ELSE NULL END) OR
    NOT (n.`actor_id` <=> CASE s.record_type WHEN 'AUDIT_LOG' THEN s.`audit_actor_id` WHEN 'REVIEW' THEN s.`review_reviewer_id` WHEN 'REPORT' THEN s.`report_reporter_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REVIEW' THEN n.`room_id` ELSE NULL END <=> CASE WHEN s.record_type='REVIEW' THEN s.`review_room_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REVIEW' THEN n.`booking_id` ELSE NULL END <=> CASE WHEN s.record_type='REVIEW' THEN s.`review_booking_id` ELSE NULL END) OR
    NOT (n.`target_id` <=> CASE s.record_type WHEN 'AUDIT_LOG' THEN s.`audit_target_id` WHEN 'REPORT' THEN s.`report_target_id` ELSE NULL END) OR
    NOT (n.`target_type` <=> CASE s.record_type WHEN 'AUDIT_LOG' THEN s.`audit_target_type` WHEN 'REPORT' THEN s.`report_target_type` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='AUDIT_LOG' THEN n.`action` ELSE NULL END <=> CASE WHEN s.record_type='AUDIT_LOG' THEN s.`audit_action` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='AUDIT_LOG' THEN n.`actor_type` ELSE NULL END <=> CASE WHEN s.record_type='AUDIT_LOG' THEN s.`audit_actor_type` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PUSH_DELIVERY' THEN n.`attempts` ELSE NULL END <=> CASE WHEN s.record_type='PUSH_DELIVERY' THEN s.`delivery_attempts` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='NOTIFICATION' THEN n.`body` ELSE NULL END <=> CASE WHEN s.record_type='NOTIFICATION' THEN s.`notification_body` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REVIEW' THEN n.`comment` ELSE NULL END <=> CASE WHEN s.record_type='REVIEW' THEN s.`review_comment` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PUSH_DELIVERY' THEN n.`delivery_status` ELSE NULL END <=> CASE WHEN s.record_type='PUSH_DELIVERY' THEN s.`delivery_status` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REPORT' THEN n.`description` ELSE NULL END <=> CASE WHEN s.record_type='REPORT' THEN s.`report_description` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='AUDIT_LOG' THEN n.`detail` ELSE NULL END <=> CASE WHEN s.record_type='AUDIT_LOG' THEN s.`audit_detail` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PUSH_DELIVERY' THEN n.`device_id` ELSE NULL END <=> CASE WHEN s.record_type='PUSH_DELIVERY' THEN s.`delivery_device_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='IDEMPOTENCY' THEN n.`expires_at` ELSE NULL END <=> CASE WHEN s.record_type='IDEMPOTENCY' THEN s.`request_expires_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REVIEW' THEN n.`hide_reason` ELSE NULL END <=> CASE WHEN s.record_type='REVIEW' THEN s.`review_hide_reason` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='IDEMPOTENCY' THEN n.`idempotency_key` ELSE NULL END <=> CASE WHEN s.record_type='IDEMPOTENCY' THEN s.`request_idempotency_key` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='AUDIT_LOG' THEN n.`ip_address` ELSE NULL END <=> CASE WHEN s.record_type='AUDIT_LOG' THEN s.`audit_ip_address` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='NOTIFICATION' THEN n.`is_read` ELSE NULL END <=> CASE WHEN s.record_type='NOTIFICATION' THEN s.`notification_is_read` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PUSH_DELIVERY' THEN n.`last_error` ELSE NULL END <=> CASE WHEN s.record_type='PUSH_DELIVERY' THEN s.`delivery_last_error` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PUSH_DELIVERY' THEN n.`next_attempt_at` ELSE NULL END <=> CASE WHEN s.record_type='PUSH_DELIVERY' THEN s.`delivery_next_attempt_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PUSH_DELIVERY' THEN n.`notification_id` ELSE NULL END <=> CASE WHEN s.record_type='PUSH_DELIVERY' THEN s.`delivery_notification_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='NOTIFICATION' THEN n.`notification_type` ELSE NULL END <=> CASE WHEN s.record_type='NOTIFICATION' THEN s.`notification_type` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REVIEW' THEN n.`rating` ELSE NULL END <=> CASE WHEN s.record_type='REVIEW' THEN s.`review_rating` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REPORT' THEN n.`reason_code` ELSE NULL END <=> CASE WHEN s.record_type='REPORT' THEN s.`report_reason_code` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='NOTIFICATION' THEN n.`ref_id` ELSE NULL END <=> CASE WHEN s.record_type='NOTIFICATION' THEN s.`notification_ref_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='NOTIFICATION' THEN n.`ref_type` ELSE NULL END <=> CASE WHEN s.record_type='NOTIFICATION' THEN s.`notification_ref_type` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REPORT' THEN n.`report_status` ELSE NULL END <=> CASE WHEN s.record_type='REPORT' THEN s.`report_status` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='IDEMPOTENCY' THEN n.`request_hash` ELSE NULL END <=> CASE WHEN s.record_type='IDEMPOTENCY' THEN s.`request_request_hash` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='IDEMPOTENCY' THEN n.`request_status` ELSE NULL END <=> CASE WHEN s.record_type='IDEMPOTENCY' THEN s.`request_status` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REPORT' THEN n.`resolution_note` ELSE NULL END <=> CASE WHEN s.record_type='REPORT' THEN s.`report_resolution_note` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REPORT' THEN n.`resolved_at` ELSE NULL END <=> CASE WHEN s.record_type='REPORT' THEN s.`report_resolved_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REPORT' THEN n.`resolved_by` ELSE NULL END <=> CASE WHEN s.record_type='REPORT' THEN s.`report_resolved_by` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='IDEMPOTENCY' THEN n.`response_body` ELSE NULL END <=> CASE WHEN s.record_type='IDEMPOTENCY' THEN s.`request_response_body` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='IDEMPOTENCY' THEN n.`response_content_type` ELSE NULL END <=> CASE WHEN s.record_type='IDEMPOTENCY' THEN s.`request_response_content_type` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='IDEMPOTENCY' THEN n.`response_location` ELSE NULL END <=> CASE WHEN s.record_type='IDEMPOTENCY' THEN s.`request_response_location` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='IDEMPOTENCY' THEN n.`response_status_code` ELSE NULL END <=> CASE WHEN s.record_type='IDEMPOTENCY' THEN s.`request_response_status_code` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='NOTIFICATION' THEN n.`title` ELSE NULL END <=> CASE WHEN s.record_type='NOTIFICATION' THEN s.`notification_title` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='AUDIT_LOG' THEN n.`trace_id` ELSE NULL END <=> CASE WHEN s.record_type='AUDIT_LOG' THEN s.`audit_trace_id` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='REVIEW' THEN n.`visible` ELSE NULL END <=> CASE WHEN s.record_type='REVIEW' THEN s.`review_visible` ELSE NULL END) OR
    NOT (n.`created_at` <=> CASE s.record_type WHEN 'NOTIFICATION' THEN s.`notification_created_at` WHEN 'PUSH_DELIVERY' THEN s.`delivery_created_at` WHEN 'AUDIT_LOG' THEN s.`audit_created_at` WHEN 'IDEMPOTENCY' THEN s.`request_created_at` WHEN 'REVIEW' THEN s.`review_created_at` WHEN 'REPORT' THEN s.`report_created_at` ELSE NULL END) OR
    NOT (n.`updated_at` <=> CASE s.record_type WHEN 'REVIEW' THEN s.`review_updated_at` WHEN 'REPORT' THEN s.`report_updated_at` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PUSH_DELIVERY' THEN n.`device_id_kind` ELSE NULL END <=> CASE WHEN s.record_type='PUSH_DELIVERY' THEN s.`delivery_device_id_kind` ELSE NULL END) OR
    NOT (CASE WHEN n.record_type='PUSH_DELIVERY' THEN n.`notification_id_kind` ELSE NULL END <=> CASE WHEN s.record_type='PUSH_DELIVERY' THEN s.`delivery_notification_id_kind` ELSE NULL END));
DROP TEMPORARY TABLE schema20_copy_guard;

-- Validate all relationships on staged tables before switching names.
ALTER TABLE `account_records_v20` ADD CONSTRAINT `fk_account_deletion_user` FOREIGN KEY (`deletion_user_id`) REFERENCES `users` (`id`);
ALTER TABLE `account_records_v20` ADD CONSTRAINT `fk_account_device_user` FOREIGN KEY (`device_user_id`) REFERENCES `users` (`id`);
ALTER TABLE `account_records_v20` ADD CONSTRAINT `fk_account_lifecycle_user` FOREIGN KEY (`lifecycle_user_id`) REFERENCES `users` (`id`);
ALTER TABLE `account_records_v20` ADD CONSTRAINT `fk_account_preference_user` FOREIGN KEY (`preference_user_id`) REFERENCES `users` (`id`);
ALTER TABLE `account_records_v20` ADD CONSTRAINT `fk_account_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
ALTER TABLE `catalog_items_v20` ADD CONSTRAINT `fk_catalog_listing` FOREIGN KEY (`listing_id`) REFERENCES `listings` (`id`);
ALTER TABLE `catalog_items_v20` ADD CONSTRAINT `fk_catalog_room` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`);
ALTER TABLE `catalog_items_v20` ADD CONSTRAINT `fk_catalog_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records_v20` ADD CONSTRAINT `fk_rental_allocated_payment` FOREIGN KEY (`allocated_payment_id`,`allocated_payment_id_kind`) REFERENCES `rental_records_v20` (`id`,`record_type`);
ALTER TABLE `rental_records_v20` ADD CONSTRAINT `fk_rental_host` FOREIGN KEY (`host_id`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records_v20` ADD CONSTRAINT `fk_rental_listing` FOREIGN KEY (`listing_id`) REFERENCES `listings` (`id`);
ALTER TABLE `rental_records_v20` ADD CONSTRAINT `fk_rental_room` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`);
ALTER TABLE `rental_records_v20` ADD CONSTRAINT `fk_rental_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records_v20` ADD CONSTRAINT `fk_rental_booking` FOREIGN KEY (`booking_id`,`booking_id_kind`) REFERENCES `rental_records_v20` (`id`,`record_type`);
ALTER TABLE `rental_records_v20` ADD CONSTRAINT `fk_rental_opened_by` FOREIGN KEY (`opened_by`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records_v20` ADD CONSTRAINT `fk_rental_resolved_by` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records_v20` ADD CONSTRAINT `fk_rental_actor` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records_v20` ADD CONSTRAINT `fk_rental_payer` FOREIGN KEY (`payer_id`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records_v20` ADD CONSTRAINT `fk_rental_refund_payment` FOREIGN KEY (`refund_payment_id`,`refund_payment_id_kind`) REFERENCES `rental_records_v20` (`id`,`record_type`);
ALTER TABLE `rental_records_v20` ADD CONSTRAINT `fk_rental_viewing_slot` FOREIGN KEY (`viewing_slot_id`,`viewing_slot_id_kind`) REFERENCES `rental_records_v20` (`id`,`record_type`);
ALTER TABLE `rental_records_v20` ADD CONSTRAINT `fk_rental_webhook_payment` FOREIGN KEY (`webhook_payment_id`,`webhook_payment_id_kind`) REFERENCES `rental_records_v20` (`id`,`record_type`);
ALTER TABLE `activity_records_v20` ADD CONSTRAINT `fk_activity_actor` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`);
ALTER TABLE `activity_records_v20` ADD CONSTRAINT `fk_activity_device` FOREIGN KEY (`device_id`,`device_id_kind`) REFERENCES `account_records_v20` (`id`,`record_type`);
ALTER TABLE `activity_records_v20` ADD CONSTRAINT `fk_activity_notification` FOREIGN KEY (`notification_id`,`notification_id_kind`) REFERENCES `activity_records_v20` (`id`,`record_type`);
ALTER TABLE `activity_records_v20` ADD CONSTRAINT `fk_activity_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
ALTER TABLE `activity_records_v20` ADD CONSTRAINT `fk_activity_resolved_by` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`);
ALTER TABLE `activity_records_v20` ADD CONSTRAINT `fk_activity_room` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`);

-- Keep join rows and their IDs unchanged while moving their role/amenity foreign keys.
ALTER TABLE user_roles DROP FOREIGN KEY fk_user_roles_typed;
ALTER TABLE room_amenities DROP FOREIGN KEY fk_room_amenities_typed;
RENAME TABLE
    `account_records` TO `account_records_v19_backup`, `account_records_v20` TO `account_records`,
    `catalog_items` TO `catalog_items_v19_backup`, `catalog_items_v20` TO `catalog_items`,
    `rental_records` TO `rental_records_v19_backup`, `rental_records_v20` TO `rental_records`,
    `activity_records` TO `activity_records_v19_backup`, `activity_records_v20` TO `activity_records`;
ALTER TABLE user_roles ADD CONSTRAINT fk_user_roles_role FOREIGN KEY (role_id,role_id_kind) REFERENCES account_records(id,record_type);
ALTER TABLE room_amenities ADD CONSTRAINT fk_room_amenities_amenity FOREIGN KEY (amenity_id,amenity_id_kind) REFERENCES catalog_items(id,record_type);

-- Drop only the verified old copies; the new tables already hold every original ID/value.
ALTER TABLE `account_records_v19_backup` DROP FOREIGN KEY `fk_deletion_user_id`;
ALTER TABLE `account_records_v19_backup` DROP FOREIGN KEY `fk_device_user_id`;
ALTER TABLE `account_records_v19_backup` DROP FOREIGN KEY `fk_lifecycle_user_id`;
ALTER TABLE `account_records_v19_backup` DROP FOREIGN KEY `fk_preference_user_id`;
ALTER TABLE `account_records_v19_backup` DROP FOREIGN KEY `fk_refresh_user_id`;
ALTER TABLE `account_records_v19_backup` DROP FOREIGN KEY `fk_verify_user_id`;
ALTER TABLE `catalog_items_v19_backup` DROP FOREIGN KEY `fk_fee_listing_id`;
ALTER TABLE `catalog_items_v19_backup` DROP FOREIGN KEY `fk_wishlist_room_id`;
ALTER TABLE `catalog_items_v19_backup` DROP FOREIGN KEY `fk_wishlist_user_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_booking_allocated_payment_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_booking_host_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_booking_listing_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_booking_room_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_booking_tenant_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_case_booking_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_case_opened_by`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_case_resolved_by`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_history_actor_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_history_booking_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_payment_booking_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_payment_payer_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_refund_payment_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_slot_host_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_slot_room_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_viewing_host_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_viewing_room_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_viewing_tenant_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_viewing_viewing_slot_id`;
ALTER TABLE `rental_records_v19_backup` DROP FOREIGN KEY `fk_webhook_payment_id`;
ALTER TABLE `activity_records_v19_backup` DROP FOREIGN KEY `fk_audit_actor_id`;
ALTER TABLE `activity_records_v19_backup` DROP FOREIGN KEY `fk_delivery_device_id`;
ALTER TABLE `activity_records_v19_backup` DROP FOREIGN KEY `fk_delivery_notification_id`;
ALTER TABLE `activity_records_v19_backup` DROP FOREIGN KEY `fk_notification_user_id`;
ALTER TABLE `activity_records_v19_backup` DROP FOREIGN KEY `fk_report_reporter_id`;
ALTER TABLE `activity_records_v19_backup` DROP FOREIGN KEY `fk_report_resolved_by`;
ALTER TABLE `activity_records_v19_backup` DROP FOREIGN KEY `fk_review_reviewer_id`;
ALTER TABLE `activity_records_v19_backup` DROP FOREIGN KEY `fk_review_room_id`;
DROP TABLE `account_records_v19_backup`,`catalog_items_v19_backup`,`rental_records_v19_backup`,`activity_records_v19_backup`;

ALTER TABLE `users` COMMENT='User accounts and profiles. Sessions and devices are in account_records.';
ALTER TABLE `user_roles` COMMENT='Roles granted to users. role_id references a ROLE account record.';
ALTER TABLE `rooms` COMMENT='Rooms, owner, location, rental terms and availability.';
ALTER TABLE `room_amenities` COMMENT='Amenities assigned to rooms. amenity_id references an AMENITY catalog item.';
ALTER TABLE `listings` COMMENT='Public listings, moderation, publication deadlines and terms version.';
ALTER TABLE `media` COMMENT='File metadata and object-storage references; file bytes are outside MySQL.';
ALTER TABLE `conversations` COMMENT='Tenant-host conversations and message sequence counters.';
ALTER TABLE `messages` COMMENT='Durable chat messages; client UUID provides retry deduplication.';
ALTER TABLE `read_markers` COMMENT='Last read message sequence for each conversation member.';
ALTER TABLE `flyway_schema_history` COMMENT='Flyway migration history and checksums. Managed by Flyway only.';
