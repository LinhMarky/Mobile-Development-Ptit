package com.homely.rental.payment.entity;

import com.homely.rental.common.persistence.RentalRecord;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@DiscriminatorValue("REFUND")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Refund extends RentalRecord {

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "refund_payment_id", nullable = true)
    private Payment payment;

    @Column(name = "provider_refund_id", length = 100)
    private String providerRefundId;

    @Column(name = "amount_vnd", precision = 18, scale = 0, nullable = true)
    private BigDecimal amountVnd;

    @Enumerated(EnumType.STRING)
    @Column(name = "refund_reason", length = 30)
    private RefundReason reason;

    @Enumerated(EnumType.STRING)
    @Column(name = "refund_status", length = 20, nullable = true)
    private RefundStatus status = RefundStatus.PENDING;

    @Column(name = "attempt_count", nullable = true)
    private int attemptCount = 0;

    @Column(name = "next_attempt_at")
    private Instant nextAttemptAt;

    @Column(name = "last_error_code", length = 100)
    private String lastErrorCode;

    @Column(name = "completed_at")
    private Instant completedAt;

    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at")
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }
}
