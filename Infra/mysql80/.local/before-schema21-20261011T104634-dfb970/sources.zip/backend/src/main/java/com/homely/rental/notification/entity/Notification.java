package com.homely.rental.notification.entity;

import com.homely.rental.common.persistence.ActivityRecord;

import com.homely.rental.auth.entity.User;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("NOTIFICATION")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Notification extends ActivityRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = true)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(name = "notification_type", length = 50, nullable = true)
    private NotificationType type;

    @Column(name = "title", length = 255, nullable = true)
    private String title;

    @Column(name = "body", length = 2000, columnDefinition = "TEXT")
    private String body;

    /** Reference type: "booking", "viewing", "review", "listing", "message" */
    @Column(name = "ref_type", length = 50)
    private String refType;

    @Column(name = "ref_id")
    private Long refId;

    @Column(name = "is_read", nullable = true)
    private boolean isRead = false;

    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now().truncatedTo(java.time.temporal.ChronoUnit.MILLIS);
}
