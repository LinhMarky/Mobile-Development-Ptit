package com.homely.rental.interaction.entity;

import com.homely.rental.common.persistence.RentalRecord;

import com.homely.rental.auth.entity.User;
import com.homely.rental.catalog.entity.Room;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("VIEWING_SLOT")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class ViewingSlot extends RentalRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "room_id", nullable = true)
    private Room room;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "host_id", nullable = true)
    private User host;

    @Column(name = "start_at", nullable = true)
    private Instant startAt;

    @Column(name = "end_at", nullable = true)
    private Instant endAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "slot_status", length = 20, nullable = true)
    private ViewingSlotStatus status = ViewingSlotStatus.OPEN;

    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at")
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }
}
