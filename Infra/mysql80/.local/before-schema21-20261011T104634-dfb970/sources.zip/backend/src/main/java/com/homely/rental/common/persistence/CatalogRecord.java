package com.homely.rental.common.persistence;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

/** Shared storage with common columns; concrete repositories keep business types separate. */
@Entity
@Table(name = "catalog_items", uniqueConstraints = {
        @UniqueConstraint(name = "uk_catalog_kind_name", columnNames = {"record_type", "name"}),
        @UniqueConstraint(name = "uk_catalog_kind_user_id_room_id", columnNames = {"record_type", "user_id", "room_id"})
})
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "record_type", length = 32)
@org.hibernate.annotations.Check(constraints = """
        record_type IN ('AMENITY','LISTING_FEE','WISHLIST_ITEM')
        AND (record_type <> 'AMENITY' OR (name IS NOT NULL))
        AND (record_type <> 'LISTING_FEE' OR (listing_id IS NOT NULL AND fee_code IS NOT NULL AND fee_mode IS NOT NULL AND amount_vnd IS NOT NULL AND sort_order IS NOT NULL))
        AND (record_type <> 'WISHLIST_ITEM' OR (user_id IS NOT NULL AND room_id IS NOT NULL))
        """)
@Getter
@Setter
public abstract class CatalogRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

}
