package com.homely.rental.booking.entity;

import com.homely.rental.common.persistence.RentalRecord;

import com.homely.rental.auth.entity.User;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("BOOKING_HISTORY")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class BookingStatusHistory extends RentalRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "booking_id", nullable = true)
    private Booking booking;

    @Column(name = "from_status", length = 30)
    private String fromStatus;

    @Column(name = "to_status", length = 30, nullable = true)
    private String toStatus;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "actor_id")
    private User actor;

    @Enumerated(EnumType.STRING)
    @Column(name = "actor_type", length = 20, nullable = true)
    private ActorType actorType;

    @Column(name = "history_reason", length = 1000)
    private String reason;

    @Column(name = "trace_id", length = 64, nullable = true)
    private String traceId;

    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();
}
