package com.homely.rental.catalog.service;

import com.homely.rental.auth.entity.User;
import com.homely.rental.auth.security.UserResolver;
import com.homely.rental.catalog.entity.Room;
import com.homely.rental.catalog.entity.Listing;
import com.homely.rental.catalog.entity.ListingStatus;
import com.homely.rental.catalog.entity.WishlistItem;
import com.homely.rental.catalog.repository.RoomRepository;
import com.homely.rental.catalog.repository.ListingRepository;
import com.homely.rental.catalog.repository.WishlistRepository;
import com.homely.rental.common.dto.PageResponse;
import com.homely.rental.common.exception.IdInvalidException;
import com.homely.rental.common.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.LinkedHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.time.Instant;

/**
 * Wishlist service (CAT11–CAT13).
 * Handles save/unsave rooms and listing saved rooms.
 */
@Service
@RequiredArgsConstructor
public class WishlistService {

    private final WishlistRepository wishlistRepository;
    private final RoomRepository roomRepository;
    private final UserResolver userResolver;
    private final ListingRepository listingRepository;
    private final ListingService listingService;

    // CAT11: Save room to wishlist
    @Transactional
    public Map<String, String> saveRoom(Long roomId) throws IdInvalidException {
        User user = userResolver.requireCurrent();
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new ResourceNotFoundException("Room", roomId));

        if (wishlistRepository.existsByUserIdAndRoomId(user.getId(), roomId)) {
            return Map.of("status", "already_saved");
        }

        WishlistItem item = new WishlistItem();
        item.setUser(user);
        item.setRoom(room);
        wishlistRepository.save(item);

        return Map.of("status", "saved");
    }

    // CAT12: Remove room from wishlist
    @Transactional
    public Map<String, String> unsaveRoom(Long roomId) throws IdInvalidException {
        User user = userResolver.requireCurrent();
        wishlistRepository.deleteByUserIdAndRoomId(user.getId(), roomId);
        return Map.of("status", "removed");
    }

    // CAT13: List saved rooms
    @Transactional(readOnly = true)
    public PageResponse<Map<String, Object>> getSavedRooms(Pageable pageable) throws IdInvalidException {
        User user = userResolver.requireCurrent();
        Page<WishlistItem> page = wishlistRepository.findByUserId(user.getId(), pageable);
        var roomIds = page.getContent().stream().map(item -> item.getRoom().getId()).toList();
        Instant now = Instant.now();
        // A wishlist retains room IDs after an advert is hidden. Never expose draft/private advert data.
        var publicListings = roomIds.isEmpty() ? Map.<Long, Listing>of()
                : listingRepository.findByRoomIdIn(roomIds).stream()
                .filter(listing -> listing.getStatus() == ListingStatus.PUBLISHED)
                .filter(listing -> listing.getExpiresAt() == null || listing.getExpiresAt().isAfter(now))
                .collect(Collectors.toMap(listing -> listing.getRoom().getId(), Function.identity()));
        var items = page.getContent().stream().map(wi -> {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", wi.getId());
            item.put("room_id", wi.getRoom().getId());
            item.put("unit_code", wi.getRoom().getUnitCode());
            item.put("address", wi.getRoom().getAddress() != null ? wi.getRoom().getAddress().getLine() : "");
            item.put("saved_at", wi.getCreatedAt().toString());
            Listing listing = publicListings.get(wi.getRoom().getId());
            item.put("listing_id", listing == null ? null : listing.getId());
            item.put("listing", listing == null ? null : listingService.toDTO(listing));
            return item;
        }).toList();
        return PageResponse.of(page, items);
    }

    // Check if room is saved
    public boolean isSaved(Long roomId) throws IdInvalidException {
        User user = userResolver.requireCurrent();
        return wishlistRepository.existsByUserIdAndRoomId(user.getId(), roomId);
    }

}
