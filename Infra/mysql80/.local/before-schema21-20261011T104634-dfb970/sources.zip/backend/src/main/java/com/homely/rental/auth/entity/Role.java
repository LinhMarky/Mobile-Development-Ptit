package com.homely.rental.auth.entity;

import com.homely.rental.common.persistence.AccountRecord;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@DiscriminatorValue("ROLE")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Role extends AccountRecord {

    @Enumerated(EnumType.STRING)
    @Column(name = "role_name", length = 20, nullable = true)
    private RoleName name;
}
