package com.homely.rental.common.persistence;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

/** Shared storage with common columns; concrete repositories keep business types separate. */
@Entity
@Table(name = "rental_records", uniqueConstraints = {
        @UniqueConstraint(name = "uk_rental_kind_allocated_payment_id", columnNames = {"record_type", "allocated_payment_id"}),
        @UniqueConstraint(name = "uk_rental_kind_provider_payment_id", columnNames = {"record_type", "provider_payment_id"}),
        @UniqueConstraint(name = "uk_rental_kind_refund_payment_id", columnNames = {"record_type", "refund_payment_id"}),
        @UniqueConstraint(name = "uk_rental_kind_provider_refund_id", columnNames = {"record_type", "provider_refund_id"}),
        @UniqueConstraint(name = "uk_rental_kind_event_provider_event_id", columnNames = {"record_type", "event_provider", "event_id"})
})
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "record_type", length = 32)
@org.hibernate.annotations.Check(constraints = """
        record_type IN ('BOOKING','BOOKING_CASE','BOOKING_HISTORY','VIEWING_SLOT','VIEWING','PAYMENT','REFUND','WEBHOOK_RECEIPT')
        AND (record_type <> 'BOOKING' OR (tenant_id IS NOT NULL AND host_id IS NOT NULL AND room_id IS NOT NULL AND listing_id IS NOT NULL AND booking_status IS NOT NULL AND occupant_count IS NOT NULL AND rent_vnd IS NOT NULL AND deposit_vnd IS NOT NULL AND terms_snapshot IS NOT NULL AND snapshot_schema_version IS NOT NULL AND request_expires_at IS NOT NULL))
        AND (record_type <> 'BOOKING_CASE' OR (booking_id IS NOT NULL AND case_type IS NOT NULL AND description IS NOT NULL AND case_status IS NOT NULL))
        AND (record_type <> 'BOOKING_HISTORY' OR (booking_id IS NOT NULL AND to_status IS NOT NULL AND actor_type IS NOT NULL AND trace_id IS NOT NULL))
        AND (record_type <> 'VIEWING_SLOT' OR (room_id IS NOT NULL AND host_id IS NOT NULL AND start_at IS NOT NULL AND end_at IS NOT NULL AND slot_status IS NOT NULL))
        AND (record_type <> 'VIEWING' OR (viewing_slot_id IS NOT NULL AND tenant_id IS NOT NULL AND room_id IS NOT NULL AND host_id IS NOT NULL AND viewing_status IS NOT NULL))
        AND (record_type <> 'PAYMENT' OR (booking_id IS NOT NULL AND payer_id IS NOT NULL AND provider IS NOT NULL AND amount_vnd IS NOT NULL AND currency IS NOT NULL AND payment_status IS NOT NULL AND expires_at IS NOT NULL AND is_test IS NOT NULL))
        AND (record_type <> 'REFUND' OR (refund_payment_id IS NOT NULL AND amount_vnd IS NOT NULL AND refund_status IS NOT NULL AND attempt_count IS NOT NULL))
        AND (record_type <> 'WEBHOOK_RECEIPT' OR (event_provider IS NOT NULL AND event_id IS NOT NULL AND payload_hash IS NOT NULL AND processed_at IS NOT NULL))
        """)
@Getter
@Setter
public abstract class RentalRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;
}
