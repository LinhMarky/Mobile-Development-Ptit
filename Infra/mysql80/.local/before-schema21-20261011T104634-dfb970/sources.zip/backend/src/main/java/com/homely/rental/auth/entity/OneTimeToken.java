package com.homely.rental.auth.entity;

import com.homely.rental.common.persistence.AccountRecord;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * One-time token for email verification and password reset flows (SEC-03).
 */
@Entity
@DiscriminatorValue("ONE_TIME_TOKEN")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OneTimeToken extends AccountRecord {

    @Column(name = "token_hash", length = 64, nullable = true)
    private String tokenHash;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = true)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(name = "token_purpose", length = 30, nullable = true)
    private OneTimeTokenPurpose purpose;

    @Column(name = "used")
    private boolean used = false;

    @Column(name = "expires_at", nullable = true)
    private Instant expiresAt;

    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    public enum OneTimeTokenPurpose {
        EMAIL_VERIFICATION,
        PASSWORD_RESET
    }
}
