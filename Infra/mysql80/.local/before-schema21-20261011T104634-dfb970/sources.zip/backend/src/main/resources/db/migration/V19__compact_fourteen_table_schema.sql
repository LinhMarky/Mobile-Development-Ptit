-- Compact schema: 13 application tables + Flyway history = 14 physical tables.
-- This migration accepts an unused V18 database only; existing business data is never discarded.
-- V1-V18 checksums stay unchanged. Take a backup before upgrading.
CREATE TEMPORARY TABLE schema14_empty_guard (row_count BIGINT PRIMARY KEY);
INSERT INTO schema14_empty_guard VALUES (0);
INSERT INTO schema14_empty_guard SELECT 0 WHERE ((SELECT COUNT(*) FROM `account_deletion_requests`) + (SELECT COUNT(*) FROM `account_lifecycle_locks`) + (SELECT COUNT(*) FROM `audit_logs`) + (SELECT COUNT(*) FROM `booking_cases`) + (SELECT COUNT(*) FROM `booking_status_history`) + (SELECT COUNT(*) FROM `bookings`) + (SELECT COUNT(*) FROM `case_evidence`) + (SELECT COUNT(*) FROM `conversations`) + (SELECT COUNT(*) FROM `device_tokens`) + (SELECT COUNT(*) FROM `idempotency_keys`) + (SELECT COUNT(*) FROM `listing_fees`) + (SELECT COUNT(*) FROM `listing_status_history`) + (SELECT COUNT(*) FROM `listings`) + (SELECT COUNT(*) FROM `media`) + (SELECT COUNT(*) FROM `messages`) + (SELECT COUNT(*) FROM `notification_preferences`) + (SELECT COUNT(*) FROM `notifications`) + (SELECT COUNT(*) FROM `one_time_tokens`) + (SELECT COUNT(*) FROM `payment_webhook_receipts`) + (SELECT COUNT(*) FROM `payments`) + (SELECT COUNT(*) FROM `push_deliveries`) + (SELECT COUNT(*) FROM `read_markers`) + (SELECT COUNT(*) FROM `refresh_tokens`) + (SELECT COUNT(*) FROM `refunds`) + (SELECT COUNT(*) FROM `reports`) + (SELECT COUNT(*) FROM `reviews`) + (SELECT COUNT(*) FROM `room_amenities`) + (SELECT COUNT(*) FROM `rooms`) + (SELECT COUNT(*) FROM `user_roles`) + (SELECT COUNT(*) FROM `users`) + (SELECT COUNT(*) FROM `viewing_slots`) + (SELECT COUNT(*) FROM `viewing_status_history`) + (SELECT COUNT(*) FROM `viewings`) + (SELECT COUNT(*) FROM `wishlist_items`)) <> 0;
DROP TEMPORARY TABLE schema14_empty_guard;

CREATE TABLE `account_records` (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    record_type VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    version INT NOT NULL DEFAULT 0,
    UNIQUE KEY `uk_account_records_typed_id` (id, record_type),
    CONSTRAINT `ck_account_records_kind` CHECK (record_type IN ('ROLE','REFRESH_TOKEN','ONE_TIME_TOKEN','DEVICE_TOKEN','PREFERENCES','DELETION_REQUEST','LIFECYCLE_LOCK')),
    `role_name` varchar(20) NULL,
    CONSTRAINT `ck_role_required` CHECK (record_type <> 'ROLE' OR (`role_name` IS NOT NULL)),
    UNIQUE KEY `uk_account_records_1` (`role_name`),
    `refresh_token_hash` varchar(64) NULL,
    `refresh_user_id` bigint NULL,
    `refresh_installation_id` varchar(36) NULL,
    `refresh_device_name` varchar(100) NULL,
    `refresh_expires_at` datetime(3) NULL,
    `refresh_revoked` tinyint(1) NULL DEFAULT '0',
    `refresh_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    CONSTRAINT `ck_refresh_required` CHECK (record_type <> 'REFRESH_TOKEN' OR (`refresh_token_hash` IS NOT NULL AND `refresh_user_id` IS NOT NULL AND `refresh_installation_id` IS NOT NULL AND `refresh_device_name` IS NOT NULL AND `refresh_expires_at` IS NOT NULL AND `refresh_revoked` IS NOT NULL)),
    KEY `ix_account_records_2` (record_type,`refresh_expires_at`),
    KEY `ix_account_records_3` (record_type,`refresh_user_id`),
    UNIQUE KEY `uk_account_records_4` (`refresh_token_hash`),
    `verify_token_hash` varchar(64) NULL,
    `verify_user_id` bigint NULL,
    `verify_purpose` varchar(30) NULL,
    `verify_used` tinyint(1) NULL DEFAULT '0',
    `verify_expires_at` datetime(3) NULL,
    `verify_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    CONSTRAINT `ck_verify_required` CHECK (record_type <> 'ONE_TIME_TOKEN' OR (`verify_token_hash` IS NOT NULL AND `verify_user_id` IS NOT NULL AND `verify_purpose` IS NOT NULL AND `verify_used` IS NOT NULL AND `verify_expires_at` IS NOT NULL)),
    KEY `ix_account_records_5` (record_type,`verify_expires_at`),
    KEY `ix_account_records_6` (record_type,`verify_user_id`),
    UNIQUE KEY `uk_account_records_7` (`verify_token_hash`),
    `device_user_id` bigint NULL,
    `device_token` TEXT NULL,
    `device_platform` varchar(10) NULL DEFAULT 'ANDROID',
    `device_device_name` varchar(100) NULL,
    `device_installation_id` varchar(36) NULL,
    `device_active` tinyint(1) NULL DEFAULT '1',
    `device_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `device_updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `device_active_installation` varchar(36) GENERATED ALWAYS AS (IF(record_type='DEVICE_TOKEN', if(`device_active`,`device_installation_id`,NULL), NULL)) STORED,
    `device_active_token_hash` varchar(64) GENERATED ALWAYS AS (IF(record_type='DEVICE_TOKEN', if(`device_active`,sha2(`device_token`,256),NULL), NULL)) STORED,
    CONSTRAINT `ck_device_required` CHECK (record_type <> 'DEVICE_TOKEN' OR (`device_user_id` IS NOT NULL AND `device_token` IS NOT NULL AND `device_platform` IS NOT NULL AND `device_device_name` IS NOT NULL AND `device_installation_id` IS NOT NULL AND `device_active` IS NOT NULL)),
    KEY `ix_account_records_8` (record_type,`device_user_id`,`device_active`),
    UNIQUE KEY `uk_account_records_9` (`device_active_installation`),
    UNIQUE KEY `uk_account_records_10` (`device_active_token_hash`),
    UNIQUE KEY `uk_account_records_11` (`device_user_id`,`device_installation_id`),
    `preference_user_id` bigint NULL,
    `preference_transaction_push` tinyint(1) NULL DEFAULT '1',
    `preference_transaction_email` tinyint(1) NULL DEFAULT '1',
    `preference_chat_push` tinyint(1) NULL DEFAULT '1',
    `preference_recommendation_push` tinyint(1) NULL DEFAULT '1',
    `preference_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `preference_updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    CONSTRAINT `ck_preference_required` CHECK (record_type <> 'PREFERENCES' OR (`preference_user_id` IS NOT NULL AND `preference_transaction_push` IS NOT NULL AND `preference_transaction_email` IS NOT NULL AND `preference_chat_push` IS NOT NULL AND `preference_recommendation_push` IS NOT NULL)),
    UNIQUE KEY `uk_account_records_12` (`preference_user_id`),
    `deletion_user_id` bigint NULL,
    `deletion_reason` varchar(1000) NULL DEFAULT '',
    `deletion_status` varchar(20) NULL DEFAULT 'PENDING',
    `deletion_failure_code` varchar(100) NULL,
    `deletion_completed_at` datetime(3) NULL,
    `deletion_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `deletion_updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    CONSTRAINT `ck_deletion_required` CHECK (record_type <> 'DELETION_REQUEST' OR (`deletion_user_id` IS NOT NULL AND `deletion_reason` IS NOT NULL AND `deletion_status` IS NOT NULL)),
    KEY `ix_account_records_13` (record_type,`deletion_status`),
    UNIQUE KEY `uk_account_records_14` (`deletion_user_id`),
    `lifecycle_user_id` bigint NULL,
    CONSTRAINT `ck_lifecycle_required` CHECK (record_type <> 'LIFECYCLE_LOCK' OR (`lifecycle_user_id` IS NOT NULL)),
    UNIQUE KEY `uk_account_records_15` (`lifecycle_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE `catalog_items` (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    record_type VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    UNIQUE KEY `uk_catalog_items_typed_id` (id, record_type),
    CONSTRAINT `ck_catalog_items_kind` CHECK (record_type IN ('AMENITY','LISTING_FEE','WISHLIST_ITEM')),
    `amenity_name` varchar(100) NULL,
    `amenity_icon` varchar(100) NULL,
    `amenity_category` varchar(50) NULL,
    CONSTRAINT `ck_amenity_required` CHECK (record_type <> 'AMENITY' OR (`amenity_name` IS NOT NULL)),
    UNIQUE KEY `uk_catalog_items_1` (`amenity_name`),
    `fee_listing_id` bigint NULL,
    `fee_fee_code` varchar(50) NULL,
    `fee_fee_mode` varchar(20) NULL DEFAULT 'FIXED',
    `fee_amount_vnd` decimal(18,0) NULL,
    `fee_unit_name` varchar(50) NULL,
    `fee_note` varchar(500) NULL,
    `fee_sort_order` int NULL DEFAULT '0',
    CONSTRAINT `ck_fee_required` CHECK (record_type <> 'LISTING_FEE' OR (`fee_listing_id` IS NOT NULL AND `fee_fee_code` IS NOT NULL AND `fee_fee_mode` IS NOT NULL AND `fee_amount_vnd` IS NOT NULL AND `fee_sort_order` IS NOT NULL)),
    KEY `ix_catalog_items_2` (record_type,`fee_listing_id`),
    `wishlist_user_id` bigint NULL,
    `wishlist_room_id` bigint NULL,
    `wishlist_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    CONSTRAINT `ck_wishlist_required` CHECK (record_type <> 'WISHLIST_ITEM' OR (`wishlist_user_id` IS NOT NULL AND `wishlist_room_id` IS NOT NULL)),
    KEY `ix_catalog_items_3` (record_type,`wishlist_room_id`),
    KEY `ix_catalog_items_4` (record_type,`wishlist_user_id`),
    UNIQUE KEY `uk_catalog_items_5` (`wishlist_user_id`,`wishlist_room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE `rental_records` (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    record_type VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    version INT NOT NULL DEFAULT 0,
    UNIQUE KEY `uk_rental_records_typed_id` (id, record_type),
    CONSTRAINT `ck_rental_records_kind` CHECK (record_type IN ('BOOKING','BOOKING_CASE','BOOKING_HISTORY','VIEWING_SLOT','VIEWING','PAYMENT','REFUND','WEBHOOK_RECEIPT')),
    `booking_tenant_id` bigint NULL,
    `booking_host_id` bigint NULL,
    `booking_room_id` bigint NULL,
    `booking_listing_id` bigint NULL,
    `booking_status` varchar(20) NULL DEFAULT 'PENDING',
    `booking_desired_move_in` date NULL,
    `booking_occupant_count` int NULL DEFAULT '1',
    `booking_rent_vnd` decimal(18,0) NULL,
    `booking_deposit_vnd` decimal(18,0) NULL DEFAULT '0',
    `booking_note` varchar(1000) NULL,
    `booking_terms_snapshot` json NULL,
    `booking_snapshot_schema_version` int NULL DEFAULT '1',
    `booking_request_expires_at` datetime(3) NULL,
    `booking_hold_expires_at` datetime(3) NULL,
    `booking_handover_due_at` datetime(3) NULL,
    `booking_tenant_terms_accepted_at` datetime(3) NULL,
    `booking_tenant_handover_confirmed_at` datetime(3) NULL,
    `booking_host_handover_confirmed_at` datetime(3) NULL,
    `booking_allocated_payment_id` bigint NULL,
    `booking_completed_at` datetime(3) NULL,
    `booking_cancelled_at` datetime(3) NULL,
    `booking_last_reason` varchar(1000) NULL,
    `booking_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `booking_updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `booking_active_room_id` bigint GENERATED ALWAYS AS (IF(record_type='BOOKING', (case when (`booking_status` in (_utf8mb4'APPROVED',_utf8mb4'CONFIRMED')) then `booking_room_id` else NULL end), NULL)) STORED,
    `booking_open_room_id` bigint GENERATED ALWAYS AS (IF(record_type='BOOKING', (case when (`booking_status` in (_utf8mb4'PENDING',_utf8mb4'APPROVED',_utf8mb4'CONFIRMED')) then `booking_room_id` else NULL end), NULL)) STORED,
    CONSTRAINT `ck_booking_required` CHECK (record_type <> 'BOOKING' OR (`booking_tenant_id` IS NOT NULL AND `booking_host_id` IS NOT NULL AND `booking_room_id` IS NOT NULL AND `booking_listing_id` IS NOT NULL AND `booking_status` IS NOT NULL AND `booking_occupant_count` IS NOT NULL AND `booking_rent_vnd` IS NOT NULL AND `booking_deposit_vnd` IS NOT NULL AND `booking_terms_snapshot` IS NOT NULL AND `booking_snapshot_schema_version` IS NOT NULL AND `booking_request_expires_at` IS NOT NULL)),
    UNIQUE KEY `uk_rental_records_1` (`booking_allocated_payment_id`),
    KEY `ix_rental_records_2` (record_type,`booking_listing_id`),
    KEY `ix_rental_records_3` (record_type,`booking_room_id`),
    KEY `ix_rental_records_4` (record_type,`booking_status`,`booking_handover_due_at`),
    KEY `ix_rental_records_5` (record_type,`booking_status`,`booking_hold_expires_at`),
    KEY `ix_rental_records_6` (record_type,`booking_status`,`booking_request_expires_at`),
    KEY `ix_rental_records_7` (record_type,`booking_host_id`,`booking_status`,`booking_created_at`,`id`),
    KEY `ix_rental_records_8` (record_type,`booking_tenant_id`,`booking_status`,`booking_created_at`,`id`),
    UNIQUE KEY `uk_rental_records_9` (`booking_active_room_id`),
    UNIQUE KEY `uk_rental_records_10` (`booking_tenant_id`,`booking_open_room_id`),
    `booking_allocated_payment_id_kind` VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'PAYMENT',
    CONSTRAINT `ck_booking_allocated_payment_id_kind` CHECK (`booking_allocated_payment_id_kind` = 'PAYMENT'),
    `case_booking_id` bigint NULL,
    `case_type` varchar(30) NULL,
    `case_opened_by` bigint NULL,
    `case_description` text NULL,
    `case_status` varchar(20) NULL DEFAULT 'OPEN',
    `case_decision` varchar(30) NULL,
    `case_resolution_note` text NULL,
    `case_resolved_by` bigint NULL,
    `case_resolved_at` datetime(3) NULL,
    `case_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `case_updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `case_open_booking_id` bigint GENERATED ALWAYS AS (IF(record_type='BOOKING_CASE', (case when (`case_status` in (_utf8mb4'OPEN',_utf8mb4'IN_REVIEW')) then `case_booking_id` else NULL end), NULL)) STORED,
    `case_tenant_refund_vnd` decimal(18,0) NULL,
    `case_host_retained_vnd` decimal(18,0) NULL,
    CONSTRAINT `ck_case_required` CHECK (record_type <> 'BOOKING_CASE' OR (`case_booking_id` IS NOT NULL AND `case_type` IS NOT NULL AND `case_description` IS NOT NULL AND `case_status` IS NOT NULL)),
    KEY `ix_rental_records_11` (record_type,`case_opened_by`),
    KEY `ix_rental_records_12` (record_type,`case_resolved_by`),
    KEY `ix_rental_records_13` (record_type,`case_booking_id`,`case_status`),
    UNIQUE KEY `uk_rental_records_14` (`case_open_booking_id`),
    `case_booking_id_kind` VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'BOOKING',
    CONSTRAINT `ck_case_booking_id_kind` CHECK (`case_booking_id_kind` = 'BOOKING'),
    `history_booking_id` bigint NULL,
    `history_from_status` varchar(30) NULL,
    `history_to_status` varchar(30) NULL,
    `history_actor_id` bigint NULL,
    `history_actor_type` varchar(20) NULL,
    `history_reason` varchar(1000) NULL,
    `history_trace_id` varchar(64) NULL,
    `history_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    CONSTRAINT `ck_history_required` CHECK (record_type <> 'BOOKING_HISTORY' OR (`history_booking_id` IS NOT NULL AND `history_to_status` IS NOT NULL AND `history_actor_type` IS NOT NULL AND `history_trace_id` IS NOT NULL)),
    KEY `ix_rental_records_15` (record_type,`history_actor_id`),
    KEY `ix_rental_records_16` (record_type,`history_booking_id`,`history_created_at`),
    `history_booking_id_kind` VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'BOOKING',
    CONSTRAINT `ck_history_booking_id_kind` CHECK (`history_booking_id_kind` = 'BOOKING'),
    `slot_room_id` bigint NULL,
    `slot_host_id` bigint NULL,
    `slot_start_at` datetime(3) NULL,
    `slot_end_at` datetime(3) NULL,
    `slot_status` varchar(20) NULL DEFAULT 'OPEN',
    `slot_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `slot_updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    CONSTRAINT `ck_slot_required` CHECK (record_type <> 'VIEWING_SLOT' OR (`slot_room_id` IS NOT NULL AND `slot_host_id` IS NOT NULL AND `slot_start_at` IS NOT NULL AND `slot_end_at` IS NOT NULL AND `slot_status` IS NOT NULL)),
    KEY `ix_rental_records_17` (record_type,`slot_host_id`,`slot_status`),
    KEY `ix_rental_records_18` (record_type,`slot_room_id`,`slot_status`,`slot_start_at`),
    `viewing_viewing_slot_id` bigint NULL,
    `viewing_tenant_id` bigint NULL,
    `viewing_room_id` bigint NULL,
    `viewing_host_id` bigint NULL,
    `viewing_status` varchar(30) NULL DEFAULT 'REQUESTED',
    `viewing_note` varchar(1000) NULL,
    `viewing_cancelled_reason` varchar(1000) NULL,
    `viewing_completed_at` datetime(3) NULL,
    `viewing_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `viewing_updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    CONSTRAINT `ck_viewing_required` CHECK (record_type <> 'VIEWING' OR (`viewing_viewing_slot_id` IS NOT NULL AND `viewing_tenant_id` IS NOT NULL AND `viewing_room_id` IS NOT NULL AND `viewing_host_id` IS NOT NULL AND `viewing_status` IS NOT NULL)),
    KEY `ix_rental_records_19` (record_type,`viewing_viewing_slot_id`),
    KEY `ix_rental_records_20` (record_type,`viewing_host_id`,`viewing_status`),
    KEY `ix_rental_records_21` (record_type,`viewing_room_id`,`viewing_status`),
    KEY `ix_rental_records_22` (record_type,`viewing_tenant_id`,`viewing_status`),
    `viewing_viewing_slot_id_kind` VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'VIEWING_SLOT',
    CONSTRAINT `ck_viewing_viewing_slot_id_kind` CHECK (`viewing_viewing_slot_id_kind` = 'VIEWING_SLOT'),
    `payment_booking_id` bigint NULL,
    `payment_payer_id` bigint NULL,
    `payment_provider` varchar(20) NULL DEFAULT 'MOCK_SANDBOX',
    `payment_provider_payment_id` varchar(100) NULL,
    `payment_amount_vnd` decimal(18,0) NULL,
    `payment_currency` char(3) NULL DEFAULT 'VND',
    `payment_status` varchar(20) NULL DEFAULT 'PENDING',
    `payment_expires_at` datetime(3) NULL,
    `payment_succeeded_at` datetime(3) NULL,
    `payment_failure_code` varchar(100) NULL,
    `payment_is_test` tinyint(1) NULL DEFAULT '1',
    `payment_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `payment_updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    `payment_pending_booking_id` bigint GENERATED ALWAYS AS (IF(record_type='PAYMENT', (case when (`payment_status` = _utf8mb4'PENDING') then `payment_booking_id` else NULL end), NULL)) STORED,
    CONSTRAINT `ck_payment_required` CHECK (record_type <> 'PAYMENT' OR (`payment_booking_id` IS NOT NULL AND `payment_payer_id` IS NOT NULL AND `payment_provider` IS NOT NULL AND `payment_amount_vnd` IS NOT NULL AND `payment_currency` IS NOT NULL AND `payment_status` IS NOT NULL AND `payment_expires_at` IS NOT NULL AND `payment_is_test` IS NOT NULL)),
    KEY `ix_rental_records_23` (record_type,`payment_payer_id`),
    KEY `ix_rental_records_24` (record_type,`payment_booking_id`),
    KEY `ix_rental_records_25` (record_type,`payment_status`,`payment_expires_at`),
    UNIQUE KEY `uk_rental_records_26` (`payment_provider_payment_id`),
    UNIQUE KEY `uk_rental_records_27` (`payment_pending_booking_id`),
    `payment_booking_id_kind` VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'BOOKING',
    CONSTRAINT `ck_payment_booking_id_kind` CHECK (`payment_booking_id_kind` = 'BOOKING'),
    `refund_payment_id` bigint NULL,
    `refund_provider_refund_id` varchar(100) NULL,
    `refund_amount_vnd` decimal(18,0) NULL,
    `refund_reason` varchar(30) NULL,
    `refund_status` varchar(20) NULL DEFAULT 'PENDING',
    `refund_attempt_count` int NULL DEFAULT '0',
    `refund_next_attempt_at` datetime(3) NULL,
    `refund_last_error_code` varchar(100) NULL,
    `refund_completed_at` datetime(3) NULL,
    `refund_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `refund_updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    CONSTRAINT `ck_refund_required` CHECK (record_type <> 'REFUND' OR (`refund_payment_id` IS NOT NULL AND `refund_amount_vnd` IS NOT NULL AND `refund_status` IS NOT NULL AND `refund_attempt_count` IS NOT NULL)),
    KEY `ix_rental_records_28` (record_type,`refund_status`,`refund_next_attempt_at`),
    UNIQUE KEY `uk_rental_records_29` (`refund_payment_id`),
    UNIQUE KEY `uk_rental_records_30` (`refund_provider_refund_id`),
    `refund_payment_id_kind` VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'PAYMENT',
    CONSTRAINT `ck_refund_payment_id_kind` CHECK (`refund_payment_id_kind` = 'PAYMENT'),
    `webhook_provider` varchar(20) NULL,
    `webhook_event_id` char(36) NULL,
    `webhook_payment_id` bigint NULL,
    `webhook_payload_hash` binary(32) NULL,
    `webhook_outcome` varchar(30) NULL,
    `webhook_processed_at` datetime(3) NULL,
    `webhook_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    CONSTRAINT `ck_webhook_required` CHECK (record_type <> 'WEBHOOK_RECEIPT' OR (`webhook_provider` IS NOT NULL AND `webhook_event_id` IS NOT NULL AND `webhook_payload_hash` IS NOT NULL AND `webhook_processed_at` IS NOT NULL)),
    KEY `ix_rental_records_31` (record_type,`webhook_payment_id`),
    UNIQUE KEY `uk_rental_records_32` (`webhook_provider`,`webhook_event_id`),
    `webhook_payment_id_kind` VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'PAYMENT',
    CONSTRAINT `ck_webhook_payment_id_kind` CHECK (`webhook_payment_id_kind` = 'PAYMENT')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE `activity_records` (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    record_type VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    version INT NOT NULL DEFAULT 0,
    UNIQUE KEY `uk_activity_records_typed_id` (id, record_type),
    CONSTRAINT `ck_activity_records_kind` CHECK (record_type IN ('NOTIFICATION','PUSH_DELIVERY','AUDIT_LOG','IDEMPOTENCY','REVIEW','REPORT')),
    `notification_user_id` bigint NULL,
    `notification_type` varchar(50) NULL,
    `notification_title` varchar(255) NULL,
    `notification_body` TEXT NULL,
    `notification_ref_type` varchar(50) NULL,
    `notification_ref_id` bigint NULL,
    `notification_is_read` tinyint(1) NULL DEFAULT '0',
    `notification_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    CONSTRAINT `ck_notification_required` CHECK (record_type <> 'NOTIFICATION' OR (`notification_user_id` IS NOT NULL AND `notification_type` IS NOT NULL AND `notification_title` IS NOT NULL AND `notification_is_read` IS NOT NULL)),
    KEY `ix_activity_records_1` (record_type,`notification_user_id`,`notification_is_read`,`notification_created_at`),
    `delivery_notification_id` bigint NULL,
    `delivery_device_id` bigint NULL,
    `delivery_status` varchar(20) NULL DEFAULT 'PENDING',
    `delivery_attempts` int NULL DEFAULT '0',
    `delivery_next_attempt_at` datetime(3) NULL,
    `delivery_last_error` varchar(100) NULL,
    `delivery_created_at` datetime(3) NULL,
    CONSTRAINT `ck_delivery_required` CHECK (record_type <> 'PUSH_DELIVERY' OR (`delivery_notification_id` IS NOT NULL AND `delivery_device_id` IS NOT NULL AND `delivery_status` IS NOT NULL AND `delivery_attempts` IS NOT NULL AND `delivery_next_attempt_at` IS NOT NULL AND `delivery_created_at` IS NOT NULL)),
    KEY `ix_activity_records_2` (record_type,`delivery_device_id`),
    KEY `ix_activity_records_3` (record_type,`delivery_status`,`delivery_created_at`,`id`),
    KEY `ix_activity_records_4` (record_type,`delivery_status`,`delivery_next_attempt_at`),
    UNIQUE KEY `uk_activity_records_5` (`delivery_notification_id`,`delivery_device_id`),
    `delivery_device_id_kind` VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'DEVICE_TOKEN',
    CONSTRAINT `ck_delivery_device_id_kind` CHECK (`delivery_device_id_kind` = 'DEVICE_TOKEN'),
    `delivery_notification_id_kind` VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'NOTIFICATION',
    CONSTRAINT `ck_delivery_notification_id_kind` CHECK (`delivery_notification_id_kind` = 'NOTIFICATION'),
    `audit_actor_id` bigint NULL,
    `audit_actor_type` varchar(20) NULL,
    `audit_action` varchar(100) NULL,
    `audit_target_type` varchar(50) NULL,
    `audit_target_id` bigint NULL,
    `audit_detail` json NULL,
    `audit_ip_address` varchar(45) NULL,
    `audit_trace_id` varchar(64) NULL,
    `audit_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    CONSTRAINT `ck_audit_required` CHECK (record_type <> 'AUDIT_LOG' OR (`audit_actor_type` IS NOT NULL AND `audit_action` IS NOT NULL AND `audit_target_type` IS NOT NULL AND `audit_target_id` IS NOT NULL)),
    KEY `ix_activity_records_6` (record_type,`audit_actor_id`,`audit_created_at`),
    KEY `ix_activity_records_7` (record_type,`audit_target_type`,`audit_target_id`,`audit_created_at`),
    `request_idempotency_key` varchar(512) NULL,
    `request_status` varchar(20) NULL DEFAULT 'PROCESSING',
    `request_response_status_code` int NULL,
    `request_response_body` longtext NULL,
    `request_expires_at` datetime(3) NULL,
    `request_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `request_request_hash` varchar(64) NULL,
    `request_response_content_type` varchar(255) NULL,
    `request_response_location` TEXT NULL,
    CONSTRAINT `ck_request_required` CHECK (record_type <> 'IDEMPOTENCY' OR (`request_idempotency_key` IS NOT NULL AND `request_status` IS NOT NULL AND `request_expires_at` IS NOT NULL)),
    UNIQUE KEY `uk_activity_records_8` (`request_idempotency_key`),
    KEY `ix_activity_records_9` (record_type,`request_status`,`request_expires_at`,`id`),
    KEY `ix_activity_records_10` (record_type,`request_expires_at`),
    `review_booking_id` bigint NULL,
    `review_reviewer_id` bigint NULL,
    `review_room_id` bigint NULL,
    `review_rating` int NULL,
    `review_comment` TEXT NULL,
    `review_visible` tinyint(1) NULL DEFAULT '1',
    `review_hide_reason` varchar(500) NULL,
    `review_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `review_updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    CONSTRAINT `ck_review_required` CHECK (record_type <> 'REVIEW' OR (`review_booking_id` IS NOT NULL AND `review_reviewer_id` IS NOT NULL AND `review_room_id` IS NOT NULL AND `review_rating` IS NOT NULL AND `review_visible` IS NOT NULL)),
    UNIQUE KEY `uk_activity_records_11` (`review_booking_id`),
    KEY `ix_activity_records_12` (record_type,`review_reviewer_id`),
    KEY `ix_activity_records_13` (record_type,`review_room_id`,`review_visible`,`review_created_at`),
    `report_reporter_id` bigint NULL,
    `report_target_type` varchar(50) NULL,
    `report_target_id` bigint NULL,
    `report_reason_code` varchar(50) NULL,
    `report_description` TEXT NULL,
    `report_status` varchar(20) NULL DEFAULT 'PENDING',
    `report_resolved_by` bigint NULL,
    `report_resolution_note` varchar(1000) NULL,
    `report_resolved_at` datetime(3) NULL,
    `report_created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `report_updated_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    CONSTRAINT `ck_report_required` CHECK (record_type <> 'REPORT' OR (`report_reporter_id` IS NOT NULL AND `report_target_type` IS NOT NULL AND `report_target_id` IS NOT NULL AND `report_reason_code` IS NOT NULL AND `report_status` IS NOT NULL)),
    KEY `ix_activity_records_14` (record_type,`report_resolved_by`),
    KEY `ix_activity_records_15` (record_type,`report_reporter_id`),
    KEY `ix_activity_records_16` (record_type,`report_status`),
    KEY `ix_activity_records_17` (record_type,`report_target_type`,`report_target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

ALTER TABLE `account_records` ADD CONSTRAINT `fk_refresh_user_id` FOREIGN KEY (`refresh_user_id`) REFERENCES `users` (`id`);
ALTER TABLE `account_records` ADD CONSTRAINT `fk_verify_user_id` FOREIGN KEY (`verify_user_id`) REFERENCES `users` (`id`);
ALTER TABLE `account_records` ADD CONSTRAINT `fk_device_user_id` FOREIGN KEY (`device_user_id`) REFERENCES `users` (`id`);
ALTER TABLE `account_records` ADD CONSTRAINT `fk_preference_user_id` FOREIGN KEY (`preference_user_id`) REFERENCES `users` (`id`);
ALTER TABLE `account_records` ADD CONSTRAINT `fk_deletion_user_id` FOREIGN KEY (`deletion_user_id`) REFERENCES `users` (`id`);
ALTER TABLE `account_records` ADD CONSTRAINT `fk_lifecycle_user_id` FOREIGN KEY (`lifecycle_user_id`) REFERENCES `users` (`id`);
ALTER TABLE `catalog_items` ADD CONSTRAINT `fk_fee_listing_id` FOREIGN KEY (`fee_listing_id`) REFERENCES `listings` (`id`);
ALTER TABLE `catalog_items` ADD CONSTRAINT `fk_wishlist_room_id` FOREIGN KEY (`wishlist_room_id`) REFERENCES `rooms` (`id`);
ALTER TABLE `catalog_items` ADD CONSTRAINT `fk_wishlist_user_id` FOREIGN KEY (`wishlist_user_id`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_booking_host_id` FOREIGN KEY (`booking_host_id`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_booking_listing_id` FOREIGN KEY (`booking_listing_id`) REFERENCES `listings` (`id`);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_booking_allocated_payment_id` FOREIGN KEY (`booking_allocated_payment_id`,`booking_allocated_payment_id_kind`) REFERENCES `rental_records` (id,record_type);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_booking_room_id` FOREIGN KEY (`booking_room_id`) REFERENCES `rooms` (`id`);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_booking_tenant_id` FOREIGN KEY (`booking_tenant_id`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_case_booking_id` FOREIGN KEY (`case_booking_id`,`case_booking_id_kind`) REFERENCES `rental_records` (id,record_type);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_case_opened_by` FOREIGN KEY (`case_opened_by`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_case_resolved_by` FOREIGN KEY (`case_resolved_by`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_history_actor_id` FOREIGN KEY (`history_actor_id`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_history_booking_id` FOREIGN KEY (`history_booking_id`,`history_booking_id_kind`) REFERENCES `rental_records` (id,record_type);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_slot_host_id` FOREIGN KEY (`slot_host_id`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_slot_room_id` FOREIGN KEY (`slot_room_id`) REFERENCES `rooms` (`id`);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_viewing_host_id` FOREIGN KEY (`viewing_host_id`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_viewing_room_id` FOREIGN KEY (`viewing_room_id`) REFERENCES `rooms` (`id`);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_viewing_viewing_slot_id` FOREIGN KEY (`viewing_viewing_slot_id`,`viewing_viewing_slot_id_kind`) REFERENCES `rental_records` (id,record_type);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_viewing_tenant_id` FOREIGN KEY (`viewing_tenant_id`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_payment_booking_id` FOREIGN KEY (`payment_booking_id`,`payment_booking_id_kind`) REFERENCES `rental_records` (id,record_type);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_payment_payer_id` FOREIGN KEY (`payment_payer_id`) REFERENCES `users` (`id`);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_refund_payment_id` FOREIGN KEY (`refund_payment_id`,`refund_payment_id_kind`) REFERENCES `rental_records` (id,record_type);
ALTER TABLE `rental_records` ADD CONSTRAINT `fk_webhook_payment_id` FOREIGN KEY (`webhook_payment_id`,`webhook_payment_id_kind`) REFERENCES `rental_records` (id,record_type);
ALTER TABLE `activity_records` ADD CONSTRAINT `fk_notification_user_id` FOREIGN KEY (`notification_user_id`) REFERENCES `users` (`id`);
ALTER TABLE `activity_records` ADD CONSTRAINT `fk_delivery_device_id` FOREIGN KEY (`delivery_device_id`,`delivery_device_id_kind`) REFERENCES `account_records` (id,record_type);
ALTER TABLE `activity_records` ADD CONSTRAINT `fk_delivery_notification_id` FOREIGN KEY (`delivery_notification_id`,`delivery_notification_id_kind`) REFERENCES `activity_records` (id,record_type);
ALTER TABLE `activity_records` ADD CONSTRAINT `fk_audit_actor_id` FOREIGN KEY (`audit_actor_id`) REFERENCES `users` (`id`);
ALTER TABLE `activity_records` ADD CONSTRAINT `fk_review_reviewer_id` FOREIGN KEY (`review_reviewer_id`) REFERENCES `users` (`id`);
ALTER TABLE `activity_records` ADD CONSTRAINT `fk_review_room_id` FOREIGN KEY (`review_room_id`) REFERENCES `rooms` (`id`);
ALTER TABLE `activity_records` ADD CONSTRAINT `fk_report_reporter_id` FOREIGN KEY (`report_reporter_id`) REFERENCES `users` (`id`);
ALTER TABLE `activity_records` ADD CONSTRAINT `fk_report_resolved_by` FOREIGN KEY (`report_resolved_by`) REFERENCES `users` (`id`);

-- Preserve stable IDs for the only pre-existing records: role and amenity dictionaries.
INSERT INTO account_records (id,record_type,version,role_name) SELECT id,'ROLE',0,name FROM roles;
INSERT INTO catalog_items (id,record_type,amenity_name,amenity_icon,amenity_category) SELECT id,'AMENITY',name,icon,category FROM amenities;
ALTER TABLE `user_roles` DROP FOREIGN KEY `fk_user_roles_role`, ADD COLUMN `role_id_kind` VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'ROLE', ADD CONSTRAINT `ck_user_roles_kind` CHECK (`role_id_kind`='ROLE'), ADD CONSTRAINT `fk_user_roles_typed` FOREIGN KEY (`role_id`,`role_id_kind`) REFERENCES `account_records` (id,record_type);
ALTER TABLE `room_amenities` DROP FOREIGN KEY `fk_room_amenities_amenity`, ADD COLUMN `amenity_id_kind` VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'AMENITY', ADD CONSTRAINT `ck_room_amenities_kind` CHECK (`amenity_id_kind`='AMENITY'), ADD CONSTRAINT `fk_room_amenities_typed` FOREIGN KEY (`amenity_id`,`amenity_id_kind`) REFERENCES `catalog_items` (id,record_type);
ALTER TABLE `account_deletion_requests` DROP FOREIGN KEY `fk_deletion_requests_user`;
ALTER TABLE `account_lifecycle_locks` DROP FOREIGN KEY `fk_account_lifecycle_user`;
ALTER TABLE `audit_logs` DROP FOREIGN KEY `fk_audit_actor`;
ALTER TABLE `booking_cases` DROP FOREIGN KEY `fk_cases_booking`;
ALTER TABLE `booking_cases` DROP FOREIGN KEY `fk_cases_opener`;
ALTER TABLE `booking_cases` DROP FOREIGN KEY `fk_cases_resolver`;
ALTER TABLE `booking_status_history` DROP FOREIGN KEY `fk_booking_history_actor`;
ALTER TABLE `booking_status_history` DROP FOREIGN KEY `fk_booking_history_booking`;
ALTER TABLE `bookings` DROP FOREIGN KEY `fk_bookings_host`;
ALTER TABLE `bookings` DROP FOREIGN KEY `fk_bookings_listing`;
ALTER TABLE `bookings` DROP FOREIGN KEY `fk_bookings_payment`;
ALTER TABLE `bookings` DROP FOREIGN KEY `fk_bookings_room`;
ALTER TABLE `bookings` DROP FOREIGN KEY `fk_bookings_tenant`;
ALTER TABLE `case_evidence` DROP FOREIGN KEY `fk_evidence_case`;
ALTER TABLE `case_evidence` DROP FOREIGN KEY `fk_evidence_media`;
ALTER TABLE `case_evidence` DROP FOREIGN KEY `fk_evidence_uploader`;
ALTER TABLE `device_tokens` DROP FOREIGN KEY `fk_device_tokens_user`;
ALTER TABLE `listing_fees` DROP FOREIGN KEY `fk_listing_fees_listing`;
ALTER TABLE `listing_status_history` DROP FOREIGN KEY `fk_listing_history_actor`;
ALTER TABLE `listing_status_history` DROP FOREIGN KEY `fk_listing_history_listing`;
ALTER TABLE `notification_preferences` DROP FOREIGN KEY `fk_notification_prefs_user`;
ALTER TABLE `notifications` DROP FOREIGN KEY `fk_notifications_user`;
ALTER TABLE `one_time_tokens` DROP FOREIGN KEY `fk_one_time_tokens_user`;
ALTER TABLE `payment_webhook_receipts` DROP FOREIGN KEY `fk_webhook_payment`;
ALTER TABLE `payments` DROP FOREIGN KEY `fk_payments_booking`;
ALTER TABLE `payments` DROP FOREIGN KEY `fk_payments_payer`;
ALTER TABLE `push_deliveries` DROP FOREIGN KEY `fk_push_device`;
ALTER TABLE `push_deliveries` DROP FOREIGN KEY `fk_push_notification`;
ALTER TABLE `refresh_tokens` DROP FOREIGN KEY `fk_refresh_tokens_user`;
ALTER TABLE `refunds` DROP FOREIGN KEY `fk_refunds_payment`;
ALTER TABLE `reports` DROP FOREIGN KEY `fk_reports_reporter`;
ALTER TABLE `reports` DROP FOREIGN KEY `fk_reports_resolver`;
ALTER TABLE `reviews` DROP FOREIGN KEY `fk_reviews_reviewer`;
ALTER TABLE `reviews` DROP FOREIGN KEY `fk_reviews_room`;
ALTER TABLE `viewing_slots` DROP FOREIGN KEY `fk_viewing_slots_host`;
ALTER TABLE `viewing_slots` DROP FOREIGN KEY `fk_viewing_slots_room`;
ALTER TABLE `viewing_status_history` DROP FOREIGN KEY `fk_viewing_history_actor`;
ALTER TABLE `viewing_status_history` DROP FOREIGN KEY `fk_viewing_history_viewing`;
ALTER TABLE `viewings` DROP FOREIGN KEY `fk_viewings_host`;
ALTER TABLE `viewings` DROP FOREIGN KEY `fk_viewings_room`;
ALTER TABLE `viewings` DROP FOREIGN KEY `fk_viewings_slot`;
ALTER TABLE `viewings` DROP FOREIGN KEY `fk_viewings_tenant`;
ALTER TABLE `wishlist_items` DROP FOREIGN KEY `fk_wishlist_room`;
ALTER TABLE `wishlist_items` DROP FOREIGN KEY `fk_wishlist_user`;

-- All tables below were checked empty, except the dictionaries copied above.
DROP TABLE `account_deletion_requests`,`account_lifecycle_locks`,`amenities`,`audit_logs`,`booking_cases`,`booking_status_history`,`bookings`,`case_evidence`,`device_tokens`,`idempotency_keys`,`listing_fees`,`listing_status_history`,`notification_preferences`,`notifications`,`one_time_tokens`,`payment_webhook_receipts`,`payments`,`push_deliveries`,`refresh_tokens`,`refunds`,`reports`,`reviews`,`roles`,`viewing_slots`,`viewing_status_history`,`viewings`,`wishlist_items`;
