package com.homely.rental.auth.entity;

import com.homely.rental.common.persistence.AccountRecord;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;

/** A separate lock row keeps account lifecycle locks away from user foreign keys. */
@Entity
@DiscriminatorValue("LIFECYCLE_LOCK")
@Getter
@NoArgsConstructor
public class AccountLifecycleLock extends AccountRecord {

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "lifecycle_user_id")
    private User user;

    public AccountLifecycleLock(User user) { this.user = user; }
}
