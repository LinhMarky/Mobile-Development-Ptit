package com.homely.rental.auth.entity;

import com.homely.rental.common.persistence.AccountRecord;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * User notification preferences (AUTH11).
 * Tracks which notification channels the user has enabled.
 */
@Entity
@DiscriminatorValue("PREFERENCES")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class NotificationPreference extends AccountRecord {

    @OneToOne(fetch = FetchType.LAZY)
    @com.fasterxml.jackson.annotation.JsonIgnore
    @JoinColumn(name = "preference_user_id", nullable = true)
    private User user;

    @Column(name = "transaction_push", nullable = true)
    private boolean transactionPush = true;

    @Column(name = "transaction_email", nullable = true)
    private boolean transactionEmail = true;

    @Column(name = "chat_push", nullable = true)
    private boolean chatPush = true;

    @Column(name = "recommendation_push", nullable = true)
    private boolean recommendationPush = true;

    @Column(name = "created_at", updatable = false)
    @com.fasterxml.jackson.annotation.JsonIgnore
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at")
    @com.fasterxml.jackson.annotation.JsonIgnore
    private Instant updatedAt = Instant.now();
}
