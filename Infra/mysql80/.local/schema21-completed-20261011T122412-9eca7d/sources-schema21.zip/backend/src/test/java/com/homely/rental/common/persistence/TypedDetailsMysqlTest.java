package com.homely.rental.common.persistence;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import java.sql.*;
import java.util.*;
import static org.assertj.core.api.Assertions.*;

/** Upgrade a populated V20; compare every moved property and every retained relational column. */
@EnabledIfEnvironmentVariable(named="HOMELY_SCHEMA21_UPGRADE_URL", matches=".+roomly_schema21_upgrade.*")
class TypedDetailsMysqlTest {
    private static final ObjectMapper JSON = new ObjectMapper();

    @Test void upgradePreservesAllValuesCursorsAndConstraints() throws Exception {
        String url=System.getenv("HOMELY_SCHEMA21_UPGRADE_URL");
        String user=System.getenv().getOrDefault("HOMELY_TEST_MYSQL_USER","root");
        String password=System.getenv().getOrDefault("HOMELY_TEST_MYSQL_PASSWORD","");
        Flyway.configure().dataSource(url,user,password).target("19").cleanDisabled(true).load().migrate();
        JsonNode fixture=resource("v19-upgrade-fixture.json");
        try (var connection=DriverManager.getConnection(url,user,password); var sql=connection.createStatement()) {
            for (JsonNode row:fixture.get("rows")) SchemaSimplificationMysqlTest.insert(connection,row);
            sql.executeUpdate("UPDATE rental_records SET booking_allocated_payment_id="+fixture.get("payment_id").asLong()+" WHERE id="+fixture.get("booking_id").asLong());
            sql.executeUpdate("UPDATE read_markers r JOIN conversations c ON c.id=r.conversation_id SET r.last_read_sequence=IF(r.user_id=c.host_id,1,0)");
            Flyway.configure().dataSource(url,user,password).target("20").cleanDisabled(true).load().migrate();
            for (String table:List.of("account_records","catalog_items","rental_records","activity_records","conversations"))
                sql.execute("ALTER TABLE "+table+" AUTO_INCREMENT=5000");
            var projections=resource("v21-upgrade-projections.json");
            var before=snapshot(connection,projections,"before");
            Flyway.configure().dataSource(url,user,password).cleanDisabled(true).load().migrate();
            assertThat(snapshot(connection,projections,"after")).isEqualTo(before);
            try(var rows=sql.executeQuery("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type='BASE TABLE'")) {
                rows.next(); assertThat(rows.getInt(1)).isEqualTo(13);
            }
            for(String table:List.of("account_records","catalog_items","rental_records","activity_records","conversations")) {
                try(var rows=sql.executeQuery("SELECT AUTO_INCREMENT FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='"+table+"'")) {
                    rows.next(); assertThat(rows.getLong(1)).isGreaterThanOrEqualTo(5000);
                }
            }
            // Validation must reject malformed data, missing required fields and unknown keys.
            for(String invalid:List.of("NULL","'{}'","JSON_OBJECT('schemaVersion',2,'title','bad')",
                    "JSON_OBJECT('schemaVersion',1,'title',123)","JSON_OBJECT('schemaVersion',1,'title','ok','extra',true)"))
                assertThatThrownBy(()->sql.executeUpdate("UPDATE activity_records SET details="+invalid+" WHERE record_type='NOTIFICATION'"))
                        .as(invalid).isInstanceOf(SQLException.class);
            assertThatThrownBy(()->sql.executeUpdate("UPDATE conversations SET host_read_sequence=sequence+1"))
                    .isInstanceOf(SQLException.class);
            assertThatThrownBy(()->sql.executeUpdate("INSERT INTO user_roles(user_id,role_id) SELECT 1,id FROM account_records WHERE record_type='LIFECYCLE_LOCK' LIMIT 1"))
                    .isInstanceOf(SQLException.class);
        }
    }

    private static JsonNode resource(String name) throws Exception {
        try(var input=TypedDetailsMysqlTest.class.getResourceAsStream("/schema/"+name)) {
            return JSON.readTree(Objects.requireNonNull(input));
        }
    }
    private static Map<String,List<List<String>>> snapshot(Connection connection,JsonNode projections,String stage) throws Exception {
        var result=new LinkedHashMap<String,List<List<String>>>();
        for(var entry:projections.properties())
            result.put(entry.getKey(),SchemaSimplificationMysqlTest.read(connection,entry.getValue().get(stage).asText()));
        return result;
    }
}
