package com.homely.rental.common.persistence;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.homely.rental.common.persistence.details.PaymentDetails;
import org.junit.jupiter.api.Test;
import java.time.Instant;
import static org.assertj.core.api.Assertions.*;

class DetailsSerializationTest {
    @Test void paymentJsonPreservesFalseFlagAndUtcTimeUnderTheStoredKeys() throws Exception {
        ObjectMapper mapper = new ObjectMapper().findAndRegisterModules();
        PaymentDetails details = new PaymentDetails();
        details.setTest(false);
        details.setSucceededAt(Instant.parse("2026-09-01T08:09:10.123Z"));
        var json = mapper.readTree(mapper.writeValueAsString(details));
        assertThat(json.get("isTest").booleanValue()).isFalse();
        assertThat(json.has("test")).isFalse();
        assertThat(json.get("succeededAt").asText()).isEqualTo("2026-09-01T08:09:10.123Z");
        assertThat(mapper.treeToValue(json, PaymentDetails.class)).isEqualTo(details);
    }
}
