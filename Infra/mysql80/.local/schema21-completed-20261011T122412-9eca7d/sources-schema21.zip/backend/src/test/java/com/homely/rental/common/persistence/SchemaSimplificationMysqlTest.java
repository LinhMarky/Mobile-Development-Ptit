package com.homely.rental.common.persistence;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.*;

import static org.assertj.core.api.Assertions.*;

/** Upgrade a populated V19 in an isolated schema, including cross-table cycles and Unicode. */
@EnabledIfEnvironmentVariable(named = "HOMELY_SCHEMA20_UPGRADE_URL", matches = ".+roomly_schema20_upgrade.*")
class SchemaSimplificationMysqlTest {
    private static final ObjectMapper JSON = new ObjectMapper();

    @Test void populatedV19KeepsEntityValuesIdsVersionsRelationshipsAndIdentityCounters() throws Exception {
        String url = System.getenv("HOMELY_SCHEMA20_UPGRADE_URL");
        String user = System.getenv().getOrDefault("HOMELY_TEST_MYSQL_USER", "root");
        String password = System.getenv().getOrDefault("HOMELY_TEST_MYSQL_PASSWORD", "");
        Flyway.configure().dataSource(url, user, password).cleanDisabled(true)
                .baselineOnMigrate(false).target("19").load().migrate();
        JsonNode fixture;
        try (var stream = getClass().getResourceAsStream("/schema/v19-upgrade-fixture.json")) {
            fixture = JSON.readTree(Objects.requireNonNull(stream));
        }
        try (var connection = DriverManager.getConnection(url, user, password)) {
            for (JsonNode row : fixture.get("rows")) insert(connection, row);
            try (var sql = connection.createStatement()) {
                sql.executeUpdate("UPDATE rental_records SET booking_allocated_payment_id=" + fixture.get("payment_id").asLong()
                        + " WHERE id=" + fixture.get("booking_id").asLong());
                for (JsonNode table : fixture.get("roots")) {
                    sql.execute("ALTER TABLE " + identifier(table.asText()) + " AUTO_INCREMENT=5000");
                }
            }
            var beforeEntities = entities(connection, fixture, false);
            var beforeOtherTables = untouched(connection, fixture);
            Flyway.configure().dataSource(url, user, password).cleanDisabled(true)
                    .baselineOnMigrate(false).target("20").load().migrate();
            assertThat(entities(connection, fixture, true)).isEqualTo(beforeEntities);
            assertThat(untouched(connection, fixture)).isEqualTo(beforeOtherTables);
            try (var sql = connection.createStatement()) {
                try (var result = sql.executeQuery("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type='BASE TABLE'")) {
                    result.next(); assertThat(result.getInt(1)).isEqualTo(14);
                }
                Map<String, Integer> expectedColumns = Map.of("account_records", 31, "catalog_items", 15,
                        "rental_records", 82, "activity_records", 48);
                for (var entry : expectedColumns.entrySet()) {
                    try (var result = sql.executeQuery("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='" + entry.getKey() + "'")) {
                        result.next(); assertThat(result.getInt(1)).as(entry.getKey()).isEqualTo(entry.getValue());
                    }
                    try (var result = sql.executeQuery("SELECT AUTO_INCREMENT FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='" + entry.getKey() + "'")) {
                        result.next(); assertThat(result.getLong(1)).isGreaterThanOrEqualTo(5000);
                    }
                }
                // Migration must preserve refresh history on the same installation and token purposes.
                try (var result = sql.executeQuery("SELECT COUNT(*) FROM account_records WHERE record_type='REFRESH_TOKEN'")) {
                    result.next(); assertThat(result.getInt(1)).isEqualTo(2);
                }
                assertThatThrownBy(() -> sql.executeUpdate("INSERT INTO account_records(record_type,token_hash,user_id,installation_id,device_name,expires_at) "
                        + "SELECT record_type,token_hash,user_id,installation_id,device_name,expires_at FROM account_records WHERE record_type='REFRESH_TOKEN' LIMIT 1"))
                        .isInstanceOf(SQLException.class);
                assertThatThrownBy(() -> sql.executeUpdate("INSERT INTO user_roles(user_id,role_id) "
                        + "SELECT 1,id FROM account_records WHERE record_type='LIFECYCLE_LOCK' LIMIT 1"))
                        .isInstanceOf(SQLException.class);
            }
        }
    }

    private static String identifier(String name) {
        if (!name.matches("[a-z_][a-z0-9_]*")) throw new IllegalArgumentException("Invalid fixture identifier");
        return "`" + name + "`";
    }

    static void insert(Connection connection, JsonNode row) throws Exception {
        var fields = new ArrayList<String>();
        row.get("values").fieldNames().forEachRemaining(fields::add);
        String columns = String.join(",", fields.stream().map(SchemaSimplificationMysqlTest::identifier).toList());
        String placeholders = String.join(",", Collections.nCopies(fields.size(), "?"));
        try (var sql = connection.prepareStatement("INSERT INTO " + identifier(row.get("table").asText())
                + "(" + columns + ") VALUES(" + placeholders + ")")) {
            for (int index = 0; index < fields.size(); index++) {
                JsonNode value = row.get("values").get(fields.get(index));
                if (value.isObject() && value.has("hex")) sql.setBytes(index + 1, HexFormat.of().parseHex(value.get("hex").asText()));
                else sql.setObject(index + 1, value.isNull() ? null : value.isNumber() ? value.numberValue() : value.asText());
            }
            sql.executeUpdate();
        }
    }

    private static Map<String, List<List<String>>> entities(Connection connection, JsonNode fixture, boolean after) throws Exception {
        var result = new LinkedHashMap<String, List<List<String>>>();
        for (var entry : fixture.get("projections").properties()) {
            var fields = new ArrayList<String>();
            fields.add("id");
            if (!entry.getValue().get("table").asText().equals("catalog_items")) fields.add("version");
            for (var column : entry.getValue().get("columns").properties()) fields.add(after ? column.getValue().asText() : column.getKey());
            String query = "SELECT " + String.join(",", fields.stream().map(SchemaSimplificationMysqlTest::identifier).toList())
                    + " FROM " + identifier(entry.getValue().get("table").asText()) + " WHERE record_type='" + entry.getKey() + "' ORDER BY id";
            result.put(entry.getKey(), read(connection, query));
        }
        return result;
    }

    private static Map<String, List<List<String>>> untouched(Connection connection, JsonNode fixture) throws Exception {
        var result = new LinkedHashMap<String, List<List<String>>>();
        for (JsonNode table : fixture.get("untouched_tables")) {
            result.put(table.asText(), read(connection, "SELECT * FROM " + identifier(table.asText()) + " ORDER BY 1,2"));
        }
        return result;
    }

    static List<List<String>> read(Connection connection, String query) throws SQLException {
        var values = new ArrayList<List<String>>();
        try (var sql = connection.createStatement(); var rows = sql.executeQuery(query)) {
            while (rows.next()) {
                var row = new ArrayList<String>();
                for (int index = 1; index <= rows.getMetaData().getColumnCount(); index++) {
                    Object value = rows.getObject(index);
                    row.add(value instanceof byte[] bytes ? HexFormat.of().formatHex(bytes) : value == null ? null : value.toString());
                }
                values.add(row);
            }
        }
        return values;
    }
}
