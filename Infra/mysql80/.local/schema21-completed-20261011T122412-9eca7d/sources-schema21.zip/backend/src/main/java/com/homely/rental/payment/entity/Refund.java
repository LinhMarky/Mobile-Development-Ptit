package com.homely.rental.payment.entity;

import com.homely.rental.common.persistence.RentalRecord;

import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.RefundDetails;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@DiscriminatorValue("REFUND")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Refund extends RentalRecord {

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "refund_payment_id", nullable = true)
    private Payment payment;

    @Column(name = "provider_refund_id", length = 100)
    private String providerRefundId;

    @Column(name = "amount_vnd", precision = 18, scale = 0, nullable = true)
    private BigDecimal amountVnd;

    @Enumerated(EnumType.STRING)
    @Column(name = "refund_reason", length = 30)
    private RefundReason reason;

    @Enumerated(EnumType.STRING)
    @Column(name = "refund_status", length = 20, nullable = true)
    private RefundStatus status = RefundStatus.PENDING;

    @Column(name = "attempt_count", nullable = true)
    private int attemptCount = 0;

    @Column(name = "next_attempt_at")
    private Instant nextAttemptAt;



    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at")
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private RefundDetails details = new RefundDetails();

    public String getLastErrorCode() { return details.getLastErrorCode(); }
    public void setLastErrorCode(String value) { details.setLastErrorCode(value); }

    public Instant getCompletedAt() { return details.getCompletedAt(); }
    public void setCompletedAt(Instant value) { details.setCompletedAt(value); }
}
