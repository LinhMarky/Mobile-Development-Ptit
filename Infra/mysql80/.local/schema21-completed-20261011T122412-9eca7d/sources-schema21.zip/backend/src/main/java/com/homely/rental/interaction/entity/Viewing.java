package com.homely.rental.interaction.entity;

import com.homely.rental.common.persistence.RentalRecord;

import com.homely.rental.auth.entity.User;
import com.homely.rental.catalog.entity.Room;
import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.ViewingDetails;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("VIEWING")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Viewing extends RentalRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "viewing_slot_id", nullable = true)
    private ViewingSlot viewingSlot;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tenant_id", nullable = true)
    private User tenant;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "room_id", nullable = true)
    private Room room;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "host_id", nullable = true)
    private User host;

    @Enumerated(EnumType.STRING)
    @Column(name = "viewing_status", length = 30, nullable = true)
    private ViewingStatus status = ViewingStatus.REQUESTED;




    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at")
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private ViewingDetails details = new ViewingDetails();

    public String getNote() { return details.getNote(); }
    public void setNote(String value) { details.setNote(value); }

    public String getCancelledReason() { return details.getCancelledReason(); }
    public void setCancelledReason(String value) { details.setCancelledReason(value); }

    public Instant getCompletedAt() { return details.getCompletedAt(); }
    public void setCompletedAt(Instant value) { details.setCompletedAt(value); }
}
