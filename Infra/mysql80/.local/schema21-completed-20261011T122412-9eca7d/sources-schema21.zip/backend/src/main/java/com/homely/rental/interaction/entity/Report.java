package com.homely.rental.interaction.entity;

import com.homely.rental.common.persistence.ActivityRecord;

import com.homely.rental.auth.entity.User;
import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.ReportDetails;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("REPORT")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Report extends ActivityRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "actor_id", nullable = true)
    private User reporter;

    /** "listing", "review", "message", "user" */
    @Column(name = "target_type", length = 50, nullable = true)
    private String targetType;

    @Column(name = "target_id", nullable = true)
    private Long targetId;

    /** SPAM, SCAM, INAPPROPRIATE, DUPLICATE, OTHER */
    @Column(name = "reason_code", length = 50, nullable = true)
    private String reasonCode;


    @Enumerated(EnumType.STRING)
    @Column(name = "report_status", length = 20, nullable = true)
    private ReportStatus status = ReportStatus.PENDING;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "resolved_by")
    private User resolvedBy;



    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at")
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private ReportDetails details = new ReportDetails();

    public String getDescription() { return details.getDescription(); }
    public void setDescription(String value) { details.setDescription(value); }

    public String getResolutionNote() { return details.getResolutionNote(); }
    public void setResolutionNote(String value) { details.setResolutionNote(value); }

    public Instant getResolvedAt() { return details.getResolvedAt(); }
    public void setResolvedAt(Instant value) { details.setResolvedAt(value); }
}
