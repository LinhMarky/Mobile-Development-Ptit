package com.homely.rental.auth.entity;

import com.homely.rental.common.persistence.AccountRecord;

import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.DeviceTokenDetails;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * Stores FCM device tokens for push notifications (AUTH10).
 */
@Entity
@DiscriminatorValue("DEVICE_TOKEN")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DeviceToken extends AccountRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "device_user_id", nullable = true)
    private User user;

    @Column(name = "fcm_token", length = 4096, nullable = true, columnDefinition = "TEXT")
    private String token;

    @Enumerated(EnumType.STRING)
    @Column(name = "platform", length = 10, nullable = true)
    private Platform platform = Platform.ANDROID;


    @Column(name = "installation_id", length = 36, nullable = true)
    private String installationId;

    @Column(name = "device_active")
    private boolean active = true;

    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at")
    private Instant updatedAt = Instant.now();

    public enum Platform {
        ANDROID
    }

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private DeviceTokenDetails details = new DeviceTokenDetails();

    public String getDeviceName() { return details.getDeviceName(); }
    public void setDeviceName(String value) { details.setDeviceName(value); }
}
