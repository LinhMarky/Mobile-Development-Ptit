package com.homely.rental.notification.push;

import com.homely.rental.common.persistence.ActivityRecord;
import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.PushDeliveryDetails;
import lombok.*;
import java.time.Instant;
@Entity @DiscriminatorValue("PUSH_DELIVERY")
@Getter @Setter @NoArgsConstructor
public class PushDelivery extends ActivityRecord {

    @Column(name = "notification_id",nullable = true) private Long notificationId;
    @Column(name = "device_id",nullable = true) private Long deviceId;
    @Column(name = "delivery_status", nullable = true,length=20) private String status="PENDING";
    @Column(name = "attempts", nullable = true) private int attempts;
    @Column(name = "next_attempt_at",nullable = true) private Instant nextAttemptAt=Instant.now();
    @Column(name = "created_at",nullable = true) private Instant createdAt=Instant.now();


    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private PushDeliveryDetails details = new PushDeliveryDetails();

    public String getLastError() { return details.getLastError(); }
    public void setLastError(String value) { details.setLastError(value); }
}
