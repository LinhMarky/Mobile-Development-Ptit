package com.homely.rental.payment.entity;

import com.homely.rental.common.persistence.RentalRecord;

import com.homely.rental.auth.entity.User;
import com.homely.rental.booking.entity.Booking;
import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.PaymentDetails;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@DiscriminatorValue("PAYMENT")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Payment extends RentalRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "booking_id", nullable = true)
    private Booking booking;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payer_id", nullable = true)
    private User payer;

    @Enumerated(EnumType.STRING)
    @Column(name = "provider", length = 20, nullable = true)
    private PaymentProvider provider = PaymentProvider.MOCK_SANDBOX;

    @Column(name = "provider_payment_id", length = 100)
    private String providerPaymentId;

    @Column(name = "amount_vnd", precision = 18, scale = 0, nullable = true)
    private BigDecimal amountVnd;

    @Column(name = "currency", columnDefinition = "CHAR(3)", nullable = true)
    private String currency = "VND";

    @Enumerated(EnumType.STRING)
    @Column(name = "payment_status", length = 20, nullable = true)
    private PaymentStatus status = PaymentStatus.PENDING;

    @Column(name = "expires_at", nullable = true)
    private Instant expiresAt;




    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at")
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private PaymentDetails details = new PaymentDetails();

    public Instant getSucceededAt() { return details.getSucceededAt(); }
    public void setSucceededAt(Instant value) { details.setSucceededAt(value); }

    public String getFailureCode() { return details.getFailureCode(); }
    public void setFailureCode(String value) { details.setFailureCode(value); }

    public boolean isTest() { return details.isTest(); }
    public void setTest(boolean value) { details.setTest(value); }
}
