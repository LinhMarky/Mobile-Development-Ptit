package com.homely.rental.booking.entity;

import com.homely.rental.common.persistence.RentalRecord;

import com.homely.rental.auth.entity.User;
import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.BookingCaseDetails;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("BOOKING_CASE")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class BookingCase extends RentalRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "booking_id", nullable = true)
    private Booking booking;

    @Enumerated(EnumType.STRING)
    @Column(name = "case_type", length = 30, nullable = true)
    private BookingCaseType type;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "opened_by")
    private User openedBy;


    @Enumerated(EnumType.STRING)
    @Column(name = "case_status", length = 20, nullable = true)
    private CaseStatus status = CaseStatus.OPEN;

    @Enumerated(EnumType.STRING)
    @Column(name = "case_decision", length = 30)
    private BookingCaseDecision decision;
    @Column(name = "tenant_refund_vnd", precision=18, scale=0)
    private java.math.BigDecimal tenantRefundVnd;
    @Column(name = "host_retained_vnd", precision=18, scale=0)
    private java.math.BigDecimal hostRetainedVnd;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "resolved_by")
    private User resolvedBy;


    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at")
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private BookingCaseDetails details = new BookingCaseDetails();

    public String getDescription() { return details.getDescription(); }
    public void setDescription(String value) { details.setDescription(value); }

    public String getResolutionNote() { return details.getResolutionNote(); }
    public void setResolutionNote(String value) { details.setResolutionNote(value); }

    public Instant getResolvedAt() { return details.getResolvedAt(); }
    public void setResolvedAt(Instant value) { details.setResolvedAt(value); }
}
