package com.homely.rental.common.persistence;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

/** Shared storage with common columns; concrete repositories keep business types separate. */
@Entity
@Table(name = "account_records", uniqueConstraints = {
        @UniqueConstraint(name = "uk_account_kind_role_name", columnNames = {"record_type", "role_name"}),
        @UniqueConstraint(name = "uk_account_kind_device_user_id_installation_id", columnNames = {"record_type", "device_user_id", "installation_id"}),
        @UniqueConstraint(name = "uk_account_kind_preference_user_id", columnNames = {"record_type", "preference_user_id"}),
        @UniqueConstraint(name = "uk_account_kind_deletion_user_id", columnNames = {"record_type", "deletion_user_id"}),
        @UniqueConstraint(name = "uk_account_kind_lifecycle_user_id", columnNames = {"record_type", "lifecycle_user_id"}),
        @UniqueConstraint(name = "uk_account_kind_token_hash", columnNames = {"record_type", "token_hash"})
})
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "record_type", length = 32)
@org.hibernate.annotations.Check(constraints = """
        record_type IN ('ROLE','REFRESH_TOKEN','ONE_TIME_TOKEN','DEVICE_TOKEN','PREFERENCES','DELETION_REQUEST','LIFECYCLE_LOCK')
        AND (record_type <> 'ROLE' OR (role_name IS NOT NULL))
        AND (record_type <> 'REFRESH_TOKEN' OR (token_hash IS NOT NULL AND user_id IS NOT NULL AND installation_id IS NOT NULL AND details IS NOT NULL AND expires_at IS NOT NULL AND revoked IS NOT NULL))
        AND (record_type <> 'ONE_TIME_TOKEN' OR (token_hash IS NOT NULL AND user_id IS NOT NULL AND token_purpose IS NOT NULL AND used IS NOT NULL AND expires_at IS NOT NULL))
        AND (record_type <> 'DEVICE_TOKEN' OR (device_user_id IS NOT NULL AND fcm_token IS NOT NULL AND platform IS NOT NULL AND details IS NOT NULL AND installation_id IS NOT NULL AND device_active IS NOT NULL))
        AND (record_type <> 'PREFERENCES' OR (preference_user_id IS NOT NULL AND details IS NOT NULL AND details IS NOT NULL AND details IS NOT NULL AND details IS NOT NULL))
        AND (record_type <> 'DELETION_REQUEST' OR (deletion_user_id IS NOT NULL AND details IS NOT NULL AND deletion_status IS NOT NULL))
        AND (record_type <> 'LIFECYCLE_LOCK' OR (lifecycle_user_id IS NOT NULL))
        """)
@Getter
@Setter
public abstract class AccountRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;
}
