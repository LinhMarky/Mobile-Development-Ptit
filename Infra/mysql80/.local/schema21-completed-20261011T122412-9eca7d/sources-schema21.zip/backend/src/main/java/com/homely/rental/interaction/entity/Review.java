package com.homely.rental.interaction.entity;

import com.homely.rental.common.persistence.ActivityRecord;

import com.homely.rental.auth.entity.User;
import com.homely.rental.catalog.entity.Room;
import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.ReviewDetails;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("REVIEW")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Review extends ActivityRecord {

    /** One review per booking — UNIQUE constraint in DB */
    @Column(name = "booking_id", nullable = true)
    private Long bookingId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "actor_id", nullable = true)
    private User reviewer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "room_id", nullable = true)
    private Room room;

    @Column(name = "rating", nullable = true)
    private int rating; // 1–5


    @Column(name = "visible", nullable = true)
    private boolean visible = true;


    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at")
    private Instant updatedAt = Instant.now();

    @PreUpdate
    void onUpdate() { this.updatedAt = Instant.now(); }

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private ReviewDetails details = new ReviewDetails();

    public String getComment() { return details.getComment(); }
    public void setComment(String value) { details.setComment(value); }

    public String getHideReason() { return details.getHideReason(); }
    public void setHideReason(String value) { details.setHideReason(value); }
}
