package com.homely.rental.common.persistence.details;

import lombok.Data;
import java.time.Instant;
import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonFormat;

/** Only optional display/history data. Version 1 is validated by MySQL JSON Schema. */
@Data
public class PaymentDetails {
    private int schemaVersion = 1;
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant succeededAt;
    private String failureCode;
    private boolean isTest = true;

    // Keep the stored key explicit: JavaBeans otherwise calls this property "test".
    @com.fasterxml.jackson.annotation.JsonProperty("isTest")
    public boolean isTest() { return isTest; }

    @com.fasterxml.jackson.annotation.JsonProperty("isTest")
    public void setTest(boolean value) { isTest = value; }
}
