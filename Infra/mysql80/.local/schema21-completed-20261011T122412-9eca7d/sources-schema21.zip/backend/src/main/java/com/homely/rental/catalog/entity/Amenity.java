package com.homely.rental.catalog.entity;

import com.homely.rental.common.persistence.CatalogRecord;

import com.homely.rental.common.entity.AbstractAuditingEntity;
import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.AmenityDetails;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Amenity entity for rooms (CAT14).
 * Represents a facility/feature that can be associated with rooms.
 */
@Entity
@DiscriminatorValue("AMENITY")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Amenity extends CatalogRecord {

    @Column(name = "name", length = 100, nullable = true)
    private String name;


    @Column(name = "category", length = 50)
    private String category;

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private AmenityDetails details = new AmenityDetails();

    public String getIcon() { return details.getIcon(); }
    public void setIcon(String value) { details.setIcon(value); }
}
