package com.homely.rental.common.audit;

import com.homely.rental.common.persistence.ActivityRecord;

import com.homely.rental.auth.entity.User;
import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.AuditLogDetails;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("AUDIT_LOG")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class AuditLog extends ActivityRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "actor_id")
    private User actor;

    @Column(name = "actor_type", length = 20, nullable = true)
    private String actorType;

    @Column(name = "action", length = 100, nullable = true)
    private String action;

    @Column(name = "target_type", length = 50, nullable = true)
    private String targetType;

    @Column(name = "target_id", nullable = true)
    private Long targetId;




    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private AuditLogDetails details = new AuditLogDetails();

    public String getDetail() { return details.getDetail(); }
    public void setDetail(String value) { details.setDetail(value); }

    public String getIpAddress() { return details.getIpAddress(); }
    public void setIpAddress(String value) { details.setIpAddress(value); }

    public String getTraceId() { return details.getTraceId(); }
    public void setTraceId(String value) { details.setTraceId(value); }

    @lombok.Builder
    public static AuditLog create(User actor, String actorType, String action, String targetType,
                                  Long targetId, String detail, String ipAddress, String traceId, Instant createdAt) {
        AuditLog log = new AuditLog();
        log.setActor(actor); log.setActorType(actorType); log.setAction(action);
        log.setTargetType(targetType); log.setTargetId(targetId); log.setDetail(detail);
        log.setIpAddress(ipAddress); log.setTraceId(traceId);
        if (createdAt != null) log.setCreatedAt(createdAt);
        return log;
    }
}
