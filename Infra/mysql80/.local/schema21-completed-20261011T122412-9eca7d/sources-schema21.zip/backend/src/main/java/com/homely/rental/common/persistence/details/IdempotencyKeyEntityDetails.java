package com.homely.rental.common.persistence.details;

import lombok.Data;
import java.time.Instant;
import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonFormat;

/** Only optional display/history data. Version 1 is validated by MySQL JSON Schema. */
@Data
public class IdempotencyKeyEntityDetails {
    private int schemaVersion = 1;
    private String responseContentType;
    private String responseLocation;
    private Integer responseStatusCode;
    private String responseBody;
}
