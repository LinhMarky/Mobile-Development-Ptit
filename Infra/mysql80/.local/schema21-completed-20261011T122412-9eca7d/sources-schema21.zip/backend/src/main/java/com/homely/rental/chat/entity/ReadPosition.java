package com.homely.rental.chat.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Getter;
import java.time.Instant;

/** A member's monotonic cursor, stored with the two-party conversation. */
@Embeddable
@Getter
public class ReadPosition {
    @Column(nullable = false)
    private long sequence;
    private Instant updatedAt;

    public void advanceTo(long requested, Instant now) {
        if (updatedAt == null || requested > sequence) {
            sequence = requested;
            updatedAt = now;
        }
    }
}
