package com.homely.rental.catalog.entity;

import com.homely.rental.common.persistence.CatalogRecord;

import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.ListingFeeDetails;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Listing fee entity (BR-04).
 * Additional fees associated with a listing (electricity, water, internet, etc.)
 */
@Entity
@DiscriminatorValue("LISTING_FEE")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ListingFee extends CatalogRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "listing_id", nullable = true)
    private Listing listing;

    @Column(name = "fee_code", length = 50, nullable = true)
    private String feeCode;

    @Column(name = "fee_mode", length = 20, nullable = true)
    private String feeMode = "FIXED";

    @Column(name = "amount_vnd", precision = 18, scale = 0, nullable = true)
    private BigDecimal amountVnd;



    @Column(name = "sort_order", nullable = true)
    private int sortOrder = 0;

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private ListingFeeDetails details = new ListingFeeDetails();

    public String getUnitName() { return details.getUnitName(); }
    public void setUnitName(String value) { details.setUnitName(value); }

    public String getNote() { return details.getNote(); }
    public void setNote(String value) { details.setNote(value); }
}
