package com.homely.rental.notification.entity;

import com.homely.rental.common.persistence.ActivityRecord;

import com.homely.rental.auth.entity.User;
import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.NotificationDetails;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("NOTIFICATION")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Notification extends ActivityRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = true)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(name = "notification_type", length = 50, nullable = true)
    private NotificationType type;



    /** Reference type: "booking", "viewing", "review", "listing", "message" */
    @Column(name = "ref_type", length = 50)
    private String refType;

    @Column(name = "ref_id")
    private Long refId;

    @Column(name = "is_read", nullable = true)
    private boolean isRead = false;

    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now().truncatedTo(java.time.temporal.ChronoUnit.MILLIS);

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private NotificationDetails details = new NotificationDetails();

    public String getTitle() { return details.getTitle(); }
    public void setTitle(String value) { details.setTitle(value); }

    public String getBody() { return details.getBody(); }
    public void setBody(String value) { details.setBody(value); }
}
