package com.homely.rental.common.persistence;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

/** Shared storage with common columns; concrete repositories keep business types separate. */
@Entity
@Table(name = "activity_records", uniqueConstraints = {
        @UniqueConstraint(name = "uk_activity_kind_booking_id", columnNames = {"record_type", "booking_id"}),
        @UniqueConstraint(name = "uk_activity_kind_notification_id_device_id", columnNames = {"record_type", "notification_id", "device_id"}),
        @UniqueConstraint(name = "uk_activity_kind_idempotency_key", columnNames = {"record_type", "idempotency_key"})
})
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "record_type", length = 32)
@org.hibernate.annotations.Check(constraints = """
        record_type IN ('NOTIFICATION','PUSH_DELIVERY','AUDIT_LOG','IDEMPOTENCY','REVIEW','REPORT')
        AND (record_type <> 'NOTIFICATION' OR (user_id IS NOT NULL AND notification_type IS NOT NULL AND details IS NOT NULL AND is_read IS NOT NULL))
        AND (record_type <> 'PUSH_DELIVERY' OR (notification_id IS NOT NULL AND device_id IS NOT NULL AND delivery_status IS NOT NULL AND attempts IS NOT NULL AND next_attempt_at IS NOT NULL AND created_at IS NOT NULL))
        AND (record_type <> 'AUDIT_LOG' OR (actor_type IS NOT NULL AND action IS NOT NULL AND target_type IS NOT NULL AND target_id IS NOT NULL))
        AND (record_type <> 'IDEMPOTENCY' OR (idempotency_key IS NOT NULL AND request_status IS NOT NULL AND expires_at IS NOT NULL))
        AND (record_type <> 'REVIEW' OR (booking_id IS NOT NULL AND actor_id IS NOT NULL AND room_id IS NOT NULL AND rating IS NOT NULL AND visible IS NOT NULL))
        AND (record_type <> 'REPORT' OR (actor_id IS NOT NULL AND target_type IS NOT NULL AND target_id IS NOT NULL AND reason_code IS NOT NULL AND report_status IS NOT NULL))
        """)
@Getter
@Setter
public abstract class ActivityRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private int version;
}
