package com.homely.rental.booking.entity;

import com.homely.rental.common.persistence.RentalRecord;

import com.homely.rental.auth.entity.User;
import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.BookingStatusHistoryDetails;
import lombok.*;

import java.time.Instant;

@Entity
@DiscriminatorValue("BOOKING_HISTORY")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class BookingStatusHistory extends RentalRecord {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "booking_id", nullable = true)
    private Booking booking;

    @Column(name = "from_status", length = 30)
    private String fromStatus;

    @Column(name = "to_status", length = 30, nullable = true)
    private String toStatus;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "actor_id")
    private User actor;

    @Enumerated(EnumType.STRING)
    @Column(name = "actor_type", length = 20, nullable = true)
    private ActorType actorType;



    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private BookingStatusHistoryDetails details = new BookingStatusHistoryDetails();

    public String getReason() { return details.getReason(); }
    public void setReason(String value) { details.setReason(value); }

    public String getTraceId() { return details.getTraceId(); }
    public void setTraceId(String value) { details.setTraceId(value); }
}
