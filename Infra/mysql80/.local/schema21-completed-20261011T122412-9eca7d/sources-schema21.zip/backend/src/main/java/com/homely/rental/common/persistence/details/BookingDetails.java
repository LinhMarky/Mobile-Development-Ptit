package com.homely.rental.common.persistence.details;

import lombok.Data;
import java.time.Instant;
import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonFormat;

/** Only optional display/history data. Version 1 is validated by MySQL JSON Schema. */
@Data
public class BookingDetails {
    private int schemaVersion = 1;
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private LocalDate desiredMoveIn;
    private String note;
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant tenantTermsAcceptedAt;
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant tenantHandoverConfirmedAt;
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant hostHandoverConfirmedAt;
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant completedAt;
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant cancelledAt;
    private String lastReason;
}
