package com.homely.rental.common.idempotency;

import com.homely.rental.common.persistence.ActivityRecord;

import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.IdempotencyKeyEntityDetails;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * Stores idempotency keys to prevent duplicate processing of POST mutation requests.
 * Key = Idempotency-Key header + principal.id + request_path.
 */
@Entity
@DiscriminatorValue("IDEMPOTENCY")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class IdempotencyKeyEntity extends ActivityRecord {

    /** SHA-256 of principal, HTTP method, request path and client key. */
    @Column(name = "idempotency_key", length = 512, nullable = true)
    private String idempotencyKey;

    @Column(name = "request_hash", length = 64)
    private String requestHash;



    @Enumerated(EnumType.STRING)
    @Column(name = "request_status", length = 20, nullable = true)
    private IdempotencyStatus status = IdempotencyStatus.PROCESSING;



    @Column(name = "expires_at", nullable = true)
    private Instant expiresAt;

    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    public enum IdempotencyStatus {
        PROCESSING,
        COMPLETED
    }

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private IdempotencyKeyEntityDetails details = new IdempotencyKeyEntityDetails();

    public String getResponseContentType() { return details.getResponseContentType(); }
    public void setResponseContentType(String value) { details.setResponseContentType(value); }

    public String getResponseLocation() { return details.getResponseLocation(); }
    public void setResponseLocation(String value) { details.setResponseLocation(value); }

    public Integer getResponseStatusCode() { return details.getResponseStatusCode(); }
    public void setResponseStatusCode(Integer value) { details.setResponseStatusCode(value); }

    public String getResponseBody() { return details.getResponseBody(); }
    public void setResponseBody(String value) { details.setResponseBody(value); }
}
