package com.homely.rental.auth.entity;

import com.homely.rental.common.persistence.AccountRecord;

import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.AccountDeletionRequestDetails;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * Account deletion request entity (§2.8).
 * Tracks user-initiated account deletion with status lifecycle.
 */
@Entity
@DiscriminatorValue("DELETION_REQUEST")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccountDeletionRequest extends AccountRecord {

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "deletion_user_id", nullable = true)
    private User user;


    @Enumerated(EnumType.STRING)
    @Column(name = "deletion_status", length = 20, nullable = true)
    private DeletionStatus status = DeletionStatus.PENDING;



    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at")
    private Instant updatedAt = Instant.now();

    public enum DeletionStatus {
        PENDING,
        PROCESSING,
        COMPLETED,
        FAILED
    }

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private AccountDeletionRequestDetails details = new AccountDeletionRequestDetails();

    public String getReason() { return details.getReason(); }
    public void setReason(String value) { details.setReason(value); }

    public String getFailureCode() { return details.getFailureCode(); }
    public void setFailureCode(String value) { details.setFailureCode(value); }

    public Instant getCompletedAt() { return details.getCompletedAt(); }
    public void setCompletedAt(Instant value) { details.setCompletedAt(value); }
}
