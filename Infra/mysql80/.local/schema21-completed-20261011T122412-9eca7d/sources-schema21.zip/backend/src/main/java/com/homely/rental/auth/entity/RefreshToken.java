package com.homely.rental.auth.entity;

import com.homely.rental.common.persistence.AccountRecord;

import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.RefreshTokenDetails;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * Refresh token entity for session management (SEC-02).
 * Each login creates a new session/refresh token record.
 */
@Entity
@DiscriminatorValue("REFRESH_TOKEN")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RefreshToken extends AccountRecord {

    @Column(name = "token_hash", length = 64, nullable = true)
    private String tokenHash;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = true)
    private User user;

    @Column(name = "installation_id", length = 36, nullable = true)
    private String installationId;


    @Column(name = "expires_at", nullable = true)
    private Instant expiresAt;

    @Column(name = "revoked")
    private boolean revoked = false;

    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private RefreshTokenDetails details = new RefreshTokenDetails();

    public String getDeviceName() { return details.getDeviceName(); }
    public void setDeviceName(String value) { details.setDeviceName(value); }
}
