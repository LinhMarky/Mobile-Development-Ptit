package com.homely.rental.auth.entity;

import com.homely.rental.common.persistence.AccountRecord;

import jakarta.persistence.*;
import com.homely.rental.common.persistence.details.NotificationPreferenceDetails;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * User notification preferences (AUTH11).
 * Tracks which notification channels the user has enabled.
 */
@Entity
@DiscriminatorValue("PREFERENCES")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class NotificationPreference extends AccountRecord {

    @OneToOne(fetch = FetchType.LAZY)
    @com.fasterxml.jackson.annotation.JsonIgnore
    @JoinColumn(name = "preference_user_id", nullable = true)
    private User user;





    @Column(name = "created_at", updatable = false)
    @com.fasterxml.jackson.annotation.JsonIgnore
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at")
    @com.fasterxml.jackson.annotation.JsonIgnore
    private Instant updatedAt = Instant.now();

    /** Versioned presentation/history details; searchable fields remain relational columns. */
    @org.hibernate.annotations.JdbcTypeCode(org.hibernate.type.SqlTypes.JSON)
    @Column(name = "details", columnDefinition = "JSON")
    @com.fasterxml.jackson.annotation.JsonIgnore
    @lombok.Getter(lombok.AccessLevel.NONE)
    @lombok.Setter(lombok.AccessLevel.NONE)
    private NotificationPreferenceDetails details = new NotificationPreferenceDetails();

    public boolean isTransactionPush() { return details.isTransactionPush(); }
    public void setTransactionPush(boolean value) { details.setTransactionPush(value); }

    public boolean isTransactionEmail() { return details.isTransactionEmail(); }
    public void setTransactionEmail(boolean value) { details.setTransactionEmail(value); }

    public boolean isChatPush() { return details.isChatPush(); }
    public void setChatPush(boolean value) { details.setChatPush(value); }

    public boolean isRecommendationPush() { return details.isRecommendationPush(); }
    public void setRecommendationPush(boolean value) { details.setRecommendationPush(value); }
}
