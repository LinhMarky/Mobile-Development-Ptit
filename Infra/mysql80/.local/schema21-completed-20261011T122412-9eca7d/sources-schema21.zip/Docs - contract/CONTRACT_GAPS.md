# Khoảng trống và quyết định còn mở

**Quyết định V21:** Chủ dự án chọn JSON có cấu trúc cho chi tiết phụ, giữ cột/ràng buộc dữ liệu chính và toàn bộ API/chức năng. Schema còn 13 bảng, 243 cột; mô hình lai theo giới hạn dự án, không gọi là 3NF hoàn toàn. Read markers nằm trong hội thoại hai thành viên. Thiết kế hiện tại: [DATABASE.md](DATABASE.md); các mục V19/V20 là lịch sử.

Cập nhật ngày 10/10/2026, đối chiếu code và contract v1.6. File này phân biệt hành vi đã có với chính sách chưa chốt; đề xuất không phải chức năng đã triển khai. Bằng chứng runtime và backlog FE/BE tập trung tại [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md).

**Quyết định schema đã chốt:** Chủ dự án chọn giữ chức năng/API, chấp nhận đổi persistence để còn 14 bảng tổng cộng. Mapping V19 tại [SCHEMA_14_TABLES.md](SCHEMA_14_TABLES.md), không đổi các quyết định nghiệp vụ bên dưới. Giới hạn triển khai: V19 chỉ nhận database chưa có dữ liệu nghiệp vụ; database V18 đã dùng cần một migration dữ liệu riêng, không tự xóa/reset để nâng cấp.

**Tối ưu V20:** Giữ 14 bảng và dữ liệu V19, giảm 46 cột trùng, không đổi API/DTO/enum. V20 đã kiểm thử nâng cấp database có dữ liệu; giới hạn V19 ở trên vẫn áp dụng nếu xuất phát từ V18. Dừng ứng dụng ghi và backup trước đổi schema. Thiết kế dưới 15 bảng vẫn cần bảng chứa nhiều loại bản ghi; đây là đánh đổi đã chốt, không coi ít bảng là chuẩn hóa đầy đủ.

---

## GAP-01: Tác động của `mark-rented` (HOST05) lên Listing Status

- **Trạng thái:** Chưa chốt/triển khai trọn luồng cho thuê ngoài app. Contract liệt kê HOST05/HOST06 (`mark-rented`, `mark-available`) nhưng `RoomController` hiện chỉ có HOST01–HOST04; không coi hai endpoint này đã sẵn sàng cho FE.
- **Mô tả:** Khi bổ sung thao tác đổi availability vì thuê ngoài app, cần quyết định có đổi Listing PUBLISHED sang HIDDEN/ARCHIVED, và xử lý thế nào nếu đang có booking hoặc lịch xem.
- **Tham chiếu:** PROJECT_CONTRACT BR-13, BR-02
- **Hành vi hiện tại:** Search chỉ lấy listing PUBLISHED chưa hết hạn với room AVAILABLE; detail/fees vẫn cho đọc listing PUBLISHED còn hiệu lực của room HELD/RENTED và trả availability. Không tự suy từ việc đổi availability rằng tin đã bị ẩn.
- **Đề xuất chờ chốt:** Giữ trạng thái/terms_version của listing, hiển thị tình trạng phòng và chỉ đưa trở lại search khi AVAILABLE, tin còn hiệu lực và các điều kiện nghiệp vụ được đáp ứng. Phải chốt guard với booking/hold trước khi bổ sung API.

---

## GAP-02: Pagination / Cursor khi load Message cũ nhất trong Chat

- **Trạng thái:** Chưa hỗ trợ neo cửa sổ quanh một sequence/tin chưa đọc.
- **Mô tả:** API hiện hỗ trợ cửa sổ mới nhất, `before_sequence` và `after_sequence`; chưa có `around_sequence`.
- **Tham chiếu:** PROJECT_CONTRACT §7.2, BR-11
- **Quy tắc tích hợp:** Hai cursor loại trừ biên, không dùng cùng lúc; `limit` 1..50, mặc định 20, kết quả ASC. `has_more` theo hướng truy vấn; `next_cursor` chỉ trỏ về tin cũ. HTTP có wrapper: MessagePageDTO ở `response.data`, danh sách tin ở `response.data.data`. Đồng bộ tin mới dùng sequence cuối của danh sách. Chi tiết tại [CHAT.md](CHAT.md).

---

## GAP-03: Tên phòng hiển thị trong hội thoại khi Listing bị xóa

- **Trạng thái:** Đã chốt và triển khai; không còn là backlog mở.
- **Tham chiếu:** PROJECT_CONTRACT §1.8, §2.12
- **Hành vi:** Lưu `room_title` snapshot trong conversation khi tạo. Đổi/ẩn/archive listing không thay title lịch sử. Conversation cũ tiếp tục dùng bởi thành viên ACTIVE; tạo/mở yêu cầu verified, tạo mới cần listing PUBLISHED và `expires_at > now`. Retention giữ lịch sử nghiệp vụ.

---

## GAP-04: Khôi phục listing sau moderation

Listing SUSPENDED không xuất hiện công khai và host không tự submit lại. Chưa có endpoint/quy tắc khôi phục listing bị admin tạm ngưng: cần chốt ai được khôi phục, điều kiện duyệt lại, thời hạn tin và audit trước khi thêm API. Xem [ADMIN_NOTIFICATIONS.md](ADMIN_NOTIFICATIONS.md).

## GAP-05: NO_ACTION với case quá hạn bàn giao

Settlement sandbox đã có: REFUND_TENANT hoàn toàn bộ; FORFEIT_DEPOSIT hoàn 0; SPLIT dùng `tenant_refund_vnd` nguyên, lớn hơn 0 và nhỏ hơn payment. Ba quyết định này yêu cầu booking CONFIRMED/payment đã phân bổ SUCCEEDED, ghi phần hoàn/giữ cọc, chuyển booking CANCELLED và phòng AVAILABLE trong transaction. Chưa chuyển tiền thật.

NO_ACTION chỉ đóng case/ghi kết luận, giữ booking và deadline. Job quá hạn hiện chỉ loại case OPEN/IN_REVIEW; cần tái hiện/chốt việc có mở lại case sau NO_ACTION, hay dùng quy tắc gia hạn/cooldown/đánh dấu đã xét. Không tự đổi NO_ACTION thành hủy booking hoặc refund.

## Ranh giới hiện hành cần giữ khi tích hợp

- **HTTP/STOMP:** HTTP JSON dùng global wrapper `{statusCode,message,data}`, lỗi có ProblemDTO trong `data`. STOMP ACK/message/error dùng DTO trực tiếp. File binary và response không body giữ đúng giao thức.
- **Chat:** Chỉ TEXT, membership và verified theo thao tác; IMAGE/SYSTEM chưa hỗ trợ. Giữ UUID khi retry, deduplicate, đọc REST history sau reconnect. Lỗi chưa có correlation UUID bắt buộc. Simple broker/rate limit nằm trong một process: chạy một backend instance, không cam kết delivery exactly-once qua mạng. Chi tiết tại [CHAT.md](CHAT.md).
- **JWT:** Logout thu hồi refresh session và device theo phạm vi yêu cầu; khóa tài khoản thu hồi refresh session và khiến worker bỏ qua delivery khi tài khoản inactive. Access JWT của tài khoản ACTIVE vẫn theo TTL, mặc định 15 phút. Inactive/pending/deleted/suspended bị kiểm tra từ DB. Mở khóa không hồi sinh refresh session, nhưng chưa có danh sách thu hồi riêng từng access JWT; token cũ còn hạn có thể lại hợp lệ sau mở khóa.
- **Thông báo:** Đã có inbox, MySQL outbox/worker, Firebase Admin gateway, retry/lease/preference/invalid-token handling và producer nghiệp vụ. Không dùng Kafka. Project thật `roomly-6d99d` đã cấu hình PASS runtime local; OAuth và FCM API V1 trả HTTP 200 với `validate_only:true` lúc 17:59:13 ngày 09/10/2026 (giờ Việt Nam). Kiểm tra này không gửi notification. Delivery tới thiết bị và phần ghép Roomly FE vẫn chưa nghiệm thu. Xem [FIREBASE_SETUP.md](FIREBASE_SETUP.md).
- **Khả năng phục hồi và sản phẩm:** Report target/admin queue, media recovery, idempotency reconciliation và các phần FE/BE cần cải thiện vẫn theo [backlog hiện tại](IMPLEMENTATION_STATUS.md). Backup–restore local đã có bằng chứng; không coi đó là nghiệm thu VPS hoặc toàn bộ app.
