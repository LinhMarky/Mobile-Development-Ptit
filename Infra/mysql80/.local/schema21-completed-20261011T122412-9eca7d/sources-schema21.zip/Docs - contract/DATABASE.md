# Database Roomly — hướng dẫn schema V21

Mục tiêu đã chốt: ít hơn 15 bảng, giữ đầy đủ chức năng và API, dữ liệu chính có ràng buộc quan hệ; chi tiết phụ được lưu JSON có cấu trúc. V21 có **13 bảng vật lý: 12 bảng ứng dụng và 1 bảng Flyway**, không dùng view để che bảng. Đây là thiết kế lai theo giới hạn dự án, không phải mô hình chuẩn hóa 3NF hoàn toàn.

## Đọc và xếp database

Sơ đồ kéo/thả tại [DATABASE.drawio](DATABASE.drawio). Mở bằng diagrams.net → File → Open From → Device, chọn file này. Sơ đồ trình bày các cột chính để dễ xếp; cột kỹ thuật và ràng buộc đầy đủ nằm trong DDL xuất từ database.

| Nhóm | Bảng | Vai trò |
| --- | --- | --- |
| Tài khoản | `users` | Hồ sơ và trạng thái tài khoản |
| Tài khoản | `user_roles` | Vai trò được cấp cho tài khoản; giữ khóa ngoại |
| Tài khoản | `account_records` | Vai trò, phiên đăng nhập, thiết bị FCM, preferences và yêu cầu xóa |
| Phòng | `rooms` | Phòng, chủ phòng, địa chỉ và điều khoản |
| Phòng | `listings` | Tin đăng, duyệt và thời hạn hiển thị |
| Phòng | `room_amenities` | Liên kết phòng–tiện ích; giữ khóa ngoại |
| Phòng | `catalog_items` | Tiện ích, phí tin đăng và phòng đã lưu |
| Phòng | `media` | Metadata ảnh; file nằm trong MinIO |
| Giao dịch | `rental_records` | Booking, xem phòng, thanh toán, hoàn tiền, tranh chấp và lịch sử |
| Chat | `conversations` | Hai thành viên, sequence và trạng thái đã đọc của từng người |
| Chat | `messages` | Tin nhắn, sequence và mã chống gửi trùng |
| Hoạt động | `activity_records` | Thông báo, hàng đợi FCM, audit, idempotency, review và report |
| Kỹ thuật | `flyway_schema_history` | Phiên bản và checksum migration; không sửa tay |

Không gộp bảng nối vai trò/tiện ích vào JSON: cần giữ liên kết nhiều–nhiều và khóa ngoại. Không gộp tin nhắn vào hội thoại: lịch sử cần phân trang, chống trùng và tăng độc lập. `read_markers` đã bỏ; hợp đồng chat chỉ có hai thành viên nên bốn cột sequence/thời gian trong `conversations` biểu diễn trực tiếp trạng thái này.

## Cột chính và chi tiết JSON

| Bảng chung | V20 | V21 | Chi tiết chuyển vào `details` |
| --- | ---: | ---: | --- |
| `account_records` | 31 | 24 | Tên thiết bị, lựa chọn kênh thông báo, lý do/kết quả xóa tài khoản |
| `catalog_items` | 15 | 13 | Icon, đơn vị tính và ghi chú phí; `sort_order` vẫn là cột để sắp xếp |
| `rental_records` | 82 | 65 | Ghi chú, mô tả, lý do, thời gian lịch sử và kết quả phụ |
| `activity_records` | 48 | 34 | Nội dung thông báo, review/report, audit và response cần replay |

Tổng số cột **283 → 243**. Số cột `conversations` tăng 11→15 nhưng bỏ toàn bộ bảng `read_markers` 4 cột, nên không tăng tổng cột vì chat.

ID, version, khóa ngoại, unique, trạng thái, số tiền, rating, token, trường lọc/sắp xếp và thời điểm dùng cho job vẫn là cột. Không đưa quan hệ, tiền hoặc khóa chống trùng vào JSON. Các cột `*_kind` vẫn bảo vệ FK không trỏ nhầm loại bản ghi trong bảng chung.

Ví dụ một notification:

```json
{"schemaVersion":1,"title":"Lịch xem phòng đã xác nhận","body":"Hẹn bạn lúc 9 giờ."}
```

Mỗi loại có chi tiết JSON dùng lớp Java `*Details` riêng trong `common/persistence/details`, không dùng `Map<String,Object>` chung. Getter/setter nghiệp vụ giữ tên cũ; JSON nội bộ không thêm trường vào response của FE. MySQL kiểm tra phiên bản, kiểu, trường bắt buộc, độ dài VARCHAR cũ và từ chối key không khai báo bằng `JSON_SCHEMA_VALID` + `CHECK`. Tham khảo [MySQL 8.0 — JSON Schema validation](https://dev.mysql.com/doc/refman/8.0/en/json-validation-functions.html).

Trường mới cần thay cả lớp Details và schema kiểm tra bằng migration mới. Trường trở thành điều kiện lọc/sắp xếp thường xuyên cần được đưa lại thành cột có index; không quét JSON để thay cho query/index hiện có.

## Tra cứu nhanh trong Workbench

Refresh schema `roomly_local80`. Không import DDL đè database đang chạy. Mở [inspect_database.sql](../Infra/mysql80/inspect_database.sql) hoặc dùng:

```sql
SELECT id, room_id, tenant_id, host_id, booking_status, rent_vnd, deposit_vnd
FROM rental_records WHERE record_type='BOOKING' ORDER BY id DESC LIMIT 20;

SELECT id, notification_type, is_read,
       details->>'$.title' AS title, details->>'$.body' AS body
FROM activity_records WHERE record_type='NOTIFICATION' ORDER BY id DESC LIMIT 20;

SELECT id, tenant_id, host_id, sequence, tenant_read_sequence, host_read_sequence
FROM conversations ORDER BY id DESC LIMIT 20;
```

## Nâng cấp và kiểm chứng

V1–V20 giữ checksum. V21 thêm `details`, chuyển dữ liệu theo `record_type`, đối chiếu từng giá trị trước khi bỏ cột cũ. Cursors đã đọc được kiểm tra thành viên/giới hạn sequence, sao chép và đối chiếu trước khi bỏ bảng. Giữ nguyên ID, version, liên kết, sequence, thời gian và identity counter.

Phải dừng ứng dụng ghi và backup đầy đủ trước nâng cấp. Native command `python -B ./Infra/mysql80/local_mysql.py streamline` chỉ nhận V20→V21 đã có backup/checksum và đúng JAR/migration qua kiểm thử MySQL; không clean/reset. DDL MySQL không rollback toàn bộ, nên nếu bị ngắt phải kiểm tra trạng thái và backup trước phục hồi.

V19 là bước cũ V18→V19 chỉ nhận database chưa có dữ liệu nghiệp vụ; V20/V21 hỗ trợ dữ liệu ở đúng phiên bản đầu vào. Không dùng các bước này để reset database V18 đã có người dùng.

Kết quả thực thi, test, DDL và backup hiện hành nằm trong [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md). Chỉ số cấu trúc trong file này mô tả mục tiêu V21; trạng thái PASS lấy từ báo cáo nghiệm thu.


**Nghiệm thu V21 — 11/10/2026 19:23 VN:** Đã áp dụng vào `roomly_local80`, 13 bảng/21 migration, 243 cột, health UP. 278 test H2/MySQL 8.0.45 đạt, 0 failure/error/skipped; 22 test công cụ native và 14 test đóng gói đạt. Test migration đối chiếu từng trường JSON, các cột quan hệ, cursors, Unicode/JSON/binary, ID/version và identity counters của database V20 có dữ liệu giả. Test cập nhật chỉ JSON xác nhận dữ liệu/version được lưu; JSON payment giữ đúng cờ `isTest=false`. Database thật giữ số hàng ở bảng còn lại; read markers chuyển vào conversation. 81 paths/components OpenAPI, 165 file Android, 17 controller, 52 DTO, 31 service ngoài ChatService, application.properties, openapi.yaml và V1–V20 giữ nguyên byte so với backup trước V21.

Bằng chứng V21: `backend\target\local-mysql80\schema21-tests-20261011T122142-77d83a.json` và `backend\target\local-mysql80\schema21-runtime-20261011T122316-28f12e.json`. Backup trước nâng cấp: `Infra\mysql80\.local\before-schema21-20261011T104634-dfb970`; snapshot hoàn tất ngoài build: `Infra/mysql80/.local/schema21-completed-*/`. DDL mới: `backend\target\local-mysql80\schema-20261011T122251-c25224.sql`. Bản Docker/VPS chứa V21 chưa được build/kiểm thử; mail/FCM/MinIO và E2E điện thoại không được nghiệm thu lại trong đợt schema này.
