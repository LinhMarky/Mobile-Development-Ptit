-- Read-only queries for MySQL Workbench 8.0 CE.
-- Connection: Standard TCP/IP, 127.0.0.1:3306, schema roomly_local80.
USE roomly_local80;

SELECT VERSION() AS mysql_version, DATABASE() AS current_database,
       CURRENT_USER() AS authenticated_account, @@port AS mysql_port;

SELECT version, description, type, success
FROM flyway_schema_history
ORDER BY installed_rank;

SELECT t.table_name, COUNT(c.column_name) AS columns_in_table, t.table_comment
FROM information_schema.tables t
JOIN information_schema.columns c
  ON c.table_schema=t.table_schema AND c.table_name=t.table_name
WHERE t.table_schema = DATABASE() AND t.table_type='BASE TABLE'
GROUP BY t.table_name, t.table_comment
ORDER BY t.table_name;

-- V21: 12 application tables + Flyway = 13 base tables, no compatibility views.
SELECT COUNT(*) AS physical_tables, 13 AS expected_tables
FROM information_schema.tables
WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE';

-- Concrete entity types sharing physical storage.
SELECT 'account_records' AS physical_table, record_type, COUNT(*) AS records
FROM account_records GROUP BY record_type
UNION ALL
SELECT 'catalog_items', record_type, COUNT(*) FROM catalog_items GROUP BY record_type
UNION ALL
SELECT 'rental_records', record_type, COUNT(*) FROM rental_records GROUP BY record_type
UNION ALL
SELECT 'activity_records', record_type, COUNT(*) FROM activity_records GROUP BY record_type;

-- V21: primary columns and individual JSON properties, rather than SELECT *.
SELECT id, user_id, installation_id, expires_at
FROM account_records WHERE record_type='REFRESH_TOKEN'
ORDER BY id DESC LIMIT 20;

SELECT id, room_id, tenant_id, host_id, booking_status, created_at
FROM rental_records WHERE record_type='BOOKING'
ORDER BY id DESC LIMIT 20;

SELECT id, notification_type, details->>'$.title' AS title, is_read, created_at
FROM activity_records WHERE record_type='NOTIFICATION'
ORDER BY id DESC LIMIT 20;

SELECT table_name, column_name, referenced_table_name, referenced_column_name
FROM information_schema.key_column_usage
WHERE table_schema = DATABASE() AND referenced_table_name IS NOT NULL
ORDER BY table_name, ordinal_position;

SELECT id, tenant_id, host_id, sequence, tenant_read_sequence, host_read_sequence
FROM conversations ORDER BY id DESC LIMIT 20;
