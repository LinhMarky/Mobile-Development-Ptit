import org.flywaydb.core.Flyway;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.DriverManager;
import java.time.Instant;
import java.util.LinkedHashMap;

/** Uses the backend's existing Flyway library and migrations. Never clean/baseline. */
public final class LocalMySqlSchema {
    public static void main(String[] args) {
        try {
            if (args.length != 3 || !("migrate".equals(args[0]) || "check".equals(args[0]) || "compact".equals(args[0]) || "simplify".equals(args[0]) || "streamline".equals(args[0]))) {
                throw new IllegalArgumentException("Expected mode, migration directory, new report path");
            }
            String password = System.getenv("ROOMLY_LOCAL_DB_PASSWORD");
            String port = System.getenv("ROOMLY_LOCAL_DB_PORT");
            if (password == null || password.isBlank() || port == null || !port.matches("[0-9]{1,5}")) {
                throw new IllegalStateException("Missing local configuration");
            }
            String url = "jdbc:mysql://127.0.0.1:" + port +
                    "/roomly_local80?sslMode=PREFERRED&serverTimezone=UTC&allowPublicKeyRetrieval=true";
            String version;
            int tables;
            int history;
            try (var connection = DriverManager.getConnection(url, "roomly_local80", password);
                 var sql = connection.createStatement()) {
                try (var rs = sql.executeQuery("SELECT VERSION(), DATABASE(), @@port")) {
                    rs.next();
                    version = rs.getString(1);
                    if (!version.matches("8\\.0\\.\\d+.*") || !"roomly_local80".equals(rs.getString(2)) ||
                            rs.getInt(3) != Integer.parseInt(port)) {
                        throw new IllegalStateException("Wrong server/schema");
                    }
                }
                try (var rs = sql.executeQuery("SELECT COUNT(*), COALESCE(SUM(table_name='flyway_schema_history'),0) " +
                        "FROM information_schema.tables WHERE table_schema=DATABASE()")) {
                    rs.next();
                    tables = rs.getInt(1);
                    history = rs.getInt(2);
                }
            }
            if (tables > 0 && history == 0) {
                throw new IllegalStateException("Nonempty schema without Flyway history");
            }
            var flyway = Flyway.configure().dataSource(url, "roomly_local80", password)
                    .locations("filesystem:" + Path.of(args[1]).toAbsolutePath().toString().replace('\\', '/'))
                    .cleanDisabled(true).baselineOnMigrate(false).validateOnMigrate(true).load();
            if ("compact".equals(args[0])) {
                var before = flyway.info();
                var pending = before.pending();
                boolean alreadyCompact = tables == 14 && pending.length == 0 && before.current() != null
                        && "19".equals(before.current().getVersion().toString());
                boolean expectedUpgrade = tables == 37 && before.current() != null
                        && "18".equals(before.current().getVersion().toString()) && pending.length == 1
                        && "19".equals(pending[0].getVersion().toString());
                if (!alreadyCompact && !expectedUpgrade) {
                    throw new IllegalStateException("Compact mode only accepts the reviewed V18 to V19 upgrade");
                }
                if (expectedUpgrade) flyway.migrate();
            } else if ("simplify".equals(args[0])) {
                var before = flyway.info();
                var pending = before.pending();
                boolean alreadySimplified = tables == 14 && pending.length == 0 && before.current() != null
                        && "20".equals(before.current().getVersion().toString());
                boolean expectedUpgrade = tables == 14 && before.current() != null
                        && "19".equals(before.current().getVersion().toString()) && pending.length == 1
                        && "20".equals(pending[0].getVersion().toString());
                if (!alreadySimplified && !expectedUpgrade) {
                    throw new IllegalStateException("Simplify mode only accepts the reviewed V19 to V20 upgrade");
                }
                if (expectedUpgrade) {
                    try (var connection = DriverManager.getConnection(url, "roomly_local80", password);
                         var sql = connection.createStatement();
                         var rs = sql.executeQuery("SELECT COUNT(*) FROM information_schema.processlist " +
                                 "WHERE ID <> CONNECTION_ID() AND DB='roomly_local80' AND USER='roomly_local80'")) {
                        rs.next();
                        if (rs.getInt(1) > 0) throw new IllegalStateException("Stop application writers before upgrading");
                    }
                    flyway.migrate();
                }
            } else if ("streamline".equals(args[0])) {
                var before = flyway.info();
                var pending = before.pending();
                boolean alreadyApplied = tables == 13 && pending.length == 0 && before.current() != null
                        && "21".equals(before.current().getVersion().toString());
                boolean expectedUpgrade = tables == 14 && before.current() != null
                        && "20".equals(before.current().getVersion().toString()) && pending.length == 1
                        && "21".equals(pending[0].getVersion().toString());
                if (!alreadyApplied && !expectedUpgrade)
                    throw new IllegalStateException("Streamline mode only accepts the reviewed V20 to V21 upgrade");
                if (expectedUpgrade) {
                    try (var connection = DriverManager.getConnection(url, "roomly_local80", password);
                         var sql = connection.createStatement();
                         var rs = sql.executeQuery("SELECT COUNT(*) FROM information_schema.processlist " +
                                 "WHERE ID <> CONNECTION_ID() AND DB='roomly_local80' AND USER='roomly_local80'")) {
                        rs.next();
                        if (rs.getInt(1) > 0) throw new IllegalStateException("Stop application writers before upgrading");
                    }
                    flyway.migrate();
                }
            } else if ("migrate".equals(args[0])) {
                // Applying upgrades to existing data needs a separate backup/review.
                if (tables > 0 && flyway.info().pending().length > 0) {
                    throw new IllegalStateException("Existing schema needs a reviewed migration");
                }
                flyway.migrate();
            }
            flyway.validate();
            var info = flyway.info();
            if (info.pending().length != 0 || info.current() == null) {
                throw new IllegalStateException("Pending schema migrations");
            }
            var report = new LinkedHashMap<String, Object>();
            report.put("completed_at_utc", Instant.now().toString());
            report.put("mysql_version", version);
            report.put("schema", "roomly_local80");
            report.put("migration_version", info.current().getVersion().toString());
            report.put("applied_migrations", info.applied().length);
            report.put("pending_migrations", info.pending().length);
            report.put("clean_disabled", true);
            report.put("baseline_on_migrate", false);
            try (var connection = DriverManager.getConnection(url, "roomly_local80", password);
                 var sql = connection.createStatement();
                 var rs = sql.executeQuery("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type='BASE TABLE'")) {
                rs.next(); report.put("physical_tables", rs.getInt(1));
                int migrationVersion = Integer.parseInt(info.current().getVersion().toString());
                int expectedTables = migrationVersion >= 21 ? 13 : 14;
                if (migrationVersion >= 19 && rs.getInt(1) != expectedTables) {
                    throw new IllegalStateException("Unexpected physical table count for the current migration");
                }
            }
            var columnCounts = new LinkedHashMap<String, Integer>();
            try (var connection = DriverManager.getConnection(url, "roomly_local80", password);
                 var sql = connection.createStatement();
                 var rs = sql.executeQuery("SELECT table_name,COUNT(*) FROM information_schema.columns " +
                         "WHERE table_schema=DATABASE() GROUP BY table_name ORDER BY table_name")) {
                while (rs.next()) columnCounts.put(rs.getString(1), rs.getInt(2));
            }
            report.put("columns_by_table", columnCounts);
            report.put("pass", true);
            Files.writeString(Path.of(args[2]),
                    new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(report),
                    java.nio.file.StandardOpenOption.CREATE_NEW);
            System.out.println("PASS: MySQL " + version + ", roomly_local80, Flyway " +
                    info.current().getVersion() + "; other databases untouched.");
        } catch (Exception error) {
            System.err.println("Schema operation failed. No database clean/reset attempted; inspect schema state before retry. Raw SQL error omitted.");
            System.exit(1);
        }
    }
}
