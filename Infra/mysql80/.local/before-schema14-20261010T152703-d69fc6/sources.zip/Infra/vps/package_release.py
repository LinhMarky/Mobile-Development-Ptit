"""Package existing Linux AMD64 images and an explicit VPS file allowlist locally.

This does not build, pull, push, start, or deploy anything. The output directory
must be new. Credentials, application sources and data backups are not copied.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess


# Do not replace this list with a directory walk or extension glob. Even a .py
# or .md file outside this list may be a private local helper or saved result.
RELEASE_FILES = (
    "Infra/vps/.env.example",
    "Infra/vps/README.md",
    "Infra/vps/backup_restore.py",
    "Infra/vps/check_public.py",
    "Infra/vps/check_runtime.py",
    "Infra/vps/check_services.py",
    "Infra/vps/check_firebase.py",
    "Infra/vps/compose_config.py",
    "Infra/vps/configure_smtp.py",
    "Infra/vps/init_env.py",
    "Infra/vps/package_release.py",
    "Infra/vps/render_proxy.py",
    "Infra/vps/requirements-firebase.txt",
    "Infra/vps/stack.py",
    "Infra/vps/test_backup_restore.py",
    "Infra/vps/test_configuration.py",
    "Infra/vps/test_check_firebase.py",
    "Infra/vps/test_email_flow.py",
    "Infra/vps/test_package_release.py",
    "Infra/vps/test_persistence.py",
    "Infra/vps/test_proxy_integration.py",
    "Infra/vps/verify_restored_data.py",
    "Infra/vps/compose.yaml",
    "Infra/vps/compose.demo.yaml",
    "Infra/vps/compose.prod.yaml",
    "Infra/vps/compose.proxy.yaml",
    "Infra/vps/compose.smtp.yaml",
    "Infra/vps/nginx/renew-nginx.sh",
    "Infra/compose.firebase.yaml",
    "Infra/README.md",
    "Infra/minio/Dockerfile",
    "Infra/minio/README.md",
    "backend/Dockerfile",
    "backend/pom.xml",
    "Docs - contract/00_README.md",
    "Docs - contract/ADMIN_NOTIFICATIONS.md",
    "Docs - contract/BACKUP_RESTORE_09_10_2026.md",
    "Docs - contract/BE_SPEC.md",
    "Docs - contract/CHANGELOG.md",
    "Docs - contract/CHAT.md",
    "Docs - contract/CONTRACT_GAPS.md",
    "Docs - contract/FE_BACKEND_HANDOFF_08_10_2026.md",
    "Docs - contract/FE_SPEC.md",
    "Docs - contract/FIREBASE_SETUP.md",
    "Docs - contract/GLOBAL_RESPONSE_WRAPPER.md",
    "Docs - contract/IMPLEMENTATION_STATUS.md",
    "Docs - contract/MAIL_REAL_CHECK_09_10_2026.md",
    "Docs - contract/openapi.yaml",
    "Docs - contract/PROJECT_CONTRACT.md",
    "Docs - contract/TEST_PLAN.md",
    "Docs - contract/VPS_HTTPS_SMTP_FCM_08_10_2026.md",
)
OPTIONAL_FILES = ("backend/.dockerignore",)
DATA_IMAGES = (("mysql", "mysql:8.4"), ("mailpit", "axllent/mailpit:v1.31.3"))
PROTECTED_DIRECTORIES = {".git", ".agents", ".codex", ".aws"}
IMAGE_METADATA_FORMAT = (
    '{"id":{{json .Id}},"os":{{json .Os}},'
    '"architecture":{{json .Architecture}}}'
)
# This bundle supports amd64 only. Older Docker image-inspect responses omit
# Variant entirely; referring to .Variant makes the Go template fail there.


class ReleaseError(ValueError):
    """An actionable packaging failure whose message contains no Docker output."""


def validate_image_ref(reference: str) -> tuple[str, str]:
    """Accept repository:version tags, never IDs, digests, latest, or CLI flags."""
    repository, separator, tag = reference.rpartition(":")
    if (not separator or not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}", tag)
            or tag.lower() == "latest" or repository == "sha256"):
        raise ReleaseError("Images require an explicit versioned repository:tag; latest and digests are rejected")
    components = repository.split("/")
    component_pattern = r"[a-z0-9]+(?:(?:[._]|__|-+)[a-z0-9]+)*"
    if len(components) > 1 and ":" in components[0]:
        registry, _, port = components.pop(0).rpartition(":")
        if (not re.fullmatch(r"[a-z0-9]+(?:[.-][a-z0-9]+)*", registry)
                or not port.isascii() or not port.isdigit() or not 1 <= int(port) <= 65535):
            raise ReleaseError("Invalid image registry or port")
    if not components or any(not re.fullmatch(component_pattern, part) for part in components):
        raise ReleaseError("Invalid image repository; use a lowercase Docker repository name")
    return repository, tag


def safe_absolute_path(path: Path) -> Path:
    """Reject links/junctions before resolving a source or output path."""
    if ".." in path.parts:
        raise ReleaseError("Paths containing '..' are rejected; provide a direct path")
    absolute = path.absolute()
    for component in (*reversed(absolute.parents), absolute):
        if component.is_symlink() or getattr(component, "is_junction", lambda: False)():
            raise ReleaseError("Symlinks and directory junctions are not allowed in release paths")
    return absolute.resolve(strict=False)


def selected_sources(workspace: Path) -> list[tuple[str, Path]]:
    selected = []
    for relative in (*RELEASE_FILES, *OPTIONAL_FILES):
        parts = PurePosixPath(relative)
        if parts.is_absolute() or ".." in parts.parts or "\\" in relative:
            raise ReleaseError("The release allowlist contains an unsafe path")
        source = safe_absolute_path(workspace / relative)
        if not source.is_relative_to(workspace):
            raise ReleaseError("A release source escapes the workspace")
        if not source.exists() and relative in OPTIONAL_FILES:
            continue
        if not source.is_file():
            raise ReleaseError(f"Required release file missing: {relative}")
        if not stat.S_ISREG(source.stat().st_mode):
            raise ReleaseError(f"Release source must be a regular file: {relative}")
        selected.append((relative, source))
    return selected


class DockerImages:
    """Only read selected image metadata and save existing image tags."""

    def __init__(self, runner=None):
        self.runner = runner or subprocess.run

    def run(self, arguments: list[str], failure: str) -> str:
        try:
            result = self.runner(
                ["docker", "image", *arguments], capture_output=True, text=True,
                encoding="utf-8", errors="replace", check=False,
            )
        except (OSError, subprocess.SubprocessError):
            raise ReleaseError(failure) from None
        if result.returncode:
            # Docker errors/configuration can include secrets. Never relay output
            # or the exception string; both streams remain captured internally.
            raise ReleaseError(failure)
        return result.stdout

    def metadata(self, references: list[tuple[str, str]]) -> list[dict]:
        listing = self.run(["ls", "--no-trunc", "--format", "{{json .}}"],
                           "Cannot list local Docker images; ensure Docker is running")
        try:
            available = {}
            for line in listing.splitlines():
                row = json.loads(line)
                available[f"{row['Repository']}:{row['Tag']}"] = row["ID"]
        except (ValueError, KeyError, TypeError):
            raise ReleaseError("Docker returned invalid local image metadata") from None
        images = []
        for role, reference in references:
            if reference not in available:
                raise ReleaseError(f"Required image is not available locally: {reference}; this tool never pulls images")
            output = self.run(["inspect", "--format", IMAGE_METADATA_FORMAT, reference],
                              f"Cannot read selected image metadata: {reference}")
            try:
                metadata = json.loads(output)
                image_id = metadata["id"]
                operating_system = metadata["os"]
                architecture = metadata["architecture"]
                variant = metadata.get("variant") or ""
                if (not re.fullmatch(r"sha256:[a-f0-9]{64}", image_id)
                        or image_id != available[reference]
                        or not isinstance(variant, str)
                        or not re.fullmatch(r"[A-Za-z0-9_.-]*", variant)):
                    raise ValueError
            except (ValueError, KeyError, TypeError):
                raise ReleaseError(f"Invalid or changed image metadata: {reference}") from None
            if operating_system != "linux" or architecture != "amd64":
                raise ReleaseError(f"Image must target linux/amd64: {reference}")
            images.append({"role": role, "reference": reference, "id": image_id,
                           "os": operating_system, "architecture": architecture, "variant": variant})
        return images

    def save(self, destination: Path, references: list[str]) -> None:
        self.run(["save", "--output", str(destination), *references],
                 "Cannot save local images; incomplete output may remain; retry with a new output directory")


def file_record(path: Path, output: Path) -> dict:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            size += len(block)
            digest.update(block)
    return {"path": path.relative_to(output).as_posix(), "size_bytes": size, "sha256": digest.hexdigest()}


def create_release(workspace: Path, output: Path, backend_image: str, minio_image: str,
                   *, include_data_images: bool = False, runner=None) -> dict:
    workspace = safe_absolute_path(workspace)
    output = safe_absolute_path(output)
    if any(part.casefold() in PROTECTED_DIRECTORIES for part in output.parts):
        raise ReleaseError("Output cannot be inside a protected .git/.agents/.codex/.aws directory")
    if output.exists():
        raise ReleaseError("Output already exists; choose a new directory; nothing was overwritten")
    backend_repository, backend_tag = validate_image_ref(backend_image)
    validate_image_ref(minio_image)
    if backend_image == minio_image:
        raise ReleaseError("Backend and MinIO must use separate image references")
    references = [("backend", backend_image), ("minio", minio_image)]
    if include_data_images:
        references.extend(DATA_IMAGES)
    sources = selected_sources(workspace)
    docker = DockerImages(runner)
    images = docker.metadata(references)
    try:
        # Reserve the exact requested path exclusively, including on Windows.
        output.mkdir(parents=True, exist_ok=False)
        files = []
        for relative, source in sources:
            safe_absolute_path(source)
            destination = output / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            safe_absolute_path(destination)
            with source.open("rb") as source_stream, destination.open("xb") as destination_stream:
                shutil.copyfileobj(source_stream, destination_stream)
            destination.chmod(stat.S_IMODE(source.stat().st_mode))
            files.append(file_record(destination, output))
        archive = output / "images.tar"
        docker.save(archive, [reference for _, reference in references])
        safe_absolute_path(archive)
        if not archive.is_file() or not archive.stat().st_size:
            raise ReleaseError("Docker did not create a nonempty image archive; incomplete output may remain")
        # Saving must use tags, so detect a tag changed concurrently with the
        # export before declaring the bundle complete or recording stale IDs.
        if docker.metadata(references) != images:
            raise ReleaseError("Selected image tags changed during packaging; incomplete output remains; retry with a new directory")
        files.append(file_record(archive, output))
        manifest = {
            "schema_version": 1,
            "created_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
            "target_platform": "linux/amd64",
            "image_archive": "images.tar",
            "images": images,
            "compose_image_settings": {"BACKEND_IMAGE": backend_repository, "BACKEND_TAG": backend_tag,
                                       "MINIO_IMAGE": minio_image},
            "scope": {
                "runtime_images_provided": True,
                "data_images_included": include_data_images,
                "files": "Explicit deployment and documentation allowlist only",
                "backend_context": "Dockerfile/pom.xml and optional .dockerignore only; no application source; cannot rebuild",
                "credentials_and_private_state": "Excluded; configure separately on the target",
                "database_and_object_backups": "Excluded; use the separate backup/restore procedure",
                "deployment_performed": False,
            },
            # manifest.json excludes its own hash; every payload file is listed.
            "files": sorted(files, key=lambda item: item["path"]),
        }
        with (output / "manifest.json").open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(manifest, stream, indent=2, ensure_ascii=False)
            stream.write("\n")
    except OSError:
        raise ReleaseError("Cannot create the bundle; nothing was overwritten; incomplete output may remain") from None
    return manifest


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="New output directory; existing paths are rejected")
    parser.add_argument("--backend-image", required=True, help="Already built/verified backend repository:version")
    parser.add_argument("--minio-image", required=True, help="Already built/verified MinIO repository:version")
    parser.add_argument("--include-data-images", action="store_true",
                        help="Also save existing mysql:8.4 and axllent/mailpit:v1.31.3 for an offline target")
    args = parser.parse_args(argv)
    try:
        manifest = create_release(Path(__file__).resolve().parents[2], args.output,
                                  args.backend_image, args.minio_image,
                                  include_data_images=args.include_data_images)
    except ReleaseError as error:
        parser.exit(1, f"Packaging failed: {error}\n")
    except OSError:
        parser.exit(1, "Packaging failed: Cannot read release inputs or access the output directory\n")
    print(f"Created release bundle: {args.output}")
    print(f"Payload: {len(manifest['files'])} files, {len(manifest['images'])} linux/amd64 images; manifest.json contains SHA-256 hashes.")


if __name__ == "__main__":
    main()
