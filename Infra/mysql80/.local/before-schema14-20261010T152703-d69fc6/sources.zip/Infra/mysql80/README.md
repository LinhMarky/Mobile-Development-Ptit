# MySQL 8.0 cài trực tiếp trên máy và Workbench CE

Bộ này tạo database riêng **roomly_local80** trên MySQL Server 8.0, dùng đúng 18 migration trong backend. Không sinh lại Entity/Repository, không sửa application.properties hoặc profile Docker/VPS. Workbench CE là công cụ mở database; Spring Boot kết nối tới MySQL Server.

Đã kiểm chứng ngày 10/10/2026: MySQL Community Server **8.0.45**, dịch vụ **MySQL80**, cổng **3306**; đăng nhập bằng tài khoản ứng dụng `roomly_local80@127.0.0.1` thành công. Schema có **37 bảng** (bao gồm `flyway_schema_history`), **58 khóa ngoại**, **18/18 migration** thành công. Backend khởi động với Hibernate `validate`; health `UP`, Swagger/OpenAPI và API tìm phòng đều HTTP 200. Global response vẫn là `statusCode`, `message`, `data`.

Bằng chứng: `backend/target/local-mysql80/runtime-verification-20261010T151926-11fa3a.json`. So sánh với bản sao lưu xác nhận **488 tệp nguồn có trước bước MySQL không đổi**. Build backend đạt 211 test thực thi, 55 test MySQL opt-in được bỏ qua; 11 test an toàn của công cụ đạt. Chưa kiểm chứng MinIO, email hoặc push trên tiến trình native này.

## 1. Tạo database bằng mật khẩu nhập ẩn

Từ thư mục gốc D:/BACKEND/Mobile, mở PowerShell:

~~~powershell
powershell -NoProfile -ExecutionPolicy Bypass -File ./Infra/mysql80/Setup-LocalMySQL80.ps1
~~~

Nhập mật khẩu MySQL root ngay trong cửa sổ đó. Không gửi mật khẩu vào chat. Mật khẩu không hiện khi gõ.

Setup chỉ tạo schema/user mới khi cả hai chưa tồn tại; dừng nếu trùng tên. Backend dùng user roomly_local80 chỉ có quyền trong schema tương ứng. Mật khẩu root không lưu; credential ứng dụng ngẫu nhiên được giữ tại Infra/mysql80/.local/connection-private.json, thư mục riêng theo tài khoản Windows đã chạy setup và đã Git ignore. Cấu hình nằm ngoài backend/target để `mvn clean` không xóa mất. Chạy setup và backend bằng cùng tài khoản Windows; lỗi quyền truy cập sẽ dừng trước khi thao tác database.

Nếu mất config nhưng database đã tồn tại, không xóa database/user để chạy lại. Cần kiểm tra kết nối và khôi phục credential riêng.

Setup yêu cầu Python, MySQL client và JDK17. JAR backend phải được build trước:

~~~powershell
cd backend
$env:JAVA_HOME = 'C:/Program Files/Java/jdk-17'
./mvnw.cmd -o -B -ntp package
~~~

Không cần build lại nếu JAR hiện tại đã có và khớp code. Script migrate dùng thư viện Flyway/MySQL/Jackson từ chính JAR đó, SQL migration từ source hiện tại.

## 2. Mở trên MySQL Workbench 8.0 CE

Tạo connection mới bằng dấu +:

| Trường | Giá trị |
| --- | --- |
| Connection Name | Roomly Local MySQL80 |
| Connection Method | Standard (TCP/IP) |
| Hostname | 127.0.0.1 |
| Port | 3306 |
| Username | root để kiểm tra bằng mật khẩu bạn đã biết |
| Default Schema | roomly_local80 |

Chọn Test Connection, nhập mật khẩu trên máy. Sau khi setup PASS, refresh Schemas, mở roomly_local80 → Tables. Mở inspect_database.sql trong thư mục này và chạy các truy vấn chỉ đọc để xem phiên bản, bảng, migration và khóa ngoại.

Backend sử dụng tài khoản riêng roomly_local80; việc mở Workbench bằng root không đổi user backend.

## 3. Schema và SQL được sinh

Flyway tạo bảng theo V1–V18, lưu checksum/version trong flyway_schema_history. Giữ Hibernate ddl-auto=validate; không bật create/update, không clean hoặc baseline một schema cũ.

Sau setup, file schema-*.sql trong backend/target/local-mysql80 là DDL xuất từ database thật, không có dữ liệu người dùng và bỏ DROP TABLE. Dùng để đọc, dựng ER diagram hoặc làm tài liệu; không import lại đè database đang dùng và không coi bản DDL này là lịch sử Flyway.

Các thao tác riêng, từ gốc repository:

~~~powershell
python -B ./Infra/mysql80/local_mysql.py check
python -B ./Infra/mysql80/local_mysql.py export-schema
~~~

Mỗi report/output có tên mới. Migrate từ chối schema có bảng mà không có lịch sử Flyway, hoặc schema đã có dữ liệu cần migration mới. Nâng cấp schema cũ cần quy trình backup/kiểm tra riêng.

## 4. Chạy backend kết nối database này

~~~powershell
python -B ./Infra/mysql80/local_mysql.py run
~~~

Backend local riêng dùng http://127.0.0.1:18091; Swagger /swagger-ui/index.html, health /actuator/health. Profile local-mysql80 chỉ được nạp bằng lệnh trên. Cổng khác 18089 nên không dừng/thay backend Docker. Lệnh từ chối cổng đã có chương trình dùng.

Database mới bắt đầu trống, demo seed/mock payment/FCM/job xóa dữ liệu tắt. Dịch vụ MinIO/SMTP là phần riêng; thiếu chúng thì ảnh/email chưa thể hoạt động. Cấu hình Gmail/Firebase/Docker hiện có được giữ nguyên.

Nếu sau đó chọn backend local này cho điện thoại USB, dùng adb reverse tcp:18091 tcp:18091 và build Roomly với -PROOMLY_API_URL=http://127.0.0.1:18091/api/v1/. Không kết nối app Android trực tiếp tới MySQL.

## 5. Bảo toàn và kiểm chứng

Trước bước MySQL đã lưu bản nguồn tại backend/target/local-mysql80/sources-before-mysql80-*.zip. Công cụ không đổi mật khẩu root, không restart MySQL, không DROP/TRUNCATE database hiện có và không reset volume Docker. Database mới được tạo bằng DDL MySQL nên nếu một bước setup bị ngắt, có thể còn schema/user mới chưa hoàn tất; công cụ dừng để kiểm tra, không tự xóa.

Kiểm thử công cụ không chạm database:

~~~powershell
python -B -m unittest discover -s ./Infra/mysql80 -p test_local_mysql.py -v
~~~

Tham khảo [MySQL: kết nối bằng command options](https://dev.mysql.com/doc/refman/8.0/en/connecting.html), [MySQL: option files](https://dev.mysql.com/doc/refman/8.0/en/option-files.html), [Flyway: MySQL](https://documentation.red-gate.com/flyway/reference/database-driver-reference/mysql).
